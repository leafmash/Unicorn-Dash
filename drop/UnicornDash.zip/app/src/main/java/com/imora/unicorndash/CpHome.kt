package com.imora.unicorndash

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun LevelBadge(level: Int, size: Dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(PrimaryBrush)
            .border(2.dp, Color(0xDDFFFFFF), CircleShape),
        contentAlignment = Alignment.Center
    ) { Tx(level.toString(), size.value * 0.42f) }
}

@Composable
fun ProfileCapsule(s: Snap, modifier: Modifier = Modifier) {
    Glass(modifier.height(54.dp), 18.dp) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(start = 6.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LevelBadge(s.lv, 42.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Tx("PLAYER", 11f, color = Pal.Sun, spacing = 0.5f)
                    Tx("${s.xpCur}/${s.xpNeed} XP", 9.5f, color = Pal.Lilac, weight = FontWeight.Bold, shadow = false)
                }
                Spacer(Modifier.height(5.dp))
                Bar(s.xpCur.toFloat() / s.xpNeed, Modifier.fillMaxWidth(), 7.dp)
            }
        }
    }
}

@Composable
fun StarChip(s: Snap, modifier: Modifier = Modifier) {
    Pill(modifier, 34.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StarIcon(16.dp, true)
            Spacer(Modifier.width(6.dp))
            Tx("${s.stars}/${s.starsMax}", 12f, color = Pal.Sun)
        }
    }
}

@Composable
fun TopStatus(s: Snap, modifier: Modifier = Modifier) {
    Row(
        modifier.height(54.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StarChip(s)
        CoinPill(s.bank, height = 34.dp)
        HeartPill(s.hearts, height = 34.dp)
        RoundBtn(34.dp, onClick = { UiBridge.fire("settings") }) { GearIcon(18.dp) }
        RoundBtn(34.dp, onClick = { UiBridge.fire("mute") }) { SoundIcon(18.dp, s.music || s.sfx) }
    }
}

@Composable
fun MissionsCard(s: Snap, showBest: Boolean, modifier: Modifier = Modifier) {
    Glass(modifier, 18.dp) {
        Column(
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Tx("DAILY MISSIONS", 10.5f, color = Pal.Sun, spacing = 0.5f)
                Tx(T("Day {0} streak", s.streak), 9.5f, color = Pal.Rose, weight = FontWeight.Bold, shadow = false)
            }
            for (m in s.missions) MissionRow(m)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Tx(T("{0} of {1} awards", s.achDone, s.achTotal), 9.5f, color = Color(0xFFA9FFE3), weight = FontWeight.Bold, shadow = false)
                if (showBest) Tx(T("BEST {0}", s.best), 9.5f, color = Pal.Sun, weight = FontWeight.Bold, shadow = false)
            }
        }
    }
}

@Composable
fun RailTile(
    label: String,
    accent: Color,
    badge: Boolean,
    index: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable (Color) -> Unit
) {
    Box(modifier.enter(index)) {
        FaceButton(
            modifier = Modifier.width(70.dp),
            height = 64.dp,
            radius = 18.dp,
            skin = skinOf(Kind.Soft),
            lip = 4.dp,
            onClick = onClick
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                icon(accent)
                Spacer(Modifier.height(3.dp))
                Tx(label, 10f, spacing = 0.4f)
            }
        }
        if (badge) {
            val tr = rememberInfiniteTransition(label = "badge")
            val k = tr.animateFloat(0.85f, 1.2f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "bk")
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 4.dp, y = (-4).dp)
                    .size(15.dp)
                    .graphicsLayer {
                        scaleX = k.value
                        scaleY = k.value
                    }
                    .clip(CircleShape)
                    .background(Color(0xFFFF4F93))
                    .border(2.dp, Color(0xFF2A1670), CircleShape)
            )
        }
    }
}

@Composable
fun DailyCard(s: Snap, short: Boolean, modifier: Modifier = Modifier) {
    val done = s.dailyDone
    val ink = if (done) Color.White else Color(0xFF5A3000)
    Box(modifier.enter(5)) {
        FaceButton(
            modifier = Modifier.fillMaxWidth(),
            height = 54.dp,
            radius = 16.dp,
            skin = skinOf(if (done) Kind.Soft else Kind.Gold),
            lip = 4.dp,
            onClick = { UiBridge.fire("daily") }
        ) {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CalendarIcon(24.dp, if (done) Pal.Mint else ink)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                    Tx(if (short) "DAILY" else "DAILY CHALLENGE", 11f, color = ink, shadow = done, spacing = 0.4f)
                    Tx(
                        s.dailyText,
                        9.5f,
                        color = if (done) Pal.Mint else Color(0xFF7A4500),
                        weight = FontWeight.Bold,
                        shadow = false
                    )
                }
                ArrowIcon(16.dp, false, if (done) Pal.Lilac else ink)
            }
        }
    }
}

@Composable
fun BestCard(best: Int, modifier: Modifier = Modifier) {
    Box(modifier.enter(5)) {
        Glass(Modifier.fillMaxWidth().height(54.dp), 16.dp) {
            Row(
                Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                BoardIcon(22.dp, Pal.Cyan)
                Spacer(Modifier.width(9.dp))
                Tx(T("BEST {0}", best), 14f, color = Pal.Sun)
            }
        }
    }
}
