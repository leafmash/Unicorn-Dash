package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

fun z0f(rd: Double) {
    x.lineWidth = 7.0
    layer(rd * 0.08, 400.0, 1) { px, r1, _ ->
        for (k in 0 until 6) {
            x.strokeStyle = hsl(k * 55.0, 90.0, 68.0, 0.5)
            x.beginPath()
            x.arc(px, G + 20.0, 150.0 + 30.0 * r1 - k * 7.0, PI, PI * 2.0)
            x.stroke()
        }
    }
}

fun z0n(rd: Double) {
    x.fillStyle = Z.near
    wave(rd * 0.2, G - 34.0, 18.0, 70.0, 0.43)
}

fun z0m(rd: Double) {
    x.fillStyle = Z.edge
    x.beginPath()
    layer(rd * 0.45, 80.0, 3) { px, r1, r2 ->
        disc(px, G - 6.0, 12.0 + 8.0 * r1)
        disc(px + 14.0, G - 4.0, 9.0 + 6.0 * r2)
        disc(px - 12.0, G - 4.0, 8.0 + 5.0 * r2)
    }
    x.fill()
}

fun z0g(rd: Double) {
    x.lineWidth = 2.0
    layer(rd, 46.0, 21) { px, r1, r2 ->
        x.strokeStyle = Z.edge
        x.beginPath()
        x.moveTo(px, G + 3.0)
        x.lineTo(px, G - 9.0 - r1 * 7.0)
        x.stroke()
        x.fillStyle = hsl(r2 * 360.0, 90.0, 70.0)
        x.beginPath()
        disc(px, G - 12.0 - r1 * 7.0, 3.4)
        x.fill()
    }
}

fun z1f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 120.0, 1) { px, r1, _ -> dome(px, G, 38.0 + 46.0 * r1, 1.15) }
    x.fill()
    x.fillStyle = rgba(255, 255, 255, 0.6)
    layer(rd * 0.08, 120.0, 1) { px, r1, r2 ->
        x.fillRect(px - 8.0, G - 24.0 - r1 * 30.0, 5.0, 2.0)
        x.fillRect(px + 6.0, G - 40.0 - r2 * 20.0, 2.0, 5.0)
    }
}

fun z1n(rd: Double) {
    x.lineCap = CAP_ROUND
    x.lineWidth = 8.0
    layer(rd * 0.2, 110.0, 2) { px, r1, _ ->
        val h = 46.0 + 44.0 * r1
        x.beginPath()
        x.moveTo(px, G)
        x.lineTo(px, G - h)
        x.arc(px + 9.0, G - h, 9.0, PI, PI * 2.0)
        x.lineTo(px + 18.0, G - h + 8.0)
        x.strokeStyle = hex(0xffffff)
        x.stroke()
        x.setLineDash(5.0, 8.0)
        x.lineCap = CAP_BUTT
        x.strokeStyle = hex(0xff5c93)
        x.stroke()
        x.clearLineDash()
        x.lineCap = CAP_ROUND
    }
}

fun z1m(rd: Double) {
    layer(rd * 0.45, 150.0, 3) { px, r1, r2 ->
        val h = 34.0 + r1 * 18.0
        x.strokeStyle = rgba(255, 255, 255, 0.8)
        x.lineWidth = 3.0
        x.beginPath()
        x.moveTo(px, G)
        x.lineTo(px, G - h)
        x.stroke()
        x.fillStyle = hsl(r2 * 360.0, 85.0, 70.0)
        x.beginPath()
        disc(px, G - h - 8.0, 12.0)
        x.fill()
        x.strokeStyle = rgba(255, 255, 255, 0.85)
        x.lineWidth = 2.0
        x.beginPath()
        x.arc(px, G - h - 8.0, 7.0, 0.0, 4.4)
        x.stroke()
    }
}

fun z1g(rd: Double) {
    val o = rd % 28.0
    x.fillStyle = rgba(255, 255, 255, 0.92)
    x.beginPath()
    var i = -1
    while (i < L / 28.0 + 2.0) {
        val cc = i * 28.0 - o + 14.0
        x.moveTo(cc + 14.0, G)
        x.arc(cc, G, 14.0, 0.0, PI)
        i++
    }
    x.fill()
    layer(rd, 50.0, 22) { px, r1, r2 ->
        x.fillStyle = hsl(r2 * 360.0, 90.0, 65.0)
        x.fillRect(px, G + 30.0 + r1 * 30.0, 6.0, 2.5)
    }
}

fun z2f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 62.0, 1) { px, r1, _ -> pine(px, G, 70.0 + 80.0 * r1, 18.0 + 8.0 * r1) }
    x.fill()
}

fun z2n(rd: Double) {
    x.fillStyle = Z.near
    x.beginPath()
    layer(rd * 0.2, 90.0, 2) { px, r1, _ -> pine(px, G, 50.0 + 50.0 * r1, 16.0) }
    x.fill()
}

fun z2m(rd: Double) {
    layer(rd * 0.45, 300.0, 3) { px, r1, _ ->
        x.fillStyle = rgba(10, 6, 30, 0.9)
        x.beginPath()
        x.rect(px - 14.0, G - 20.0, 28.0, 20.0)
        tri(px, G - 20.0, 16.0, 20.0)
        x.rect(px + 8.0, G - 34.0, 5.0, 12.0)
        x.fill()
        x.halo(px - 4.0, G - 10.0, 9.0, 45.0, 100.0, 70.0, 0.8 + 0.2 * sway(3.0, r1 * 9.0))
    }
}

fun z2g(rd: Double) {
    x.strokeStyle = Z.edge
    x.lineWidth = 1.6
    x.beginPath()
    layer(rd, 22.0, 21) { px, r1, r2 ->
        x.moveTo(px, G + 3.0)
        x.quadraticCurveTo(px + 3.0, G - 5.0 - r1 * 6.0, px + 6.0 * (r2 - 0.5), G - 10.0 - r1 * 8.0)
    }
    x.stroke()
}

fun z3f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 170.0, 1) { px, r1, r2 ->
        val h = 100.0 + 80.0 * r1
        val w = 70.0 + 30.0 * r2
        x.moveTo(px - w, G)
        x.lineTo(px - w * 0.35, G - h * 0.6)
        x.lineTo(px - w * 0.12, G - h * 0.5)
        x.lineTo(px, G - h)
        x.lineTo(px + w * 0.2, G - h * 0.55)
        x.lineTo(px + w * 0.45, G - h * 0.7)
        x.lineTo(px + w, G)
    }
    x.fill()
    x.fillStyle = rgba(255, 255, 255, 0.88)
    x.beginPath()
    layer(rd * 0.08, 170.0, 1) { px, r1, r2 ->
        val h = 100.0 + 80.0 * r1
        val w = 70.0 + 30.0 * r2
        x.moveTo(px - w * 0.3, G - h * 0.72)
        x.lineTo(px, G - h)
        x.lineTo(px + w * 0.25, G - h * 0.7)
        x.lineTo(px + w * 0.1, G - h * 0.62)
        x.lineTo(px - w * 0.05, G - h * 0.7)
        x.lineTo(px - w * 0.18, G - h * 0.62)
    }
    x.fill()
}

fun z3n(rd: Double) {
    x.fillStyle = Z.near
    x.beginPath()
    layer(rd * 0.2, 64.0, 2) { px, r1, r2 ->
        tri(px, G, 40.0 + 60.0 * r1, 8.0 + 5.0 * r2)
        tri(px + 10.0, G, (40.0 + 60.0 * r1) * 0.6, 6.0)
    }
    x.fill()
}

fun z3m(rd: Double) {
    layer(rd * 0.45, 260.0, 3) { px, _, _ ->
        x.fillStyle = hex(0xffffff)
        x.beginPath()
        disc(px, G - 8.0, 9.0)
        disc(px, G - 22.0, 7.0)
        disc(px, G - 33.0, 5.0)
        x.fill()
        x.fillStyle = hex(0xff8a3c)
        x.beginPath()
        tri(px + 7.0, G - 33.0, 3.0, 2.0)
        x.fill()
        x.fillStyle = hex(0x222233)
        x.fillRect(px - 2.5, G - 35.0, 1.6, 1.6)
        x.fillRect(px + 1.0, G - 35.0, 1.6, 1.6)
    }
}

fun z3g(rd: Double) {
    x.fillStyle = hex(0xffffff)
    x.beginPath()
    x.moveTo(0.0, G + 3.0)
    var i = 0.0
    while (i <= L + 10.0) {
        x.lineTo(i, G - 2.0 - 3.0 * sin((i + rd) / 16.0) - 2.0 * sin((i + rd) / 7.0))
        i += 10.0
    }
    x.lineTo(L + 10.0, G + 3.0)
    x.fill()
    x.fillStyle = rgba(180, 230, 255, 0.85)
    x.beginPath()
    layer(rd, 60.0, 22) { px, r1, _ -> tri(px, G + 2.0, 6.0 + 6.0 * r1, 3.0) }
    x.fill()
}

fun z4f(rd: Double) {
    x.fillStyle = Z.far
    wave(rd * 0.08, G - 70.0, 38.0, 120.0, 0.37)
}

fun z4n(rd: Double) {
    x.fillStyle = Z.near
    x.beginPath()
    layer(rd * 0.2, 280.0, 2) { px, r1, _ -> tri(px, G, 70.0 + 50.0 * r1, (70.0 + 50.0 * r1) * 0.9) }
    x.fill()
    x.fillStyle = rgba(0, 0, 0, 0.25)
    x.beginPath()
    layer(rd * 0.2, 280.0, 2) { px, r1, _ ->
        val h = 70.0 + 50.0 * r1
        x.moveTo(px, G - h)
        x.lineTo(px + h * 0.9, G)
        x.lineTo(px, G)
    }
    x.fill()
}

fun z4m(rd: Double) {
    x.fillStyle = rgba(60, 20, 40, 0.8)
    x.beginPath()
    layer(rd * 0.45, 120.0, 3) { px, r1, _ ->
        val h = 34.0 + 18.0 * r1
        x.rect(px - 3.5, G - h, 7.0, h)
        x.rect(px - 12.0, G - h * 0.55, 9.0, 4.0)
        x.rect(px - 12.0, G - h * 0.55 - 12.0, 4.0, 16.0)
        x.rect(px + 3.5, G - h * 0.7, 9.0, 4.0)
        x.rect(px + 9.0, G - h * 0.7 - 10.0, 4.0, 14.0)
    }
    x.fill()
}

fun z4g(rd: Double) {
    x.fillStyle = Z.soil
    x.beginPath()
    layer(rd, 90.0, 22) { px, r1, _ -> dome(px, G + 1.0, 22.0 + 10.0 * r1, 0.2) }
    x.fill()
    x.strokeStyle = rgba(255, 255, 255, 0.22)
    x.lineWidth = 2.0
    x.beginPath()
    layer(rd, 56.0, 21) { px, r1, _ ->
        x.moveTo(px, G + 14.0 + r1 * 40.0)
        x.quadraticCurveTo(px + 14.0, G + 10.0 + r1 * 40.0, px + 28.0, G + 14.0 + r1 * 40.0)
    }
    x.stroke()
}

fun z5f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 230.0, 1) { px, r1, _ ->
        val h = 110.0 + 50.0 * r1
        x.moveTo(px - 130.0, G)
        x.lineTo(px - 24.0, G - h)
        x.lineTo(px + 24.0, G - h)
        x.lineTo(px + 130.0, G)
    }
    x.fill()
    x.strokeStyle = hex(0xff7a2a)
    x.lineWidth = 3.0
    x.lineJoin = JOIN_ROUND
    layer(rd * 0.08, 230.0, 1) { px, r1, _ ->
        val h = 110.0 + 50.0 * r1
        x.halo(px, G - h, 44.0, 18.0, 100.0, 55.0, 0.6 + 0.2 * sway(2.0, r1 * 9.0))
        x.beginPath()
        x.moveTo(px - 4.0, G - h)
        x.lineTo(px - 30.0, G - h * 0.5)
        x.lineTo(px - 38.0, G - h * 0.2)
        x.stroke()
    }
}

fun z5n(rd: Double) {
    x.fillStyle = Z.near
    x.beginPath()
    layer(rd * 0.2, 70.0, 2) { px, r1, _ ->
        val h = 30.0 + 50.0 * r1
        x.moveTo(px - 18.0, G)
        x.lineTo(px - 10.0, G - h * 0.6)
        x.lineTo(px - 3.0, G - h)
        x.lineTo(px + 5.0, G - h * 0.7)
        x.lineTo(px + 12.0, G - h * 0.85)
        x.lineTo(px + 20.0, G)
    }
    x.fill()
}

fun z5m(rd: Double) {
    layer(rd * 0.45, 160.0, 3) { px, r1, _ -> x.halo(px, G - 4.0, 26.0 + 10.0 * r1, 18.0, 100.0, 55.0, 0.35 + 0.2 * sway(3.0, r1 * 9.0)) }
}

fun z5g(rd: Double) {
    x.strokeStyle = hex(0xff8a2c)
    x.lineWidth = 2.4
    x.lineJoin = JOIN_ROUND
    x.beginPath()
    layer(rd, 90.0, 21) { px, r1, r2 ->
        x.moveTo(px, G + 6.0)
        x.lineTo(px + 10.0, G + 16.0 + r1 * 10.0)
        x.lineTo(px + 4.0, G + 28.0 + r1 * 10.0)
        x.lineTo(px + 16.0, G + 40.0 + r2 * 8.0)
    }
    x.stroke()
    x.fillStyle = rgba(255, 140, 40, 0.85)
    x.beginPath()
    layer(rd, 40.0, 22) { px, r1, r2 -> tri(px, G + 1.0, 5.0 + 6.0 * abs(sway(6.0, r2 * 20.0)) + r1 * 3.0, 3.5) }
    x.fill()
}

fun z6f(rd: Double) {
    val y0 = -ty - 10.0
    x.fillStyle = Z.far
    x.beginPath()
    x.rect(0.0, y0, L, 14.0)
    layer(rd * 0.08, 64.0, 1) { px, r1, _ ->
        x.moveTo(px - 14.0, y0 + 10.0)
        x.lineTo(px, y0 + 50.0 + 110.0 * r1)
        x.lineTo(px + 14.0, y0 + 10.0)
    }
    x.fill()
}

fun z6n(rd: Double) {
    layer(rd * 0.2, 100.0, 2) { px, r1, r2 ->
        for (k in 0 until 3) {
            x.fillStyle = hsl(Z.hue + k * 25.0, 75.0, 55.0 + k * 7.0, 0.55)
            x.beginPath()
            crys(px + (k - 1) * 14.0, 30.0 + 60.0 * (if (k == 1) r1 else r2 * 0.7), 8.0 + 4.0 * k % 3)
            x.fill()
        }
    }
}

fun z6m(rd: Double) {
    layer(rd * 0.45, 110.0, 3) { px, r1, r2 ->
        val py = G - 70.0 - r1 * 100.0 + sway(1.4, r2 * 9.0) * 6.0
        x.halo(px, py, 12.0, Z.hue + 40.0, 100.0, 75.0, 0.5 + 0.3 * sway(2.0, r1 * 7.0))
        x.fillStyle = rgba(255, 255, 255, 0.85)
        x.beginPath()
        x.moveTo(px, py - 5.0)
        x.lineTo(px + 3.5, py)
        x.lineTo(px, py + 5.0)
        x.lineTo(px - 3.5, py)
        x.fill()
    }
}

fun z6g(rd: Double) {
    x.fillStyle = rgba(200, 170, 255, 0.7)
    x.beginPath()
    layer(rd, 44.0, 21) { px, r1, _ -> tri(px, G + 2.0, 8.0 + 10.0 * r1, 3.5) }
    x.fill()
}

fun z7f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 120.0, 1) { px, r1, r2 ->
        val b = G - 120.0 - r1 * 30.0
        x.rect(px - 7.0, b, 14.0, G - b)
        disc(px, b - 6.0, 40.0 + 10.0 * r2)
        disc(px - 28.0, b + 14.0, 28.0)
        disc(px + 28.0, b + 12.0, 30.0)
    }
    x.fill()
}

fun z7n(rd: Double) {
    layer(rd * 0.2, 110.0, 2) { px, r1, r2 ->
        val h = 30.0 + 24.0 * r1
        x.fillStyle = rgba(255, 250, 235, 0.9)
        x.fillRect(px - 5.0, G - h, 10.0, h)
        x.fillStyle = hsl(340.0 + r2 * 30.0, 75.0, 58.0)
        x.beginPath()
        dome(px, G - h + 4.0, 20.0 + 8.0 * r1, 0.7)
        x.fill()
        x.fillStyle = hex(0xffffff)
        x.beginPath()
        disc(px - 8.0, G - h - 4.0, 3.0)
        disc(px + 6.0, G - h - 8.0, 3.4)
        disc(px + 1.0, G - h - 1.0, 2.2)
        x.fill()
    }
}

fun z7m(rd: Double) {
    val y0 = -ty - 10.0
    x.strokeStyle = Z.edge
    x.fillStyle = Z.edge
    x.lineWidth = 2.0
    layer(rd * 0.45, 80.0, 3) { px, r1, r2 ->
        val len = 40.0 + 90.0 * r1
        val ex = px + sway(1.2, r2 * 9.0) * 10.0
        x.beginPath()
        x.moveTo(px, y0)
        x.quadraticCurveTo(px + sway(1.0, r2 * 9.0) * 8.0, y0 + len * 0.5, ex, y0 + len)
        x.stroke()
        x.beginPath()
        x.ellipse(ex, y0 + len + 3.0, 3.0, 6.0, 0.0, 0.0, 7.0)
        x.fill()
    }
}

fun z7g(rd: Double) {
    x.strokeStyle = Z.edge
    x.lineWidth = 2.0
    x.beginPath()
    layer(rd, 30.0, 21) { px, r1, r2 ->
        x.moveTo(px, G + 3.0)
        x.lineTo(px - 6.0, G - 8.0 - r1 * 6.0)
        x.moveTo(px, G + 3.0)
        x.lineTo(px, G - 12.0 - r1 * 8.0)
        x.moveTo(px, G + 3.0)
        x.lineTo(px + 6.0, G - 8.0 - r2 * 6.0)
    }
    x.stroke()
}

fun z8f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 260.0, 1) { px, r1, _ ->
        val h = 90.0 + 50.0 * r1
        x.rect(px - 18.0, G - h, 36.0, h)
        x.rect(px - 46.0, G - h * 0.65, 24.0, h * 0.65)
        x.rect(px + 22.0, G - h * 0.7, 24.0, h * 0.7)
        for (k in 0 until 3) x.rect(px - 18.0 + k * 14.0, G - h - 6.0, 8.0, 6.0)
        tri(px, G - h - 6.0, 30.0, 20.0)
        tri(px - 34.0, G - h * 0.65, 22.0, 15.0)
        tri(px + 34.0, G - h * 0.7, 22.0, 15.0)
    }
    x.fill()
}

fun z8n(rd: Double) {
    x.fillStyle = Z.near
    x.beginPath()
    layer(rd * 0.2, 90.0, 2) { px, r1, r2 ->
        disc(px, G - 8.0, 26.0 + 10.0 * r1)
        disc(px + 28.0, G - 4.0, 20.0 + 8.0 * r2)
        disc(px - 26.0, G - 2.0, 18.0)
    }
    x.fill()
}

fun z8m(rd: Double) {
    layer(rd * 0.45, 260.0, 3) { px, r1, r2 ->
        val py = 70.0 + r1 * 80.0 + sway(0.8, r2 * 9.0) * 6.0
        x.fillStyle = rgb(150, 120, 170)
        x.beginPath()
        x.moveTo(px - 30.0, py)
        x.lineTo(px + 30.0, py)
        x.lineTo(px, py + 30.0)
        x.fill()
        x.fillStyle = rgb(120, 210, 150)
        x.beginPath()
        oval(px, py, 32.0, 6.0)
        x.fill()
    }
}

fun z8g(rd: Double) {
    x.fillStyle = rgba(255, 255, 255, 0.95)
    x.beginPath()
    layer(rd, 34.0, 21) { px, r1, _ -> disc(px, G + 2.0, 9.0 + 5.0 * r1) }
    x.fill()
}
