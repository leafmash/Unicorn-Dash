package com.imora.unicorndash

import kotlin.math.ceil

private val MINT = hex(0x7dffd4)
private val SUN = hex(0xffe27a)
private val SOFT = hex(0xd9ccff)
private val ROSE = hex(0xffb0cf)
private val TAB_NAMES = arrayOf("UNICORNS", "TRAILS", "HORNS", "PETS", "SKILLS")
private const val CARD_W = 76.0
private const val CARD_GAP = 8.0
private const val PER = 6

fun tabBtn(id: String, text: String, on: Boolean, cx: Double, cy: Double, w: Double, h: Double) {
    uiPush(id, cx - w / 2.0, cy - h / 2.0, w, h)
    pill(cx - w / 2.0, cy - h / 2.0, w, h, h / 2.0)
    if (on) x.fillShader = x.lin(0.0, cy - h / 2.0, 0.0, cy + h / 2.0, PINK_TOP, PURPLE_BOT)
    else x.fillStyle = if (hov == id) rgba(255, 255, 255, 0.2) else rgba(255, 255, 255, 0.1)
    x.fill()
    x.strokeStyle = if (on) rgba(255, 255, 255, 0.8) else rgba(255, 255, 255, 0.3)
    x.lineWidth = 1.4
    x.stroke()
    label(text, 12.0, cx, cy + 1.0, WHITE)
}

private fun drawCardArt(tab: Int, i: Int, bx: Double, y0: Double) {
    val cx = bx + CARD_W / 2.0
    when (tab) {
        0 -> {
            uq.clear()
            uq.x = cx + 4.0
            uq.y = y0 + 102.0
            uq.ang = 0.0
            uq.sq = 1.0
            uq.dk = 0.0
            uq.air = false
            uq.tt = clock + i
            uq.sc = 0.78
            uq.hn = hornSel
            unicorn(uq, i)
        }
        1 -> {
            ribbon(bx + 8.0, bx + CARD_W - 8.0, y0 + 66.0, i, clock)
            sparkle(bx + CARD_W - 14.0, y0 + 40.0, 5.0, i.toDouble())
        }
        3 -> if (PT[i].kind.isNotEmpty()) petDraw(PT[i].kind, cx, y0 + 78.0, 2.3, clock + i, false)
        4 -> skillIcon(SKL[i].k, cx, y0 + 70.0, 2.4)
        else -> {
            x.save()
            x.translate(cx, y0 + 96.0)
            x.scale(3.4, 3.4)
            x.translate(-34.0, 60.0)
            hornShape(i, clock, SK[skin].horn)
            x.restore()
        }
    }
}

fun shopUI() {
    val cx = L / 2.0
    val count = tabCount(shopTab)
    val own = tabOwn(shopTab)
    val sel = tabSel(shopTab)
    val pages = ceil(count.toDouble() / PER).toInt()
    val x0 = cx - (PER * CARD_W + (PER - 1) * CARD_GAP) / 2.0
    veil(0.8)
    title("SHOP", 26.0, cx, 26.0)
    chip(L - MR - 60.0, 26.0, 120.0, 24.0, bank.toString(), SUN, true)
    heartChip(L - MR - 170.0, 26.0, 74.0, 24.0, "x$hearts")
    for (k in 0 until 5) tabBtn("tab$k", TAB_NAMES[k], k == shopTab, cx + (k - 2) * 98.0, 62.0, 92.0, 26.0)
    for (j in 0 until PER) {
        val i = shopPage * PER + j
        if (i >= count) break
        val bx = x0 + j * (CARD_W + CARD_GAP)
        val isSel = i == shopSel
        val kk = "k${shopTab}_$i"
        val k = damp(bsGetOr(kk, 0.0), if (isSel) 1.0 else 0.0, 14.0, fdt)
        bs[kk] = k
        val y0 = 94.0 - 6.0 * k
        val h = 144.0
        val zone = itemZone(shopTab, i)
        val owned = own[i] != 0
        val locked = !owned && zone >= 0
        uiPush("card$i", bx, 94.0, CARD_W, h)
        if (isSel) x.halo(bx + CARD_W / 2.0, y0 + 72.0, 88.0, 300.0, 100.0, 70.0, 0.35)
        pill(bx, y0, CARD_W, h, 16.0)
        x.fillStyle = if (isSel) rgba(255, 255, 255, 0.2) else rgba(255, 255, 255, 0.08)
        x.fill()
        x.strokeStyle = if (i == sel) MINT else if (isSel) rgba(255, 255, 255, 0.8) else rgba(255, 255, 255, 0.25)
        x.lineWidth = if (i == sel) 2.6 else 1.5
        x.stroke()
        fitLabel(itemName(shopTab, i), 12.0, bx + CARD_W / 2.0, y0 + 15.0, WHITE, ALIGN_CENTER, CARD_W - 6.0)
        x.save()
        x.alpha *= if (owned) 1.0 else 0.55
        drawCardArt(shopTab, i, bx, y0)
        x.restore()
        if (locked) {
            pill(bx, y0, CARD_W, h, 16.0)
            x.fillStyle = rgba(10, 5, 35, 0.45)
            x.fill()
            iconLock(bx + CARD_W / 2.0, y0 + 66.0, 11.0)
        }
        val hc = itemHc(shopTab, i)
        if (i == sel) {
            label("EQUIPPED", 10.5, bx + CARD_W / 2.0, y0 + 130.0, MINT)
        } else if (owned) {
            label("OWNED", 11.0, bx + CARD_W / 2.0, y0 + 130.0, hex(0xb8ffe6))
        } else if (zone >= 0) {
            label(ZN[zone].name, 9.5, bx + CARD_W / 2.0, y0 + 130.0, ROSE)
        } else if (hc > 0) {
            heartPath(bx + CARD_W / 2.0 - 16.0, y0 + 130.0, 6.0)
            x.fillStyle = PINK_HEART
            x.fill()
            x.lineWidth = 1.2
            x.strokeStyle = WHITE
            x.stroke()
            label(hc.toString(), 12.0, bx + CARD_W / 2.0 - 6.0, y0 + 131.0, hex(0xffd0e0), ALIGN_LEFT)
        } else {
            iconCoin(bx + CARD_W / 2.0 - 18.0, y0 + 130.0, 6.0)
            label(itemCost(shopTab, i).toString(), 12.0, bx + CARD_W / 2.0 - 8.0, y0 + 131.0, SUN, ALIGN_LEFT)
        }
    }
    val curZone = itemZone(shopTab, shopSel)
    val curOwned = own[shopSel] != 0
    val lockedSel = !curOwned && curZone >= 0
    val curHc = itemHc(shopTab, shopSel)
    fitLabel(itemName(shopTab, shopSel), 15.0, cx, 258.0, WHITE, ALIGN_CENTER, L - 80.0)
    if (lockedSel) {
        label(T("Clear {0} levels in {1}  ({2}/{0})", CFG_NEED, zn(curZone), cleared(curZone)), 11.0, cx, 276.0, ROSE)
    } else if (shopTab == 3 && PT[shopSel].desc.isNotEmpty()) {
        fitLabel(PT[shopSel].desc, 11.0, cx, 276.0, SOFT, ALIGN_CENTER, L - 80.0)
    } else if (shopTab == 4) {
        val sk = SKL[shopSel]
        fitLabel(T(sk.desc) + "  -  " + T("{0}s cooldown", sk.cd.toInt()), 11.0, cx, 276.0, SOFT, ALIGN_CENTER, L - 80.0)
    }
    if (pages > 1) {
        if (shopPage > 0) ibtn("sprev", cx - 44.0, 296.0, 13.0, iconArrowLeft)
        if (shopPage < pages - 1) ibtn("snext", cx + 44.0, 296.0, 13.0, iconArrowRight)
        for (k in 0 until pages) {
            x.fillStyle = if (k == shopPage) WHITE else rgba(255, 255, 255, 0.3)
            x.beginPath()
            x.arc(cx + (k - (pages - 1) / 2.0) * 12.0, 296.0, if (k == shopPage) 3.6 else 2.8, 0.0, 7.0)
            x.fill()
        }
    }
    btn("back", "BACK", cx - 100.0, 332.0, 140.0, 34.0, 's')
    if (curOwned) {
        val equipped = shopSel == sel
        btn("buy", if (equipped) "EQUIPPED" else "EQUIP", cx + 100.0, 332.0, 150.0, 34.0, if (equipped) 'x' else 'p')
    } else if (lockedSel) {
        btn("buy", "LOCKED", cx + 100.0, 332.0, 150.0, 34.0, 'x')
    } else {
        val price = if (curHc > 0) curHc else itemCost(shopTab, shopSel)
        btn("buy", T("BUY {0}", price), cx + 100.0, 332.0, 150.0, 34.0, if (curHc > 0) 'd' else 'g', if (curHc > 0) "heart" else "coin")
    }
}

fun choice(id: String, text: String, value: String, cx: Double, cy: Double, w: Double, h: Double) {
    uiPush(id, cx - w / 2.0, cy - h / 2.0, w, h)
    if (hov == id) {
        pill(cx - w / 2.0, cy - h / 2.0, w, h, h / 2.0)
        x.fillStyle = rgba(255, 255, 255, 0.1)
        x.fill()
    }
    label(text, 14.0, cx - w / 2.0 + 16.0, cy + 1.0, WHITE, ALIGN_LEFT)
    x.setFont(13.0)
    val vw = x.measureText(fmt(value)) + 28.0
    val bx = cx + w / 2.0 - 14.0 - vw
    pill(bx, cy - 11.0, vw, 22.0, 11.0)
    x.fillShader = x.lin(bx, 0.0, bx + vw, 0.0, PINK_TOP, PURPLE_BOT)
    x.fill()
    label(value, 13.0, bx + vw / 2.0, cy + 1.0, WHITE)
}
