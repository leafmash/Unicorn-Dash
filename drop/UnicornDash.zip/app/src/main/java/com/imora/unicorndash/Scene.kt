package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.sin

private val ZF: Array<(Double) -> Unit> = arrayOf(::z0f, ::z1f, ::z2f, ::z3f, ::z4f, ::z5f, ::z6f, ::z7f, ::z8f, ::z9f, ::z10f, ::z11f, ::z12f, ::z13f, ::z14f, ::z15f, ::z16f, ::z17f)
private val ZNr: Array<(Double) -> Unit> = arrayOf(::z0n, ::z1n, ::z2n, ::z3n, ::z4n, ::z5n, ::z6n, ::z7n, ::z8n, ::z9n, ::z10n, ::z11n, ::z12n, ::z13n, ::z14n, ::z15n, ::z16n, ::z17n)
private val ZM: Array<(Double) -> Unit> = arrayOf(::z0m, ::z1m, ::z2m, ::z3m, ::z4m, ::z5m, ::z6m, ::z7m, ::z8m, ::z9m, ::z10m, ::z11m, ::z12m, ::z13m, ::z14m, ::z15m, ::z16m, ::z17m)
private val ZG: Array<(Double) -> Unit> = arrayOf(::z0g, ::z1g, ::z2g, ::z3g, ::z4g, ::z5g, ::z6g, ::z7g, ::z8g, ::z9g, ::z10g, ::z11g, ::z12g, ::z13g, ::z14g, ::z15g, ::z16g, ::z17g)
private val NC = booleanArrayOf(false, false, false, false, false, true, true, false, false, true, true, false, false, false, true, false, false, false)

fun groundBase() {
    x.fillShader = x.lin(0.0, G, 0.0, 360.0 + ty, Z.soil, Z.edge)
    x.fillRect(0.0, G, L, 80.0 + ty + 10.0)
    x.fillStyle = Z.edge
    x.fillRect(0.0, G, L, 6.0)
}

fun backdrop(rd: Double) {
    val i = Z.i
    x.save()
    x.lineCap = CAP_BUTT
    x.lineJoin = JOIN_MITER
    x.alpha = 0.8
    ZF[i](rd)
    x.alpha = 0.5
    ZNr[i](rd)
    x.alpha = 0.3
    ZM[i](rd)
    x.restore()
    x.save()
    x.fillShader = x.lin(0.0, G - 170.0, 0.0, G, Z.botClear, Z.botHaze)
    x.fillRect(0.0, G - 170.0, L, 170.0)
    x.restore()
    groundBase()
    x.save()
    x.beginPath()
    x.rect(0.0, G + 2.0, L, 130.0)
    x.clip()
    x.lineCap = CAP_BUTT
    x.lineJoin = JOIN_MITER
    x.alpha = 0.75
    ZG[i](rd)
    x.restore()
}

fun scene(rd: Double) {
    x.fillShader = x.lin(0.0, 0.0, 0.0, G, Z.top, Z.bot)
    x.fillRect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)

    if (Z.night > 0.1) {
        x.fillStyle = hex(0xffffff)
        for (i in 0 until 60) {
            x.alpha = Z.night * (0.3 + 0.7 * abs(sin(t * 2.0 + i)))
            x.fillRect(hs(i) * L, hs(i + 99) * 190.0, 1.6, 1.6)
        }
        x.alpha = 1.0
    }
    if (Z.night > 0.55) {
        val cyc = t / 6.0
        val k = cyc % 1.0
        val id = Math.floor(cyc).toInt()
        if (k < 0.12) {
            val f = k / 0.12
            val sx0 = hs(id) * L * 0.8 + 40.0
            val sy0 = 20.0 + hs(id + 5) * 60.0
            val hx = sx0 + f * 150.0
            val hy = sy0 + f * 70.0
            x.strokeShader = x.lin(hx - 60.0, hy - 28.0, hx, hy, rgba(255, 255, 255, 0.0), rgba(255, 255, 255, 1.0 - f))
            x.lineWidth = 2.0
            x.lineCap = CAP_ROUND
            x.beginPath()
            x.moveTo(hx - 60.0, hy - 28.0)
            x.lineTo(hx, hy)
            x.stroke()
        }
    }

    val sx = L * 0.76
    val sy = 88.0 + 30.0 * Z.night + sin(t * 0.5) * 2.0
    x.halo(sx, sy, 170.0, if (Z.night > 0.5) 230.0 else 40.0, 100.0, if (Z.night > 0.5) 85.0 else 80.0, 0.55)
    x.halo(sx, sy, 80.0, if (Z.night > 0.5) 230.0 else 40.0, 100.0, 92.0, 0.45)
    x.fillStyle = Z.body
    x.beginPath()
    x.arc(sx, sy, 32.0, 0.0, 7.0)
    x.fill()
    if (Z.night > 0.5) {
        x.fillStyle = rgba(120, 120, 180, 0.14 * Z.night)
        x.beginPath()
        x.arc(sx - 10.0, sy - 6.0, 6.0, 0.0, 7.0)
        x.arc(sx + 8.0, sy + 9.0, 4.5, 0.0, 7.0)
        x.arc(sx + 12.0, sy - 10.0, 3.0, 0.0, 7.0)
        x.fill()
    }

    x.fillStyle = rgba(255, 255, 255, if (NC[Z.i]) 0.0 else 0.75 - 0.5 * Z.night)
    x.beginPath()
    layer(rd * 0.05 + t * 10.0, 190.0, 5) { px, r1, r2 ->
        val y = 36.0 + 100.0 * r1
        val s = 0.8 + r2 * 0.7
        x.moveTo(px + 14.0 * s, y)
        x.arc(px, y, 14.0 * s, 0.0, 7.0)
        x.moveTo(px + 48.0 * s, y - 4.0 * s)
        x.arc(px + 30.0 * s, y - 6.0 * s, 18.0 * s, 0.0, 7.0)
        x.moveTo(px + 62.0 * s, y)
        x.arc(px + 48.0 * s, y, 14.0 * s, 0.0, 7.0)
    }
    x.fill()

    backdrop(rd)
}
