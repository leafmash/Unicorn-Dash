package com.imora.unicorndash

import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

private val MINT = hex(0x7dffd4)
private val SUN = hex(0xffe27a)
private val SOFT = hex(0xd9ccff)
private val DIM = hex(0xa89cd4)
private val CYAN = hex(0x9fefff)
private val ROSE = hex(0xffb0cf)
private val TRACK = rgba(255, 255, 255, 0.16)
private val dateCache = HashMap<Int, String>()

private fun dayLabel(d: Int): String {
    val cached = dateCache[d]
    if (cached != null) return cached
    val z = d + 719468
    val era = floorDiv(z, 146097)
    val doe = z - era * 146097
    val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
    val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
    val mp = (5 * doy + 2) / 153
    val dd = doy - (153 * mp + 2) / 5 + 1
    val mm = if (mp < 10) mp + 3 else mp - 9
    val s = (if (mm < 10) "0$mm" else "$mm") + "-" + (if (dd < 10) "0$dd" else "$dd")
    if (dateCache.size > 200) dateCache.clear()
    dateCache[d] = s
    return s
}

private fun floorDiv(a: Int, b: Int): Int = Math.floorDiv(a, b)

private fun pageDots(cx: Double, y: Double, pages: Int, cur: Int) {
    for (k in 0 until pages) {
        x.fillStyle = if (k == cur) WHITE else rgba(255, 255, 255, 0.3)
        x.beginPath()
        x.arc(cx + (k - (pages - 1) / 2.0) * 12.0, y, if (k == cur) 3.6 else 2.8, 0.0, 7.0)
        x.fill()
    }
}

fun settingsUI() {
    val cx = L / 2.0
    veil(0.8)
    panel(cx, 182.0, 380.0, 330.0)
    title("SETTINGS", 26.0, cx, 40.0)
    toggle("tmusic", "Music", opt.music, cx, 78.0, 320.0, 26.0)
    toggle("tsfx", "Sound effects", opt.sfx, cx, 106.0, 320.0, 26.0)
    toggle("tvib", "Vibration", opt.vib, cx, 134.0, 320.0, 26.0)
    toggle("tghost", "Ghost of your best run", opt.ghost, cx, 162.0, 320.0, 26.0)
    choice("tlang", "Language", if (opt.lang == "bn") "বাংলা" else "English", cx, 190.0, 320.0, 26.0)
    btn("stats", "STATS", cx - 112.0, 228.0, 104.0, 30.0, 's')
    btn("export", "EXPORT", cx, 228.0, 104.0, 30.0, 's')
    btn("import", "IMPORT", cx + 112.0, 228.0, 104.0, 30.0, 's')
    val sure = nowMs() - confirmAt < 3000.0
    btn("reset", if (sure) "TAP AGAIN TO CONFIRM" else "RESET PROGRESS", cx, 268.0, 210.0, 26.0, if (sure) 'd' else 's')
    btn("back", "BACK", cx, 310.0, 140.0, 34.0, 'p')
}

private val statHeads = arrayOf(
    "PLAYER LEVEL", "XP", "RUNS", "PLAY TIME", "TOTAL COINS", "DISTANCE", "OBSTACLES DODGED", "NEAR MISSES",
    "POWER-UPS", "SPINS", "BEST COMBO", "BEST ENDLESS", "STARS", "LEVELS CLEARED", "ZONES OPEN", "AWARDS"
)
private val statColors = intArrayOf(
    hex(0xffffff), hex(0xd9ccff), hex(0xffffff), hex(0x9fefff), hex(0xffe27a), hex(0x9fefff), hex(0xffffff), hex(0xffb0cf),
    hex(0xffffff), hex(0xffffff), hex(0xffb0cf), hex(0xffe27a), hex(0xffe27a), hex(0xffffff), hex(0xffffff), hex(0x7dffd4)
)

private fun statValue(i: Int, clearedCount: Int, bestEndless: Int): String {
    val hrs = floor(stats.time / 3600.0).toInt()
    val mins = floor((stats.time % 3600.0) / 60.0).toInt()
    return when (i) {
        0 -> plv().toString()
        1 -> xp.toString()
        2 -> stats.runs.toString()
        3 -> T("{0}h {1}m", hrs, mins)
        4 -> stats.coins.toString()
        5 -> T("{0} m", stats.dist)
        6 -> stats.dodge.toString()
        7 -> stats.near.toString()
        8 -> stats.pw.toString()
        9 -> stats.spins.toString()
        10 -> "x" + stats.bc
        11 -> bestEndless.toString()
        12 -> "${totalStars()}/${ZN.size * CFG_LEVELS * 3}"
        13 -> "$clearedCount/${ZN.size * CFG_LEVELS}"
        14 -> "${openCount()}/${ZN.size}"
        else -> "${achDone()}/${ACH.size}"
    }
}

fun statsUI() {
    val cx = L / 2.0
    val tw = 108.0
    val th = 46.0
    val g = 8.0
    val x0 = cx - (4.0 * tw + 3.0 * g) / 2.0
    veil(0.8)
    title("STATISTICS", 26.0, cx, 30.0)
    var lv = 0
    for (z in prog) for (v in z) if (v > 0) lv++
    var be = 0
    for (v in eb) be = max(be, v)
    for (i in 0 until 16) {
        tile(x0 + tw / 2.0 + (i % 4) * (tw + g), 82.0 + floor(i / 4.0) * (th + g), tw, th, statHeads[i], statValue(i, lv, be), statColors[i])
    }
    btn("back", "BACK", cx, 322.0, 140.0, 34.0, 'p')
}

fun giftUI() {
    val gf = gift ?: return
    val cx = L / 2.0
    val k = clamp((nowMs() - giftAt) / 500.0, 0.0, 1.0)
    if (k <= 0.0) return
    x.save()
    x.alpha *= k
    x.fillStyle = rgba(8, 4, 28, 0.62)
    x.fillRect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
    val sc = 0.85 + 0.15 * easeOut(k)
    x.translate(cx, 170.0)
    x.scale(sc, sc)
    x.translate(-cx, -170.0)
    panel(cx, 170.0, 300.0, 210.0)
    title("DAILY GIFT", 26.0, cx, 112.0)
    iconCoin(cx - 62.0, 160.0, 20.0)
    label("+" + gf.amt, 44.0, cx - 30.0, 161.0, SUN, ALIGN_LEFT)
    label(T("Day {0} streak", gf.streak), 13.0, cx, 194.0, ROSE)
    label("Come back tomorrow for more", 11.5, cx, 212.0, SOFT)
    btn("claim", "CLAIM", cx, 248.0, 160.0, 40.0, 'g')
    x.restore()
}

fun awardsUI() {
    val cx = L / 2.0
    val per = 8
    val pages = ceil(ACH.size.toDouble() / per).toInt()
    val cw = 226.0
    val ch = 50.0
    veil(0.8)
    title("AWARDS", 28.0, cx, 30.0)
    chip(cx, 56.0, 110.0, 22.0, "${achDone()}/${ACH.size}", SUN)
    for (k in 0 until per) {
        val i = apage * per + k
        if (i >= ACH.size) break
        val a = ACH[i]
        val bx = cx - cw - 5.0 + (k % 2) * (cw + 10.0)
        val by = 76.0 + floor(k / 2.0) * (ch + 6.0)
        val v = min(a.g(), a.m)
        val f = v.toDouble() / a.m
        val dn = ach[i] != 0
        pill(bx, by, cw, ch, 14.0)
        x.fillStyle = if (dn) rgba(125, 255, 212, 0.14) else rgba(255, 255, 255, 0.09)
        x.fill()
        x.strokeStyle = if (dn) MINT else rgba(255, 255, 255, 0.3)
        x.lineWidth = 1.4
        x.stroke()
        label(a.n, 12.5, bx + 12.0, by + 14.0, if (dn) hex(0xb8ffe6) else WHITE, ALIGN_LEFT)
        if (dn) {
            label("DONE", 10.5, bx + cw - 12.0, by + 14.0, MINT, ALIGN_RIGHT)
        } else {
            iconCoin(bx + cw - 38.0, by + 14.0, 5.5)
            label(a.r.toString(), 11.0, bx + cw - 29.0, by + 15.0, SUN, ALIGN_LEFT)
        }
        label(a.d, 10.0, bx + 12.0, by + 29.0, SOFT, ALIGN_LEFT)
        pill(bx + 12.0, by + 38.0, cw - 24.0, 5.0, 2.5)
        x.fillStyle = TRACK
        x.fill()
        if (f > 0.0) {
            pill(bx + 12.0, by + 38.0, max(5.0, (cw - 24.0) * f), 5.0, 2.5)
            x.fillStyle = if (dn) MINT else hex(0xffb0e8)
            x.fill()
        }
    }
    btn("back", "BACK", cx - 150.0, 326.0, 110.0, 34.0, 's')
    if (apage > 0) ibtn("aprev", cx - 52.0, 326.0, 17.0, iconArrowLeft)
    if (apage < pages - 1) ibtn("anext", cx + 52.0, 326.0, 17.0, iconArrowRight)
    pageDots(cx, 326.0, pages, apage)
}

private val boardColors = intArrayOf(hex(0xffd23f), hex(0xe4e8f4), hex(0xf0b27a))

fun boardUI() {
    val cx = L / 2.0
    val open = zoneOpen(lbz)
    val list = lb[lbz]
    veil(0.8)
    title("LEADERBOARD", 26.0, cx, 28.0)
    ibtn("lprev", cx - 130.0, 62.0, 14.0, iconArrowLeft)
    ibtn("lnext", cx + 130.0, 62.0, 14.0, iconArrowRight)
    label(ZN[lbz].name, 18.0, cx, 60.0, WHITE)
    label("ENDLESS  -  TOP 10", 10.5, cx, 80.0, SOFT)
    glass(cx - 150.0, 92.0, 300.0, 222.0, 16.0, 0.75)
    if (!open) {
        label("Locked", 16.0, cx, 200.0, DIM)
    } else if (list.isEmpty()) {
        label("No runs yet", 15.0, cx, 200.0, DIM)
    } else {
        for (i in list.indices) {
            val e = list[i]
            val yy = 108.0 + i * 21.0
            val col = if (i < 3) boardColors[i] else WHITE
            label("#" + (i + 1), 13.0, cx - 130.0, yy, col, ALIGN_LEFT)
            label(e.s.toString(), 14.0, cx - 10.0, yy, col, ALIGN_RIGHT)
            label(dayLabel(e.d), 10.5, cx + 130.0, yy, hex(0xbfb2ec), ALIGN_RIGHT)
        }
    }
    label(if (gh.containsKey("E$lbz")) "Ghost saved" else "No ghost yet", 10.5, cx, 324.0, hex(0xbfb2ec))
    btn("back", "BACK", cx - 150.0, 336.0, 100.0, 26.0, 's')
}

fun spinUI() {
    val cx = L / 2.0
    val cy = 176.0
    val rad = 98.0
    val seg = TAU / SPIN.size
    veil(0.8)
    title("DAILY SPIN", 28.0, cx, 28.0)
    if (spinning) {
        val k = clamp((nowMs() - spinT0) / 4200.0, 0.0, 1.0)
        spinA = spinFrom + (spinTo - spinFrom) * (1.0 - (1.0 - k).pow(4.0))
        val ti = floor(spinA / seg).toInt()
        if (ti != spinTick) {
            spinTick = ti
            snd("tick")
        }
        if (k >= 1.0) {
            spinning = false
            spinA = spinTo
            val sg = SPIN[spinIdx]
            say(T(if (sg.hearts) "+{0} hearts" else "+{0} coins", sg.amount))
            snd("gift")
        }
    }
    x.halo(cx, cy, rad * 1.35, 300.0, 100.0, 70.0, 0.3)
    x.save()
    x.translate(cx, cy)
    for (i in SPIN.indices) {
        val a0 = -PI / 2.0 + spinA + i * seg
        x.beginPath()
        x.moveTo(0.0, 0.0)
        x.arc(0.0, 0.0, rad, a0, a0 + seg)
        x.closePath()
        x.fillStyle = hsl((i * 45 + 280) % 360.0, 80.0, if (i % 2 == 1) 60.0 else 52.0)
        x.fill()
        x.strokeStyle = rgba(255, 255, 255, 0.7)
        x.lineWidth = 1.5
        x.stroke()
        x.save()
        x.rotate(a0 + seg / 2.0)
        if (SPIN[i].hearts) {
            heartPath(rad * 0.56, -1.0, 8.0)
            x.fillStyle = PINK_HEART
            x.fill()
            x.lineWidth = 1.4
            x.strokeStyle = WHITE
            x.stroke()
            label("x" + SPIN[i].amount, 13.0, rad * 0.8, 0.0, WHITE)
        } else {
            label(SPIN[i].amount.toString(), 15.0, rad * 0.66, 0.0, WHITE)
        }
        x.restore()
    }
    x.strokeStyle = rgba(255, 255, 255, 0.85)
    x.lineWidth = 4.0
    x.beginPath()
    x.arc(0.0, 0.0, rad + 2.0, 0.0, 7.0)
    x.stroke()
    x.restore()
    x.fillStyle = WHITE
    x.beginPath()
    x.arc(cx, cy, 15.0, 0.0, 7.0)
    x.fill()
    iconCoin(cx, cy, 9.0)
    x.fillStyle = SUN
    x.strokeStyle = hex(0xb87400)
    x.lineWidth = 1.5
    x.beginPath()
    x.moveTo(cx - 10.0, cy - rad - 16.0)
    x.lineTo(cx + 10.0, cy - rad - 16.0)
    x.lineTo(cx, cy - rad + 5.0)
    x.closePath()
    x.fill()
    x.stroke()
    val msg = if (spinning) "Good luck!"
    else if (spinAvail()) "Your free spin is ready"
    else if (spinIdx >= 0 && spinDay == day) T(if (SPIN[spinIdx].hearts) "You won {0} hearts  -  come back tomorrow" else "You won {0} coins  -  come back tomorrow", SPIN[spinIdx].amount)
    else "Come back tomorrow for another spin"
    label(msg, 12.5, cx, 296.0, SUN)
    val canSpin = spinAvail() && !spinning
    btn("back", "BACK", cx - 90.0, 330.0, 130.0, 34.0, 's')
    btn("dospin", "SPIN", cx + 90.0, 330.0, 150.0, 36.0, if (canSpin) 'g' else 'x')
}
