package com.imora.unicorndash

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

object Pal {
    val Pink = Color(0xFFFF9BE0)
    val Purple = Color(0xFF9A5CFF)
    val Violet = Color(0xFF5B34C8)
    val Sun = Color(0xFFFFE27A)
    val Amber = Color(0xFFFFA23F)
    val Mint = Color(0xFF7DFFD4)
    val Rose = Color(0xFFFFB0CF)
    val Cyan = Color(0xFF9FEFFF)
    val Lilac = Color(0xFFD9CCFF)
    val Dim = Color(0xFFA89CD4)
    val Gold = Color(0xFFFFD23F)
    val GoldDark = Color(0xFFFFB000)
    val Heart = Color(0xFFFF5A8C)
    val Ruby = Color(0xFFD23C5C)
    val Ink = Color(0xFF2A1458)
    val Night = Color(0xFF140A33)
    val GlassTop = Color(0xCC5A3EB0)
    val GlassBot = Color(0xE0231058)
    val Rim = Color(0x66FFFFFF)
}

val PrimaryBrush = Brush.verticalGradient(listOf(Pal.Pink, Pal.Purple))
val GoldBrush = Brush.verticalGradient(listOf(Pal.Sun, Pal.Amber))
val DangerBrush = Brush.verticalGradient(listOf(Color(0xFFFF8A9A), Pal.Ruby))
val SoftBrush = Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x1AFFFFFF)))
val OffBrush = Brush.verticalGradient(listOf(Color(0x30FFFFFF), Color(0x18FFFFFF)))
val GlassBrush = Brush.verticalGradient(listOf(Pal.GlassTop, Pal.GlassBot))
val RimBrush = Brush.verticalGradient(listOf(Color(0x77FFFFFF), Color(0x14FFFFFF)))

fun hueColor(h: Double, s: Double = 100.0, l: Double = 70.0): Color = Color(hsl(h, s, l))

@Composable
fun Tx(
    text: String,
    size: Float,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    weight: FontWeight = FontWeight.ExtraBold,
    align: TextAlign = TextAlign.Start,
    maxLines: Int = 1,
    shadow: Boolean = true
) {
    BasicText(
        text = fmt(text),
        modifier = modifier,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        softWrap = maxLines > 1,
        style = TextStyle(
            color = color,
            fontSize = size.sp,
            fontWeight = weight,
            textAlign = align,
            shadow = if (shadow) Shadow(Color(0x66281450), Offset(0f, 2f), 4f) else null
        )
    )
}

@Composable
fun GradText(text: String, size: Float, modifier: Modifier = Modifier, brush: Brush = PrimaryBrush) {
    BasicText(
        text = fmt(text),
        modifier = modifier,
        maxLines = 1,
        softWrap = false,
        style = TextStyle(
            brush = brush,
            fontSize = size.sp,
            fontWeight = FontWeight.Black,
            shadow = Shadow(Color(0x88281450), Offset(0f, 3f), 8f)
        )
    )
}

@Composable
fun Modifier.pressable(enabled: Boolean = true, scaleTo: Float = 0.93f, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed && enabled) scaleTo else 1f,
        animationSpec = spring(dampingRatio = 0.42f, stiffness = 650f),
        label = "press"
    )
    return this
        .graphicsLayer {
            scaleX = sc
            scaleY = sc
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled) {
            UiBridge.tap()
            onClick()
        }
}

@Composable
fun Modifier.enter(index: Int = 0, dy: Float = 22f): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 50L)
        a.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 240f))
    }
    return this.graphicsLayer {
        val v = a.value
        alpha = if (v < 0f) 0f else if (v > 1f) 1f else v
        translationY = (1f - v) * dy * density
    }
}

@Composable
fun Modifier.popIn(delayMs: Long = 0L): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs)
        a.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = 320f))
    }
    return this.graphicsLayer {
        val v = a.value
        val sc = 0.84f + 0.16f * v
        scaleX = sc
        scaleY = sc
        alpha = if (v < 0f) 0f else if (v > 1f) 1f else v
    }
}

@Composable
fun Glass(
    modifier: Modifier = Modifier,
    radius: Dp = 22.dp,
    fill: Brush = GlassBrush,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier = modifier
            .clip(shape)
            .background(fill)
            .border(1.2.dp, RimBrush, shape),
        content = content
    )
}

enum class Kind { Primary, Gold, Danger, Soft, Off }

@Composable
fun GButton(
    text: String,
    modifier: Modifier = Modifier,
    kind: Kind = Kind.Primary,
    height: Dp = 46.dp,
    textSize: Float = 17f,
    coin: Boolean = false,
    heart: Boolean = false,
    lead: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    val enabled = kind != Kind.Off
    val shape = RoundedCornerShape(height / 2)
    val brush = when (kind) {
        Kind.Primary -> PrimaryBrush
        Kind.Gold -> GoldBrush
        Kind.Danger -> DangerBrush
        Kind.Soft -> SoftBrush
        Kind.Off -> OffBrush
    }
    val shine = rememberInfiniteTransition(label = "shine")
    val sweep by shine.animateFloat(
        initialValue = -0.4f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep"
    )
    val textColor = if (kind == Kind.Gold) Color(0xFF5A3000) else if (kind == Kind.Off) Color(0x88FFFFFF) else Color.White
    Box(
        modifier = modifier
            .height(height)
            .pressable(enabled = enabled, onClick = onClick)
            .clip(shape)
            .background(brush)
            .border(1.5.dp, if (kind == Kind.Soft || kind == Kind.Off) Color(0x55FFFFFF) else Color(0xBBFFFFFF), shape)
            .drawBehind {
                if (kind == Kind.Primary || kind == Kind.Gold) {
                    val bw = size.width * 0.28f
                    val bx = size.width * sweep
                    drawRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, Color(0x38FFFFFF), Color.Transparent),
                            startX = bx - bw,
                            endX = bx + bw
                        ),
                        topLeft = Offset(bx - bw, 0f),
                        size = Size(bw * 2f, size.height)
                    )
                }
                if (kind != Kind.Soft && kind != Kind.Off) {
                    drawRoundRect(
                        color = Color(0x2EFFFFFF),
                        topLeft = Offset(size.width * 0.04f, size.height * 0.06f),
                        size = Size(size.width * 0.92f, size.height * 0.4f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height * 0.2f)
                    )
                }
            }
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (lead != null) {
                lead()
                Spacer(Modifier.width(8.dp))
            }
            if (coin) {
                CoinIcon(textSize.dp * 1.1f)
                Spacer(Modifier.width(6.dp))
            }
            if (heart) {
                HeartIcon(textSize.dp * 1.1f)
                Spacer(Modifier.width(6.dp))
            }
            Tx(text, textSize, color = textColor, shadow = kind != Kind.Gold && kind != Kind.Off)
        }
    }
}

@Composable
fun RoundBtn(size: Dp = 42.dp, modifier: Modifier = Modifier, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .size(size)
            .pressable(onClick = onClick)
            .clip(CircleShape)
            .background(GlassBrush)
            .border(1.2.dp, RimBrush, CircleShape),
        contentAlignment = Alignment.Center
    ) { icon() }
}

@Composable
fun Pill(modifier: Modifier = Modifier, height: Dp = 30.dp, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(height / 2)
    Box(
        modifier = modifier
            .height(height)
            .clip(shape)
            .background(GlassBrush)
            .border(1.dp, RimBrush, shape)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun CoinPill(value: Int, modifier: Modifier = Modifier, height: Dp = 30.dp) {
    val shown by animateFloatAsState(value.toFloat(), tween(700, easing = FastOutSlowInEasing), label = "coins")
    Pill(modifier, height) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CoinIcon(height * 0.62f)
            Spacer(Modifier.width(6.dp))
            Tx(shown.toInt().toString(), height.value * 0.48f, color = Pal.Sun)
        }
    }
}

@Composable
fun HeartPill(value: Int, modifier: Modifier = Modifier, height: Dp = 30.dp) {
    Pill(modifier, height) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            HeartIcon(height * 0.62f)
            Spacer(Modifier.width(6.dp))
            Tx("x$value", height.value * 0.48f, color = Color(0xFFFFD0E0))
        }
    }
}

@Composable
fun Bar(fraction: Float, modifier: Modifier = Modifier, height: Dp = 8.dp, brush: Brush = PrimaryBrush) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), spring(dampingRatio = 0.8f, stiffness = 120f), label = "bar")
    val shape = RoundedCornerShape(height / 2)
    Box(
        modifier = modifier
            .height(height)
            .clip(shape)
            .background(Color(0x29FFFFFF))
    ) {
        if (f > 0.001f) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(f)
                    .clip(shape)
                    .background(brush)
            )
        }
    }
}

@Composable
fun Stat(head: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x17FFFFFF))
            .padding(horizontal = 6.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Tx(head, 9.5f, color = Color(0xFFBFB2EC), weight = FontWeight.Bold, shadow = false)
            Spacer(Modifier.height(2.dp))
            Tx(value, 17f, color = color)
        }
    }
}

@Composable
fun IconBox(size: Dp, draw: DrawScope.() -> Unit) {
    Box(Modifier.size(size).drawBehind { draw() })
}

fun DrawScope.starPath(cx: Float, cy: Float, r: Float): Path {
    val p = Path()
    for (i in 0 until 10) {
        val rr = if (i % 2 == 1) r * 0.46f else r
        val a = (-Math.PI / 2 + i * Math.PI / 5).toFloat()
        val px = cx + cos(a) * rr
        val py = cy + sin(a) * rr
        if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
    }
    p.close()
    return p
}

fun heartShape(cx: Float, cy: Float, s: Float): Path {
    val p = Path()
    p.moveTo(cx, cy + s * 0.9f)
    p.cubicTo(cx - s * 1.5f, cy - s * 0.1f, cx - s * 0.8f, cy - s * 1.2f, cx, cy - s * 0.4f)
    p.cubicTo(cx + s * 0.8f, cy - s * 1.2f, cx + s * 1.5f, cy - s * 0.1f, cx, cy + s * 0.9f)
    p.close()
    return p
}

@Composable
fun CoinIcon(size: Dp) {
    IconBox(size) {
        val r = this.size.minDimension / 2f
        val c = center
        drawCircle(Brush.verticalGradient(listOf(Color(0xFFFFE680), Pal.Gold, Pal.GoldDark)), r, c)
        drawCircle(Pal.GoldDark, r, c, style = Stroke(r * 0.16f))
        drawCircle(Color(0xCCFFB000), r * 0.58f, c, style = Stroke(r * 0.12f))
        drawCircle(Color(0xB3FFFFFF), r * 0.18f, Offset(c.x - r * 0.3f, c.y - r * 0.32f))
    }
}

@Composable
fun HeartIcon(size: Dp) {
    IconBox(size) {
        val s = this.size.minDimension * 0.4f
        val p = heartShape(this.size.width / 2f, this.size.height / 2f, s)
        drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFF8CB0), Pal.Heart)))
        drawPath(p, Color.White, style = Stroke(s * 0.14f, join = StrokeJoin.Round))
    }
}

@Composable
fun StarIcon(size: Dp, on: Boolean) {
    IconBox(size) {
        val r = this.size.minDimension / 2f * 0.92f
        val p = starPath(this.size.width / 2f, this.size.height / 2f, r)
        if (on) {
            drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFFF0A0), Pal.Gold)))
            drawPath(p, Pal.GoldDark, style = Stroke(r * 0.14f, join = StrokeJoin.Round))
        } else {
            drawPath(p, Color(0x24FFFFFF))
            drawPath(p, Color(0x57FFFFFF), style = Stroke(r * 0.14f, join = StrokeJoin.Round))
        }
    }
}

@Composable
fun LockIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val sw = w * 0.12f
        drawArc(
            color = color,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.28f, h * 0.1f),
            size = Size(w * 0.44f, h * 0.44f),
            style = Stroke(sw, cap = StrokeCap.Round)
        )
        drawRoundRect(color, Offset(w * 0.2f, h * 0.4f), Size(w * 0.6f, h * 0.5f), androidx.compose.ui.geometry.CornerRadius(w * 0.1f))
    }
}

@Composable
fun GearIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val c = center
        val r = this.size.minDimension / 2f
        val sw = r * 0.34f
        for (i in 0 until 8) {
            val a = (i * Math.PI / 4).toFloat()
            drawLine(
                color,
                Offset(c.x + cos(a) * r * 0.62f, c.y + sin(a) * r * 0.62f),
                Offset(c.x + cos(a) * r * 0.95f, c.y + sin(a) * r * 0.95f),
                strokeWidth = sw,
                cap = StrokeCap.Round
            )
        }
        drawCircle(color, r * 0.62f, c)
        drawCircle(Color(0xFF4A2A98), r * 0.26f, c)
    }
}

@Composable
fun SoundIcon(size: Dp, on: Boolean, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val p = Path()
        p.moveTo(w * 0.12f, h * 0.38f)
        p.lineTo(w * 0.32f, h * 0.38f)
        p.lineTo(w * 0.54f, h * 0.18f)
        p.lineTo(w * 0.54f, h * 0.82f)
        p.lineTo(w * 0.32f, h * 0.62f)
        p.lineTo(w * 0.12f, h * 0.62f)
        p.close()
        drawPath(p, color)
        val sw = w * 0.09f
        if (on) {
            drawArc(color, -45f, 90f, false, Offset(w * 0.4f, h * 0.3f), Size(w * 0.4f, h * 0.4f), style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(color, -50f, 100f, false, Offset(w * 0.34f, h * 0.16f), Size(w * 0.56f, h * 0.68f), style = Stroke(sw, cap = StrokeCap.Round))
        } else {
            drawLine(color, Offset(w * 0.66f, h * 0.36f), Offset(w * 0.9f, h * 0.64f), sw, StrokeCap.Round)
            drawLine(color, Offset(w * 0.9f, h * 0.36f), Offset(w * 0.66f, h * 0.64f), sw, StrokeCap.Round)
        }
    }
}

@Composable
fun PauseIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(color, Offset(w * 0.22f, h * 0.18f), Size(w * 0.18f, h * 0.64f), androidx.compose.ui.geometry.CornerRadius(w * 0.06f))
        drawRoundRect(color, Offset(w * 0.6f, h * 0.18f), Size(w * 0.18f, h * 0.64f), androidx.compose.ui.geometry.CornerRadius(w * 0.06f))
    }
}

@Composable
fun ArrowIcon(size: Dp, left: Boolean, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val p = Path()
        if (left) {
            p.moveTo(w * 0.62f, h * 0.2f)
            p.lineTo(w * 0.34f, h * 0.5f)
            p.lineTo(w * 0.62f, h * 0.8f)
        } else {
            p.moveTo(w * 0.38f, h * 0.2f)
            p.lineTo(w * 0.66f, h * 0.5f)
            p.lineTo(w * 0.38f, h * 0.8f)
        }
        drawPath(p, color, style = Stroke(w * 0.12f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun BackIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val p = Path()
        p.moveTo(w * 0.58f, h * 0.2f)
        p.lineTo(w * 0.3f, h * 0.5f)
        p.lineTo(w * 0.58f, h * 0.8f)
        drawPath(p, color, style = Stroke(w * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun PlayIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val p = Path()
        p.moveTo(w * 0.28f, h * 0.16f)
        p.lineTo(w * 0.82f, h * 0.5f)
        p.lineTo(w * 0.28f, h * 0.84f)
        p.close()
        drawPath(p, color)
    }
}

@Composable
fun LoopIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val sw = w * 0.11f
        drawArc(color, 20f, 300f, false, Offset(w * 0.14f, h * 0.2f), Size(w * 0.72f, h * 0.6f), style = Stroke(sw, cap = StrokeCap.Round))
        val p = Path()
        p.moveTo(w * 0.7f, h * 0.18f)
        p.lineTo(w * 0.86f, h * 0.36f)
        p.lineTo(w * 0.62f, h * 0.4f)
        p.close()
        drawPath(p, color)
    }
}

@Composable
fun BagIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(color, Offset(w * 0.18f, h * 0.34f), Size(w * 0.64f, h * 0.52f), androidx.compose.ui.geometry.CornerRadius(w * 0.1f))
        drawArc(color, 180f, 180f, false, Offset(w * 0.32f, h * 0.12f), Size(w * 0.36f, h * 0.44f), style = Stroke(w * 0.08f, cap = StrokeCap.Round))
    }
}

@Composable
fun MedalIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        drawLine(color, Offset(w * 0.34f, h * 0.1f), Offset(w * 0.44f, h * 0.4f), w * 0.1f, StrokeCap.Round)
        drawLine(color, Offset(w * 0.66f, h * 0.1f), Offset(w * 0.56f, h * 0.4f), w * 0.1f, StrokeCap.Round)
        drawCircle(color, w * 0.26f, Offset(w * 0.5f, h * 0.62f))
        drawPath(starPath(w * 0.5f, h * 0.62f, w * 0.16f), Color(0xFF6A3FD0))
    }
}

@Composable
fun BoardIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val cr = androidx.compose.ui.geometry.CornerRadius(w * 0.05f)
        drawRoundRect(color, Offset(w * 0.12f, h * 0.5f), Size(w * 0.22f, h * 0.38f), cr)
        drawRoundRect(color, Offset(w * 0.39f, h * 0.2f), Size(w * 0.22f, h * 0.68f), cr)
        drawRoundRect(color, Offset(w * 0.66f, h * 0.62f), Size(w * 0.22f, h * 0.26f), cr)
    }
}

@Composable
fun SpinIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val c = center
        val r = this.size.minDimension / 2f * 0.86f
        drawCircle(color, r, c, style = Stroke(r * 0.16f))
        for (i in 0 until 6) {
            val a = (i * Math.PI / 3).toFloat()
            drawLine(color, c, Offset(c.x + cos(a) * r, c.y + sin(a) * r), r * 0.1f, StrokeCap.Round)
        }
        drawCircle(color, r * 0.2f, c)
    }
}

@Composable
fun CalendarIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(color, Offset(w * 0.14f, h * 0.2f), Size(w * 0.72f, h * 0.66f), androidx.compose.ui.geometry.CornerRadius(w * 0.1f), style = Stroke(w * 0.09f))
        drawLine(color, Offset(w * 0.14f, h * 0.4f), Offset(w * 0.86f, h * 0.4f), w * 0.09f)
        drawLine(color, Offset(w * 0.34f, h * 0.1f), Offset(w * 0.34f, h * 0.28f), w * 0.09f, StrokeCap.Round)
        drawLine(color, Offset(w * 0.66f, h * 0.1f), Offset(w * 0.66f, h * 0.28f), w * 0.09f, StrokeCap.Round)
    }
}

@Composable
fun CheckIcon(size: Dp, color: Color = Color.White) {
    IconBox(size) {
        val w = this.size.width
        val h = this.size.height
        val p = Path()
        p.moveTo(w * 0.2f, h * 0.52f)
        p.lineTo(w * 0.42f, h * 0.72f)
        p.lineTo(w * 0.8f, h * 0.3f)
        drawPath(p, color, style = Stroke(w * 0.14f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun PulseGlow(color: Color, modifier: Modifier = Modifier, radius: Dp = 120.dp) {
    val tr = rememberInfiniteTransition(label = "glow")
    val k by tr.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glowk"
    )
    Box(
        modifier = modifier
            .size(radius * 2)
            .alpha(k)
            .background(Brush.radialGradient(listOf(color.copy(alpha = 0.45f), Color.Transparent)), CircleShape)
    )
}
