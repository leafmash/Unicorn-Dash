package com.imora.unicorndash

import android.content.Context
import android.graphics.Canvas
import android.os.Build
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowInsets
import java.util.concurrent.ConcurrentLinkedQueue

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private val tasks = ConcurrentLinkedQueue<Runnable>()
    private var gameThread: GameThread? = null

    @Volatile private var surfW = 0
    @Volatile private var surfH = 0
    @Volatile private var insL = 0
    @Volatile private var insR = 0
    @Volatile private var dirty = false

    init {
        holder.addCallback(this)
        isFocusable = true
        keepScreenOn = true
    }

    fun runOnGame(r: Runnable) {
        tasks.add(r)
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        if (Build.VERSION.SDK_INT >= 28) {
            val c = insets.displayCutout
            insL = c?.safeInsetLeft ?: 0
            insR = c?.safeInsetRight ?: 0
            dirty = true
        }
        return super.onApplyWindowInsets(insets)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val t = GameThread(this, holder.surface)
        gameThread = t
        t.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfW = width
        surfH = height
        dirty = true
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        gameThread?.finish()
        gameThread = null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            val id = e.getPointerId(i)
            val px = e.getX(i).toDouble()
            val py = e.getY(i).toDouble()
            tasks.add(Runnable { inputDown(id, px, py) })
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) {
            val i = e.actionIndex
            val id = e.getPointerId(i)
            val px = e.getX(i).toDouble()
            val py = e.getY(i).toDouble()
            tasks.add(Runnable { inputUp(id, px, py, false) })
        } else if (a == MotionEvent.ACTION_CANCEL) {
            val ids = IntArray(e.pointerCount) { e.getPointerId(it) }
            tasks.add(Runnable { for (id in ids) inputUp(id, 0.0, 0.0, true) })
        }
        return true
    }

    fun frame(canvas: Canvas) {
        var r = tasks.poll()
        while (r != null) {
            r.run()
            r = tasks.poll()
        }
        if (dirty) {
            dirty = false
            fitScreen(surfW, surfH, insL, insR)
        }
    }

    private class GameThread(private val view: GameView, private val surface: Surface) : Thread("ud-game") {
        @Volatile private var running = true

        fun finish() {
            running = false
            try {
                join(1000)
            } catch (e: InterruptedException) {
                currentThread().interrupt()
            }
        }

        override fun run() {
            var last = System.nanoTime()
            while (running) {
                val c: Canvas? = try {
                    if (Build.VERSION.SDK_INT >= 28) surface.lockHardwareCanvas() else surface.lockCanvas(null)
                } catch (e: Exception) {
                    null
                }
                if (c == null) {
                    try {
                        sleep(16)
                    } catch (e: InterruptedException) {
                        return
                    }
                    continue
                }
                val now = System.nanoTime()
                val dt = (now - last) / 1.0e9
                last = now
                try {
                    view.frame(c)
                    if (surfaceReady()) {
                        step(dt)
                        Audio.publish()
                        c.drawColor(BACKGROUND)
                        x.begin(c)
                        draw()
                    }
                } finally {
                    surface.unlockCanvasAndPost(c)
                }
            }
        }

        private fun surfaceReady(): Boolean = W > 0.0 && H > 0.0 && view.surfW > 0
    }

    companion object {
        const val BACKGROUND = -16054494
    }
}
