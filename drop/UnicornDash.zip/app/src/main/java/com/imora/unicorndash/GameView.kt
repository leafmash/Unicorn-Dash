package com.imora.unicorndash

import android.content.Context
import android.graphics.Canvas
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.view.Choreographer
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowInsets
import java.util.concurrent.ConcurrentLinkedQueue

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private val tasks = ConcurrentLinkedQueue<Runnable>()
    private var gameThread: GameThread? = null

    @Volatile private var surfW = 0
    @Volatile private var surfH = 0
    @Volatile private var insL = 0
    @Volatile private var insR = 0
    @Volatile private var dirty = false
    @Volatile private var fastRate = 60f

    init {
        holder.addCallback(this)
        isFocusable = true
        keepScreenOn = true
    }

    fun runOnGame(r: Runnable) {
        tasks.add(r)
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        if (Build.VERSION.SDK_INT >= 28) {
            val c = insets.displayCutout
            insL = c?.safeInsetLeft ?: 0
            insR = c?.safeInsetRight ?: 0
            dirty = true
        }
        return super.onApplyWindowInsets(insets)
    }

    private fun requestFastFrames(surface: Surface) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val d = display
                var rate = 60f
                if (d != null) {
                    for (m in d.supportedModes) if (m.refreshRate > rate) rate = m.refreshRate
                }
                fastRate = rate
                surface.setFrameRate(rate, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
            } catch (e: Exception) {
            }
        }
    }

    private fun lowerFrameRate(surface: Surface) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val next = Math.max(60f, fastRate / 2f)
                fastRate = next
                surface.setFrameRate(next, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
            } catch (e: Exception) {
            }
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        requestFastFrames(holder.surface)
        val t = GameThread(this, holder.surface)
        gameThread = t
        t.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfW = width
        surfH = height
        dirty = true
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        gameThread?.finish()
        gameThread = null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            val id = e.getPointerId(i)
            val px = e.getX(i).toDouble()
            val py = e.getY(i).toDouble()
            tasks.add(Runnable { inputDown(id, px, py) })
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) {
            val i = e.actionIndex
            val id = e.getPointerId(i)
            val px = e.getX(i).toDouble()
            val py = e.getY(i).toDouble()
            tasks.add(Runnable { inputUp(id, px, py, false) })
        } else if (a == MotionEvent.ACTION_CANCEL) {
            val ids = IntArray(e.pointerCount) { e.getPointerId(it) }
            tasks.add(Runnable { for (id in ids) inputUp(id, 0.0, 0.0, true) })
        }
        return true
    }

    fun frame(canvas: Canvas) {
        var r = tasks.poll()
        while (r != null) {
            r.run()
            r = tasks.poll()
        }
        if (dirty) {
            dirty = false
            fitScreen(surfW, surfH, insL, insR)
        }
    }

    private class GameThread(private val view: GameView, private val surface: Surface) {
        @Volatile private var running = true
        private val thread = HandlerThread("ud-game", Process.THREAD_PRIORITY_DISPLAY)
        private var handler: Handler? = null
        private var choreographer: Choreographer? = null
        private var lastNs = 0L
        private var period = 1.0 / 60.0
        private var periodCheck = 0
        private var seen = 0
        private var late = 0

        private val callback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (!running) return
                render(frameTimeNanos)
                if (running) choreographer?.postFrameCallback(this)
            }
        }

        fun start() {
            thread.start()
            val h = Handler(thread.looper)
            handler = h
            h.post {
                period = readPeriod()
                val c = Choreographer.getInstance()
                choreographer = c
                c.postFrameCallback(callback)
            }
        }

        fun finish() {
            running = false
            val h = handler
            h?.post { choreographer?.removeFrameCallback(callback) }
            thread.quitSafely()
            try {
                thread.join(1000)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }

        private fun readPeriod(): Double {
            var rate = 60f
            try {
                val d = view.display
                if (d != null && d.refreshRate > 20f) rate = d.refreshRate
            } catch (e: Exception) {
            }
            return 1.0 / rate.toDouble()
        }

        private fun pace(frameTimeNanos: Long): Double {
            if (lastNs == 0L) {
                lastNs = frameTimeNanos
                return period
            }
            val raw = (frameTimeNanos - lastNs) / 1.0e9
            lastNs = frameTimeNanos
            periodCheck++
            if (periodCheck >= 120) {
                periodCheck = 0
                period = readPeriod()
            }
            if (raw <= 0.0) return period
            seen++
            if (raw > period * 1.6) late++
            if (seen >= 180) {
                if (late > 40 && view.fastRate > 61f) view.lowerFrameRate(surface)
                seen = 0
                late = 0
            }
            val k = Math.round(raw / period).toInt()
            if (k >= 1 && k <= 4 && Math.abs(raw - k * period) < period * 0.22) return k * period
            return raw
        }

        private fun render(frameTimeNanos: Long) {
            val dt = pace(frameTimeNanos)
            val c: Canvas? = try {
                if (Build.VERSION.SDK_INT >= 28) surface.lockHardwareCanvas() else surface.lockCanvas(null)
            } catch (e: Exception) {
                null
            }
            if (c == null) return
            try {
                view.frame(c)
                if (surfaceReady()) {
                    step(dt)
                    publishUi()
                    Audio.publish()
                    Previews.process()
                    c.drawColor(BACKGROUND)
                    x.begin(c)
                    draw()
                }
            } finally {
                surface.unlockCanvasAndPost(c)
            }
        }

        private fun surfaceReady(): Boolean = W > 0.0 && H > 0.0 && view.surfW > 0
    }

    companion object {
        const val BACKGROUND = -16054494
    }
}
