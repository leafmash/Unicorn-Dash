package com.imora.unicorndash

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

fun interface Icon {
    fun draw(px: Double, py: Double, s: Double)
}

val WHITE = hex(0xffffff)
val GOLD = hex(0xffd23f)
val GOLD_DARK = hex(0xffb000)
val LILAC = hex(0x7a62a8)
val PINK_HEART = hex(0xff5a8c)

fun iconCoin(px: Double, py: Double, s: Double) {
    x.fillStyle = GOLD
    x.strokeStyle = GOLD_DARK
    x.lineWidth = max(1.2, s * 0.18)
    x.beginPath()
    x.arc(px, py, s, 0.0, 7.0)
    x.fill()
    x.stroke()
    x.strokeStyle = rgba(255, 176, 0, 0.8)
    x.lineWidth = max(1.0, s * 0.14)
    x.beginPath()
    x.arc(px, py, s * 0.58, 0.0, 7.0)
    x.stroke()
    x.fillStyle = rgba(255, 255, 255, 0.7)
    x.beginPath()
    x.ellipse(px - s * 0.3, py - s * 0.3, s * 0.2, s * 0.32, 0.5, 0.0, 7.0)
    x.fill()
}

fun iconStar(px: Double, py: Double, r: Double, on: Boolean) {
    x.lineJoin = JOIN_ROUND
    x.beginPath()
    for (i in 0 until 10) {
        val rr = if (i % 2 == 1) r * 0.46 else r
        val a = -PI / 2 + i * PI / 5
        x.lineTo(px + cos(a) * rr, py + sin(a) * rr)
    }
    x.closePath()
    if (on) {
        x.fillStyle = GOLD
        x.strokeStyle = GOLD_DARK
    } else {
        x.fillStyle = rgba(255, 255, 255, 0.14)
        x.strokeStyle = rgba(255, 255, 255, 0.34)
    }
    x.lineWidth = max(1.0, r * 0.16)
    x.fill()
    x.stroke()
}

fun iconLock(px: Double, py: Double, s: Double) {
    x.strokeStyle = WHITE
    x.lineWidth = s * 0.26
    x.lineCap = CAP_ROUND
    x.beginPath()
    x.arc(px, py - s * 0.2, s * 0.46, PI, 0.0)
    x.lineTo(px + s * 0.46, py + s * 0.1)
    x.moveTo(px - s * 0.46, py - s * 0.2)
    x.lineTo(px - s * 0.46, py + s * 0.1)
    x.stroke()
    pill(px - s * 0.72, py + s * 0.05, s * 1.44, s, s * 0.22)
    x.fillStyle = WHITE
    x.fill()
    x.fillStyle = LILAC
    x.beginPath()
    x.arc(px, py + s * 0.55, s * 0.13, 0.0, 7.0)
    x.fill()
}

val iconPause = Icon { px, py, s ->
    x.fillStyle = WHITE
    pill(px - s * 0.6, py - s * 0.65, s * 0.4, s * 1.3, s * 0.12)
    x.fill()
    pill(px + s * 0.2, py - s * 0.65, s * 0.4, s * 1.3, s * 0.12)
    x.fill()
}

private fun arrowAt(dir: Double, px: Double, py: Double, s: Double) {
    x.strokeStyle = WHITE
    x.lineWidth = s * 0.3
    x.lineCap = CAP_ROUND
    x.lineJoin = JOIN_ROUND
    x.beginPath()
    x.moveTo(px - dir * s * 0.3, py - s * 0.6)
    x.lineTo(px + dir * s * 0.3, py)
    x.lineTo(px - dir * s * 0.3, py + s * 0.6)
    x.stroke()
}

val iconArrowLeft = Icon { px, py, s -> arrowAt(-1.0, px, py, s) }
val iconArrowRight = Icon { px, py, s -> arrowAt(1.0, px, py, s) }

fun iconArrow(dir: Int): Icon = if (dir < 0) iconArrowLeft else iconArrowRight

val iconSound = Icon { px, py, s ->
    val on = opt.music || opt.sfx
    x.fillStyle = WHITE
    x.beginPath()
    x.moveTo(px - s * 0.7, py - s * 0.28)
    x.lineTo(px - s * 0.35, py - s * 0.28)
    x.lineTo(px + s * 0.05, py - s * 0.62)
    x.lineTo(px + s * 0.05, py + s * 0.62)
    x.lineTo(px - s * 0.35, py + s * 0.28)
    x.lineTo(px - s * 0.7, py + s * 0.28)
    x.closePath()
    x.fill()
    x.lineCap = CAP_ROUND
    x.lineWidth = s * 0.16
    if (on) {
        x.strokeStyle = WHITE
        x.beginPath()
        x.arc(px + s * 0.05, py, s * 0.42, -0.85, 0.85)
        x.stroke()
        x.beginPath()
        x.arc(px + s * 0.05, py, s * 0.78, -0.85, 0.85)
        x.stroke()
    } else {
        x.strokeStyle = hex(0xff8a9a)
        x.beginPath()
        x.moveTo(px + s * 0.3, py - s * 0.3)
        x.lineTo(px + s * 0.85, py + s * 0.3)
        x.moveTo(px + s * 0.85, py - s * 0.3)
        x.lineTo(px + s * 0.3, py + s * 0.3)
        x.stroke()
    }
}

val iconGear = Icon { px, py, s ->
    x.fillStyle = WHITE
    for (i in 0 until 8) {
        x.save()
        x.translate(px, py)
        x.rotate(i * PI / 4)
        x.fillRect(-s * 0.18, -s * 1.02, s * 0.36, s * 0.5)
        x.restore()
    }
    x.beginPath()
    x.arc(px, py, s * 0.74, 0.0, 7.0)
    x.fill()
    x.fillStyle = LILAC
    x.beginPath()
    x.arc(px, py, s * 0.3, 0.0, 7.0)
    x.fill()
}
