package com.imora.unicorndash

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Process

object Audio {
    private val synth = Synth()
    private val direct = DirectEmitter(synth)
    private val music = MusicSeq(direct)
    private val queue = ArrayList<Spec>()
    private val lock = Any()
    private val scratch = ArrayList<Spec>()
    private val pcm = ShortArray(BLOCK)
    private var track: AudioTrack? = null
    private var thread: Thread? = null

    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var musicOn = true
    @Volatile private var sfxOn = true
    @Volatile var stateV = 0
    @Volatile var speedV = 320.0
    @Volatile var tmV = 1.0
    @Volatile var prV = 0
    @Volatile var keyV = 0

    fun applyOptions() {
        musicOn = opt.music
        sfxOn = opt.sfx
    }

    fun publish() {
        stateV = st
        speedV = speed
        tmV = Z.tm
        prV = Z.pr
        keyV = Z.key
    }

    fun sfx(name: String, a: Double) {
        if (!sfxOn || !running) return
        synchronized(lock) {
            scratch.clear()
            buildSfx(name, a, QueueEmitter(scratch))
            for (s in scratch) queue.add(s)
        }
    }

    fun start() {
        if (running) return
        applyOptions()
        val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val size = Math.max(minBuf, BLOCK * 2 * 3)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val fmt = AudioFormat.Builder()
            .setSampleRate(SR)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        val b = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(size)
            .setTransferMode(AudioTrack.MODE_STREAM)
        if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        val t = try {
            b.build()
        } catch (e: Exception) {
            return
        }
        track = t
        running = true
        paused = false
        t.play()
        val th = Thread({ loop(t) }, "ud-audio")
        thread = th
        th.start()
    }

    fun pause() {
        paused = true
    }

    fun resume() {
        paused = false
    }

    fun stop() {
        running = false
        try {
            thread?.join(500)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        thread = null
        try {
            track?.stop()
            track?.release()
        } catch (e: Exception) {
        }
        track = null
        synth.clear()
    }

    private fun loop(t: AudioTrack) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        var pos = 0L
        val pend = ArrayList<Spec>()
        while (running) {
            if (paused) {
                try {
                    t.pause()
                    while (paused && running) Thread.sleep(40)
                    if (running) t.play()
                } catch (e: Exception) {
                    return
                }
                continue
            }
            val now = pos.toDouble() / SR
            pend.clear()
            synchronized(lock) {
                for (s in queue) pend.add(s)
                queue.clear()
            }
            for (s in pend) {
                if (s.noise) synth.puff(s.f, ((now + s.at) * SR).toLong(), s.len, s.vol, s.to, s.att, s.q, s.ft, s.bus)
                else synth.tone(s.f, ((now + s.at) * SR).toLong(), s.len, s.vol, s.type, s.att, s.hold, s.cut, s.cutTo, s.det, s.to, s.bus)
            }
            val state = stateV
            music.tick(now, state, speedV, tmV, prV, keyV, musicOn)
            synth.render(pos, pcm, BLOCK, if (musicOn) 0.9 else 0.0, if (sfxOn) 1.0 else 0.0, music.lowpassTarget(state))
            pos += BLOCK
            val w = t.write(pcm, 0, BLOCK)
            if (w < 0) return
        }
    }
}

fun snd(n: String, a: Double = 0.0) {
    Audio.sfx(n, a)
}
