package com.imora.unicorndash

import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val vigColors = intArrayOf(rgba(10, 4, 40, 0.0), rgba(10, 4, 40, 0.32))
private val vigPos = FloatArray(2)
private var vigShader: Shader? = null
private var vigKey = -1.0

private fun vignette(): Shader {
    val s = vigShader
    if (s != null && vigKey == L) return s
    val r = hypot(L, 360.0) * 0.55
    vigPos[0] = (120.0 / r).toFloat()
    vigPos[1] = 1f
    val n = x.radN(L / 2.0, 180.0, r, vigColors, vigPos)
    vigShader = n
    vigKey = L
    return n
}

private var camZoom = 0.0
private var camLift = 0.0

private fun fullRect() {
    x.fillRect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
}

fun draw() {
    val tSaved = t
    if (st == 1 && cd <= 0.0) t -= STEP * (1.0 - alpha)
    val sp = 1.0 + punch * 0.03 + camZoom
    x.setBaseTransform(u * sp, W / 2.0 * (1.0 - sp), H / 2.0 * (1.0 - sp) + sp * (ty + camLift) * u)
    val rs = if (st == 1 && cd <= 0.0) speed * STEP * (1.0 - alpha) else 0.0
    x.save()
    if (shake > 0.3) x.translate(sin(clock * 71.0) * shake * 0.5, cos(clock * 59.0) * shake * 0.5)
    scene(dist - rs)
    actors(rs)
    ambDraw()
    speedLines()
    x.restore()
    x.fillShader = vignette()
    fullRect()
    if ((slow > 0.0 || skOn("freeze")) && (st == 1 || st == 3)) {
        x.fillStyle = rgba(110, 170, 255, if (skOn("freeze")) 0.16 else min(0.12, slow * 0.06))
        fullRect()
    }
    if (flash > 0.0) {
        x.fillStyle = rgba(255, 60, 100, flash * 0.3)
        fullRect()
    }
    t = tSaved
}

private var dayCheck = 0.0

fun step(dtIn: Double) {
    val dt = min(dtIn, 0.05)
    fdt = dt
    clock += dt
    dayCheck += dt
    if (dayCheck > 30.0) {
        dayCheck = 0.0
        refreshDay()
    }
    if (fadeDir > 0) {
        fade = min(1.0, fade + dt * 5.0)
        if (fade >= 1.0) {
            fadeDir = -1
            val f = fadeCb
            fadeCb = null
            if (f != null) f()
        }
    } else if (fade > 0.0) {
        fade = max(0.0, fade - dt * 3.2)
    }
    var ts2 = 1.0
    if (st == 1) {
        if (cd > 0.0) {
            cd -= dt
            val n = Math.ceil(cd).toInt()
            if (n != cdLast) {
                cdLast = n
                snd("tick", if (n <= 0) 1.0 else 0.0)
            }
            acc = 0.0
            alpha = 1.0
        } else {
            acc += dt
            var n = 0
            while (acc >= STEP - 1.0e-7 && n < 10 && st == 1) {
                update(STEP)
                acc -= STEP
                n++
            }
            if (n == 10 || acc < 0.0) acc = 0.0
            alpha = min(1.0, acc / STEP)
        }
    } else {
        acc = 0.0
        alpha = 1.0
        if (st == 0 || st == 4 || st == 5 || (st >= 6 && st != 14)) {
            t += dt
            if (st == 8) {
                coast = damp(coast, 0.0, 3.4, dt)
                settle(dt)
                val n2 = Math.floor((nowMs() - stAt - 450.0) / 420.0).toInt() + 1
                val r = res
                while (r != null && stSnd < min(3, n2)) {
                    if (r.stars[stSnd]) snd("pop", stSnd.toDouble())
                    stSnd++
                }
            }
            dist += (if (st == 8) coast else if (st == 9) 0.0 else if (st == 0) 12.0 else if (st == 4) 230.0 else 130.0) * dt
            if (st == 0) lobbyTick(dt)
            if (st == 8) runDist += coast * dt
        }
        if (st == 2) {
            ts2 = lerp(0.25, 1.0, easeOut(clamp((nowMs() - endAt) / 700.0, 0.0, 1.0)))
            deadStep(dt)
        }
        if (st == 14) reviveTick(dt)
    }
    if (st == 12 && spinning) spinStep()
    camZoom = damp(camZoom, if (st == 1 && dash > 0.0) 0.045 else 0.0, 5.0, dt)
    camLift = damp(camLift, if (st == 1 || st == 2) clamp(G - p.y, 0.0, 220.0) * 0.04 else 0.0, 7.0, dt)
    if (st != 3) {
        effects(dt * ts2)
        ambStep(dt)
    }
}

private fun spinStep() {
    val seg = TAU / SPIN.size
    val k = clamp((nowMs() - spinT0) / 4200.0, 0.0, 1.0)
    spinA = spinFrom + (spinTo - spinFrom) * (1.0 - Math.pow(1.0 - k, 4.0))
    val ti = floor(spinA / seg).toInt()
    if (ti != spinTick) {
        spinTick = ti
        snd("tick")
    }
    if (k >= 1.0) {
        spinning = false
        spinA = spinTo
        val sg = SPIN[spinIdx]
        say(T(if (sg.hearts) "+{0} hearts" else "+{0} coins", sg.amount))
        snd("gift")
        UiBridge.force = true
    }
}
