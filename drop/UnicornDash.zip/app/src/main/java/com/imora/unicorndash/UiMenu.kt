package com.imora.unicorndash

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val MINT = hex(0x7dffd4)
private val SUN = hex(0xffe27a)
private val SOFT_LILAC = hex(0xd9ccff)
private val TRACK = rgba(255, 255, 255, 0.16)

private fun bar(bx: Double, by: Double, w: Double, h: Double, f: Double, c0: Int, c1: Int, solid: Int = 0) {
    pill(bx, by, w, h, h / 2.0)
    x.fillStyle = TRACK
    x.fill()
    if (f > 0.0) {
        pill(bx, by, max(h, w * f), h, h / 2.0)
        if (solid != 0) x.fillStyle = solid else x.fillShader = x.lin(bx, 0.0, bx + w, 0.0, c0, c1)
        x.fill()
    }
}

fun menu() {
    val cx = L / 2.0
    val x0 = ML
    val cwid = 172.0
    val x1 = L - MR - cwid
    chip(ML + 50.0, 24.0, 100.0, 24.0, T("BEST {0}", best), hex(0xf0e4ff))
    chip(L - MR - 142.0, 24.0, 110.0, 24.0, bank.toString(), SUN, true)
    heartChip(ML + 150.0, 24.0, 74.0, 24.0, "x$hearts")
    ibtn("settings", L - MR - 62.0, 24.0, 17.0, iconGear)
    ibtn("mute", L - MR - 18.0, 24.0, 17.0, iconSound)
    val avail = 2.0 * min(cx - (ML + 108.0), L - MR - 204.0 - cx)
    title("UNICORN DASH", min(30.0, avail / 8.0), cx, 30.0 + sin(clock * 1.6) * 1.5)
    chip(cx, 58.0, 150.0, 20.0, zn(zi), SOFT_LILAC)
    sparkle(cx - 150.0, 32.0, 8.0, 0.0)
    sparkle(cx + 156.0, 40.0, 6.0, 2.0)
    uiPush("pet", cx - 92.0, 118.0, 184.0, 168.0)
    glass(x0, 58.0, cwid, 120.0, 16.0, 0.8)
    label("DAILY MISSIONS", 10.5, x0 + 12.0, 73.0, SUN, ALIGN_LEFT)
    for (i in 0 until 3) {
        val m = MS[todays[i]]
        val yy = 93.0 + i * 28.0
        val done = md[i] != 0
        val f = clamp(mp[i].toDouble() / m.n, 0.0, 1.0)
        val bx = x0 + 12.0
        val bw = 68.0
        fitLabel(m.t, 10.5, x0 + 12.0, yy, if (done) MINT else hex(0xf4ecff), ALIGN_LEFT, cwid - 24.0)
        bar(bx, yy + 10.0, bw, 5.0, f, PINK_TOP, SUN, if (done) MINT else 0)
        label("${min(mp[i], m.n)}/${m.n}", 9.5, bx + bw + 8.0, yy + 12.5, hex(0xc9bdf0), ALIGN_LEFT)
        label(if (done) "DONE" else "+${m.r}", 10.0, x0 + cwid - 10.0, yy + 12.5, if (done) MINT else SUN, ALIGN_RIGHT)
    }
    glass(x1, 58.0, cwid, 120.0, 16.0, 0.8)
    val v = lvOf(xp)
    val f = v.cur.toDouble() / v.need
    label("PLAYER", 10.5, x1 + 12.0, 73.0, SUN, ALIGN_LEFT)
    label(T("LV {0}", v.n), 24.0, x1 + 12.0, 100.0, WHITE, ALIGN_LEFT)
    bar(x1 + 12.0, 120.0, cwid - 24.0, 7.0, f, PINK_TOP, PURPLE_BOT)
    label("${v.cur}/${v.need} XP", 9.5, x1 + cwid - 12.0, 100.0, SOFT_LILAC, ALIGN_RIGHT)
    iconStar(x1 + 20.0, 146.0, 8.0, true)
    label("${totalStars()}/${ZN.size * CFG_LEVELS * 3}", 11.0, x1 + 34.0, 147.0, SUN, ALIGN_LEFT)
    fitLabel(T("Day {0} streak", streak), 10.5, x1 + cwid - 12.0, 147.0, hex(0xffb0cf), ALIGN_RIGHT, 84.0)
    fitLabel(T("{0} of {1} awards", achDone(), ACH.size), 10.0, x1 + 12.0, 166.0, hex(0xa9ffe3), ALIGN_LEFT, cwid - 24.0)
    btn("shop", "SHOP", x0 + 43.0, 202.0, 82.0, 38.0, 's')
    btn("awards", "AWARDS", x0 + cwid - 43.0, 202.0, 82.0, 38.0, 's')
    btn("board", "BOARD", x1 + 43.0, 202.0, 82.0, 38.0, 's')
    btn("spin", "SPIN", x1 + cwid - 43.0, 202.0, 82.0, 38.0, 's')
    if (spinAvail()) {
        x.fillStyle = hex(0xff6fae)
        x.beginPath()
        x.arc(x1 + cwid - 6.0, 187.0, 4.5 + sin(clock * 6.0) * 0.8, 0.0, 7.0)
        x.fill()
    }
    val dc = dcfg()
    val dn = dcDone == day
    btn("daily", "DAILY CHALLENGE", x0 + cwid / 2.0, 252.0, cwid, 36.0, if (dn) 's' else 'g')
    val sub = if (dn) T("DONE") + "  " + dcBest + "/3" else zn(dc.z) + (if (dc.rule.isNotEmpty()) "  -  " + T(ruleLabel(dc.rule)) else "")
    fitLabel(sub, 10.0, x0 + cwid / 2.0, 281.0, if (dn) MINT else SOFT_LILAC, ALIGN_CENTER, cwid)
    btn("adv", "ADVENTURE", cx - 108.0, 322.0, 204.0, 50.0, 'p')
    btn("end", "ENDLESS", cx + 108.0, 322.0, 204.0, 50.0, 'p')
}

fun xpRow(y: Double) {
    val cx = L / 2.0
    val v = lvOf(xp)
    val f = v.cur.toDouble() / v.need
    label(T("LV {0}   +{1} XP", v.n, runXp), 10.5, cx - 100.0, y, SOFT_LILAC, ALIGN_LEFT)
    bar(cx - 100.0, y + 8.0, 200.0, 5.0, f, PINK_TOP, SUN)
}

fun over() {
    val cx = L / 2.0
    val k = clamp((nowMs() - stAt) / 900.0, 0.0, 1.0)
    panel(cx, 168.0, 360.0, 262.0)
    val l = lvl
    if (l != null) {
        title("LEVEL FAILED", 30.0, cx, 70.0)
        label("${floor(clamp(runDist / l.len, 0.0, 1.0) * 100.0 * easeOut(k)).toInt()}%", 54.0, cx, 118.0, WHITE)
        label(if (mode == "daily") T("DAILY CHALLENGE") + "  -  " + zn(zi) else T("{0}  -  Level {1}", zn(zi), li + 1), 12.5, cx, 152.0, SOFT_LILAC)
        tile(cx - 112.0, 190.0, 100.0, 40.0, "COINS", "$got/${l.coins}", SUN)
        tile(cx, 190.0, 100.0, 40.0, "DISTANCE", T("{0} m", floor(runDist / 80.0).toInt()), hex(0x9fefff))
        tile(cx + 112.0, 190.0, 100.0, 40.0, "SCORE", floor(score).toInt().toString(), hex(0xffb0cf))
        xpRow(221.0)
        btn("restart", "RETRY", cx - 76.0, 262.0, 130.0, 44.0, 'p')
        if (mode == "daily") btn("menu", "MENU", cx + 76.0, 262.0, 130.0, 44.0, 's') else btn("lvls", "LEVELS", cx + 76.0, 262.0, 130.0, 44.0, 's')
        return
    }
    title(if (newBest) "NEW BEST!" else "GAME OVER", 30.0, cx, 70.0)
    if (newBest) {
        sparkle(cx - 124.0, 66.0, 8.0, 1.0)
        sparkle(cx + 128.0, 74.0, 8.0, 3.0)
    }
    label(floor(score * easeOut(k)).toInt().toString(), 54.0, cx, 118.0, WHITE)
    val sc = floor(score).toInt()
    label(if (newBest) T("NEW BEST  -  {0}", zn(zi)) else T("{0} pts to beat your best  -  {1}", max(1, eb[zi] - sc), zn(zi)), 12.5, cx, 152.0, SOFT_LILAC)
    tile(cx - 112.0, 190.0, 100.0, 40.0, "COINS", coins.toString(), SUN)
    tile(cx, 190.0, 100.0, 40.0, "DISTANCE", T("{0} m", floor(runDist / 80.0).toInt()), hex(0x9fefff))
    tile(cx + 112.0, 190.0, 100.0, 40.0, "BEST COMBO", "x$runCombo", hex(0xffb0cf))
    xpRow(221.0)
    if (lbRank >= 0) label(T("TOP 10  #{0}", lbRank + 1), 10.5, cx + 100.0, 221.0, SUN, ALIGN_RIGHT)
    btn("restart", "RETRY", cx - 76.0, 262.0, 130.0, 44.0, 'p')
    btn("menu", "MENU", cx + 76.0, 262.0, 130.0, 44.0, 's')
}
