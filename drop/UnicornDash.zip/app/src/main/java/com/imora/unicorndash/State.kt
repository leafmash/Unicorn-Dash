package com.imora.unicorndash

import java.util.Locale

class Opts {
    var music = true
    var sfx = true
    var vib = true
    var ghost = true
    var lang = if (Locale.getDefault().language == "bn") "bn" else "en"
}

class Stats {
    var runs = 0
    var coins = 0
    var dist = 0
    var dodge = 0
    var near = 0
    var pw = 0
    var spins = 0
    var bc = 0
    var time = 0.0
}

class Player {
    var x = 90.0
    var y = G
    var py = G
    var vy = 0.0
    var vx = 0.0
    var air = false
    var jumps = 0
    var duck = false
    var dk = 0.0
    var sq = 1.0
    var ang = 0.0
    var dead = false
    var fall = false
    var rt = 0.0
    var vic = 0
    var vt = 0.0
    var vstart = 1.0
    var rear = 0.0
    var stand = 0
    var apex = false
    var neigh = false
    var happy = false
    var hold = 0.0
    var kind = ""
    var pit0 = 0.0
    var pit1 = 0.0
    var hasPit = false
    var rest = false
    var landed = false
    var bounces = 0
    var spin = 0.0
    var endAng = -2.6
    var jx = 0.0
    var hy = G
}

class Obs(var x: Double, val type: OT, val w: Int, val seed: Double, var v: Double) {
    var pw = 0.0
    var dead = false
    var passed = false
    var nm = false
}

class Item(val k: String, var x: Double, var y: Double, val ph: Double, var v: Double, val bonus: Boolean) {
    var gone = false
}

class Part {
    var x = 0.0
    var y = 0.0
    var vx = 0.0
    var vy = 0.0
    var life = 0.0
    var max = 0.0
    var s = 0.0
    var h = 0.0
    var sat = 0.0
    var lum = 0.0
    var a = 0.0
    var gr = 0.0
}

class TrailPt(var y: Double, var t: Double)

class Amb(var x: Double, var y: Double, var z: Double, var ph: Double)

class Pop(val t: String, var x: Double, var y: Double, var life: Double)

class Toast {
    var text = ""
    var life = 0.0
    var max = 1.8
}

class Banner {
    var text = ""
    var sub = ""
    var life = 0.0
    var max = 2.8
}

class GiftInfo(val amt: Int, val streak: Int)

class ResInfo(val stars: BooleanArray, val n: Int, val bonus: Int, val first: Boolean, val total: Int, val got: Int, val daily: Boolean)

class Ev(val at: Double, val type: OT?, val w: Int, val seed: Double, val pu: String?)

class Level(val sp: Double, val len: Double, val ev: ArrayList<Ev>, val coins: Int, val boss: Boolean, val d: Double, val rule: String)

class Ghost(var s: Double, var d: IntArray, var day: Int)

class LbEntry(val s: Int, val d: Int)

class UiBtn(var id: String, var x: Double, var y: Double, var w: Double, var h: Double)

class Lobby {
    var fx = 1.0
    var tg = 1.0
    var g = 0.0
    var gt = 0.0
    var next = 2.5
    var hop = 0.0
    var nod = 0.0
    var gh = 0.0
}

class Swipe(val id: Int, val x: Double)

class DcCfg(val seed: Int, val z: Int, val l: Int, val rule: String)

val x = Ctx()
val opt = Opts()
var stats = Stats()
var p = Player()
val obs = ArrayList<Obs>()
val items = ArrayList<Item>()
val parts = ArrayList<Part>()
val partPool = ArrayList<Part>()
val pops = ArrayList<Pop>()
val toast = Toast()
val tq = ArrayList<String>()
val banner = Banner()
val lob = Lobby()

var W = 800.0
var H = 360.0
var u = 1.0
var L = 520.0
var ty = 0.0
var padL = 0.0
var padR = 0.0
var ML = 24.0
var MR = 24.0
var coarse = true

var st = 0
var stAt = 0.0
var acc = 0.0
var alpha = 1.0
var endAt = 0.0
var frame = 0
var clock = 0.0
var fdt = 0.016
var cd = 0.0
var cdLast = 0
var ovk = 0.0
var fade = 1.0
var fadeDir = -1
var fadeCb: (() -> Unit)? = null
var lastTs = 0.0

var Z: ZoneObj = zoneObj(0)

var score = 0.0
var shown = 0.0
var coins = 0
var speed = 320.0
var gap = 520.0
var dist = 0.0
var t = 0.0
var shake = 0.0
var flash = 0.0
var combo = 0
var comboT = 0.0
var shield = 0
var magnet = 0.0
var dash = 0.0
var grace = 0.0
var mile = 0
var buffer = 0.0
var runDist = 0.0
var runDodge = 0
var runCombo = 0
var boost = 1.0
var dustT = 0.0
var hint = 0.0
var newBest = false
var hurt = 0
var lq = 0
var dbl = 0.0
var slow = 0.0
var mini = 0.0
var msc = 1.0
var got = 0
var runNear = 0
var rec = IntArray(1600)
var recN = 0
var gAcc = 0.0
var runXp = 0
var lbRank = -1
var pwRain = 0.0
var pwWing = 0.0
var pwSx = 0.0
var pwRainT = 0.0
var buddyKind = ""
var buddyRevive = 0
var budY = G
var skCd = 0.0
var skAct = 0.0
var skFxT = -1.0
var skFlash = 0.0
var petGuard = 0
var catN = 0
var lastT: OT? = null
var lastT2: OT? = null
var lifeAt = 1500.0
var revUsed = 0
var revT = 0.0
var pendHit: Obs? = null
var skillSel = 0
var dRunHome = -1

val trail = ArrayList<TrailPt>()

var best = 0
var bank = 0
var hearts = 0
var own = IntArray(SK.size) { if (it == 0) 1 else 0 }
var ownT = IntArray(TR.size) { if (it == 0) 1 else 0 }
var ownH = IntArray(HR.size) { if (it == 0) 1 else 0 }
var ownP = IntArray(PT.size) { if (it == 0) 1 else 0 }
var ownS = IntArray(SKL.size) { if (it == 0) 1 else 0 }
var skin = 0
var day = 0
var mp = IntArray(3)
var md = IntArray(3)
var shopSel = 0
var todays = intArrayOf(0, 3, 5)
var streak = 0
var lastDay = 0
var gift: GiftInfo? = null
var giftAt = 0.0
var prog = Array(ZN.size) { IntArray(CFG_LEVELS) }
var eb = IntArray(ZN.size)
var lastZ = 0
var xp = 0
var ach = IntArray(64)
var lb = Array(ZN.size) { ArrayList<LbEntry>() }
val gh = HashMap<String, Ghost>()
var spinDay = 0
var apage = 0
var lbz = 0
var ghostD: IntArray? = null
var spinA = 0.0
var spinFrom = 0.0
var spinTo = 0.0
var spinT0 = 0.0
var spinning = false
var spinIdx = -1
var spinTick = 0
var petSel = 0
var dcDone = 0
var dcBest = 0
var dcWins = 0
var dcRule = 0
var dcStreak = 0
var trailSel = 0
var hornSel = 0
var shopTab = 0
var shopPage = 0
var trailT = 0.0
var punch = 0.0

var mode = "end"
var zi = 0
var li = 0
var lvl: Level? = null
var zpage = 0
var zmode = "adv"
var zoff = 0.0
var res: ResInfo? = null
var unl = -1
var pendAct = ""
var coast = 130.0
var stSnd = 0
var swipe: Swipe? = null

val uiPool = ArrayList<UiBtn>()
var uiN = 0
var uiOn = true
var hov = ""
var downId = ""
var bs = HashMap<String, Double>()
var confirmAt = 0.0

val amb = ArrayList<Amb>()

var keyJump = false
var keyDuck = false
var ptrDuck = false
var ptrJumps = 0
val ptrIds = HashMap<Int, Char>()

fun uiPush(id: String, bx: Double, by: Double, bw: Double, bh: Double) {
    if (uiN < uiPool.size) {
        val b = uiPool[uiN]
        b.id = id
        b.x = bx
        b.y = by
        b.w = bw
        b.h = bh
    } else {
        uiPool.add(UiBtn(id, bx, by, bw, bh))
    }
    uiN++
}

fun bsGet(id: String): Double = bs[id] ?: 1.0

fun bsGetOr(id: String, d: Double): Double = bs[id] ?: d

fun say(text: String) {
    tq.add(text)
}

