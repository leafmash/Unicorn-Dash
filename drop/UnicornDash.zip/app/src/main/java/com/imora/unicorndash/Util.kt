package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

const val PI = Math.PI
const val TAU = Math.PI * 2.0

fun hs(n: Double): Double {
    val v = sin(n * 127.1 + 311.7) * 43758.5453
    return v - floor(v)
}

fun hs(n: Int): Double = hs(n.toDouble())

fun clamp(v: Double, a: Double, b: Double): Double = max(a, min(b, v))

fun clampI(v: Int, a: Int, b: Int): Int = max(a, min(b, v))

fun ease(v: Double): Double = v * v * (3.0 - 2.0 * v)

fun easeOut(v: Double): Double = 1.0 - (1.0 - v).pow(3.0)

fun lerp(a: Double, b: Double, k: Double): Double = a + (b - a) * k

fun damp(a: Double, b: Double, r: Double, dt: Double): Double = a + (b - a) * (1.0 - exp(-r * dt))

fun nowMs(): Double = System.nanoTime() / 1.0e6

fun hex(v: Int): Int = v or -16777216

fun rgba(r: Int, g: Int, b: Int, a: Double): Int {
    val ai = (clamp(a, 0.0, 1.0) * 255.0 + 0.5).toInt()
    return (ai shl 24) or (r shl 16) or (g shl 8) or b
}

fun withAlpha(c: Int, a: Double): Int {
    val ai = (clamp(a, 0.0, 1.0) * 255.0 + 0.5).toInt()
    return (ai shl 24) or (c and 0xFFFFFF)
}

private fun hueToRgb(p: Double, q: Double, tIn: Double): Double {
    var t = tIn
    if (t < 0.0) t += 1.0
    if (t > 1.0) t -= 1.0
    if (t < 1.0 / 6.0) return p + (q - p) * 6.0 * t
    if (t < 0.5) return q
    if (t < 2.0 / 3.0) return p + (q - p) * (2.0 / 3.0 - t) * 6.0
    return p
}

fun hsl(hIn: Double, sIn: Double, lIn: Double, a: Double = 1.0): Int {
    var h = hIn % 360.0
    if (h < 0.0) h += 360.0
    h /= 360.0
    val s = clamp(sIn / 100.0, 0.0, 1.0)
    val l = clamp(lIn / 100.0, 0.0, 1.0)
    val r: Double
    val g: Double
    val b: Double
    if (s == 0.0) {
        r = l
        g = l
        b = l
    } else {
        val q = if (l < 0.5) l * (1.0 + s) else l + s - l * s
        val p = 2.0 * l - q
        r = hueToRgb(p, q, h + 1.0 / 3.0)
        g = hueToRgb(p, q, h)
        b = hueToRgb(p, q, h - 1.0 / 3.0)
    }
    val ai = (clamp(a, 0.0, 1.0) * 255.0 + 0.5).toInt()
    return (ai shl 24) or ((r * 255.0 + 0.5).toInt() shl 16) or ((g * 255.0 + 0.5).toInt() shl 8) or (b * 255.0 + 0.5).toInt()
}

fun mod(a: Double, b: Double): Double {
    val r = a % b
    return if (r < 0.0) r + b else r
}

inline fun abs2(v: Double): Double = abs(v)

fun ceilI(v: Double): Int = ceil(v).toInt()

fun floorI(v: Double): Int = floor(v).toInt()

fun roundJs(v: Double): Double = floor(v + 0.5)

fun cosD(v: Double): Double = cos(v)

fun sinD(v: Double): Double = sin(v)

fun rng(seed: Long): () -> Double {
    var s = (seed * 9301L + 49297L) % 2147483647L
    if (s == 0L) s = 1L
    return {
        s = (s * 48271L) % 2147483647L
        s.toDouble() / 2147483647.0
    }
}
