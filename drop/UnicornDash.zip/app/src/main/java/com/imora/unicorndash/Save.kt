package com.imora.unicorndash

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

private var prefs: SharedPreferences? = null

fun initSave(ctx: Context) {
    prefs = ctx.getSharedPreferences("unicorn-dash", Context.MODE_PRIVATE)
}

private fun intArr(a: IntArray): JSONArray {
    val j = JSONArray()
    for (v in a) j.put(v)
    return j
}

fun snapshot(includeGhost: Boolean): JSONObject {
    val o = JSONObject()
    o.put("best", best)
    o.put("bank", bank)
    o.put("hearts", hearts)
    val op = JSONObject()
    op.put("music", opt.music)
    op.put("sfx", opt.sfx)
    op.put("vib", opt.vib)
    op.put("ghost", opt.ghost)
    op.put("lang", opt.lang)
    o.put("opt", op)
    o.put("own", intArr(own))
    o.put("skin", skin)
    o.put("ownT", intArr(ownT))
    o.put("trailSel", trailSel)
    o.put("ownH", intArr(ownH))
    o.put("hornSel", hornSel)
    o.put("day", day)
    o.put("mp", intArr(mp))
    o.put("md", intArr(md))
    o.put("streak", streak)
    o.put("lastDay", lastDay)
    val so = JSONObject()
    so.put("runs", stats.runs)
    so.put("coins", stats.coins)
    so.put("dist", stats.dist)
    so.put("dodge", stats.dodge)
    so.put("near", stats.near)
    so.put("pw", stats.pw)
    so.put("spins", stats.spins)
    so.put("bc", stats.bc)
    so.put("time", stats.time)
    o.put("stats", so)
    val pr = JSONArray()
    for (z in prog) pr.put(intArr(z))
    o.put("prog", pr)
    o.put("eb", intArr(eb))
    o.put("lz", if (dRunHome >= 0) dRunHome else lastZ)
    o.put("xp", xp)
    val ac = JSONArray()
    for (i in ACH.indices) ac.put(ach[i])
    o.put("ach", ac)
    val lbj = JSONArray()
    for (z in lb) {
        val zj = JSONArray()
        for (e in z) {
            val ej = JSONObject()
            ej.put("s", e.s)
            ej.put("d", e.d)
            zj.put(ej)
        }
        lbj.put(zj)
    }
    o.put("lb", lbj)
    if (includeGhost) {
        val gj = JSONObject()
        for ((k, g) in gh) {
            val ge = JSONObject()
            ge.put("s", g.s)
            ge.put("d", intArr(g.d))
            ge.put("day", g.day)
            gj.put(k, ge)
        }
        o.put("gh", gj)
    }
    o.put("spinDay", spinDay)
    o.put("ownP", intArr(ownP))
    o.put("petSel", petSel)
    o.put("dcDone", dcDone)
    o.put("dcBest", dcBest)
    o.put("dcWins", dcWins)
    o.put("dcRule", dcRule)
    o.put("dcStreak", dcStreak)
    o.put("ownS", intArr(ownS))
    o.put("sk2", skillSel)
    return o
}

fun save() {
    val pf = prefs ?: return
    try {
        pf.edit().putString("save", snapshot(true).toString()).apply()
    } catch (e: Exception) {
        return
    }
}

private fun ownFrom(s: JSONObject, key: String, n: Int): IntArray {
    val a = s.optJSONArray(key)
    return IntArray(n) { i -> if (i == 0 || (a != null && a.optInt(i, 0) != 0)) 1 else 0 }
}

private fun intList(a: JSONArray?, n: Int): IntArray {
    return IntArray(n) { i -> if (a != null) a.optInt(i, 0) else 0 }
}

fun applySave(s: JSONObject) {
    best = s.optInt("best", 0)
    bank = s.optInt("bank", 0)
    hearts = s.optInt("hearts", 0)
    val op = s.optJSONObject("opt")
    if (op != null) {
        opt.music = op.optBoolean("music", opt.music)
        opt.sfx = op.optBoolean("sfx", opt.sfx)
        opt.vib = op.optBoolean("vib", opt.vib)
        opt.ghost = op.optBoolean("ghost", opt.ghost)
        val lg = op.optString("lang", opt.lang)
        opt.lang = if (lg == "bn") "bn" else "en"
    } else if (s.optBoolean("muted", false)) {
        opt.music = false
        opt.sfx = false
    }
    own = ownFrom(s, "own", SK.size)
    val sk = s.optInt("skin", 0)
    skin = if (sk in own.indices && own[sk] != 0) sk else 0
    ownT = ownFrom(s, "ownT", TR.size)
    val ts = s.optInt("trailSel", 0)
    trailSel = if (ts in ownT.indices && ownT[ts] != 0) ts else 0
    ownH = ownFrom(s, "ownH", HR.size)
    val hsel = s.optInt("hornSel", 0)
    hornSel = if (hsel in ownH.indices && ownH[hsel] != 0) hsel else 0
    ownP = ownFrom(s, "ownP", PT.size)
    val ps = s.optInt("petSel", 0)
    petSel = if (ps in ownP.indices && ownP[ps] != 0) ps else 0
    dcDone = s.optInt("dcDone", 0)
    dcBest = s.optInt("dcBest", 0)
    dcWins = s.optInt("dcWins", 0)
    dcRule = s.optInt("dcRule", 0)
    dcStreak = s.optInt("dcStreak", 0)
    ownS = ownFrom(s, "ownS", SKL.size)
    val ss = s.optInt("sk2", 0)
    skillSel = if (ss in ownS.indices && ownS[ss] != 0) ss else 0
    day = s.optInt("day", 0)
    mp = intList(s.optJSONArray("mp"), 3)
    md = intList(s.optJSONArray("md"), 3)
    streak = s.optInt("streak", 0)
    lastDay = s.optInt("lastDay", 0)
    val st2 = Stats()
    val so = s.optJSONObject("stats")
    if (so != null) {
        st2.runs = so.optInt("runs", 0)
        st2.coins = so.optInt("coins", 0)
        st2.dist = so.optInt("dist", 0)
        st2.dodge = so.optInt("dodge", 0)
        st2.near = so.optInt("near", 0)
        st2.pw = so.optInt("pw", 0)
        st2.spins = so.optInt("spins", 0)
        st2.bc = so.optInt("bc", 0)
        st2.time = so.optDouble("time", 0.0)
    }
    stats = st2
    val pr = s.optJSONArray("prog")
    if (pr != null) {
        prog = Array(ZN.size) { i ->
            val row = pr.optJSONArray(i)
            IntArray(CFG_LEVELS) { k -> clampI(if (row != null) row.optInt(k, 0) else 0, 0, 3) }
        }
    }
    val ebj = s.optJSONArray("eb")
    if (ebj != null) {
        eb = IntArray(ZN.size) { i -> ebj.optInt(i, 0) }
    } else {
        eb = IntArray(ZN.size)
        eb[0] = best
    }
    lastZ = clampI(s.optInt("lz", 0), 0, ZN.size - 1)
    xp = Math.max(0, s.optInt("xp", 0))
    spinDay = s.optInt("spinDay", 0)
    val gj = s.optJSONObject("gh")
    if (gj != null) {
        gh.clear()
        val it = gj.keys()
        while (it.hasNext()) {
            val k = it.next()
            val ge = gj.optJSONObject(k) ?: continue
            val da = ge.optJSONArray("d") ?: continue
            gh[k] = Ghost(ge.optDouble("s", 0.0), IntArray(da.length()) { i -> da.optInt(i, 0) }, ge.optInt("day", 0))
        }
    }
    val aj = s.optJSONArray("ach")
    ach = IntArray(64)
    for (i in ACH.indices) ach[i] = if (aj != null && aj.optInt(i, 0) != 0) 1 else 0
    val lj = s.optJSONArray("lb")
    lb = Array(ZN.size) { i ->
        val list = ArrayList<LbEntry>()
        val zj = if (lj != null) lj.optJSONArray(i) else null
        if (zj != null) {
            var n = 0
            while (n < zj.length() && n < 10) {
                val ej = zj.optJSONObject(n)
                if (ej != null) list.add(LbEntry(ej.optInt("s", 0), ej.optInt("d", 0)))
                n++
            }
        }
        list
    }
    unlockCosmetics(true)
    if (!zoneOpen(lastZ)) lastZ = 0
}

fun loadSave() {
    val pf = prefs
    try {
        val txt = if (pf != null) pf.getString("save", null) else null
        if (txt != null) applySave(JSONObject(txt))
    } catch (e: Exception) {
        best = Math.max(best, 0)
    }
    if (!zoneOpen(lastZ)) lastZ = 0
}

fun codeHash(str: String): String {
    var h = 5381L
    for (ch in str) {
        h = (((h shl 5) + h + ch.code.toLong()) and 0xFFFFFFFFL)
    }
    return java.lang.Long.toString(h, 36)
}

fun makeCode(): String {
    val o = snapshot(false)
    val b = Base64.encodeToString(o.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    return "UD1." + b + "." + codeHash(b)
}

fun readCode(c: String): JSONObject? {
    val m = c.trim().split(".")
    if (m.size != 3 || m[0] != "UD1" || codeHash(m[1]) != m[2]) return null
    return try {
        val txt = String(Base64.decode(m[1], Base64.DEFAULT), Charsets.UTF_8)
        val o = JSONObject(txt)
        if (o.optJSONArray("prog") != null) o else null
    } catch (e: Exception) {
        null
    }
}
