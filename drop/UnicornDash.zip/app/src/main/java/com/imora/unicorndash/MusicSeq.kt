package com.imora.unicorndash

import kotlin.math.pow

private fun hz(n: Int): Double = 261.63 * 2.0.pow(n / 12.0)

class MusicSeq(private val em: Emitter) {
    private var nextT = 0.0
    private var stp = 0
    private var inten = 0.0
    private var key = 0

    fun lowpassTarget(state: Int): Double = if (state == 3 || state == 14) 650.0 else 18000.0

    fun tick(now: Double, state: Int, speedV: Double, tm: Double, pr: Int, zoneKey: Int, enabled: Boolean) {
        if (!enabled) return
        if (nextT < now) nextT = now + 0.06
        val tgt = if (state == 1) 1.0 else if (state == 3 || state == 14) 0.1 else if (state == 2) 0.0 else 0.35
        inten += (tgt - inten) * 0.12
        val sn = if (state == 1 || state == 3) clamp((speedV - 320.0) / 380.0, 0.0, 1.0) else 0.0
        val dur = (0.15 - 0.026 * sn) * tm
        while (nextT < now + 0.25) {
            val i = stp % 16
            val bar = ((stp shr 4) + pr) % 4
            val cyc = (stp shr 6) and 1
            val at = nextT + (if (i % 2 == 1) dur * 0.1 else 0.0)
            val ch = CH[bar]
            if (i == 0) {
                key = zoneKey
                for (n in ch) {
                    em.tone(f = hz(n + key), at = at, len = dur * 17.0, hold = dur * 10.0, att = 0.6, type = OSC_TRI, vol = 0.026, det = 6.0, cut = 1200.0, bus = BUS_MUS)
                }
                em.tone(f = hz(ch[0] + key - 12), at = at, len = dur * 17.0, hold = dur * 10.0, att = 0.5, vol = 0.05, bus = BUS_MUS)
            }
            if (i == 0 || i == 6 || i == 8 || i == 14) {
                em.tone(f = hz(ch[0] + key - 12), at = at, len = dur * 3.0, type = OSC_TRI, vol = 0.08 + 0.05 * inten, att = 0.01, cut = 900.0, bus = BUS_MUS)
            }
            if (i % 2 == 0) {
                val order = intArrayOf(0, 1, 2, 1, 0, 2, 1, 2)
                val idx = order[i shr 1]
                val n = ch[idx] + 12 + (if (cyc == 1 && idx == 2) 12 else 0)
                em.tone(f = hz(n + key), at = at, len = dur * 2.6, type = OSC_TRI, vol = 0.026 + 0.018 * inten, att = 0.004, cut = 3600.0, cutTo = 800.0, det = 4.0, bus = BUS_MUS)
            }
            for (m in MEL[bar]) {
                if (m[0] != i) continue
                val f = hz(m[1] + key + (if (cyc == 1) 12 else 0))
                em.tone(f = f, at = at, len = dur * 6.0, vol = 0.04, att = 0.012, bus = BUS_MUS)
                em.tone(f = f * 2.0, at = at, len = dur * 3.0, vol = 0.01, att = 0.01, bus = BUS_MUS)
            }
            if (inten > 0.5) {
                val d = inten
                if (i % 4 == 0) em.tone(f = 140.0, to = 44.0, at = at, len = 0.22, vol = 0.26 * d, att = 0.003, bus = BUS_MUS)
                if (i == 4 || i == 12) {
                    em.puff(f = 2200.0, q = 0.7, at = at, len = 0.13, vol = 0.07 * d, bus = BUS_MUS)
                    em.tone(f = 190.0, to = 120.0, at = at, len = 0.1, type = OSC_TRI, vol = 0.05 * d, bus = BUS_MUS)
                }
                if (i % 2 == 1) em.puff(f = 9000.0, ft = FLT_HIGH, q = 0.4, at = at, len = 0.04, vol = 0.03 * d, bus = BUS_MUS)
                if (i % 8 == 6) em.puff(f = 8000.0, ft = FLT_HIGH, q = 0.4, at = at, len = 0.16, vol = 0.025 * d, bus = BUS_MUS)
            }
            nextT += dur
            stp++
        }
    }
}
