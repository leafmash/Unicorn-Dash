package com.imora.unicorndash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SkillButton(s: Snap) {
    val tr = rememberInfiniteTransition(label = "skill")
    val pulse by tr.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "pulse"
    )
    var pressed by remember { mutableStateOf(false) }
    val hue = hueColor(s.skHue, 100.0, if (s.skReady) 76.0 else 62.0)
    val frac by animateFloatAsState(s.skF.toFloat(), tween(120), label = "skf")
    val target = if (pressed) 0.86f else if (s.skReady) pulse else 1f
    val scale by animateFloatAsState(target, spring(dampingRatio = 0.5f, stiffness = 700f), label = "sksc")
    Box(
        modifier = Modifier
            .size(66.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .pointerInput(s.skReady) {
                detectTapGestures(onPress = {
                    pressed = true
                    if (s.skReady) {
                        UiBridge.tap()
                        UiBridge.fire("skill")
                    }
                    tryAwaitRelease()
                    pressed = false
                })
            },
        contentAlignment = Alignment.Center
    ) {
        if (s.skReady) PulseGlow(hueColor(s.skHue), Modifier.alpha(0.9f), 52.dp)
        Box(
            Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(Color(0xD11E1050))
                .border(1.2.dp, Color(0x55FFFFFF), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize().padding(3.dp)) {
                val sw = 5.dp.toPx()
                drawArc(Color(0x29FFFFFF), 0f, 360f, false, style = Stroke(sw))
                drawArc(
                    if (s.skActive) Color.White else hue,
                    -90f,
                    360f * frac.coerceIn(0f, 1f),
                    false,
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
            SkillGlyph(s.skKey, hue, if (s.skReady || s.skActive) 1f else 0.4f)
            if (s.skCd > 0) Tx(s.skCd.toString(), 17f)
        }
    }
}

@Composable
fun SkillGlyph(key: String, color: Color, a: Float) {
    Canvas(Modifier.size(30.dp).alpha(a)) {
        val w = size.width
        val h = size.height
        val sw = w * 0.1f
        when (key) {
            "dash" -> {
                for (i in 0 until 3) {
                    drawLine(color, Offset(w * 0.1f, h * (0.3f + i * 0.2f)), Offset(w * (0.55f + (1 - i % 2) * 0.1f), h * (0.3f + i * 0.2f)), sw, StrokeCap.Round)
                }
                drawCircle(color, w * 0.14f, Offset(w * 0.78f, h * 0.5f))
            }
            "candy" -> {
                drawCircle(color, w * 0.22f, Offset(w * 0.5f, h * 0.5f))
                drawLine(color, Offset(w * 0.14f, h * 0.5f), Offset(w * 0.28f, h * 0.5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.72f, h * 0.5f), Offset(w * 0.86f, h * 0.5f), sw, StrokeCap.Round)
            }
            "aura" -> {
                drawArc(color, 0f, 360f, false, Offset(w * 0.18f, h * 0.18f), Size(w * 0.64f, h * 0.64f), style = Stroke(sw))
                drawCircle(color, w * 0.1f, Offset(w * 0.5f, h * 0.5f))
            }
            "moon" -> {
                drawArc(color, 120f, 300f, false, Offset(w * 0.2f, h * 0.15f), Size(w * 0.6f, h * 0.7f), style = Stroke(sw * 1.4f, cap = StrokeCap.Round))
            }
            "freeze" -> {
                for (i in 0 until 3) {
                    val a = (i * Math.PI / 3).toFloat()
                    drawLine(
                        color,
                        Offset(w * 0.5f + cos(a) * w * 0.34f, h * 0.5f + sin(a) * h * 0.34f),
                        Offset(w * 0.5f - cos(a) * w * 0.34f, h * 0.5f - sin(a) * h * 0.34f),
                        sw,
                        StrokeCap.Round
                    )
                }
            }
            "fire" -> {
                drawCircle(color, w * 0.2f, Offset(w * 0.5f, h * 0.62f))
                drawCircle(color, w * 0.12f, Offset(w * 0.5f, h * 0.3f))
            }
            "blast" -> {
                drawCircle(color, w * 0.16f, Offset(w * 0.5f, h * 0.5f))
                for (i in 0 until 8) {
                    val a = (i * Math.PI / 4).toFloat()
                    drawLine(
                        color,
                        Offset(w * 0.5f + cos(a) * w * 0.26f, h * 0.5f + sin(a) * h * 0.26f),
                        Offset(w * 0.5f + cos(a) * w * 0.42f, h * 0.5f + sin(a) * h * 0.42f),
                        sw,
                        StrokeCap.Round
                    )
                }
            }
            else -> {
                drawPath(starPath(w * 0.5f, h * 0.5f, w * 0.4f), color)
            }
        }
    }
}

@Composable
fun PowerRing(p: UPower) {
    val color = hueColor(p.hue, 100.0, 72.0)
    val f by animateFloatAsState(p.frac.toFloat(), tween(120), label = "pf")
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color(0xB31E1050)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().padding(2.dp)) {
            val sw = 3.dp.toPx()
            drawArc(Color(0x29FFFFFF), 0f, 360f, false, style = Stroke(sw))
            drawArc(color, -90f, 360f * f, false, style = Stroke(sw, cap = StrokeCap.Round))
        }
        SkillGlyph(
            when (p.key) {
                "shield" -> "aura"
                "magnet" -> "candy"
                "star" -> "dash"
                "slow" -> "freeze"
                "mini" -> "moon"
                "rain" -> "candy"
                "wings" -> "moon"
                "sx2" -> "blast"
                else -> "x"
            },
            color,
            1f
        )
    }
}

@Composable
fun ComboBadge(s: Snap) {
    if (s.combo <= 1) return
    val pop = remember { Animatable(1f) }
    LaunchedEffect(s.combo) {
        pop.snapTo(1.4f)
        pop.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = 500f))
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth.toFloat()
        val hPx = constraints.maxHeight.toFloat()
        Box(
            Modifier
                .size(56.dp)
                .graphicsLayer {
                    translationX = UiBridge.comboX.floatValue * wPx - 28.dp.toPx()
                    translationY = UiBridge.comboY.floatValue * hPx - 28.dp.toPx()
                    scaleX = pop.value
                    scaleY = pop.value
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 3.dp.toPx()
                drawArc(Color(0x33FFFFFF), 0f, 360f, false, style = Stroke(sw))
                drawArc(Color(0xE6FFE27A), -90f, 360f * s.comboF.toFloat(), false, style = Stroke(sw, cap = StrokeCap.Round))
            }
            Tx("x${s.combo}", (17 + s.combo).coerceAtMost(26).toFloat(), color = Color(0xFFFFE27A))
        }
    }
}

@Composable
fun Hud(s: Snap) {
    val margin = 14.dp
    ComboBadge(s)
    Box(Modifier.fillMaxSize().padding(horizontal = margin, vertical = 10.dp)) {
        Column(Modifier.align(Alignment.TopStart)) {
            Tx(s.score.toString(), 34f)
            Tx(s.sub, 12f, color = Color(0xFFE9DCFF), weight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Pill(height = 26.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CoinIcon(16.dp)
                    Spacer(Modifier.width(6.dp))
                    Tx(if (s.levelMode) "${s.got}/${s.levelCoins}" else s.runCoins.toString(), 13f, color = Color(0xFFFFE27A))
                }
            }
            if (s.powers.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (p in s.powers) PowerRing(p)
                }
            }
        }

        Column(Modifier.align(Alignment.TopCenter), horizontalAlignment = Alignment.CenterHorizontally) {
            if (!s.levelMode) {
                HeartPill(s.hearts, height = 26.dp)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Bar(s.progress.toFloat(), Modifier.width(150.dp), 8.dp, GoldBrush)
                    Spacer(Modifier.width(8.dp))
                    StarIcon(18.dp, s.progress >= 1.0)
                }
                if (s.rule.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Tx(s.rule, 11f, color = Pal.Rose)
                }
            }
        }

        Column(Modifier.align(Alignment.TopEnd), horizontalAlignment = Alignment.End) {
            RoundBtn(40.dp, onClick = { UiBridge.fire("pause") }) { PauseIcon(20.dp) }
            Spacer(Modifier.height(6.dp))
            Tx(T("{0} m", s.dist), 12f, color = Color(0xFFE9DCFF), weight = FontWeight.Bold)
        }

        Box(Modifier.align(Alignment.BottomEnd).padding(bottom = 4.dp)) { SkillButton(s) }

        if (s.bannerA > 0.01) {
            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 64.dp)
                    .alpha(s.bannerA.toFloat())
                    .graphicsLayer { translationY = (1f - s.bannerA.toFloat()) * 14f },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Tx(s.bannerSub, 12f, color = Color(0xFFFFE27A))
                GradText(s.bannerText, 30f)
            }
        }

        if (s.hintA > 0.01) {
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = 6.dp)
                    .alpha(s.hintA.toFloat() * 0.85f),
                horizontalArrangement = Arrangement.spacedBy(70.dp)
            ) {
                Glass(radius = 14.dp) { Tx(if (s.coarse) "HOLD TO DUCK" else "DOWN = DUCK", 12f, Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) }
                Glass(radius = 14.dp) { Tx(if (s.coarse) "TAP TO JUMP" else "SPACE = JUMP", 12f, Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) }
            }
        }
    }
}

@Composable
fun Countdown(s: Snap) {
    if (s.cdN <= 0) return
    val f = s.cdF.toFloat()
    val sc = 1.5f - 0.5f * (1f - (1f - f) * (1f - f) * (1f - f))
    val a = 1f - ((f - 0.6f) / 0.4f).coerceIn(0f, 1f)
    Box(Modifier.fillMaxSize().background(Color(0x47140A33)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Tx("GET READY", 16f, color = Color(0xFFFFE27A))
            Box(
                Modifier.graphicsLayer {
                    scaleX = sc
                    scaleY = sc
                    alpha = a
                }
            ) { GradText(s.cdN.toString(), 96f) }
        }
    }
}

@Composable
fun ToastLayer(s: Snap) {
    if (s.toast.isEmpty() || s.toastK <= 0.0) return
    val k = s.toastK.toFloat()
    val inn = ((1f - k) * 8f).coerceIn(0f, 1f)
    val out = (k * 5f).coerceIn(0f, 1f)
    val a = if (inn < out) inn else out
    val top = s.st == 1
    Box(Modifier.fillMaxSize().padding(top = if (top) 70.dp else 14.dp, bottom = 16.dp)) {
        Box(
            Modifier
                .align(if (top || s.st == 0) Alignment.TopCenter else Alignment.BottomCenter)
                .alpha(a)
                .graphicsLayer { translationY = (1f - inn) * -20f }
        ) {
            Glass(radius = 18.dp) {
                Tx(s.toast, 14f, Modifier.padding(horizontal = 18.dp, vertical = 8.dp), align = TextAlign.Center)
            }
        }
    }
}
