package com.imora.unicorndash

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay

@Composable
fun snapFor(key: Int): Snap {
    val cur = UiBridge.snap.value
    val ref = remember { arrayOfNulls<Snap>(1) }
    if (cur.st == key) ref[0] = cur
    return ref[0] ?: cur
}

@Composable
fun Gate(stAtMs: Double, content: @Composable () -> Unit) {
    val ready by produceState(nowMs() >= stAtMs, stAtMs) {
        val d = stAtMs - nowMs()
        if (d > 0.0) delay(d.toLong())
        value = true
    }
    if (ready) content()
}

@Composable
fun UiRoot() {
    val s = UiBridge.snap.value
    val dim by animateFloatAsState(
        targetValue = when (s.st) {
            4 -> 0.6f
            5, 6, 7, 10, 11, 12, 13 -> 0.85f
            else -> 0f
        },
        animationSpec = tween(300),
        label = "dim"
    )
    Box(Modifier.fillMaxSize()) {
        if (dim > 0.01f) Scrim(dim)
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout)) {
            AnimatedVisibility(
                visible = s.st == 1 || s.st == 3 || s.st == 14,
                enter = fadeIn(tween(220)),
                exit = fadeOut(tween(260))
            ) {
                Hud(UiBridge.snap.value)
            }
            Countdown(s)
            AnimatedContent(
                targetState = s.st,
                transitionSpec = {
                    (fadeIn(tween(260, 90)) + scaleIn(tween(260, 90), 0.96f)) togetherWith fadeOut(tween(140))
                },
                label = "screens"
            ) { st ->
                val sn = snapFor(st)
                when (st) {
                    0 -> MenuScreen(sn)
                    2 -> Gate(sn.stAtMs) { OverScreen(sn) }
                    3 -> PauseScreen(sn)
                    4 -> ShopScreen(sn)
                    5 -> SettingsScreen(sn)
                    6 -> ZonesScreen(sn)
                    7 -> LevelsScreen(sn)
                    8 -> Gate(sn.stAtMs) { CompleteScreen(sn) }
                    9 -> UnlockScreen(sn)
                    10 -> AwardsScreen(sn)
                    11 -> BoardScreen(sn)
                    12 -> SpinScreen(sn)
                    13 -> StatsScreen(sn)
                    14 -> ReviveScreen(sn)
                    else -> Box(Modifier.fillMaxSize())
                }
            }
            AnimatedVisibility(visible = s.giftOn && s.st == 0, enter = fadeIn(tween(250)), exit = fadeOut(tween(200))) {
                GiftDialog(UiBridge.snap.value)
            }
            ToastLayer(s)
        }
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = UiBridge.fade.floatValue }
                .background(Color(0xFF0B0722))
        )
    }
}
