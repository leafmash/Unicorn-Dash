package com.imora.unicorndash

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Alignment
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import kotlinx.coroutines.delay

@Composable
fun snapFor(key: Int): Snap {
    val cur = UiBridge.snap.value
    val ref = remember { arrayOfNulls<Snap>(1) }
    if (cur.st == key) ref[0] = cur
    return ref[0] ?: cur
}

@Composable
fun Gate(stAtMs: Double, content: @Composable () -> Unit) {
    val ready by produceState(nowMs() >= stAtMs, stAtMs) {
        val d = stAtMs - nowMs()
        if (d > 0.0) delay(d.toLong())
        value = true
    }
    if (ready) content()
}

@Composable
fun UiRoot() {
    val s = UiBridge.snap.value
    val sys = LocalDensity.current
    var missionsOpen by remember { mutableStateOf(false) }
    var booting by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(2100)
        booting = false
    }
    val showMissions = missionsOpen && s.st == 0
    BackHandler(enabled = showMissions) { missionsOpen = false }
    CompositionLocalProvider(LocalDensity provides Density(sys.density, 1f)) {
        val open by produceState(nowMs() >= s.stAtMs, s.st, s.stAtMs) {
            val d = s.stAtMs - nowMs()
            value = d <= 0.0
            if (d > 0.0) {
                delay(d.toLong())
                value = true
            }
        }
        val giftUp = s.giftOn && s.st == 0
        val dim by animateFloatAsState(
            targetValue = when (s.st) {
                2 -> if (open) 0.9f else 0f
                8 -> if (open) 0.88f else 0f
                4 -> 0.6f
                14 -> 0.7f
                3, 5, 6, 7, 9, 10, 11, 12, 13 -> 1f
                else -> if (giftUp) 1f else 0f
            },
            animationSpec = tween(300),
            label = "dim"
        )
        val tone = when (s.st) {
            9 -> 2
            5, 6, 7, 10, 11, 12, 13 -> 3
            else -> 1
        }
        Box(Modifier.fillMaxSize()) {
            if (dim > 0.01f) Scrim(dim, tone)
            Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout)) {
                AnimatedVisibility(
                    visible = s.st == 1 || s.st == 3 || s.st == 14,
                    enter = fadeIn(tween(220)),
                    exit = fadeOut(tween(260))
                ) {
                    Hud(UiBridge.snap.value)
                }
                Countdown(s)
                AnimatedContent(
                    targetState = s.st,
                    transitionSpec = {
                        (fadeIn(tween(260, 90)) + scaleIn(tween(260, 90), 0.96f)) togetherWith fadeOut(tween(140))
                    },
                    label = "screens"
                ) { st ->
                    val sn = snapFor(st)
                    when (st) {
                        0 -> MenuScreen(sn) { missionsOpen = true }
                        2 -> Gate(sn.stAtMs) { OverScreen(sn) }
                        3 -> PauseScreen(sn)
                        4 -> ShopScreen(sn)
                        5 -> SettingsScreen(sn)
                        6 -> ZonesScreen(sn)
                        7 -> LevelsScreen(sn)
                        8 -> Gate(sn.stAtMs) { CompleteScreen(sn) }
                        9 -> UnlockScreen(sn)
                        10 -> AwardsScreen(sn)
                        11 -> BoardScreen(sn)
                        12 -> SpinScreen(sn)
                        13 -> StatsScreen(sn)
                        14 -> ReviveScreen(sn)
                        else -> Box(Modifier.fillMaxSize())
                    }
                }
                AnimatedVisibility(visible = giftUp, enter = fadeIn(tween(250)), exit = fadeOut(tween(200))) {
                    GiftDialog(UiBridge.snap.value)
                }
                ToastLayer(s)
            }
            AnimatedVisibility(visible = showMissions, enter = fadeIn(tween(200)), exit = fadeOut(tween(160))) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0xB3140A33))
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { missionsOpen = false },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        Modifier
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                            .popIn(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        MissionsCard(UiBridge.snap.value, true, Modifier.width(380.dp))
                        Spacer(Modifier.height(10.dp))
                        GButton("CLOSE", Modifier.width(150.dp), Kind.Soft, 40.dp, 14f) { missionsOpen = false }
                    }
                }
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = UiBridge.fade.floatValue }
                    .background(Color(0xFF0B0722))
            )
            AnimatedVisibility(visible = booting, exit = fadeOut(tween(450))) {
                LoadingScreen()
            }
        }
    }
}
