package com.imora.unicorndash

private val BN1 = mapOf(
    "Rainbow Meadow" to "রংধনু মাঠ", "Candy Clouds" to "ক্যান্ডি মেঘ", "Starlight Night" to "তারার রাত", "Frozen Peaks" to "বরফের চূড়া",
    "Sunset Dunes" to "সূর্যাস্তের বালিয়াড়ি", "Ember Realm" to "অঙ্গার রাজ্য", "Crystal Caves" to "স্ফটিক গুহা", "Enchanted Forest" to "মায়াবী বন",
    "Cloud Kingdom" to "মেঘের রাজ্য", "Neon City" to "নিয়ন শহর", "Deep Ocean" to "গভীর সাগর", "Autumn Hills" to "শরতের পাহাড়",
    "Desert Oasis" to "মরুদ্যান", "Haunted Mist" to "ভুতুড়ে কুয়াশা", "Space Rings" to "মহাকাশ বলয়", "Rainbow Waterfall" to "রংধনু ঝর্ণা",
    "Moon Garden" to "চাঁদের বাগান", "Golden Temple" to "সোনালি মন্দির",
    "Classic" to "ক্লাসিক", "Sunny" to "রোদেলা", "Candy" to "ক্যান্ডি", "Frost" to "তুষার", "Galaxy" to "গ্যালাক্সি", "Aurora" to "অরোরা", "Ember" to "অঙ্গার", "Moonlit" to "জ্যোৎস্না",
    "Rainbow" to "রংধনু", "Stardust" to "তারার ধুলো", "Flame" to "আগুন", "Neon" to "নিয়ন", "Golden" to "সোনালি", "Crystal" to "স্ফটিক", "Candy Cane" to "ক্যান্ডি কেন", "Starlight" to "তারা-আলো",
    "BEST {0}" to "সেরা {0}", "LV {0}" to "লেভেল {0}", "UNICORN DASH" to "ইউনিকর্ন ড্যাশ", "DAILY MISSIONS" to "দৈনিক মিশন", "Day {0} streak" to "{0} দিনের স্ট্রিক", "DONE" to "সম্পন্ন", "PLAYER" to "প্লেয়ার", "{0} of {1} awards" to "{0}/{1} অ্যাওয়ার্ড",
    "SHOP" to "দোকান", "AWARDS" to "পুরস্কার", "BOARD" to "র‍্যাংক", "SPIN" to "স্পিন", "ADVENTURE" to "অ্যাডভেঞ্চার", "ENDLESS" to "অন্তহীন",
    "CLOSE" to "বন্ধ", "Award ready: {0}" to "অ্যাওয়ার্ড তৈরি: {0}", "Loading..." to "লোড হচ্ছে...", "Hold the screen to jump higher" to "স্ক্রিন চেপে ধরলে লাফ উঁচু হয়", "Collect coins to unlock new unicorns" to "কয়েন জমিয়ে নতুন ইউনিকর্ন আনলক করো", "Finish the daily challenge for a bonus" to "দৈনিক চ্যালেঞ্জ শেষ করলে বোনাস মেলে", "Claim your awards from the Awards page" to "পুরস্কার পেজ থেকে অ্যাওয়ার্ড ক্লেম করো", "Near misses build your combo" to "কাছাকাছি এড়ালে কম্বো বাড়ে",
    "Collect 40 coins in one run" to "এক রানে 40টা কয়েন তোলো", "Score 600 in one run" to "এক রানে 600 স্কোর করো", "Dodge 40 obstacles today" to "আজ 40টা বাধা এড়াও",
    "Double jump 25 times today" to "আজ 25 বার ডাবল জাম্প দাও", "Collect 120 coins today" to "আজ 120টা কয়েন তোলো", "Play 5 runs today" to "আজ 5টা রান খেলো",
    "Hit a x5 coin combo 3 times" to "3 বার x5 কয়েন কম্বো করো", "Grab 4 power-ups today" to "আজ 4টা পাওয়ার-আপ নাও",
    "Mission done +{0}" to "মিশন সম্পন্ন +{0}", "Level up! LV {0}  +{1}" to "লেভেল আপ! {0}  +{1}", "Award: {0}  +{1}" to "পুরস্কার: {0}  +{1}",
    "Come back tomorrow" to "কাল আবার এসো", "Shield ready" to "ঢাল প্রস্তুত", "Magnet on" to "চুম্বক চালু", "Double coins" to "ডাবল কয়েন", "Slow motion" to "স্লো মোশন",
    "Mini unicorn" to "মিনি ইউনিকর্ন", "Rainbow Dash" to "রেইনবো ড্যাশ", "Shield broken" to "ঢাল ভেঙে গেছে", "Nice run" to "দারুণ রান", "Rainbow speed" to "রংধনু গতি",
    "Unstoppable" to "অপ্রতিরোধ্য", "Legend" to "কিংবদন্তি", "FINISH" to "শেষ", "Locked" to "লক", "LOCKED" to "লক", "STARS {0}/{1}" to "তারা {0}/{1}"
)

private val BN2 = mapOf(
    "Pick a zone" to "একটা জোন বাছো", "Pick a zone to run forever" to "যে জোনে অনন্ত দৌড়াবে সেটা বাছো", "BACK" to "ফিরে যাও", "BOSS" to "বস", "Special rule" to "বিশেষ নিয়ম",
    "{0} unlocked" to "{0} আনলক হয়েছে", "Clear {0} levels to unlock {1}  ({2}/{0})" to "{1} খুলতে {0}টা লেভেল শেষ করো ({2}/{0})", "Final zone of this version" to "এই সংস্করণের শেষ জোন",
    "LEVEL {0}" to "লেভেল {0}", "{0} m" to "{0} মি", "NO DUCKING" to "ডাক দেওয়া নিষেধ", "NO DOUBLE JUMP" to "ডাবল জাম্প নিষেধ", "30 SECOND SPRINT" to "30 সেকেন্ডের স্প্রিন্ট",
    "FINAL CHALLENGE" to "শেষ চ্যালেঞ্জ", "HOLD TO DUCK" to "ডাকতে ধরে রাখো", "DOWN = DUCK" to "নিচ = ডাক", "TAP TO JUMP" to "লাফাতে ট্যাপ করো", "SPACE = JUMP" to "স্পেস = লাফ",
    "GET READY" to "তৈরি হও",
    "Right: tap jump, hold higher, twice for double jump  |  Left: hold to duck" to "ডান: ট্যাপে লাফ, ধরলে উঁচু, দুবার = ডাবল জাম্প  |  বাম: ধরে রাখলে ডাক",
    "Space / Up: jump (twice = double)  |  Down: duck  |  P: pause" to "স্পেস / ওপর: লাফ (দুবার = ডাবল)  |  নিচ: ডাক  |  P: বিরতি",
    "LEVEL FAILED" to "লেভেল ব্যর্থ", "COINS" to "কয়েন", "DISTANCE" to "দূরত্ব", "SCORE" to "স্কোর", "RETRY" to "আবার", "LEVELS" to "লেভেল", "NEW BEST!" to "নতুন সেরা!", "GAME OVER" to "খেলা শেষ",
    "{0}  -  Level {1}" to "{0}  -  লেভেল {1}", "NEW BEST  -  {0}" to "নতুন সেরা  -  {0}", "{0} pts to beat your best  -  {1}" to "সেরা ভাঙতে আর {0} পয়েন্ট  -  {1}",
    "BEST COMBO" to "সেরা কম্বো", "TOP 10  #{0}" to "শীর্ষ 10  #{0}", "MENU" to "মেনু", "LEVEL COMPLETE" to "লেভেল সম্পূর্ণ", "Finish" to "শেষ করা", "{0}% coins" to "{0}% কয়েন",
    "No damage" to "ক্ষতি ছাড়া", "FIRST CLEAR" to "প্রথমবার", "BONUS" to "বোনাস", "NEXT" to "পরেরটা", "ZONE UNLOCKED" to "জোন আনলক", "CONTINUE" to "এগিয়ে চলো", "PAUSED" to "বিরতি",
    "RESUME" to "চালাও", "RESTART" to "নতুন করে", "Music" to "সঙ্গীত", "Sound effects" to "সাউন্ড ইফেক্ট", "Vibration" to "ভাইব্রেশন", "Ghost of your best run" to "সেরা রানের ভূত",
    "SETTINGS" to "সেটিংস", "RUNS" to "রান", "TOTAL COINS" to "মোট কয়েন", "TAP AGAIN TO CONFIRM" to "নিশ্চিত করতে আবার চাপো", "RESET PROGRESS" to "প্রগ্রেস মুছো",
    "DAILY GIFT" to "দৈনিক উপহার", "Come back tomorrow for more" to "আরও পেতে কাল এসো", "CLAIM" to "নাও", "LEADERBOARD" to "লিডারবোর্ড", "ENDLESS  -  TOP 10" to "অন্তহীন  -  সেরা 10",
    "No runs yet" to "এখনও কোনো রান নেই", "Ghost saved" to "ভূত সংরক্ষিত", "No ghost yet" to "এখনও ভূত নেই", "DAILY SPIN" to "দৈনিক স্পিন", "Good luck!" to "শুভকামনা!",
    "Your free spin is ready" to "ফ্রি স্পিন তৈরি", "You won {0} coins  -  come back tomorrow" to "{0} কয়েন জিতেছ  -  কাল আবার এসো", "Come back tomorrow for another spin" to "আরেকটা স্পিনের জন্য কাল এসো",
    "+{0} coins" to "+{0} কয়েন", "Finish the previous zone first" to "আগে আগের জোন শেষ করো", "Finish the previous level first" to "আগে আগের লেভেল শেষ করো",
    "Not enough coins" to "কয়েন কম", "Progress reset" to "প্রগ্রেস মুছে গেছে", "Close call! +15" to "অল্পের জন্য! +15", "EQUIPPED" to "পরানো", "OWNED" to "আছে", "EQUIP" to "পরাও", "BUY {0}" to "কেনো {0}",
    "UNICORNS" to "ইউনিকর্ন", "TRAILS" to "ট্রেইল", "HORNS" to "শিং", "Clear {0} levels in {1}  ({2}/{0})" to "{1}-এ {0}টা লেভেল শেষ করো ({2}/{0})",
    "Language" to "ভাষা", "STATS" to "পরিসংখ্যান", "EXPORT" to "এক্সপোর্ট", "IMPORT" to "ইমপোর্ট", "Copy" to "কপি", "Copied" to "কপি হয়েছে", "Cancel" to "বাতিল", "Close" to "বন্ধ",
    "Paste your backup code here" to "ব্যাকআপ কোড এখানে পেস্ট করো", "Backup code" to "ব্যাকআপ কোড", "Invalid code" to "কোডটা ঠিক নয়", "Progress imported" to "প্রগ্রেস ইমপোর্ট হয়েছে",
    "STATISTICS" to "পরিসংখ্যান", "PLAYER LEVEL" to "প্লেয়ার লেভেল", "XP" to "এক্সপি", "PLAY TIME" to "খেলার সময়", "{0}h {1}m" to "{0} ঘ {1} মি", "OBSTACLES DODGED" to "বাধা এড়ানো",
    "NEAR MISSES" to "অল্পের জন্য", "POWER-UPS" to "পাওয়ার-আপ", "SPINS" to "স্পিন", "BEST ENDLESS" to "সেরা অন্তহীন", "STARS" to "তারা", "LEVELS CLEARED" to "লেভেল শেষ", "ZONES OPEN" to "জোন খোলা",
    "x2" to "x2"
)

private val BN3 = mapOf(
    "First Steps" to "প্রথম পদক্ষেপ", "Finish a run" to "একটা রান শেষ করো", "Regular" to "নিয়মিত", "Play 50 runs" to "50টা রান খেলো", "Pocket Money" to "হাতখরচ",
    "Collect 500 coins in total" to "মোট 500 কয়েন তোলো", "Treasure Hunter" to "গুপ্তধন শিকারি", "Collect 5000 coins in total" to "মোট 5000 কয়েন তোলো",
    "Level Up!" to "লেভেল আপ!", "Clear any level" to "যেকোনো লেভেল শেষ করো", "First Zone Done" to "প্রথম জোন শেষ", "Clear all levels of zone 1" to "জোন 1-এর সব লেভেল শেষ করো",
    "Explorer" to "অভিযাত্রী", "Unlock 5 zones" to "5টা জোন আনলক করো", "Globetrotter" to "বিশ্বভ্রমণকারী", "Unlock 10 zones" to "10টা জোন আনলক করো", "World Walker" to "বিশ্বজয়ী",
    "Unlock every zone" to "সব জোন আনলক করো", "Shiny" to "ঝলমলে", "Earn 3 stars on a level" to "একটা লেভেলে 3 তারা পাও", "Star Collector" to "তারা সংগ্রাহক", "Earn 25 stars" to "25টা তারা পাও",
    "Star Hoarder" to "তারার ভান্ডার", "Earn 100 stars" to "100টা তারা পাও", "Perfectionist" to "নিখুঁত", "Earn 3 stars on every level" to "সব লেভেলে 3 তারা পাও",
    "Boss Slayer" to "বস-বিজয়ী", "Beat 3 final challenges" to "3টা শেষ চ্যালেঞ্জ জেতো", "Boss Crusher" to "বস-দমনকারী", "Beat 10 final challenges" to "10টা শেষ চ্যালেঞ্জ জেতো",
    "Close Call" to "অল্পের জন্য", "Make 10 near misses" to "10 বার অল্পের জন্য বাঁচো", "Daredevil" to "দুঃসাহসী", "Make 100 near misses" to "100 বার অল্পের জন্য বাঁচো",
    "Combo Master" to "কম্বো ওস্তাদ", "Reach a x5 coin combo" to "x5 কয়েন কম্বো করো", "Endless Beginner" to "অন্তহীন নবীন", "Score 1000 in Endless" to "অন্তহীনে 1000 স্কোর করো",
    "Endless Hero" to "অন্তহীন বীর", "Score 3000 in Endless" to "অন্তহীনে 3000 স্কোর করো", "Dodger" to "এড়ানোর ওস্তাদ", "Dodge 500 obstacles" to "500টা বাধা এড়াও", "Marathon" to "ম্যারাথন",
    "Run 5000 m in total" to "মোট 5000 মিটার দৌড়াও", "Rising Star" to "উদীয়মান তারা", "Reach player level 5" to "প্লেয়ার লেভেল 5-এ ওঠো", "Veteran" to "অভিজ্ঞ",
    "Reach player level 15" to "প্লেয়ার লেভেল 15-এ ওঠো", "Power Up" to "পাওয়ার-আপ", "Grab 25 power-ups" to "25টা পাওয়ার-আপ নাও", "Lucky" to "ভাগ্যবান", "Use the daily spin" to "দৈনিক স্পিন ব্যবহার করো",
    "Fashionista" to "সাজুগুজু", "Own 3 unicorn skins" to "3টা ইউনিকর্ন স্কিন রাখো", "Rule Breaker" to "নিয়মভাঙা", "Clear a daily challenge with a special rule" to "বিশেষ নিয়মের ডেইলি চ্যালেঞ্জ শেষ করো",
    "Loyal" to "বিশ্বস্ত", "Reach a 7 day streak" to "7 দিনের স্ট্রিক করো"
)

private val BN4 = mapOf(
    "Coin rain" to "কয়েন বৃষ্টি", "Wings - tap to flap" to "ডানা - ট্যাপ করে ওড়ো", "Double score" to "ডাবল স্কোর", "Phoenix saved you" to "ফিনিক্স বাঁচিয়ে দিয়েছে",
    "PETS" to "সঙ্গী", "None" to "কিছু না", "Fairy" to "পরী", "Kitten" to "বিড়ালছানা", "Dragon" to "ড্রাগন", "Phoenix" to "ফিনিক্স",
    "Pulls coins for 4s every 16s" to "প্রতি ১৬ সেকেন্ডে ৪ সেকেন্ড কয়েন টানে", "Lucky coins now and then" to "মাঝেমধ্যে বাড়তি কয়েন দেয়", "Blocks the first hit each run" to "প্রতি রানে প্রথম আঘাত ঠেকায়", "Revives you once per run" to "প্রতি রানে একবার বাঁচিয়ে তোলে",
    "DAILY CHALLENGE" to "দৈনিক চ্যালেঞ্জ", "DAILY" to "দৈনিক", "DAILY COMPLETE" to "দৈনিক চ্যালেঞ্জ সম্পূর্ণ",
    "Daily Hero" to "দৈনিক বীর", "Finish a daily challenge" to "একটা দৈনিক চ্যালেঞ্জ শেষ করো", "Daily Streak" to "দৈনিক ধারা", "Finish daily challenges 5 days in a row" to "টানা 5 দিন দৈনিক চ্যালেঞ্জ শেষ করো",
    "Rainbow Flash" to "রংধনু ঝলক", "Brief invincible dash" to "অল্প সময়ের অজেয় ড্যাশ", "Sun Blast" to "সূর্য-বিস্ফোরণ", "Destroys obstacles ahead" to "সামনের বাধা ভেঙে দেয়",
    "Candy Shower" to "মিষ্টি বৃষ্টি", "Short burst of coin rain" to "অল্প সময় কয়েন বৃষ্টি", "Time Freeze" to "সময় থামানো", "Slows the world down" to "দুনিয়া ধীর করে দেয়",
    "Star Warp" to "তারা-লাফ", "Teleports you forward" to "সামনে টেলিপোর্ট করে", "Aurora Shield" to "অরোরা ঢাল", "Blocks one hit" to "একটা আঘাত ঠেকায়",
    "Flame Breath" to "আগুনের শ্বাস", "Burns obstacles ahead" to "সামনের বাধা পুড়িয়ে দেয়", "Moon Leap" to "চাঁদের লাফ", "Low gravity and extra jumps" to "হালকা মাধ্যাকর্ষণ ও বাড়তি লাফ",
    "{0}s cooldown" to "{0} সেকেন্ড কুলডাউন", "Skill blocked here" to "এখানে স্কিল চলবে না",
    "SKILLS" to "স্কিল", "Own the {0} skin to unlock" to "{0} স্কিন থাকলে আনলক হবে",
    "Skills are off in final challenges" to "ফাইনাল চ্যালেঞ্জে স্কিল বন্ধ", "Shield already active" to "ঢাল আগে থেকেই চালু",
    "Extra life" to "বাড়তি প্রাণ", "Bonus life" to "বোনাস প্রাণ", "Life lost" to "একটা প্রাণ গেল", "Lives full" to "প্রাণ পূর্ণ",
    "REVIVE?" to "আবার বাঁচবে?", "REVIVE" to "হার্ট দিয়ে বাঁচো", "NO THANKS" to "না, থাক", "Hearts {0}   Cost {1}" to "হার্ট {0}   খরচ {1}", "Heart used" to "একটা হার্ট খরচ হলো", "Heart +1" to "হার্ট +1",
    "Power-ups last 50% longer" to "পাওয়ার-আপ 50% বেশি টেকে", "More hearts, +5 coins every 10 coins" to "বেশি হার্ট আসে, প্রতি 10 কয়েনে +5", "+20% score" to "+20% স্কোর", "Free revive, clears the path" to "ফ্রি বাঁচায়, পথ পরিষ্কার করে",
    "+{0} hearts" to "+{0} হার্ট", "You won {0} hearts  -  come back tomorrow" to "{0} হার্ট জিতেছ  -  কাল আবার এসো", "Not enough hearts" to "হার্ট কম"
)

val BN: HashMap<String, String> = HashMap<String, String>().apply {
    putAll(BN1)
    putAll(BN2)
    putAll(BN3)
    putAll(BN4)
}

const val BD = "০১২৩৪৫৬৭৮৯"

private val fmtCache = java.util.concurrent.ConcurrentHashMap<String, String>()

fun isBn(): Boolean = opt.lang == "bn"

fun T(k: String, vararg a: Any): String {
    var r = k
    if (isBn()) {
        val m = BN[k]
        if (m != null) r = m
    }
    for (i in a.indices) {
        r = r.replace("{" + i + "}", a[i].toString())
    }
    return r
}

fun fmt(text: String): String {
    if (!isBn()) return text
    val cached = fmtCache[text]
    if (cached != null) return cached
    var r = text
    val m = BN[r]
    if (m != null) r = m
    val sb = StringBuilder(r.length)
    for (ch in r) {
        if (ch in '0'..'9') sb.append(BD[ch - '0']) else sb.append(ch)
    }
    val out = sb.toString()
    if (fmtCache.size > 3000) fmtCache.clear()
    fmtCache[text] = out
    return out
}

fun zn(i: Int): String = T(ZN[i].name)
