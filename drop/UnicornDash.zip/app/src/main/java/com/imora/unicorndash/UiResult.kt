package com.imora.unicorndash

import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.round
import kotlin.math.sin

private val MINT = hex(0x7dffd4)
private val SUN = hex(0xffe27a)
private val DIM = hex(0xa89cd4)
private val STAR_NAMES = arrayOf("Finish", "", "No damage")

fun completeUI() {
    val r0 = res ?: return
    val cx = L / 2.0
    val tm = nowMs() - stAt
    panel(cx, 172.0, 380.0, 274.0)
    title(if (r0.daily) "DAILY COMPLETE" else "LEVEL COMPLETE", 28.0, cx, 62.0)
    for (i in 0 until 3) {
        val px = cx + (i - 1) * 74.0
        val k = clamp((tm - 450.0 - i * 420.0) / 320.0, 0.0, 1.0)
        val on = r0.stars[i]
        iconStar(px, 112.0, 24.0, false)
        if (on && k > 0.0) {
            val r = 24.0 * ((0.4 + 0.6 * easeOut(k)) + 0.3 * sin(PI * k))
            x.halo(px, 112.0, r * 2.2, 48.0, 100.0, 70.0, 0.5 * k)
            iconStar(px, 112.0, r, true)
        }
        val name = if (i == 1) T("{0}% coins", round(CFG_COIN_PCT * 100.0).toInt()) else STAR_NAMES[i]
        label(name, 10.5, px, 150.0, if (on && k >= 1.0) MINT else DIM)
    }
    tile(cx - 112.0, 192.0, 100.0, 40.0, "COINS", "${r0.got}/${r0.total}", SUN)
    tile(cx, 192.0, 100.0, 40.0, "SCORE", floor(score).toInt().toString(), hex(0x9fefff))
    tile(cx + 112.0, 192.0, 100.0, 40.0, if (r0.first) "FIRST CLEAR" else "BONUS", "+${r0.bonus}", hex(0xffb0cf))
    xpRow(220.0)
    if (r0.daily) {
        btn("restart", "RETRY", cx - 76.0, 264.0, 130.0, 44.0, 's')
        btn("menu", "MENU", cx + 76.0, 264.0, 130.0, 44.0, 'p')
        return
    }
    btn("restart", "RETRY", cx - 118.0, 264.0, 96.0, 38.0, 's')
    btn("next", "NEXT", cx, 264.0, 120.0, 44.0, 'p')
    btn("lvls", "LEVELS", cx + 118.0, 264.0, 96.0, 38.0, 's')
}

fun unlockUI() {
    if (unl < 0) return
    val cx = L / 2.0
    val k = clamp((nowMs() - stAt) / 600.0, 0.0, 1.0)
    panel(cx, 172.0, 340.0, 246.0)
    title("ZONE UNLOCKED", 26.0, cx, 82.0)
    val sc = 0.6 + 0.4 * easeOut(k)
    x.halo(cx, 162.0, 110.0, ZN[unl].hue, 100.0, 70.0, 0.35 * k)
    x.save()
    x.translate(cx, 162.0)
    x.scale(sc, sc)
    zprev(unl, -62.0, -40.0, 124.0, 80.0, 16.0)
    pill(-62.0, -40.0, 124.0, 80.0, 16.0)
    x.strokeStyle = rgba(255, 255, 255, 0.85)
    x.lineWidth = 2.0
    x.stroke()
    x.restore()
    label(ZN[unl].name, 20.0, cx, 218.0, WHITE)
    sparkle(cx - 128.0, 100.0, 9.0, 0.0)
    sparkle(cx + 130.0, 112.0, 8.0, 2.0)
    sparkle(cx - 104.0, 206.0, 7.0, 4.0)
    sparkle(cx + 108.0, 200.0, 9.0, 1.0)
    btn("cont", "CONTINUE", cx, 262.0, 170.0, 40.0, 'g')
}

fun reviveUI() {
    val cx = L / 2.0
    val f = clamp(revT / 5.0, 0.0, 1.0)
    x.fillStyle = rgba(10, 5, 35, 0.55)
    x.fillRect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
    panel(cx, 172.0, 330.0, 262.0)
    title("REVIVE?", 30.0, cx, 78.0)
    val pul = 1.0 + 0.06 * sin(clock * 6.0)
    x.save()
    x.translate(cx, 140.0)
    x.scale(pul, pul)
    x.lineWidth = 6.0
    x.lineCap = CAP_ROUND
    x.strokeStyle = rgba(255, 255, 255, 0.16)
    x.beginPath()
    x.arc(0.0, 0.0, 38.0, 0.0, 7.0)
    x.stroke()
    x.strokeStyle = PINK_HEART
    x.beginPath()
    x.arc(0.0, 0.0, 38.0, -PI / 2.0, -PI / 2.0 + 6.283 * f)
    x.stroke()
    heartPath(0.0, 2.0, 22.0)
    x.fillStyle = PINK_HEART
    x.fill()
    x.lineWidth = 2.4
    x.strokeStyle = WHITE
    x.stroke()
    x.restore()
    label(T("Hearts {0}   Cost {1}", hearts, 1 shl revUsed), 12.5, cx, 192.0, hex(0xffd0e0))
    btn("revive", "REVIVE", cx, 230.0, 220.0, 46.0, 'g')
    btn("skip", "NO THANKS", cx, 280.0, 140.0, 32.0, 's')
}

fun pauseUI() {
    val cx = L / 2.0
    x.fillStyle = rgba(10, 5, 35, 0.5)
    x.fillRect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
    panel(cx, 172.0, 320.0, 246.0)
    title("PAUSED", 32.0, cx, 92.0)
    btn("resume", "RESUME", cx, 140.0, 200.0, 46.0, 'p')
    btn("restart", "RESTART", cx - 54.0, 190.0, 100.0, 36.0, 's')
    btn("menu", "MENU", cx + 54.0, 190.0, 100.0, 36.0, 's')
    toggle("tmusic", "Music", opt.music, cx, 232.0, 240.0, 28.0)
    toggle("tsfx", "Sound effects", opt.sfx, cx, 262.0, 240.0, 28.0)
}
