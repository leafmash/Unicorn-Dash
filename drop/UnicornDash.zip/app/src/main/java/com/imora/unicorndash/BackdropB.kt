package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

fun z9f(rd: Double) {
    layer(rd * 0.08, 64.0, 1) { px, r1, r2 ->
        val w = 36.0 + 22.0 * r2
        val h = 80.0 + 110.0 * r1
        val id = Math.floor(r1 * 997.0).toInt()
        x.fillStyle = Z.far
        x.fillRect(px - w / 2.0, G - h, w, h)
        x.fillStyle = rgba(255, 230, 120, 0.6)
        var yy = G - h + 8.0
        var j = 0
        while (yy < G - 8.0) {
            var xx = px - w / 2.0 + 5.0
            var k = 0
            while (xx < px + w / 2.0 - 5.0) {
                if (hs((id + j * 7 + k * 3).toDouble()) > 0.55) x.fillRect(xx, yy, 4.0, 6.0)
                xx += 10.0
                k++
            }
            yy += 12.0
            j++
        }
    }
}

fun z9n(rd: Double) {
    x.fillStyle = Z.near
    x.strokeStyle = Z.edge
    x.lineWidth = 1.5
    layer(rd * 0.2, 100.0, 2) { px, r1, r2 ->
        val w = 44.0 + 20.0 * r2
        val h = 50.0 + 70.0 * r1
        x.beginPath()
        x.rect(px - w / 2.0, G - h, w, h)
        x.fill()
        x.stroke()
        x.beginPath()
        x.moveTo(px, G - h)
        x.lineTo(px, G - h - 14.0)
        x.stroke()
    }
}

fun z9m(rd: Double) {
    layer(rd * 0.45, 180.0, 3) { px, r1, r2 ->
        val py = G - 60.0 - r1 * 60.0
        val hu = r2 * 360.0
        x.halo(px, py + 8.0, 26.0, hu, 100.0, 60.0, 0.25)
        x.strokeStyle = hsl(hu, 100.0, 65.0)
        x.lineWidth = 3.0
        x.strokeRect(px - 18.0, py, 36.0, 16.0)
    }
}

fun z9g(rd: Double) {
    x.strokeStyle = Z.edge
    x.alpha = 0.55
    x.lineWidth = 1.2
    x.beginPath()
    for (k in 0 until 3) {
        x.moveTo(0.0, G + 16.0 + k * 20.0)
        x.lineTo(L, G + 16.0 + k * 20.0)
    }
    val o = rd % 40.0
    var i = -1
    while (i < L / 40.0 + 1.0) {
        x.moveTo(i * 40.0 - o, G + 6.0)
        x.lineTo(i * 40.0 - o - 24.0, G + 90.0)
        i++
    }
    x.stroke()
    x.alpha = 1.0
    x.fillStyle = hex(0xff5ad8)
    val o2 = rd % 60.0
    i = -1
    while (i < L / 60.0 + 1.0) {
        x.fillRect(i * 60.0 - o2, G + 24.0, 26.0, 3.0)
        i++
    }
}

fun z10f(rd: Double) {
    x.strokeStyle = Z.far
    x.lineWidth = 12.0
    x.lineCap = CAP_ROUND
    x.lineJoin = JOIN_ROUND
    layer(rd * 0.08, 70.0, 1) { px, r1, r2 ->
        val h = 100.0 + 80.0 * r1
        x.beginPath()
        x.moveTo(px, G)
        for (k in 1..6) x.lineTo(px + sin(t * 1.2 + k * 0.8 + r2 * 9.0) * k * 3.0, G - h * k / 6.0)
        x.stroke()
    }
}

fun z10n(rd: Double) {
    x.lineWidth = 6.0
    x.lineCap = CAP_ROUND
    layer(rd * 0.2, 120.0, 2) { px, r1, r2 ->
        x.strokeStyle = hsl(340.0 + r2 * 40.0, 70.0, 62.0)
        x.beginPath()
        x.moveTo(px, G)
        x.lineTo(px, G - 30.0 - 20.0 * r1)
        x.moveTo(px, G - 14.0)
        x.lineTo(px - 16.0, G - 34.0 - 10.0 * r1)
        x.moveTo(px, G - 20.0)
        x.lineTo(px + 16.0, G - 38.0 - 8.0 * r2)
        x.stroke()
    }
}

fun z10m(rd: Double) {
    layer(rd * 0.45, 200.0, 3) { px, r1, r2 ->
        val py = 70.0 + r1 * 140.0 + sin(t * 1.5 + r2 * 9.0) * 6.0
        x.fillStyle = hsl(30.0 + r2 * 30.0, 90.0, 65.0)
        x.beginPath()
        oval(px, py, 12.0, 6.0)
        x.moveTo(px + 10.0, py)
        x.lineTo(px + 20.0, py - 6.0)
        x.lineTo(px + 20.0, py + 6.0)
        x.fill()
        x.fillStyle = hex(0x112233)
        x.fillRect(px - 8.0, py - 2.0, 2.0, 2.0)
    }
}

fun z10g(rd: Double) {
    x.fillStyle = rgba(255, 255, 255, 0.3)
    x.beginPath()
    layer(rd, 40.0, 21) { px, r1, r2 -> disc(px, G + 14.0 + r1 * 30.0, 2.0 + 3.0 * r2) }
    x.fill()
    x.fillStyle = hex(0xffd5e8)
    x.beginPath()
    layer(rd, 130.0, 22) { px, _, _ -> dome(px, G + 1.0, 7.0, 0.9) }
    x.fill()
}

fun z11f(rd: Double) {
    x.fillStyle = Z.far
    wave(rd * 0.08, G - 60.0, 30.0, 100.0, 0.41)
}

fun z11n(rd: Double) {
    layer(rd * 0.2, 95.0, 2) { px, r1, r2 ->
        val b = G - 40.0 - r1 * 20.0
        x.fillStyle = rgb(90, 50, 40)
        x.fillRect(px - 3.0, b, 6.0, G - b)
        x.fillStyle = hsl(5.0 + r2 * 45.0, 80.0, 48.0 + r1 * 10.0)
        x.beginPath()
        disc(px, b - 12.0, 22.0 + 8.0 * r2)
        disc(px - 14.0, b - 4.0, 14.0)
        disc(px + 14.0, b - 4.0, 14.0)
        x.fill()
    }
}

fun z11m(rd: Double) {
    val o = (rd * 0.45) % 40.0
    x.strokeStyle = rgba(95, 52, 32, 0.75)
    x.lineWidth = 3.0
    x.beginPath()
    x.moveTo(0.0, G - 8.0)
    x.lineTo(L, G - 8.0)
    x.moveTo(0.0, G - 18.0)
    x.lineTo(L, G - 18.0)
    var i = -1
    while (i < L / 40.0 + 1.0) {
        x.moveTo(i * 40.0 - o, G)
        x.lineTo(i * 40.0 - o, G - 24.0)
        i++
    }
    x.stroke()
}

fun z11g(rd: Double) {
    layer(rd, 200.0, 21) { px, _, _ ->
        x.fillStyle = hex(0xff8a1e)
        x.beginPath()
        oval(px, G - 5.0, 9.0, 7.0)
        x.fill()
        x.fillStyle = hex(0x3c8a3a)
        x.fillRect(px - 1.5, G - 14.0, 3.0, 4.0)
    }
    layer(rd, 30.0, 22) { px, r1, r2 ->
        x.fillStyle = hsl(r2 * 50.0, 85.0, 52.0)
        x.beginPath()
        x.ellipse(px, G + 10.0 + r1 * 50.0, 4.0, 2.0, r2 * 3.0, 0.0, 7.0)
        x.fill()
    }
}

fun z12f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 200.0, 1) { px, r1, r2 ->
        val w = 60.0 + 40.0 * r2
        val h = 90.0 + 50.0 * r1
        x.moveTo(px - w, G)
        x.lineTo(px - w, G - h * 0.4)
        x.lineTo(px - w * 0.7, G - h * 0.4)
        x.lineTo(px - w * 0.7, G - h)
        x.lineTo(px + w * 0.6, G - h)
        x.lineTo(px + w * 0.6, G - h * 0.55)
        x.lineTo(px + w, G - h * 0.55)
        x.lineTo(px + w, G)
    }
    x.fill()
}

fun z12n(rd: Double) {
    x.lineCap = CAP_ROUND
    layer(rd * 0.2, 170.0, 2) { px, r1, _ ->
        val h = 70.0 + 30.0 * r1
        x.strokeStyle = rgb(110, 70, 40)
        x.lineWidth = 5.0
        x.beginPath()
        x.moveTo(px, G)
        x.quadraticCurveTo(px + 10.0, G - h * 0.5, px + 4.0, G - h)
        x.stroke()
        x.strokeStyle = Z.edge
        x.lineWidth = 4.0
        x.beginPath()
        for (k in -2..2) {
            x.moveTo(px + 4.0, G - h)
            x.quadraticCurveTo(px + 4.0 + k * 12.0, G - h - 16.0 + abs(k) * 3.0, px + 4.0 + k * 22.0, G - h + 8.0 + abs(k) * 4.0)
        }
        x.stroke()
    }
}

fun z12m(rd: Double) {
    x.fillStyle = Z.soil
    x.beginPath()
    layer(rd * 0.45, 140.0, 3) { px, r1, _ -> dome(px, G, 40.0 + 20.0 * r1, 0.35) }
    x.fill()
}

fun z12g(rd: Double) {
    x.fillStyle = rgba(70, 190, 220, 0.9)
    x.beginPath()
    layer(rd, 260.0, 22) { px, r1, _ -> oval(px, G + 10.0, 40.0 + 14.0 * r1, 5.0) }
    x.fill()
    x.strokeStyle = Z.edge
    x.lineWidth = 2.0
    x.beginPath()
    layer(rd, 60.0, 21) { px, r1, _ ->
        x.moveTo(px, G + 3.0)
        x.lineTo(px - 3.0, G - 8.0 - r1 * 4.0)
        x.moveTo(px, G + 3.0)
        x.lineTo(px + 4.0, G - 9.0 - r1 * 4.0)
    }
    x.stroke()
}

fun z13f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 90.0, 1) { px, r1, r2 ->
        val w = 12.0 + 6.0 * r2
        val h = 34.0 + 30.0 * r1
        x.moveTo(px - w, G)
        x.lineTo(px - w, G - h + w)
        x.arc(px, G - h + w, w, PI, PI * 2.0)
        x.lineTo(px + w, G)
    }
    x.fill()
}

fun z13n(rd: Double) {
    x.strokeStyle = Z.near
    x.lineCap = CAP_ROUND
    x.lineJoin = JOIN_ROUND
    layer(rd * 0.2, 150.0, 2) { px, r1, _ ->
        val h = 80.0 + 60.0 * r1
        x.lineWidth = 7.0
        x.beginPath()
        x.moveTo(px, G)
        x.lineTo(px + 4.0, G - h * 0.5)
        x.lineTo(px - 2.0, G - h)
        x.stroke()
        x.lineWidth = 3.5
        x.beginPath()
        x.moveTo(px + 4.0, G - h * 0.5)
        x.lineTo(px + 26.0, G - h * 0.75)
        x.lineTo(px + 34.0, G - h * 0.72)
        x.moveTo(px + 1.0, G - h * 0.7)
        x.lineTo(px - 24.0, G - h * 0.9)
        x.lineTo(px - 32.0, G - h * 0.85)
        x.stroke()
    }
}

fun z13m(rd: Double) {
    layer(rd * 0.45, 200.0, 3) { px, r1, r2 -> x.halo(px + sway(0.4, r2 * 9.0) * 20.0, G - 14.0 - r1 * 30.0, 60.0, 200.0, 10.0, 80.0, 0.12) }
}

fun z13g(rd: Double) {
    val o = rd % 18.0
    x.strokeStyle = rgba(20, 24, 34, 0.9)
    x.lineWidth = 2.0
    x.beginPath()
    x.moveTo(0.0, G - 8.0)
    x.lineTo(L, G - 8.0)
    var i = -1
    while (i < L / 18.0 + 1.0) {
        x.moveTo(i * 18.0 - o, G + 2.0)
        x.lineTo(i * 18.0 - o, G - 18.0)
        i++
    }
    x.stroke()
    x.fillStyle = rgba(20, 24, 34, 0.9)
    x.beginPath()
    i = -1
    while (i < L / 18.0 + 1.0) {
        tri(i * 18.0 - o, G - 18.0, 6.0, 2.5)
        i++
    }
    x.fill()
}

fun z14f(rd: Double) {
    layer(rd * 0.08, 340.0, 1) { px, r1, r2 ->
        val r = 26.0 + 34.0 * r1
        val py = 50.0 + r2 * 110.0
        x.fillStyle = Z.far
        x.beginPath()
        disc(px, py, r)
        x.fill()
        x.strokeStyle = Z.edge
        x.lineWidth = 3.0
        x.beginPath()
        x.moveTo(px + r * 1.7, py)
        x.ellipse(px, py, r * 1.7, r * 0.38, -0.35, 0.0, 7.0)
        x.stroke()
    }
}

fun z14n(rd: Double) {
    x.fillStyle = Z.near
    layer(rd * 0.2, 110.0, 2) { px, r1, r2 ->
        val py = 40.0 + r1 * 180.0 + sway(0.7, r2 * 9.0) * 8.0
        val rr = 10.0 + 10.0 * r2
        x.beginPath()
        for (k in 0 until 7) {
            val a = k / 7.0 * PI * 2.0 + r1 * 3.0
            val rad = rr * (0.7 + 0.3 * hs((k + Math.floor(r1 * 50.0).toInt()).toDouble()))
            if (k > 0) x.lineTo(px + cos(a) * rad, py + sin(a) * rad)
            else x.moveTo(px + cos(a) * rad, py + sin(a) * rad)
        }
        x.fill()
    }
}

fun z14m(rd: Double) {
    layer(rd * 0.45, 300.0, 3) { px, r1, r2 ->
        val py = 40.0 + r1 * 100.0
        x.fillStyle = hex(0xc9d4ff)
        x.fillRect(px - 4.0, py - 4.0, 8.0, 8.0)
        x.fillStyle = hex(0x5aa0ff)
        x.fillRect(px - 20.0, py - 3.0, 13.0, 6.0)
        x.fillRect(px + 7.0, py - 3.0, 13.0, 6.0)
        x.halo(px, py - 6.0, 5.0, 0.0, 100.0, 70.0, 0.4 + 0.4 * abs(sway(3.0, r2 * 9.0)))
    }
}

fun z14g(rd: Double) {
    val o = rd % 50.0
    x.strokeStyle = rgba(160, 140, 255, 0.5)
    x.lineWidth = 1.5
    x.beginPath()
    var i = -1
    while (i < L / 50.0 + 1.0) {
        x.moveTo(i * 50.0 - o, G + 6.0)
        x.lineTo(i * 50.0 - o, G + 90.0)
        i++
    }
    x.moveTo(0.0, G + 30.0)
    x.lineTo(L, G + 30.0)
    x.moveTo(0.0, G + 56.0)
    x.lineTo(L, G + 56.0)
    x.stroke()
    layer(rd, 50.0, 21) { px, r1, r2 -> x.halo(px, G + 16.0, 5.0, if (r2 > 0.5) 200.0 else 330.0, 100.0, 70.0, 0.5 + 0.4 * abs(sway(2.0, r1 * 9.0))) }
}

fun z15f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 200.0, 1) { px, r1, r2 ->
        val w = 44.0 + 16.0 * r2
        val h = 120.0 + 50.0 * r1
        x.moveTo(px - w, G)
        x.lineTo(px - w, G - h + 14.0)
        x.quadraticCurveTo(px - w, G - h, px - w + 14.0, G - h)
        x.lineTo(px + w - 14.0, G - h)
        x.quadraticCurveTo(px + w, G - h, px + w, G - h + 14.0)
        x.lineTo(px + w, G)
    }
    x.fill()
    x.strokeStyle = rgba(255, 255, 255, 0.7)
    x.lineWidth = 10.0
    x.setLineDash(14.0, 10.0)
    x.dashOffset = -t * 60.0
    layer(rd * 0.08, 200.0, 1) { px, r1, _ ->
        x.beginPath()
        x.moveTo(px, G - 120.0 - 50.0 * r1 + 10.0)
        x.lineTo(px, G)
        x.stroke()
    }
    x.clearLineDash()
}

fun z15n(rd: Double) {
    x.fillStyle = Z.near
    x.beginPath()
    layer(rd * 0.2, 140.0, 2) { px, _, _ ->
        for (k in 0 until 4) x.rect(px - 40.0 + k * 10.0, G - 14.0 * (k + 1), 80.0 - k * 20.0, 14.0)
    }
    x.fill()
}

fun z15m(rd: Double) {
    layer(rd * 0.45, 200.0, 3) { px, _, _ -> x.halo(px, G - 10.0, 50.0, 190.0, 40.0, 95.0, 0.25) }
}

fun z15g(rd: Double) {
    layer(rd, 44.0, 21) { px, r1, r2 ->
        x.fillStyle = hsl(160.0 + r2 * 60.0, 60.0, 75.0, 0.85)
        x.beginPath()
        oval(px, G + 5.0 + r1 * 20.0, 8.0 + 6.0 * r2, 4.0)
        x.fill()
    }
}

fun z16f(rd: Double) {
    layer(rd * 0.08, 200.0, 1) { px, r1, r2 ->
        val h = 100.0 + 60.0 * r1
        x.strokeStyle = Z.far
        x.lineWidth = 6.0
        x.beginPath()
        x.moveTo(px, G)
        x.quadraticCurveTo(px + 10.0, G - h * 0.5, px, G - h)
        x.stroke()
        x.fillStyle = Z.far
        for (k in 0 until 6) {
            val a = k * PI / 3.0 + r2
            x.beginPath()
            x.ellipse(px + cos(a) * 16.0, G - h + sin(a) * 16.0, 16.0, 7.0, a, 0.0, 7.0)
            x.fill()
        }
    }
}

fun z16n(rd: Double) {
    layer(rd * 0.2, 90.0, 2) { px, r1, r2 ->
        val h = 50.0 + 40.0 * r1
        x.strokeStyle = Z.near
        x.lineWidth = 3.0
        x.beginPath()
        x.moveTo(px, G)
        x.quadraticCurveTo(px + 12.0, G - h, px + 16.0, G - h)
        x.stroke()
        x.fillStyle = hsl(Z.hue + r2 * 60.0, 70.0, 72.0, 0.85)
        x.beginPath()
        x.moveTo(px + 16.0, G - h)
        x.lineTo(px + 25.0, G - h + 18.0)
        x.lineTo(px + 7.0, G - h + 18.0)
        x.fill()
    }
}

fun z16m(rd: Double) {
    val y0 = -ty - 10.0
    layer(rd * 0.45, 110.0, 3) { px, r1, r2 ->
        val len = 40.0 + 80.0 * r1
        x.strokeStyle = rgba(255, 255, 255, 0.4)
        x.lineWidth = 1.0
        x.beginPath()
        x.moveTo(px, y0)
        x.lineTo(px, y0 + len)
        x.stroke()
        x.halo(px, y0 + len + 8.0, 18.0, 50.0 + r2 * 40.0, 100.0, 75.0, 0.55 + 0.2 * sway(2.0, r2 * 9.0))
        x.fillStyle = hex(0xfff6c8)
        x.beginPath()
        disc(px, y0 + len + 8.0, 5.0)
        x.fill()
    }
}

fun z16g(rd: Double) {
    layer(rd, 36.0, 21) { px, r1, r2 ->
        x.fillStyle = hsl(200.0 + r2 * 140.0, 80.0, 80.0, 0.8)
        x.beginPath()
        x.ellipse(px, G + 10.0 + r1 * 40.0, 4.0, 2.0, r2 * 3.0, 0.0, 7.0)
        x.fill()
    }
    layer(rd, 90.0, 23) { px, r1, r2 ->
        if (r2 > 0.7) return@layer
        x.halo(px, G - 6.0, 5.0, 190.0 + r1 * 120.0, 100.0, 78.0, 0.5 + 0.4 * abs(sway(2.0, r1 * 9.0)))
    }
}

fun z17f(rd: Double) {
    x.fillStyle = Z.far
    x.beginPath()
    layer(rd * 0.08, 240.0, 1) { px, _, _ ->
        for (k in 0 until 3) {
            val w = 46.0 - k * 9.0
            val y = G - k * 38.0
            x.rect(px - w + 6.0, y - 26.0, 2.0 * w - 12.0, 26.0)
            x.moveTo(px - w - 12.0, y - 26.0)
            x.lineTo(px - w + 4.0, y - 40.0)
            x.lineTo(px + w - 4.0, y - 40.0)
            x.lineTo(px + w + 12.0, y - 26.0)
        }
        tri(px, G - 114.0, 22.0, 3.0)
    }
    x.fill()
}

fun z17n(rd: Double) {
    val o = (rd * 0.2) % 64.0
    x.fillStyle = Z.near
    x.beginPath()
    var i = -1
    while (i < L / 64.0 + 1.0) {
        val cx = i * 64.0 - o
        x.rect(cx - 6.0, G - 62.0, 12.0, 62.0)
        x.rect(cx - 10.0, G - 66.0, 20.0, 6.0)
        x.rect(cx - 9.0, G - 6.0, 18.0, 6.0)
        i++
    }
    x.rect(0.0, G - 76.0, L, 10.0)
    x.fill()
}

fun z17m(rd: Double) {
    val y0 = -ty - 10.0
    layer(rd * 0.45, 120.0, 3) { px, r1, r2 ->
        val len = 40.0 + 70.0 * r1
        x.strokeStyle = rgba(255, 215, 100, 0.6)
        x.lineWidth = 1.2
        x.beginPath()
        x.moveTo(px, y0)
        x.lineTo(px, y0 + len)
        x.stroke()
        x.halo(px, y0 + len + 9.0, 16.0, 30.0, 100.0, 62.0, 0.4 + 0.2 * sway(2.0, r2 * 9.0))
        x.fillStyle = hex(0xe0482a)
        x.fillRect(px - 6.0, y0 + len, 12.0, 18.0)
        x.fillStyle = hex(0xffd24a)
        x.fillRect(px - 7.0, y0 + len - 2.0, 14.0, 3.0)
        x.fillRect(px - 7.0, y0 + len + 17.0, 14.0, 3.0)
    }
}

fun z17g(rd: Double) {
    val o = rd % 40.0
    x.fillStyle = rgba(255, 255, 255, 0.18)
    var i = -1
    while (i < L / 40.0 + 1.0) {
        x.fillRect(i * 40.0 - o, G + 8.0, 20.0, 10.0)
        x.fillRect(i * 40.0 - o + 20.0, G + 18.0, 20.0, 10.0)
        i++
    }
    x.strokeStyle = rgba(120, 70, 10, 0.55)
    x.lineWidth = 2.0
    x.beginPath()
    i = -1
    while (i < L / 20.0 + 1.0) {
        val cx = i * 20.0 - rd % 20.0
        x.moveTo(cx, G + 40.0)
        x.lineTo(cx + 10.0, G + 40.0)
        x.lineTo(cx + 10.0, G + 50.0)
        x.lineTo(cx + 4.0, G + 50.0)
        x.lineTo(cx + 4.0, G + 44.0)
        i++
    }
    x.stroke()
}
