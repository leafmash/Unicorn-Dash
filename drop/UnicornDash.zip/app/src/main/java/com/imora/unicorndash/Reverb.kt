package com.imora.unicorndash

import kotlin.math.pow

class Comb(private val size: Int, private val feedback: Double, private val damp: Double) {
    private val buf = DoubleArray(size)
    private var pos = 0
    private var store = 0.0

    fun process(x: Double): Double {
        val out = buf[pos]
        store = out * (1.0 - damp) + store * damp
        buf[pos] = x + store * feedback
        pos++
        if (pos >= size) pos = 0
        return out
    }
}

class AllPass(private val size: Int, private val gain: Double) {
    private val buf = DoubleArray(size)
    private var pos = 0

    fun process(x: Double): Double {
        val b = buf[pos]
        val out = -x + b
        buf[pos] = x + b * gain
        pos++
        if (pos >= size) pos = 0
        return out
    }
}

class Reverb {
    private val delays = intArrayOf(1557, 1617, 1491, 1422, 1277, 1356)
    private val combs = Array(delays.size) { Comb(delays[it], 10.0.pow(-3.0 * delays[it] / (1.8 * SR)), 0.25) }
    private val all1 = AllPass(556, 0.5)
    private val all2 = AllPass(225, 0.5)

    fun process(x: Double): Double {
        var s = 0.0
        for (c in combs) s += c.process(x)
        s /= combs.size
        return all2.process(all1.process(s)) * 1.6
    }
}
