package com.imora.unicorndash

import android.graphics.Bitmap
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class UMission(val title: String, val prog: Int, val need: Int, val reward: Int, val done: Boolean)

class UAch(val name: String, val desc: String, val reward: Int, val value: Int, val max: Int, val done: Boolean)

class UItem(val name: String, val owned: Boolean, val equipped: Boolean, val lockZone: String, val coins: Int, val hearts: Int)

class UZone(val name: String, val open: Boolean, val stars: Int, val best: Int, val full: Boolean, val current: Boolean)

class ULevel(val n: Int, val stars: Int, val open: Boolean, val boss: Boolean, val next: Boolean)

class UBoard(val score: Int, val date: String)

class UPower(val key: String, val hue: Double, val frac: Double)

class UStat(val head: String, val value: String, val tone: Int)

class Snap {
    var st = 0
    var stAtMs = 0.0
    var bank = 0
    var hearts = 0
    var best = 0
    var zi = 0
    var li = 0
    var zoneName = ""
    var mode = "end"
    var music = true
    var sfx = true
    var vib = true
    var ghost = true
    var bn = false
    var lang = "en"
    var toast = ""
    var toastK = 0.0
    var giftOn = false
    var giftAmt = 0
    var giftStreak = 0
    var levelMode = false
    var daily = false
    var boss = false
    var levelCoins = 0
    var rule = ""
    var sub = ""
    var score = 0
    var scoreF = 0
    var runCoins = 0
    var got = 0
    var dist = 0
    var progress = 0.0
    var combo = 0
    var comboF = 0.0
    var comboFx = 0.3
    var comboFy = 0.5
    var powers: List<UPower> = emptyList()
    var skKey = ""
    var skHue = 0.0
    var skF = 0.0
    var skCd = 0
    var skReady = false
    var skActive = false
    var skOff = false
    var bannerText = ""
    var bannerSub = ""
    var bannerA = 0.0
    var cdN = 0
    var cdF = 0.0
    var hintA = 0.0
    var coarse = true
    var missions: List<UMission> = emptyList()
    var lv = 1
    var xpCur = 0
    var xpNeed = 100
    var runXp = 0
    var stars = 0
    var starsMax = 0
    var streak = 0
    var achDone = 0
    var achTotal = 0
    var spinReady = false
    var dailyDone = false
    var dailyText = ""
    var newBest = false
    var pct = 0
    var runCombo = 0
    var toBeat = 0
    var lbRank = -1
    var resStars = BooleanArray(3)
    var resGot = 0
    var resTotal = 0
    var resBonus = 0
    var resFirst = false
    var resDaily = false
    var unlockZone = -1
    var reviveF = 0.0
    var reviveCost = 1
    var shopTab = 0
    var shopSel = 0
    var items: List<UItem> = emptyList()
    var shopNote = ""
    var zmode = "adv"
    var zones: List<UZone> = emptyList()
    var zpage = 0
    var levels: List<ULevel> = emptyList()
    var levelsNote = ""
    var levelsNoteOk = false
    var achs: List<UAch> = emptyList()
    var lbz = 0
    var lbName = ""
    var lbOpen = true
    var board: List<UBoard> = emptyList()
    var ghostSaved = false
    var spinning = false
    var spinFrom = 0.0
    var spinTo = 0.0
    var spinT0 = 0.0
    var spinIdx = -1
    var spinA = 0.0
    var spinWon = false
    var statsList: List<UStat> = emptyList()
    var confirmReset = false
}

object UiBridge {
    val snap = mutableStateOf(Snap())
    val fade = mutableFloatStateOf(0f)
    val comboX = mutableFloatStateOf(0.3f)
    val comboY = mutableFloatStateOf(0.5f)
    @Volatile var view: GameView? = null
    @Volatile var force = false
    var lastPub = 0.0
    var lastSt = -1

    fun fire(id: String) {
        val v = view ?: return
        v.runOnGame {
            act(id)
            force = true
        }
    }

    fun tap() {
        buzz(7)
    }
}

object Previews {
    val bitmaps = ConcurrentHashMap<String, Bitmap>()
    val version = mutableIntStateOf(0)
    private val queue = ConcurrentLinkedQueue<String>()
    private val queued = ConcurrentHashMap<String, Boolean>()

    fun request(key: String) {
        if (bitmaps.containsKey(key)) return
        if (queued.putIfAbsent(key, true) == null) queue.add(key)
    }

    fun process() {
        var n = 0
        var any = false
        while (n < 2) {
            val k = queue.poll() ?: break
            n++
            try {
                render(k)
                any = true
            } catch (e: Exception) {
            }
            queued.remove(k)
        }
        if (any) version.intValue = version.intValue + 1
    }

    private fun render(key: String) {
        val parts = key.split(":")
        if (parts[0] == "s") {
            val tab = parts[1].toInt()
            val i = parts[2].toInt()
            val bmp = Bitmap.createBitmap(228, 330, Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(bmp)
            x.begin(c)
            c.scale(3f, 3f)
            c.translate(0f, -10f)
            cardArt(tab, i)
            bitmaps[key] = bmp
        } else if (parts[0] == "z") {
            val i = parts[1].toInt()
            val bmp = Bitmap.createBitmap(450, 252, Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(bmp)
            x.begin(c)
            c.scale(3f, 3f)
            zprev(i, 0.0, 0.0, 150.0, 84.0, 0.0)
            bitmaps[key] = bmp
        }
    }

    private fun cardArt(tab: Int, i: Int) {
        val w = 76.0
        val cx = w / 2.0
        when (tab) {
            0 -> {
                uq.clear()
                uq.x = cx + 4.0
                uq.y = 102.0
                uq.ang = 0.0
                uq.sq = 1.0
                uq.dk = 0.0
                uq.air = false
                uq.tt = clock + i
                uq.sc = 0.78
                uq.hn = hornSel
                unicorn(uq, i)
            }
            1 -> {
                ribbon(8.0, w - 8.0, 66.0, i, clock)
                sparkle(w - 14.0, 40.0, 5.0, i.toDouble())
            }
            3 -> if (PT[i].kind.isNotEmpty()) petDraw(PT[i].kind, cx, 78.0, 2.3, clock + i, false)
            4 -> skillIcon(SKL[i].k, cx, 70.0, 2.4)
            else -> {
                x.save()
                x.translate(cx, 96.0)
                x.scale(3.4, 3.4)
                x.translate(-34.0, 60.0)
                hornShape(i, clock, SK[skin].horn)
                x.restore()
            }
        }
    }
}

private val dateCache = HashMap<Int, String>()

private fun dayLabel(d: Int): String {
    val cached = dateCache[d]
    if (cached != null) return cached
    val z = d + 719468
    val era = Math.floorDiv(z, 146097)
    val doe = z - era * 146097
    val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
    val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
    val mp2 = (5 * doy + 2) / 153
    val dd = doy - (153 * mp2 + 2) / 5 + 1
    val mm = if (mp2 < 10) mp2 + 3 else mp2 - 9
    val s = (if (mm < 10) "0$mm" else "$mm") + "-" + (if (dd < 10) "0$dd" else "$dd")
    if (dateCache.size > 200) dateCache.clear()
    dateCache[d] = s
    return s
}

private val STAT_HEADS = arrayOf(
    "PLAYER LEVEL", "XP", "RUNS", "PLAY TIME", "TOTAL COINS", "DISTANCE", "OBSTACLES DODGED", "NEAR MISSES",
    "POWER-UPS", "SPINS", "BEST COMBO", "BEST ENDLESS", "STARS", "LEVELS CLEARED", "ZONES OPEN", "AWARDS"
)

private fun statValue(i: Int, clearedCount: Int, bestEndless: Int): String {
    val hrs = floor(stats.time / 3600.0).toInt()
    val mins = floor((stats.time % 3600.0) / 60.0).toInt()
    return when (i) {
        0 -> plv().toString()
        1 -> xp.toString()
        2 -> stats.runs.toString()
        3 -> T("{0}h {1}m", hrs, mins)
        4 -> stats.coins.toString()
        5 -> T("{0} m", stats.dist)
        6 -> stats.dodge.toString()
        7 -> stats.near.toString()
        8 -> stats.pw.toString()
        9 -> stats.spins.toString()
        10 -> "x" + stats.bc
        11 -> bestEndless.toString()
        12 -> "${totalStars()}/${ZN.size * CFG_LEVELS * 3}"
        13 -> "$clearedCount/${ZN.size * CFG_LEVELS}"
        14 -> "${openCount()}/${ZN.size}"
        else -> "${achDone()}/${ACH.size}"
    }
}

private val PU_KEYS = arrayOf("shield", "magnet", "star", "coin2", "slow", "mini", "rain", "wings", "sx2")
private val PU_HUES = doubleArrayOf(190.0, 340.0, 48.0, 50.0, 215.0, 285.0, 160.0, 255.0, 110.0)
private val PU_MAX = doubleArrayOf(1.0, 8.0, 6.0, 10.0, 5.0, 8.0, 6.0, 5.0, 8.0)

private fun powerValues(): DoubleArray {
    val v = DoubleArray(9)
    v[0] = if (shield > 0 || petGuard > 0) 1.0 else 0.0
    v[1] = magnet
    v[2] = dash
    v[3] = dbl
    v[4] = slow
    v[5] = mini
    v[6] = pwRain
    v[7] = pwWing
    v[8] = pwSx
    return v
}

fun buildSnap(): Snap {
    val s = Snap()
    s.st = st
    s.stAtMs = stAt
    s.bank = bank
    s.hearts = hearts
    s.best = best
    s.zi = zi
    s.li = li
    s.zoneName = ZN[zi].name
    s.mode = mode
    s.music = opt.music
    s.sfx = opt.sfx
    s.vib = opt.vib
    s.ghost = opt.ghost
    s.bn = isBn()
    s.lang = opt.lang
    s.coarse = coarse
    if (toast.life > 0.0) {
        s.toast = toast.text
        s.toastK = toast.life / toast.max
    }
    val gf = gift
    if (gf != null) {
        s.giftOn = true
        s.giftAmt = gf.amt
        s.giftStreak = gf.streak
    }
    val l = lvl
    s.levelMode = l != null
    s.daily = mode == "daily"
    s.boss = l != null && l.boss
    s.levelCoins = l?.coins ?: 0
    s.rule = if (l != null && l.rule.isNotEmpty()) T(ruleLabel(l.rule)) + (if (l.rule == "sprint") "  " + max(0, ceil((l.len - runDist) / l.sp).toInt()) + "s" else "") else ""
    s.sub = if (l != null) (if (mode == "daily") T("DAILY") else T("LEVEL {0}", li + 1)) else T("BEST {0}", max(eb[zi], floor(score).toInt()))
    s.score = floor(shown).toInt()
    s.scoreF = floor(score).toInt()
    s.runCoins = coins
    s.got = got
    s.dist = floor(runDist / 80.0).toInt()
    s.progress = if (l != null) clamp(runDist / l.len, 0.0, 1.0) else 0.0
    s.combo = if (st == 1) combo else 0
    s.comboF = clamp(comboT / 1.6, 0.0, 1.0)
    s.comboFx = clamp((p.x + 40.0) / L, 0.0, 1.0)
    s.comboFy = clamp((p.y - 88.0 + ty) / (360.0 + ty * 2.0), 0.0, 1.0)
    val pv = powerValues()
    val pl = ArrayList<UPower>()
    for (e in 0 until 9) {
        if (pv[e] > 0.0) pl.add(UPower(PU_KEYS[e], PU_HUES[e], min(1.0, pv[e] / PU_MAX[e])))
    }
    s.powers = pl
    val sk = SKL[skillSel]
    s.skKey = sk.k
    s.skHue = sk.hue
    s.skOff = l != null && l.boss
    s.skReady = !s.skOff && skCd <= 0.0 && skAct <= 0.0
    s.skActive = skAct > 0.0
    s.skF = if (s.skOff) 0.0 else if (skAct > 0.0) skAct / sk.dur else if (skCd > 0.0) 1.0 - skCd / sk.cd else 1.0
    s.skCd = if (skCd > 0.0 && skAct <= 0.0) ceil(skCd).toInt() else 0
    if (banner.life > 0.0) {
        val k = banner.life / banner.max
        s.bannerText = banner.text
        s.bannerSub = banner.sub
        s.bannerA = min(clamp((1.0 - k) * 4.0, 0.0, 1.0), clamp(k * 2.5, 0.0, 1.0))
    }
    if (st == 1 && cd > 0.0) {
        s.cdN = ceil(cd).toInt()
        s.cdF = s.cdN - cd
    }
    s.hintA = if (st == 1 && cd <= 0.0 && hint > 0.0) clamp(hint, 0.0, 1.0) else 0.0

    if (st != 1) {
        val v = lvOf(xp)
        s.lv = v.n
        s.xpCur = v.cur
        s.xpNeed = v.need
        s.runXp = runXp
        s.stars = totalStars()
        s.starsMax = ZN.size * CFG_LEVELS * 3
        s.streak = streak
        s.achDone = achDone()
        s.achTotal = ACH.size
        s.spinReady = spinAvail()
        val ml = ArrayList<UMission>()
        for (i in 0 until 3) {
            val m = MS[todays[i]]
            ml.add(UMission(m.t, min(mp[i], m.n), m.n, m.r, md[i] != 0))
        }
        s.missions = ml
        val dc = dcfg()
        s.dailyDone = dcDone == day
        s.dailyText = if (s.dailyDone) T("DONE") + "  " + dcBest + "/3" else zn(dc.z) + (if (dc.rule.isNotEmpty()) "  -  " + T(ruleLabel(dc.rule)) else "")

    }

    s.newBest = newBest
    s.pct = if (l != null) floor(clamp(runDist / l.len, 0.0, 1.0) * 100.0).toInt() else 0
    s.runCombo = runCombo
    s.toBeat = max(1, eb[zi] - floor(score).toInt())
    s.lbRank = lbRank
    s.reviveF = clamp(revT / 5.0, 0.0, 1.0)
    s.reviveCost = 1 shl revUsed
    s.unlockZone = unl
    val r0 = res
    if (r0 != null) {
        s.resStars = r0.stars.copyOf()
        s.resGot = r0.got
        s.resTotal = r0.total
        s.resBonus = r0.bonus
        s.resFirst = r0.first
        s.resDaily = r0.daily
    }

    when (st) {
        4 -> buildShop(s)
        5 -> s.confirmReset = nowMs() - confirmAt < 3000.0
        6 -> {
            s.zmode = zmode
            val zl = ArrayList<UZone>()
            for (i in ZN.indices) {
                val n = zStars(i)
                zl.add(UZone(ZN[i].name, zoneOpen(i), n, eb[i], n >= CFG_LEVELS * 3, i == zi))
            }
            s.zones = zl
            s.zpage = lastZ / CFG_PER_PAGE
        }
        7 -> {
            val ll = ArrayList<ULevel>()
            for (i in 0 until CFG_LEVELS) {
                val open = lvlOpen(zi, i)
                val n = prog[zi][i]
                ll.add(ULevel(i + 1, n, open, i == CFG_LEVELS - 1, open && n == 0))
            }
            s.levels = ll
            val hasNext = zi + 1 < ZN.size
            val open = hasNext && zoneOpen(zi + 1)
            s.levelsNoteOk = open
            s.levelsNote = if (!hasNext) T("Final zone of this version") else if (open) T("{0} unlocked", zn(zi + 1)) else T("Clear {0} levels to unlock {1}  ({2}/{0})", CFG_NEED, zn(zi + 1), cleared(zi))
        }
        10 -> {
            val al = ArrayList<UAch>()
            for (i in ACH.indices) {
                val a = ACH[i]
                al.add(UAch(a.n, a.d, a.r, min(a.g(), a.m), a.m, ach[i] != 0))
            }
            s.achs = al
        }
        11 -> {
            s.lbz = lbz
            s.lbName = ZN[lbz].name
            s.lbOpen = zoneOpen(lbz)
            val bl = ArrayList<UBoard>()
            for (e in lb[lbz]) bl.add(UBoard(e.s, dayLabel(e.d)))
            s.board = bl
            s.ghostSaved = gh.containsKey("E$lbz")
        }
        12 -> {
            s.spinning = spinning
            s.spinFrom = spinFrom
            s.spinTo = spinTo
            s.spinT0 = spinT0
            s.spinIdx = spinIdx
            s.spinA = spinA
            s.spinWon = spinIdx >= 0 && spinDay == day
        }
        13 -> {
            var lvc = 0
            for (z in prog) for (q in z) if (q > 0) lvc++
            var be = 0
            for (q in eb) be = max(be, q)
            val sl = ArrayList<UStat>()
            for (i in 0 until 16) sl.add(UStat(STAT_HEADS[i], statValue(i, lvc, be), i))
            s.statsList = sl
        }
    }
    return s
}

private fun buildShop(s: Snap) {
    val tab = shopTab
    s.shopTab = tab
    s.shopSel = shopSel
    val own = tabOwn(tab)
    val sel = tabSel(tab)
    val il = ArrayList<UItem>()
    for (i in 0 until tabCount(tab)) {
        val zone = itemZone(tab, i)
        val owned = own[i] != 0
        il.add(UItem(itemName(tab, i), owned, i == sel, if (!owned && zone >= 0) zn(zone) else "", itemCost(tab, i), itemHc(tab, i)))
    }
    s.items = il
    val i = shopSel
    val zone = itemZone(tab, i)
    val owned = own[i] != 0
    s.shopNote = if (!owned && zone >= 0) T("Clear {0} levels in {1}  ({2}/{0})", CFG_NEED, zn(zone), cleared(zone))
    else if (tab == 3 && PT[i].desc.isNotEmpty()) T(PT[i].desc)
    else if (tab == 4) T(SKL[i].desc) + "  -  " + T("{0}s cooldown", SKL[i].cd.toInt())
    else ""
}

fun publishUi() {
    val now = nowMs()
    val gap = if (st == 1) 33.0 else if (st == 3 || st == 14 || st == 12) 33.0 else 100.0
    if (UiBridge.force || st != UiBridge.lastSt || now - UiBridge.lastPub >= gap) {
        UiBridge.force = false
        UiBridge.lastSt = st
        UiBridge.lastPub = now
        UiBridge.snap.value = buildSnap()
    }
    UiBridge.fade.floatValue = fade.toFloat()
    if (st == 1 && combo > 1) {
        UiBridge.comboX.floatValue = clamp((p.x + 40.0) / L, 0.0, 1.0).toFloat()
        UiBridge.comboY.floatValue = clamp((p.y - 88.0 + ty) / (360.0 + ty * 2.0), 0.0, 1.0).toFloat()
    }
}
