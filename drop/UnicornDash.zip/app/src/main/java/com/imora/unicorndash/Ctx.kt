package com.imora.unicorndash

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

const val CAP_BUTT = 0
const val CAP_ROUND = 1
const val JOIN_MITER = 0
const val JOIN_ROUND = 1
const val ALIGN_LEFT = 0
const val ALIGN_CENTER = 1
const val ALIGN_RIGHT = 2

class Ctx {
    lateinit var canvas: Canvas
    val path = Path()
    private val tmpPath = Path()
    private val tmpMatrix = Matrix()
    private val mvals = FloatArray(9)
    private val rectF = RectF()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textFillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val glowCache = HashMap<Int, Bitmap>()
    private val linCache = HashMap<Long, LinearGradient>()
    private val radCache = HashMap<Long, RadialGradient>()
    private var hasPt = false

    var alpha = 1.0
    var inkMode = false
    private var fillColorV = Color.BLACK
    private var strokeColorV = Color.BLACK
    private var fillShaderV: Shader? = null
    private var strokeShaderV: Shader? = null
    private var lw = 1.0
    private var capV = CAP_BUTT
    private var joinV = JOIN_MITER
    private var dashA = 0f
    private var dashB = 0f
    private var dashOn = false
    var dashOffset = 0.0
    private var alignV = ALIGN_LEFT

    private val stAlpha = DoubleArray(48)
    private val stFill = IntArray(48)
    private val stStroke = IntArray(48)
    private val stFillSh = arrayOfNulls<Shader>(48)
    private val stStrokeSh = arrayOfNulls<Shader>(48)
    private val stLw = DoubleArray(48)
    private val stCap = IntArray(48)
    private val stJoin = IntArray(48)
    private val stDashA = FloatArray(48)
    private val stDashB = FloatArray(48)
    private val stDashOn = BooleanArray(48)
    private val stDashOff = DoubleArray(48)
    private val stAlign = IntArray(48)
    private val stInk = BooleanArray(48)
    private var depth = 0

    init {
        fillPaint.style = Paint.Style.FILL
        strokePaint.style = Paint.Style.STROKE
        textFillPaint.style = Paint.Style.FILL
        textStrokePaint.style = Paint.Style.STROKE
        textFillPaint.typeface = Typeface.DEFAULT_BOLD
        textStrokePaint.typeface = Typeface.DEFAULT_BOLD
        glowPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
    }

    var fillStyle: Int
        get() = fillColorV
        set(v) {
            if (inkMode) return
            fillColorV = v
            fillShaderV = null
        }

    var strokeStyle: Int
        get() = strokeColorV
        set(v) {
            if (inkMode) return
            strokeColorV = v
            strokeShaderV = null
        }

    var fillShader: Shader?
        get() = fillShaderV
        set(v) {
            if (inkMode) return
            fillShaderV = v
        }

    var strokeShader: Shader?
        get() = strokeShaderV
        set(v) {
            if (inkMode) return
            strokeShaderV = v
        }

    var lineWidth: Double
        get() = lw
        set(v) {
            lw = v
        }

    var lineCap: Int
        get() = capV
        set(v) {
            capV = v
        }

    var lineJoin: Int
        get() = joinV
        set(v) {
            joinV = v
        }

    var textAlign: Int
        get() = alignV
        set(v) {
            alignV = v
        }

    fun begin(c: Canvas) {
        canvas = c
        depth = 0
        alpha = 1.0
        inkMode = false
        fillColorV = Color.BLACK
        strokeColorV = Color.BLACK
        fillShaderV = null
        strokeShaderV = null
        lw = 1.0
        capV = CAP_BUTT
        joinV = JOIN_MITER
        dashOn = false
        dashOffset = 0.0
        alignV = ALIGN_LEFT
        path.reset()
        hasPt = false
    }

    fun save() {
        val i = depth
        if (i < 48) {
            stAlpha[i] = alpha
            stFill[i] = fillColorV
            stStroke[i] = strokeColorV
            stFillSh[i] = fillShaderV
            stStrokeSh[i] = strokeShaderV
            stLw[i] = lw
            stCap[i] = capV
            stJoin[i] = joinV
            stDashA[i] = dashA
            stDashB[i] = dashB
            stDashOn[i] = dashOn
            stDashOff[i] = dashOffset
            stAlign[i] = alignV
            stInk[i] = inkMode
        }
        depth++
        canvas.save()
    }

    fun restore() {
        if (depth <= 0) return
        depth--
        val i = depth
        if (i < 48) {
            alpha = stAlpha[i]
            fillColorV = stFill[i]
            strokeColorV = stStroke[i]
            fillShaderV = stFillSh[i]
            strokeShaderV = stStrokeSh[i]
            lw = stLw[i]
            capV = stCap[i]
            joinV = stJoin[i]
            dashA = stDashA[i]
            dashB = stDashB[i]
            dashOn = stDashOn[i]
            dashOffset = stDashOff[i]
            alignV = stAlign[i]
            inkMode = stInk[i]
        }
        canvas.restore()
    }

    fun translate(x: Double, y: Double) {
        canvas.translate(x.toFloat(), y.toFloat())
    }

    fun scale(sx: Double, sy: Double) {
        canvas.scale(sx.toFloat(), sy.toFloat())
    }

    fun rotate(a: Double) {
        canvas.rotate((a * 180.0 / PI).toFloat())
    }

    fun setBaseTransform(s: Double, tx: Double, ty: Double) {
        canvas.translate(tx.toFloat(), ty.toFloat())
        canvas.scale(s.toFloat(), s.toFloat())
    }

    fun setLineDash(a: Double, b: Double) {
        dashA = a.toFloat()
        dashB = b.toFloat()
        dashOn = true
    }

    fun clearLineDash() {
        dashOn = false
    }

    fun beginPath() {
        path.reset()
        hasPt = false
    }

    fun moveTo(x: Double, y: Double) {
        path.moveTo(x.toFloat(), y.toFloat())
        hasPt = true
    }

    fun lineTo(x: Double, y: Double) {
        if (!hasPt) {
            path.moveTo(x.toFloat(), y.toFloat())
            hasPt = true
        } else {
            path.lineTo(x.toFloat(), y.toFloat())
        }
    }

    fun quadraticCurveTo(cx: Double, cy: Double, x: Double, y: Double) {
        if (!hasPt) {
            path.moveTo(cx.toFloat(), cy.toFloat())
            hasPt = true
        }
        path.quadTo(cx.toFloat(), cy.toFloat(), x.toFloat(), y.toFloat())
    }

    fun bezierCurveTo(c1x: Double, c1y: Double, c2x: Double, c2y: Double, x: Double, y: Double) {
        if (!hasPt) {
            path.moveTo(c1x.toFloat(), c1y.toFloat())
            hasPt = true
        }
        path.cubicTo(c1x.toFloat(), c1y.toFloat(), c2x.toFloat(), c2y.toFloat(), x.toFloat(), y.toFloat())
    }

    fun closePath() {
        path.close()
    }

    fun rect(x: Double, y: Double, w: Double, h: Double) {
        val x0 = x.toFloat()
        val y0 = y.toFloat()
        val x1 = (x + w).toFloat()
        val y1 = (y + h).toFloat()
        path.moveTo(x0, y0)
        path.lineTo(x1, y0)
        path.lineTo(x1, y1)
        path.lineTo(x0, y1)
        path.close()
        path.moveTo(x0, y0)
        hasPt = true
    }

    fun roundRect(x: Double, y: Double, w: Double, h: Double, r: Double) {
        val rr = max(0.0, min(r, min(w, h) / 2.0)).toFloat()
        rectF.set(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat())
        path.addRoundRect(rectF, rr, rr, Path.Direction.CW)
        hasPt = true
    }

    fun arc(cx: Double, cy: Double, r: Double, a0: Double, a1: Double) {
        if (r <= 0.0) return
        ellipse(cx, cy, r, r, 0.0, a0, a1)
    }

    fun ellipse(cx: Double, cy: Double, rx: Double, ry: Double, rot: Double, a0: Double, a1: Double) {
        if (rx <= 0.0 || ry <= 0.0) return
        var sweep = a1 - a0
        val full = sweep >= TAU - 1.0e-6
        if (!full) {
            if (sweep < 0.0) sweep += TAU * Math.ceil(-sweep / TAU)
            sweep %= TAU
        } else {
            sweep = TAU
        }
        val startDeg = (a0 * 180.0 / PI).toFloat()
        val sweepDeg = (sweep * 180.0 / PI).toFloat()
        val target = if (rot == 0.0) path else tmpPath
        val connect = rot == 0.0 && hasPt
        if (target === tmpPath) tmpPath.reset()
        rectF.set((cx - rx).toFloat(), (cy - ry).toFloat(), (cx + rx).toFloat(), (cy + ry).toFloat())
        if (rot != 0.0) {
            rectF.set((-rx).toFloat(), (-ry).toFloat(), rx.toFloat(), ry.toFloat())
        }
        if (full) {
            target.arcTo(rectF, startDeg, 180f, !connect)
            target.arcTo(rectF, startDeg + 180f, 180f, false)
        } else {
            target.arcTo(rectF, startDeg, sweepDeg, !connect)
        }
        if (rot != 0.0) {
            tmpMatrix.reset()
            tmpMatrix.setRotate((rot * 180.0 / PI).toFloat())
            tmpMatrix.postTranslate(cx.toFloat(), cy.toFloat())
            tmpPath.transform(tmpMatrix)
            path.addPath(tmpPath)
        }
        hasPt = true
    }

    private fun prepFill() {
        val sh = fillShaderV
        if (sh != null) {
            fillPaint.shader = sh
            fillPaint.color = Color.BLACK
            fillPaint.alpha = (clamp(alpha, 0.0, 1.0) * 255.0 + 0.5).toInt()
        } else {
            fillPaint.shader = null
            fillPaint.color = fillColorV
            fillPaint.alpha = (Color.alpha(fillColorV) * clamp(alpha, 0.0, 1.0) + 0.5).toInt()
        }
        fillPaint.pathEffect = null
    }

    private fun prepStroke(extra: Double) {
        val sh = strokeShaderV
        if (sh != null) {
            strokePaint.shader = sh
            strokePaint.color = Color.BLACK
            strokePaint.alpha = (clamp(alpha, 0.0, 1.0) * 255.0 + 0.5).toInt()
        } else {
            strokePaint.shader = null
            strokePaint.color = strokeColorV
            strokePaint.alpha = (Color.alpha(strokeColorV) * clamp(alpha, 0.0, 1.0) + 0.5).toInt()
        }
        strokePaint.strokeWidth = (lw + extra).toFloat()
        strokePaint.strokeCap = if (capV == CAP_ROUND) Paint.Cap.ROUND else Paint.Cap.BUTT
        strokePaint.strokeJoin = if (joinV == JOIN_ROUND) Paint.Join.ROUND else Paint.Join.MITER
        strokePaint.strokeMiter = 10f
        if (dashOn && !inkMode) {
            strokePaint.pathEffect = DashPathEffect(floatArrayOf(dashA, dashB), dashOffset.toFloat())
        } else {
            strokePaint.pathEffect = null
        }
    }

    fun fill(evenOdd: Boolean = false) {
        prepFill()
        path.fillType = if (evenOdd) Path.FillType.EVEN_ODD else Path.FillType.WINDING
        canvas.drawPath(path, fillPaint)
        path.fillType = Path.FillType.WINDING
        if (inkMode) {
            val keep = lw
            lw = INK_OUT
            prepStroke(0.0)
            canvas.drawPath(path, strokePaint)
            lw = keep
        }
    }

    fun stroke() {
        prepStroke(if (inkMode) INK_OUT else 0.0)
        canvas.drawPath(path, strokePaint)
    }

    fun clip(evenOdd: Boolean = false) {
        path.fillType = if (evenOdd) Path.FillType.EVEN_ODD else Path.FillType.WINDING
        canvas.clipPath(path)
        path.fillType = Path.FillType.WINDING
    }

    fun fillRect(x: Double, y: Double, w: Double, h: Double) {
        prepFill()
        canvas.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), fillPaint)
    }

    fun strokeRect(x: Double, y: Double, w: Double, h: Double) {
        prepStroke(if (inkMode) INK_OUT else 0.0)
        canvas.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), strokePaint)
    }

    fun setFont(size: Double) {
        textFillPaint.textSize = size.toFloat()
        textStrokePaint.textSize = size.toFloat()
    }

    fun measureText(s: String): Double = textFillPaint.measureText(s).toDouble()

    private fun applyAlign() {
        val a = when (alignV) {
            ALIGN_CENTER -> Paint.Align.CENTER
            ALIGN_RIGHT -> Paint.Align.RIGHT
            else -> Paint.Align.LEFT
        }
        textFillPaint.textAlign = a
        textStrokePaint.textAlign = a
    }

    private fun baseline(y: Double): Float {
        val fm = textFillPaint.fontMetrics
        return (y - (fm.ascent + fm.descent) / 2.0).toFloat()
    }

    fun fillText(s: String, x: Double, y: Double) {
        applyAlign()
        val sh = fillShaderV
        if (sh != null) {
            textFillPaint.shader = sh
            textFillPaint.color = Color.BLACK
            textFillPaint.alpha = (clamp(alpha, 0.0, 1.0) * 255.0 + 0.5).toInt()
        } else {
            textFillPaint.shader = null
            textFillPaint.color = fillColorV
            textFillPaint.alpha = (Color.alpha(fillColorV) * clamp(alpha, 0.0, 1.0) + 0.5).toInt()
        }
        canvas.drawText(s, x.toFloat(), baseline(y), textFillPaint)
    }

    fun strokeText(s: String, x: Double, y: Double) {
        applyAlign()
        textStrokePaint.shader = null
        textStrokePaint.color = strokeColorV
        textStrokePaint.alpha = (Color.alpha(strokeColorV) * clamp(alpha, 0.0, 1.0) + 0.5).toInt()
        textStrokePaint.strokeWidth = lw.toFloat()
        textStrokePaint.strokeJoin = Paint.Join.ROUND
        canvas.drawText(s, x.toFloat(), baseline(y), textStrokePaint)
    }

    private fun applyUnit(sh: Shader, x0: Double, y0: Double, x1: Double, y1: Double) {
        var dx = x1 - x0
        var dy = y1 - y0
        if (abs(dx) < 1.0e-4 && abs(dy) < 1.0e-4) dx = 1.0e-4
        mvals[0] = dx.toFloat()
        mvals[1] = (-dy).toFloat()
        mvals[2] = x0.toFloat()
        mvals[3] = dy.toFloat()
        mvals[4] = dx.toFloat()
        mvals[5] = y0.toFloat()
        mvals[6] = 0f
        mvals[7] = 0f
        mvals[8] = 1f
        tmpMatrix.setValues(mvals)
        sh.setLocalMatrix(tmpMatrix)
    }

    fun lin(x0: Double, y0: Double, x1: Double, y1: Double, c0: Int, c1: Int): Shader {
        val key = (c0.toLong() shl 32) or (c1.toLong() and 0xFFFFFFFFL)
        var sh = linCache[key]
        if (sh == null) {
            if (linCache.size > 400) linCache.clear()
            sh = LinearGradient(0f, 0f, 1f, 0f, c0, c1, Shader.TileMode.CLAMP)
            linCache[key] = sh
        }
        applyUnit(sh, x0, y0, x1, y1)
        return sh
    }

    fun linN(x0: Double, y0: Double, x1: Double, y1: Double, colors: IntArray, pos: FloatArray): Shader {
        val sh = LinearGradient(x0.toFloat(), y0.toFloat(), x1.toFloat(), y1.toFloat(), colors, pos, Shader.TileMode.CLAMP)
        return sh
    }

    fun rad(cx: Double, cy: Double, r: Double, c0: Int, c1: Int): Shader {
        val key = (c0.toLong() shl 32) or (c1.toLong() and 0xFFFFFFFFL)
        var sh = radCache[key]
        if (sh == null) {
            if (radCache.size > 200) radCache.clear()
            sh = RadialGradient(0f, 0f, 1f, c0, c1, Shader.TileMode.CLAMP)
            radCache[key] = sh
        }
        tmpMatrix.reset()
        tmpMatrix.setScale(r.toFloat(), r.toFloat())
        tmpMatrix.postTranslate(cx.toFloat(), cy.toFloat())
        sh.setLocalMatrix(tmpMatrix)
        return sh
    }

    fun radN(cx: Double, cy: Double, r: Double, colors: IntArray, pos: FloatArray): Shader {
        return RadialGradient(cx.toFloat(), cy.toFloat(), r.toFloat(), colors, pos, Shader.TileMode.CLAMP)
    }

    private fun glowBitmap(h: Double, s: Double, l: Double): Bitmap {
        val hq = (((round(h / 4.0).toInt() % 90) + 90) % 90)
        val si = round(s).toInt()
        val li = round(l).toInt()
        val key = (hq * 128 + si) * 128 + li
        var bmp = glowCache[key]
        if (bmp == null) {
            bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            val hue = hq * 4.0
            val colors = intArrayOf(hsl(hue, si.toDouble(), li.toDouble(), 1.0), hsl(hue, si.toDouble(), li.toDouble(), 0.4), hsl(hue, si.toDouble(), li.toDouble(), 0.0))
            val pos = floatArrayOf(0f, 0.35f, 1f)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = RadialGradient(32f, 32f, 32f, colors, pos, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, 64f, 64f, p)
            glowCache[key] = bmp
        }
        return bmp
    }

    fun halo(px: Double, py: Double, r: Double, h: Double, s: Double, l: Double, a: Double) {
        if (a <= 0.0 || r <= 0.0 || inkMode) return
        val bmp = glowBitmap(h, s, l)
        glowPaint.alpha = (clamp(min(1.0, a) * alpha, 0.0, 1.0) * 255.0 + 0.5).toInt()
        rectF.set((px - r).toFloat(), (py - r).toFloat(), (px + r).toFloat(), (py + r).toFloat())
        canvas.drawBitmap(bmp, null, rectF, glowPaint)
    }

    fun inkBegin() {
        save()
        fillColorV = INK_COLOR
        strokeColorV = INK_COLOR
        fillShaderV = null
        strokeShaderV = null
        joinV = JOIN_ROUND
        capV = CAP_ROUND
        lw = 1.0
        inkMode = true
    }

    fun inkEnd() {
        inkMode = false
        restore()
    }

    companion object {
        const val INK_OUT = 3.2
        val INK_COLOR = rgba(36, 16, 84, 0.95)
    }
}
