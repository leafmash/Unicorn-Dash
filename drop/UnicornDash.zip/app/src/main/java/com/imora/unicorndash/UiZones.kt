package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

private val STAR_YELLOW = hex(0xffe27a)
private val PALE_LILAC = hex(0xe9dcff)
private val DIM_LILAC = hex(0xa89cd4)

fun zprev(i: Int, x0: Double, y0: Double, w: Double, h: Double, r: Double) {
    val o = zoneObj(i)
    val keepZ = Z
    val keepL = L
    val keepTy = ty
    val s = h / 250.0
    x.save()
    pill(x0, y0, w, h, r)
    x.clip()
    x.translate(x0, y0 - 120.0 * s)
    x.scale(s, s)
    Z = o
    L = w / s
    ty = 0.0
    x.fillShader = x.lin(0.0, 0.0, 0.0, G, o.top, o.bot)
    x.fillRect(0.0, 0.0, L, 372.0)
    if (o.night > 0.2) {
        x.fillStyle = rgba(255, 255, 255, 0.35 + o.night * 0.5)
        for (k in 0 until 24) x.fillRect(hs(k + i * 17) * L, 120.0 + hs(k + 50 + i * 17) * 120.0, 2.4, 2.4)
    }
    x.fillStyle = o.body
    x.beginPath()
    x.arc(L * 0.78, 168.0, 22.0, 0.0, 7.0)
    x.fill()
    backdrop(220.0 + i * 137.0)
    Z = keepZ
    L = keepL
    ty = keepTy
    x.restore()
}

fun zoneCard(i: Int, bx: Double, by: Double, w: Double, h: Double) {
    val id = "zc$i"
    val open = zoneOpen(i)
    val n = zStars(i)
    uiPush(id, bx, by, w, h)
    val s = uiScale(id, 1.05, 0.96)
    x.save()
    x.translate(bx + w / 2.0, by + h / 2.0)
    x.scale(s, s)
    x.translate(-w / 2.0, -h / 2.0)
    if (open && i == zi) x.halo(w / 2.0, h / 2.0, w * 0.7, ZN[i].hue, 100.0, 70.0, 0.22)
    pill(0.0, 0.0, w, h, 16.0)
    x.fillStyle = if (open) rgba(255, 255, 255, 0.14) else rgba(255, 255, 255, 0.06)
    x.fill()
    val full = n >= CFG_LEVELS * 3
    x.strokeStyle = if (full) GOLD else if (open) rgba(255, 255, 255, 0.55) else rgba(255, 255, 255, 0.2)
    x.lineWidth = if (full) 2.4 else 1.5
    x.stroke()
    zprev(i, 8.0, 8.0, w - 16.0, 52.0, 11.0)
    if (!open) {
        pill(8.0, 8.0, w - 16.0, 52.0, 11.0)
        x.fillStyle = rgba(10, 5, 35, 0.64)
        x.fill()
        iconLock(w / 2.0, 32.0, 12.0)
    }
    label(ZN[i].name, 12.0, w / 2.0, 74.0, if (open) WHITE else DIM_LILAC)
    if (!open) {
        label("Locked", 10.5, w / 2.0, 90.0, DIM_LILAC)
    } else if (zmode == "adv") {
        iconStar(w / 2.0 - 24.0, 90.0, 6.5, n > 0)
        label("$n/${CFG_LEVELS * 3}", 11.0, w / 2.0 - 14.0, 91.0, STAR_YELLOW, ALIGN_LEFT)
    } else {
        label(T("BEST {0}", eb[i]), 11.0, w / 2.0, 90.0, hex(0xd9ccff))
    }
    x.restore()
}

fun zonePages(): Int = ceil(ZN.size.toDouble() / CFG_PER_PAGE).toInt()

fun flip(d: Int) {
    val pages = zonePages()
    val n = clampI(zpage + d, 0, pages - 1)
    if (n == zpage) return
    zpage = n
    zoff = d * 70.0
    snd("click")
}

fun zonesUI() {
    val cx = L / 2.0
    val pages = zonePages()
    veil(0.78)
    title(if (zmode == "adv") "ADVENTURE" else "ENDLESS", 28.0, cx, 32.0)
    label(if (zmode == "adv") "Pick a zone" else "Pick a zone to run forever", 12.0, cx, 58.0, PALE_LILAC)
    val cw = 130.0
    val ch = 100.0
    val gx = 12.0
    val gy = 10.0
    val x0 = cx - (3.0 * cw + 2.0 * gx) / 2.0
    zoff = damp(zoff, 0.0, 12.0, fdt)
    x.save()
    x.alpha *= 1.0 - min(1.0, abs(zoff) / 90.0)
    for (k in 0 until CFG_PER_PAGE) {
        val i = zpage * CFG_PER_PAGE + k
        if (i >= ZN.size) break
        zoneCard(i, x0 + (k % 3) * (cw + gx) + zoff, 78.0 + floor(k / 3.0) * (ch + gy), cw, ch)
    }
    x.restore()
    btn("back", "BACK", cx - 150.0, 328.0, 110.0, 36.0, 's')
    if (pages > 1) {
        if (zpage > 0) ibtn("zprev", cx - 52.0, 328.0, 17.0, iconArrowLeft)
        if (zpage < pages - 1) ibtn("znext", cx + 52.0, 328.0, 17.0, iconArrowRight)
        for (k in 0 until pages) {
            x.fillStyle = if (k == zpage) WHITE else rgba(255, 255, 255, 0.3)
            x.beginPath()
            x.arc(cx + (k - (pages - 1) / 2.0) * 12.0, 328.0, if (k == zpage) 3.6 else 2.8, 0.0, 7.0)
            x.fill()
        }
    }
    if (zmode == "adv") {
        var tot = 0
        for (i in ZN.indices) tot += zStars(i)
        chip(cx + 150.0, 328.0, 118.0, 24.0, T("STARS {0}/{1}", tot, ZN.size * CFG_LEVELS * 3), STAR_YELLOW)
    } else {
        chip(cx + 150.0, 328.0, 110.0, 24.0, bank.toString(), STAR_YELLOW, true)
    }
}

fun levelBtn(i: Int, bx: Double, by: Double, bw: Double) {
    val id = "lv$i"
    val locked = !lvlOpen(zi, i)
    val n = prog[zi][i]
    val boss = i == CFG_LEVELS - 1
    val nextUp = !locked && n == 0
    uiPush(id, bx, by, bw, bw)
    val s = uiScale(id, 1.08, 0.94)
    x.save()
    x.translate(bx + bw / 2.0, by + bw / 2.0)
    x.scale(s, s)
    val r = bw / 2.0
    if (nextUp) x.halo(0.0, 0.0, bw * 0.9, if (boss) 350.0 else 320.0, 100.0, 70.0, 0.3 + 0.15 * sin(clock * 4.0))
    pill(-r, -r, bw, bw, 16.0)
    if (locked) {
        x.fillShader = x.lin(0.0, -r, 0.0, r, rgba(255, 255, 255, 0.12), rgba(255, 255, 255, 0.05))
    } else if (boss) {
        x.fillShader = x.lin(0.0, -r, 0.0, r, hex(0xff8a9a), hex(0xc0304f))
    } else if (n > 0) {
        x.fillShader = x.lin(0.0, -r, 0.0, r, PINK_TOP, PURPLE_BOT)
    } else {
        x.fillShader = x.lin(0.0, -r, 0.0, r, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.12))
    }
    x.fill()
    x.strokeStyle = if (locked) rgba(255, 255, 255, 0.25) else RIM_WHITE
    x.lineWidth = 1.6
    x.stroke()
    if (ruleOf(zi, i).isNotEmpty() && !locked) {
        x.fillStyle = hex(0xffb0cf)
        x.beginPath()
        x.arc(r - 8.0, -r + 8.0, 4.0, 0.0, 7.0)
        x.fill()
    }
    if (locked) {
        iconLock(0.0, -2.0, 11.0)
    } else {
        if (boss) label("BOSS", 9.5, 0.0, -r + 11.0, hex(0xfff3c4))
        label((i + 1).toString(), 24.0, 0.0, if (boss) -2.0 else -5.0, WHITE)
        for (k in 0 until 3) iconStar((k - 1) * 15.0, r - 13.0, 6.0, k < n)
    }
    x.restore()
}

fun levelsUI() {
    val cx = L / 2.0
    val bw = 62.0
    val g = 14.0
    val x0 = cx - (5.0 * bw + 4.0 * g) / 2.0
    veil(0.78)
    title(ZN[zi].name, 28.0, cx, 32.0)
    chip(cx, 62.0, 120.0, 22.0, T("STARS {0}/{1}", zStars(zi), CFG_LEVELS * 3), STAR_YELLOW)
    for (i in 0 until CFG_LEVELS) levelBtn(i, x0 + (i % 5) * (bw + g), 88.0 + floor(i / 5.0) * (bw + 22.0), bw)
    val hasNext = zi + 1 < ZN.size
    val open = hasNext && zoneOpen(zi + 1)
    val txt = if (!hasNext) T("Final zone of this version") else if (open) T("{0} unlocked", zn(zi + 1)) else T("Clear {0} levels to unlock {1}  ({2}/{0})", CFG_NEED, zn(zi + 1), cleared(zi))
    x.setFont(12.0)
    val tw = x.measureText(fmt(txt)) + 30.0
    glass(cx - tw / 2.0, 252.0, tw, 26.0, 13.0, 0.75)
    label(txt, 12.0, cx, 265.0, if (open) hex(0x7dffd4) else PALE_LILAC)
    btn("back", "BACK", cx, 322.0, 140.0, 38.0, 's')
}
