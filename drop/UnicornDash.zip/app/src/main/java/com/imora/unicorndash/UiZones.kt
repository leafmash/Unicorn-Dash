package com.imora.unicorndash

fun zprev(i: Int, x0: Double, y0: Double, w: Double, h: Double, r: Double) {
    val o = zoneObj(i)
    val keepZ = Z
    val keepL = L
    val keepTy = ty
    val s = h / 250.0
    x.save()
    pill(x0, y0, w, h, r)
    x.clip()
    x.translate(x0, y0 - 120.0 * s)
    x.scale(s, s)
    Z = o
    L = w / s
    ty = 0.0
    x.fillShader = x.lin(0.0, 0.0, 0.0, G, o.top, o.bot)
    x.fillRect(0.0, 0.0, L, 372.0)
    if (o.night > 0.2) {
        x.fillStyle = rgba(255, 255, 255, 0.35 + o.night * 0.5)
        for (k in 0 until 24) x.fillRect(hs(k + i * 17) * L, 120.0 + hs(k + 50 + i * 17) * 120.0, 2.4, 2.4)
    }
    x.fillStyle = o.body
    x.beginPath()
    x.arc(L * 0.78, 168.0, 22.0, 0.0, 7.0)
    x.fill()
    backdrop(220.0 + i * 137.0)
    Z = keepZ
    L = keepL
    ty = keepTy
    x.restore()
}
