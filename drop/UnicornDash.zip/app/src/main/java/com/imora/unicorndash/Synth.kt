package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

const val BLOCK = 512

class Synth {
    private val voices = Array(128) { Voice() }
    private val noise = FloatArray(SR)
    private val busFx = FloatArray(BLOCK)
    private val busMus = FloatArray(BLOCK)
    private val lp = Biquad()
    private val reverb = Reverb()
    private val rnd = java.util.Random(7)
    private var musGain = 0.0
    private var fxGain = 1.0
    private var lpFreq = 18000.0
    private var env = 0.0
    private var compGain = 1.0
    private val attackK = exp(-1.0 / (0.004 * SR))
    private val releaseK = exp(-1.0 / (0.25 * SR))
    private val gainK = 1.0 - exp(-1.0 / (0.05 * SR))
    private val lpK = 1.0 - exp(-64.0 / (0.12 * SR))
    private val q059 = 10.0.pow(0.5 / 20.0)
    private val tau = 2.0 * Math.PI

    init {
        for (i in noise.indices) noise[i] = (rnd.nextDouble() * 2.0 - 1.0).toFloat()
        lp.set(FLT_LOW, lpFreq, q059)
    }

    private fun alloc(): Voice {
        var oldest = voices[0]
        for (v in voices) {
            if (!v.active) return v
            if (v.startS < oldest.startS) oldest = v
        }
        return oldest
    }

    fun clear() {
        for (v in voices) v.active = false
    }

    fun tone(
        f: Double,
        startS: Long,
        len: Double,
        vol: Double,
        type: Int,
        att: Double,
        hold: Double,
        cut: Double,
        cutTo: Double,
        det: Double,
        to: Double,
        bus: Int
    ) {
        val v = alloc()
        v.setup(bus, type, startS, len, vol, att, hold, f, to, det, if (cut > 0.0) FLT_LOW else FLT_NONE, cut, cutTo, 1.122)
    }

    fun puff(f: Double, startS: Long, len: Double, vol: Double, to: Double, att: Double, q: Double, ft: Int, bus: Int) {
        val v = alloc()
        val qLin = if (ft == FLT_HIGH) 10.0.pow(q / 20.0) else q
        v.setup(bus, OSC_NOISE, startS, len, vol, att, 0.0, f, 0.0, 0.0, ft, f, to, qLin)
        v.noisePos = (rnd.nextDouble() * 0.4 * SR).toInt()
    }

    private fun blep(p: Double, dt: Double): Double {
        if (p < dt) {
            val t = p / dt
            return t + t - t * t - 1.0
        }
        if (p > 1.0 - dt) {
            val t = (p - 1.0) / dt
            return t * t + t + t + 1.0
        }
        return 0.0
    }

    private fun wave(osc: Int, p: Double, dt: Double): Double = when (osc) {
        OSC_SINE -> sin(p * tau)
        OSC_TRI -> if (p < 0.5) 4.0 * p - 1.0 else 3.0 - 4.0 * p
        OSC_SAW -> 2.0 * p - 1.0 - blep(p, dt)
        else -> {
            val h = if (p + 0.5 >= 1.0) p - 0.5 else p + 0.5
            (if (p < 0.5) 1.0 else -1.0) + blep(p, dt) - blep(h, dt)
        }
    }

    private fun renderVoice(v: Voice, blockStart: Long, count: Int) {
        val out = if (v.bus == BUS_MUS) busMus else busFx
        var i = 0
        if (v.startS > blockStart) i = (v.startS - blockStart).toInt()
        while (i < count) {
            val s = blockStart + i
            if (s >= v.endS) {
                v.active = false
                return
            }
            val n = s - v.startS
            var sample: Double
            if (v.osc == OSC_NOISE) {
                sample = noise[v.noisePos].toDouble()
                v.noisePos++
                if (v.noisePos >= SR) v.noisePos = 0
            } else {
                val dt = v.freq / SR
                if (v.dual) {
                    val d1 = dt * v.detDown
                    val d2 = dt * v.detUp
                    sample = wave(v.osc, v.ph1, d1) + wave(v.osc, v.ph2, d2)
                    v.ph1 += d1
                    if (v.ph1 >= 1.0) v.ph1 -= 1.0
                    v.ph2 += d2
                    if (v.ph2 >= 1.0) v.ph2 -= 1.0
                } else {
                    sample = wave(v.osc, v.ph1, dt)
                    v.ph1 += dt
                    if (v.ph1 >= 1.0) v.ph1 -= 1.0
                }
                if (n < v.lenN) v.freq *= v.freqRatio
            }
            if (v.filterType != FLT_NONE) {
                if (v.cutRatio != 1.0 && n < v.lenN) {
                    v.cutNow *= v.cutRatio
                    if ((n and 7L) == 0L) v.filter.set(v.filterType, v.cutNow, v.q)
                }
                sample = v.filter.process(sample)
            }
            if (n < v.attN) {
                v.gain *= v.attRatio
            } else if (n < v.attN + v.holdN) {
                v.gain = v.vol
            } else if (n < v.lenN) {
                v.gain *= v.relRatio
            }
            out[i] += (sample * v.gain).toFloat()
            i++
        }
    }

    fun render(blockStart: Long, out: ShortArray, count: Int, musTarget: Double, fxTarget: Double, lpTarget: Double) {
        java.util.Arrays.fill(busFx, 0, count, 0f)
        java.util.Arrays.fill(busMus, 0, count, 0f)
        for (v in voices) if (v.active) renderVoice(v, blockStart, count)
        for (i in 0 until count) {
            musGain += (musTarget - musGain) * gainK
            fxGain += (fxTarget - fxGain) * gainK
            if ((i and 63) == 0) {
                lpFreq += (lpTarget - lpFreq) * lpK
                lp.set(FLT_LOW, lpFreq, q059)
            }
            val bus = busMus[i] * musGain + busFx[i] * fxGain
            val wet = reverb.process(bus * 0.3) * 0.85
            val y = lp.process(bus + wet)
            val a = abs(y)
            env = if (a > env) attackK * env + (1.0 - attackK) * a else releaseK * env + (1.0 - releaseK) * a
            if ((i and 7) == 0) compGain = compressorGain(env)
            var o = y * compGain * 0.9
            if (o > 1.0) o = 1.0 else if (o < -1.0) o = -1.0
            out[i] = (o * 32767.0).toInt().toShort()
        }
    }

    private fun compressorGain(e: Double): Double {
        val db = 20.0 * ln(e + 1.0e-9) / ln(10.0)
        val over = db - THRESH
        val red = if (2.0 * over < -KNEE) 0.0
        else if (2.0 * abs(over) <= KNEE) (1.0 / RATIO - 1.0) * (over + KNEE / 2.0).pow(2.0) / (2.0 * KNEE)
        else (1.0 / RATIO - 1.0) * over
        return 10.0.pow(red / 20.0) * MAKEUP
    }

    companion object {
        const val THRESH = -18.0
        const val KNEE = 26.0
        const val RATIO = 3.5
        const val MAKEUP = 2.4
    }
}
