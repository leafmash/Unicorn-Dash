package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private val flameColors = IntArray(3)
private val flamePos = floatArrayOf(0f, 0.5f, 1f)

fun shard(px: Double, h: Double, w: Double, hue: Double) {
    x.fillShader = x.lin(0.0, -h, 0.0, 0.0, hsl(hue, 100.0, 86.0), hsl(hue, 80.0, 46.0))
    x.beginPath()
    x.moveTo(px - w, 0.0)
    x.lineTo(px - w * 0.55, -h * 0.72)
    x.lineTo(px, -h)
    x.lineTo(px + w * 0.55, -h * 0.72)
    x.lineTo(px + w, 0.0)
    x.closePath()
    x.fill()
    x.strokeStyle = hsl(hue, 100.0, 92.0, 0.9)
    x.lineWidth = 1.4
    x.stroke()
    x.beginPath()
    x.moveTo(px - w * 0.2, -h * 0.2)
    x.lineTo(px - w * 0.1, -h * 0.8)
    x.strokeStyle = rgba(255, 255, 255, 0.6)
    x.stroke()
}

fun crystal(o: Obs, ox: Double) {
    val hue = (Z.hue + 40.0) % 360.0
    x.halo(ox, G - 18.0, if (o.w == 2) 58.0 else 36.0, hue, 100.0, 65.0, 0.55 + 0.15 * sin(t * 3.0 + o.seed))
    x.save()
    x.translate(ox, G)
    if (o.w == 2) {
        shard(-16.0, 30.0, 9.0, hue)
        shard(14.0, 36.0, 11.0, hue)
        shard(0.0, 22.0, 8.0, hue + 20.0)
    } else {
        shard(0.0, 36.0, 11.0, hue)
        shard(-9.0, 20.0, 6.0, hue + 20.0)
    }
    x.restore()
}

fun storm(o: Obs, ox: Double, cy: Double) {
    if (Z.zs == "ghost") {
        ghost(o, ox, cy)
        return
    }
    x.halo(ox, cy, 36.0, 270.0, 80.0, 55.0, 0.45)
    x.fillStyle = hex(0x3a2c66)
    x.beginPath()
    x.arc(ox - 10.0, cy + 2.0, 10.0, 0.0, 7.0)
    x.moveTo(ox + 20.0, cy)
    x.arc(ox + 10.0, cy, 10.0, 0.0, 7.0)
    x.moveTo(ox + 12.0, cy - 6.0)
    x.arc(ox, cy - 6.0, 13.0, 0.0, 7.0)
    x.fill()
    x.fillStyle = rgba(190, 170, 255, 0.35)
    x.beginPath()
    x.arc(ox - 3.0, cy - 10.0, 7.0, 0.0, 7.0)
    x.fill()
    if (sin(t * 9.0 + o.seed) > 0.55) {
        x.strokeStyle = hex(0xfff3a0)
        x.lineWidth = 2.4
        x.lineJoin = JOIN_ROUND
        x.beginPath()
        x.moveTo(ox + 2.0, cy + 8.0)
        x.lineTo(ox - 4.0, cy + 18.0)
        x.lineTo(ox + 3.0, cy + 18.0)
        x.lineTo(ox - 3.0, cy + 30.0)
        x.stroke()
        x.halo(ox, cy + 18.0, 22.0, 52.0, 100.0, 70.0, 0.6)
    }
}

fun wisp(o: Obs, ox: Double) {
    val cy = wispY(o)
    if (Z.zs == "jelly") {
        jelly(o, ox, cy)
        return
    }
    for (i in 4 downTo 1) {
        val wy = G - 62.0 + sin((t - i * 0.05) * 3.2 + o.seed) * 34.0
        x.halo(ox + i * 10.0, wy, 14.0 - i * 2.0, 160.0, 100.0, 70.0, 0.45)
    }
    x.halo(ox, cy, 40.0, 160.0, 100.0, 60.0, 0.75)
    x.fillStyle = hex(0xeafffa)
    x.beginPath()
    x.arc(ox, cy, 8.0, 0.0, 7.0)
    x.fill()
}

fun portalFx(ox: Double) {
    val cy = G - 52.0
    x.halo(ox, cy, 96.0, 300.0, 100.0, 70.0, 0.6)
    for (i in 0 until 5) {
        x.strokeStyle = hsl((i * 60.0 + clock * 120.0) % 360.0, 100.0, 72.0, 0.9)
        x.lineWidth = 4.0
        x.beginPath()
        x.ellipse(ox, cy, 12.0 + i * 2.5 + sin(clock * 6.0 + i) * 1.5, 60.0 - i * 5.0, 0.0, 0.0, 7.0)
        x.stroke()
    }
    x.halo(ox, cy, 44.0, 50.0, 100.0, 85.0, 0.5)
    sparkle(ox - 24.0, cy - 40.0 + sin(clock * 2.0) * 6.0, 7.0, 1.0)
    sparkle(ox + 22.0, cy + 10.0 + sin(clock * 2.0 + 2.0) * 6.0, 6.0, 3.0)
    label("FINISH", 12.0, ox, cy - 78.0, hex(0xffe27a))
}

fun jelly(o: Obs, ox: Double, cy: Double) {
    x.halo(ox, cy, 44.0, 310.0, 80.0, 70.0, 0.6)
    val pul = sin(t * 5.0 + o.seed) * 2.0
    x.fillStyle = rgba(255, 150, 220, 0.88)
    x.beginPath()
    x.arc(ox, cy - 2.0, 12.0 + pul * 0.5, PI, 0.0)
    x.lineTo(ox + 12.0, cy + 2.0)
    x.quadraticCurveTo(ox, cy + 6.0 + pul, ox - 12.0, cy + 2.0)
    x.closePath()
    x.fill()
    x.strokeStyle = rgba(255, 190, 235, 0.85)
    x.lineWidth = 2.0
    x.lineCap = CAP_ROUND
    for (i in -2..2) {
        x.beginPath()
        x.moveTo(ox + i * 5.0, cy + 3.0)
        x.quadraticCurveTo(ox + i * 5.0 + sin(t * 4.0 + i) * 4.0, cy + 12.0, ox + i * 5.0 + sin(t * 4.0 + i + 1.0) * 3.0, cy + 21.0)
        x.stroke()
    }
    x.fillStyle = rgba(255, 255, 255, 0.6)
    x.beginPath()
    x.arc(ox - 4.0, cy - 8.0, 3.0, 0.0, 7.0)
    x.fill()
}

fun ghost(o: Obs, ox: Double, cy: Double) {
    val a = 0.6 + 0.3 * sin(t * 3.0 + o.seed)
    x.halo(ox, cy, 40.0, 200.0, 40.0, 85.0, 0.45)
    x.fillStyle = rgba(235, 240, 255, a)
    x.beginPath()
    x.arc(ox, cy - 2.0, 12.0, PI, 0.0)
    x.lineTo(ox + 12.0, cy + 12.0)
    x.lineTo(ox + 6.0, cy + 7.0)
    x.lineTo(ox, cy + 12.0)
    x.lineTo(ox - 6.0, cy + 7.0)
    x.lineTo(ox - 12.0, cy + 12.0)
    x.closePath()
    x.fill()
    x.fillStyle = hex(0x2a2050)
    x.beginPath()
    x.arc(ox - 4.0, cy - 3.0, 2.0, 0.0, 7.0)
    x.arc(ox + 4.0, cy - 3.0, 2.0, 0.0, 7.0)
    x.fill()
}

fun pit(o: Obs, ox: Double) {
    val w = o.pw
    val x0 = ox - w / 2.0
    x.fillShader = x.lin(0.0, G, 0.0, G + 90.0, rgb(6, 2, 24), rgb(20, 8, 52))
    x.fillRect(x0, G - 1.0, w, 82.0 + ty + 12.0)
    x.halo(ox, G + 46.0, w * 0.6, Z.hue, 100.0, 55.0, 0.3)
    x.fillStyle = Z.edge
    x.beginPath()
    x.moveTo(x0 - 5.0, G)
    x.lineTo(x0 + 6.0, G)
    x.lineTo(x0 + 1.0, G + 12.0)
    x.lineTo(x0 - 5.0, G + 8.0)
    x.moveTo(x0 + w + 5.0, G)
    x.lineTo(x0 + w - 6.0, G)
    x.lineTo(x0 + w - 1.0, G + 12.0)
    x.lineTo(x0 + w + 5.0, G + 8.0)
    x.fill()
    x.fillStyle = rgba(255, 255, 255, 0.12)
    for (i in 0 until 4) x.fillRect(x0 + 8.0 + i * (w - 16.0) / 4.0, G + 18.0 + (i % 2) * 14.0, 3.0, 12.0)
}

fun spin(o: Obs, ox: Double) {
    val cy = G - 16.0
    val hue = (Z.hue + 180.0) % 360.0
    x.halo(ox, cy, 34.0, hue, 100.0, 62.0, 0.5)
    x.save()
    x.translate(ox, cy)
    x.rotate(t * 7.0 + o.seed)
    x.fillStyle = hex(0xd9d2ff)
    x.strokeStyle = hsl(hue, 90.0, 60.0)
    x.lineWidth = 1.5
    x.lineJoin = JOIN_ROUND
    x.beginPath()
    for (i in 0 until 16) {
        val r2 = if (i % 2 == 1) 10.0 else 18.0
        val a = i * PI / 8.0
        x.lineTo(cos(a) * r2, sin(a) * r2)
    }
    x.closePath()
    x.fill()
    x.stroke()
    x.fillStyle = hsl(hue, 80.0, 45.0)
    x.beginPath()
    x.arc(0.0, 0.0, 6.0, 0.0, 7.0)
    x.fill()
    x.restore()
}

fun spikes(o: Obs, ox: Double) {
    val hue = (Z.hue + 40.0) % 360.0
    x.halo(ox, G - 10.0, 40.0, hue, 80.0, 60.0, 0.3)
    x.fillStyle = hsl(hue, 25.0, 82.0)
    x.strokeStyle = hsl(hue, 40.0, 40.0)
    x.lineWidth = 1.4
    x.lineJoin = JOIN_ROUND
    for (i in 0 until 4) {
        val sx = ox - 27.0 + i * 18.0
        x.beginPath()
        x.moveTo(sx - 9.0, G)
        x.lineTo(sx, G - 24.0)
        x.lineTo(sx + 9.0, G)
        x.closePath()
        x.fill()
        x.stroke()
    }
}

fun boulder(o: Obs, ox: Double) {
    val hue = (Z.hue + 30.0) % 360.0
    x.halo(ox, G - 17.0, 36.0, hue, 50.0, 50.0, 0.25)
    x.save()
    x.translate(ox, G - 17.0)
    x.rotate(-t * 8.0 - o.seed)
    val c0 = hsl(hue, 25.0, 66.0)
    val c1 = hsl(hue, 30.0, 30.0)
    x.fillShader = x.radN(-5.0, -6.0, 20.0, intArrayOf(c0, c0, c1), floatArrayOf(0f, 0.15f, 1f))
    x.beginPath()
    x.arc(0.0, 0.0, 17.0, 0.0, 7.0)
    x.fill()
    x.strokeStyle = rgba(20, 10, 50, 0.5)
    x.lineWidth = 1.6
    x.beginPath()
    x.moveTo(-10.0, -4.0)
    x.lineTo(-2.0, 2.0)
    x.lineTo(4.0, -8.0)
    x.moveTo(2.0, 2.0)
    x.lineTo(9.0, 9.0)
    x.stroke()
    x.restore()
}

fun wall(o: Obs, ox: Double) {
    val hue = (Z.hue + 20.0) % 360.0
    x.halo(ox, G - 40.0, 44.0, hue, 60.0, 55.0, 0.25)
    x.fillShader = x.lin(ox - 9.0, 0.0, ox + 9.0, 0.0, hsl(hue, 30.0, 62.0), hsl(hue, 30.0, 38.0))
    x.fillRect(ox - 9.0, G - 80.0, 18.0, 80.0)
    x.strokeStyle = rgba(20, 10, 50, 0.45)
    x.lineWidth = 1.2
    for (i in 1 until 6) {
        x.beginPath()
        x.moveTo(ox - 9.0, G - i * 13.3)
        x.lineTo(ox + 9.0, G - i * 13.3)
        x.stroke()
    }
    x.fillStyle = hsl(hue, 40.0, 72.0)
    x.fillRect(ox - 12.0, G - 80.0, 24.0, 6.0)
}

fun swing(o: Obs, ox: Double) {
    val bxx = ox + (swingX(o) - o.x)
    val byy = swingY(o)
    val hue = (Z.hue + 200.0) % 360.0
    x.halo(bxx, byy, 30.0, hue, 100.0, 60.0, 0.45)
    x.strokeStyle = rgba(210, 200, 255, 0.8)
    x.lineWidth = 2.0
    x.beginPath()
    x.moveTo(ox, G - 140.0)
    x.lineTo(bxx, byy)
    x.stroke()
    x.fillStyle = hex(0xd9d2ff)
    x.beginPath()
    x.arc(ox, G - 140.0, 6.0, 0.0, 7.0)
    x.fill()
    x.fillStyle = hex(0x2f2557)
    x.strokeStyle = hsl(hue, 90.0, 62.0)
    x.lineWidth = 2.0
    x.beginPath()
    x.arc(bxx, byy, 12.0, 0.0, 7.0)
    x.fill()
    x.stroke()
    x.fillStyle = hsl(hue, 90.0, 70.0)
    x.beginPath()
    x.arc(bxx - 3.0, byy - 3.0, 3.0, 0.0, 7.0)
    x.fill()
}

fun laser(o: Obs, ox: Double) {
    val ph = (t * 0.5 + o.seed) % 1.0
    val on = ph < 0.5
    val warn = ph > 0.82
    x.halo(ox, G - 32.0, 50.0, 330.0, 100.0, 60.0, if (on) 0.35 else 0.08)
    x.fillStyle = hex(0x3a2c66)
    x.fillRect(ox - 40.0, G - 44.0, 8.0, 44.0)
    x.fillRect(ox + 32.0, G - 44.0, 8.0, 44.0)
    x.fillStyle = if (on) hex(0xff5a8c) else hex(0x8a7ac8)
    x.fillRect(ox - 40.0, G - 46.0, 8.0, 5.0)
    x.fillRect(ox + 32.0, G - 46.0, 8.0, 5.0)
    if (on) {
        x.fillStyle = rgba(255, 90, 140, 0.35)
        x.fillRect(ox - 32.0, G - 40.0, 64.0, 16.0)
        x.fillStyle = hex(0xffd0e0)
        x.fillRect(ox - 32.0, G - 36.0, 64.0, 8.0)
    } else if (warn && sin(t * 40.0) > 0.0) {
        x.fillStyle = rgba(255, 90, 140, 0.4)
        x.fillRect(ox - 32.0, G - 33.0, 64.0, 2.0)
    }
}

fun bird(o: Obs, ox: Double) {
    val cy = G - 44.0 + sin(t * 5.0 + o.seed) * 3.0
    val fl = sin(t * 22.0 + o.seed)
    x.halo(ox, cy, 28.0, Z.hue, 80.0, 55.0, 0.3)
    x.fillStyle = hex(0x2f2557)
    x.beginPath()
    x.ellipse(ox, cy, 13.0, 8.0, 0.0, 0.0, 7.0)
    x.fill()
    x.beginPath()
    x.moveTo(ox - 2.0, cy - 2.0)
    x.quadraticCurveTo(ox + 4.0, cy - 8.0 - fl * 10.0, ox + 15.0, cy - 3.0 - fl * 12.0)
    x.lineTo(ox + 4.0, cy + 2.0)
    x.closePath()
    x.fill()
    x.fillStyle = hex(0xffb347)
    x.beginPath()
    x.moveTo(ox - 12.0, cy - 2.0)
    x.lineTo(ox - 21.0, cy + 1.0)
    x.lineTo(ox - 12.0, cy + 3.0)
    x.fill()
    x.fillStyle = hex(0xffffff)
    x.beginPath()
    x.arc(ox - 7.0, cy - 2.0, 2.2, 0.0, 7.0)
    x.fill()
    x.fillStyle = hex(0x2a2050)
    x.beginPath()
    x.arc(ox - 7.5, cy - 2.0, 1.0, 0.0, 7.0)
    x.fill()
}

fun flames(o: Obs, ox: Double) {
    x.halo(ox, G - 14.0, 46.0, 20.0, 100.0, 55.0, 0.6)
    flameColors[0] = hex(0xfff3a0)
    flameColors[1] = hex(0xff9a2a)
    flameColors[2] = hex(0xe03a1a)
    for (i in 0 until 5) {
        val fx0 = ox - 20.0 + i * 10.0
        val h = 22.0 + 10.0 * sin(t * 9.0 + i * 1.7 + o.seed) + (if (i % 2 == 1) 0.0 else 6.0)
        x.fillShader = x.linN(0.0, G - h, 0.0, G, flameColors, flamePos)
        x.beginPath()
        x.moveTo(fx0 - 6.0, G)
        x.quadraticCurveTo(fx0 - 5.0, G - h * 0.5, fx0, G - h)
        x.quadraticCurveTo(fx0 + 5.0, G - h * 0.5, fx0 + 6.0, G)
        x.fill()
    }
}

fun pillar(o: Obs, ox: Double) {
    val hue = (Z.hue + 40.0) % 360.0
    x.halo(ox, G - 28.0, 50.0, hue, 70.0, 60.0, 0.3)
    x.fillShader = x.lin(0.0, G - 54.0, 0.0, G, hsl(hue, 45.0, 72.0), hsl(hue, 45.0, 38.0))
    x.strokeStyle = hsl(hue, 60.0, 90.0, 0.9)
    x.lineWidth = 1.4
    x.lineJoin = JOIN_ROUND
    x.beginPath()
    x.moveTo(ox - 28.0, G)
    x.lineTo(ox - 28.0, G - 26.0)
    x.lineTo(ox - 2.0, G - 26.0)
    x.lineTo(ox - 2.0, G - 54.0)
    x.lineTo(ox + 24.0, G - 54.0)
    x.lineTo(ox + 24.0, G)
    x.closePath()
    x.fill()
    x.stroke()
    x.strokeStyle = rgba(255, 255, 255, 0.35)
    x.beginPath()
    x.moveTo(ox - 22.0, G - 22.0)
    x.lineTo(ox - 22.0, G - 6.0)
    x.moveTo(ox + 4.0, G - 50.0)
    x.lineTo(ox + 4.0, G - 8.0)
    x.stroke()
}

fun ice(o: Obs, ox: Double) {
    x.fillShader = x.lin(0.0, G - 3.0, 0.0, G + 9.0, rgba(240, 253, 255, 0.96), rgba(150, 215, 245, 0.92))
    pill(ox - 66.0, G - 3.0, 132.0, 12.0, 6.0)
    x.fill()
    x.fillStyle = rgba(255, 255, 255, 0.75)
    x.fillRect(ox - 48.0, G - 1.0, 22.0, 2.0)
    x.fillRect(ox + 8.0, G + 2.0, 30.0, 2.0)
    x.halo(ox + sin(t * 2.0 + o.seed) * 40.0, G - 2.0, 12.0, 190.0, 100.0, 88.0, 0.5)
}

fun coin(it: Item, ix: Double) {
    val w = max(0.22, abs(cos(t * 6.0 + it.ph)))
    x.halo(ix, it.y, 18.0, 45.0, 100.0, 60.0, 0.55)
    x.fillStyle = hex(0xffd23f)
    x.strokeStyle = hex(0xffb000)
    x.lineWidth = 2.0
    x.beginPath()
    x.ellipse(ix, it.y, 8.0 * w, 8.0, 0.0, 0.0, 7.0)
    x.fill()
    x.stroke()
    x.fillStyle = rgba(255, 255, 255, 0.7)
    x.beginPath()
    x.ellipse(ix - 2.0 * w, it.y - 2.5, 2.0 * w, 3.0, 0.0, 0.0, 7.0)
    x.fill()
}
