package com.imora.unicorndash

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

const val SR = 44100
const val OSC_SINE = 0
const val OSC_TRI = 1
const val OSC_SAW = 2
const val OSC_SQUARE = 3
const val OSC_NOISE = 4
const val FLT_NONE = 0
const val FLT_LOW = 1
const val FLT_BAND = 2
const val FLT_HIGH = 3
const val BUS_FX = 0
const val BUS_MUS = 1
const val FLOOR_GAIN = 0.0001

class Biquad {
    var b0 = 1.0
    var b1 = 0.0
    var b2 = 0.0
    var a1 = 0.0
    var a2 = 0.0
    var z1 = 0.0
    var z2 = 0.0

    fun set(type: Int, freq: Double, q: Double) {
        val f = max(10.0, min(freq, SR * 0.45))
        val w0 = 2.0 * PI * f / SR
        val cw = cos(w0)
        val alpha = sin(w0) / (2.0 * max(q, 0.0001))
        val a0 = 1.0 + alpha
        when (type) {
            FLT_LOW -> {
                b0 = (1.0 - cw) / 2.0 / a0
                b1 = (1.0 - cw) / a0
                b2 = b0
            }
            FLT_HIGH -> {
                b0 = (1.0 + cw) / 2.0 / a0
                b1 = -(1.0 + cw) / a0
                b2 = b0
            }
            else -> {
                b0 = alpha / a0
                b1 = 0.0
                b2 = -alpha / a0
            }
        }
        a1 = -2.0 * cw / a0
        a2 = (1.0 - alpha) / a0
    }

    fun reset() {
        z1 = 0.0
        z2 = 0.0
    }

    fun process(x: Double): Double {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }
}

class Voice {
    var active = false
    var bus = BUS_FX
    var osc = OSC_SINE
    var startS = 0L
    var endS = 0L
    var lenN = 1L
    var freq = 440.0
    var freqRatio = 1.0
    var detUp = 1.0
    var detDown = 1.0
    var dual = false
    var ph1 = 0.0
    var ph2 = 0.0
    var gain = FLOOR_GAIN
    var attN = 1L
    var holdN = 0L
    var attRatio = 1.0
    var relRatio = 1.0
    var vol = 0.1
    var filterType = FLT_NONE
    var cutFrom = 0.0
    var cutRatio = 1.0
    var cutNow = 0.0
    var q = 1.0
    val filter = Biquad()
    var noisePos = 0

    fun setup(
        bus: Int,
        osc: Int,
        startS: Long,
        len: Double,
        vol: Double,
        att: Double,
        hold: Double,
        freq: Double,
        freqTo: Double,
        det: Double,
        filterType: Int,
        cut: Double,
        cutTo: Double,
        q: Double
    ) {
        this.bus = bus
        this.osc = osc
        this.startS = startS
        this.lenN = max(1L, (len * SR).toLong())
        this.endS = startS + ((len + 0.05) * SR).toLong()
        this.vol = vol
        this.attN = max(1L, (att * SR).toLong())
        this.holdN = if (hold > 0.0) (hold * SR).toLong() else 0L
        val relN = max(1L, lenN - attN - holdN)
        attRatio = (vol / FLOOR_GAIN).pow(1.0 / attN)
        relRatio = (FLOOR_GAIN / vol).pow(1.0 / relN)
        gain = FLOOR_GAIN
        this.freq = freq
        freqRatio = if (freqTo > 0.0 && freq > 0.0) (freqTo / freq).pow(1.0 / lenN) else 1.0
        dual = det != 0.0
        detUp = 2.0.pow(det / 1200.0)
        detDown = 2.0.pow(-det / 1200.0)
        ph1 = 0.0
        ph2 = 0.0
        this.filterType = filterType
        cutFrom = cut
        cutNow = cut
        cutRatio = if (cutTo > 0.0 && cut > 0.0) (cutTo / cut).pow(1.0 / lenN) else 1.0
        this.q = q
        filter.reset()
        if (filterType != FLT_NONE) filter.set(filterType, cut, q)
        active = true
    }
}
