package com.imora.unicorndash

import kotlin.math.max
import kotlin.math.min

private val LEVEL_ORDER = arrayOf(
    OT.crystal, OT.spikes, OT.boulder, OT.swing, OT.laser, OT.wall, OT.stormLow, OT.stormHigh,
    OT.wisp, OT.pit, OT.spin, OT.bird, OT.pillar, OT.ice, OT.fire
)

fun ruleOf(z: Int, l: Int): String = ""

fun pickPu(rf: () -> Double, lv: Int, nd: Boolean, wl: Boolean): String {
    val names = arrayOf("shield", "magnet", "coin2", "slow", "mini", "star", "sx2", "rain", "wings", "life")
    val w = doubleArrayOf(
        24.0,
        20.0,
        if (lv >= 1) 18.0 else 0.0,
        if (lv >= 3) 12.0 else 0.0,
        if (lv >= 2) 12.0 else 0.0,
        if (lv >= 5) 8.0 else 0.0,
        if (lv >= 1) 14.0 else 0.0,
        if (lv >= 2) 10.0 else 0.0,
        if (lv >= 4 && !nd) 8.0 else 0.0,
        if (wl) (if (buddyKind == "cat") 14.0 else 7.0) else 0.0
    )
    var total = 0.0
    for (v in w) total += v
    var q = rf() * total
    for (i in w.indices) {
        q -= w[i]
        if (q <= 0.0 && w[i] > 0.0) return names[i]
    }
    return "shield"
}

fun buildLevel(z: Int, l: Int, dc: DcCfg?): Level {
    val r = rng((z * 1009 + l * 131 + 17 + (if (dc != null) dc.seed * 7919 else 0)).toLong())
    val zs = ZN[z].zs
    val boss = l == CFG_LEVELS - 1
    val d = clamp(0.05 + (z * CFG_LEVELS + l).toDouble() / (CFG_SPAN * CFG_LEVELS).toDouble() * 0.95 + (if (boss) 0.12 else 0.0), 0.0, 1.0)
    val rule = if (dc != null) dc.rule else ruleOf(z, l)
    val sp = min(300.0 + z * 8.0 + l * 14.0 + (if (boss) 24.0 else 0.0), 580.0) * (if (rule == "sprint") 1.1 else 1.0)
    val sec = if (rule == "sprint") 30.0 else 30.0 + l * 3.0 + (if (boss) 6.0 else 0.0)
    val len = Math.round(sp * sec).toDouble()
    val rh = RHY[Math.floor(r() * RHY.size).toInt()]
    val pp = if (l >= 2) 0.1 else 0.0
    val has = DoubleArray(OT.values().size)
    has[OT.crystal.ordinal] = 0.7
    has[OT.spikes.ordinal] = 0.3 + 0.2 * d
    has[OT.boulder.ordinal] = if (z >= 1 || l >= 2) 0.12 + 0.2 * d else 0.0
    has[OT.swing.ordinal] = if (z >= 1 || l >= 3) 0.12 + 0.2 * d else 0.0
    has[OT.laser.ordinal] = if (z >= 1 || l >= 3) 0.12 + 0.2 * d else 0.0
    has[OT.wall.ordinal] = if (z >= 1 || l >= 4) 0.1 + 0.18 * d else 0.0
    has[OT.stormLow.ordinal] = if (l >= 1) 0.25 + 0.35 * d else 0.0
    has[OT.stormHigh.ordinal] = if (l >= 2) 0.2 + 0.3 * d else 0.0
    has[OT.wisp.ordinal] = if (l >= 3 && (z >= 1 || l >= 5)) 0.12 + 0.2 * d else 0.0
    has[OT.pit.ordinal] = if (z >= 1 || l >= 3) 0.16 + 0.24 * d else 0.0
    has[OT.spin.ordinal] = if (z >= 1 || l >= 4) 0.14 + 0.2 * d else 0.0
    has[OT.bird.ordinal] = if ((z >= 1 && l >= 2) || l >= 6) 0.14 + 0.2 * d else 0.0
    has[OT.pillar.ordinal] = if (z >= 1 && l >= 3) 0.12 + 0.18 * d else 0.0
    has[OT.ice.ordinal] = if (zs == "ice" && l >= 1) 0.22 else 0.0
    has[OT.fire.ordinal] = if (zs == "fire" && l >= 1) 0.3 else 0.0
    var total = 0.0
    for (k in LEVEL_ORDER) total += has[k.ordinal]
    val pick = fun(): OT {
        var q = r() * total
        for (k in LEVEL_ORDER) {
            q -= has[k.ordinal]
            if (q <= 0.0) return k
        }
        return OT.crystal
    }
    val wide = fun(type: OT): Int {
        val flag = if (type == OT.crystal) r() < 0.15 + 0.5 * d else if (type == OT.pit) r() < 0.2 + 0.4 * d else false
        return if (flag) 2 else 1
    }
    val combos = ArrayList<List<ComboPart>>()
    if (boss || l >= 5) {
        for (c in COMBOS) {
            var ok = true
            for (e in c) if (has[e.type.ordinal] <= 0.0) ok = false
            if (ok) combos.add(c)
        }
        for (c in ECOMBOS) {
            var ok = true
            for (e in c) if (has[e.type.ordinal] <= 0.0) ok = false
            if (ok) combos.add(c)
        }
    }
    val ev = ArrayList<Ev>()
    var at = 900.0
    var k = 0
    var n = 0
    var lastLv: OT? = null
    val add = fun(type: OT, w: Int) {
        val half = if (type == OT.pit) (if (w == 2) 80.0 else 50.0) else 0.0
        at += half
        ev.add(Ev(at, type, w, r() * 99.0, null))
        n += coinCount(type)
        at += half
    }
    while (at < len - sp * 1.6) {
        if (combos.size > 0 && at + sp * 3.4 < len - sp * 1.6 && r() < (if (boss) 0.38 else 0.12)) {
            val c = combos[Math.floor(r() * combos.size).toInt()]
            for (i in c.indices) {
                val e = c[i]
                if (i > 0) at += sp * e.after
                add(e.type, e.w)
            }
        } else {
            var type = pick()
            var tr = 0
            while (tr < 3 && type == lastLv) {
                type = pick()
                tr++
            }
            lastLv = type
            add(type, wide(type))
        }
        val g = max(sp * (if (boss) 0.88 else 1.12 - 0.3 * d) * rh[k % rh.size] + r() * sp * (if (boss) 0.25 else 0.5), sp * 0.8)
        if (r() < pp) {
            ev.add(Ev(at + g * 0.5, null, 1, 0.0, pickPu(r, l, rule == "nodj", false)))
        }
        at += g
        k++
    }
    return Level(sp, len, ev, n, boss, d, rule)
}
