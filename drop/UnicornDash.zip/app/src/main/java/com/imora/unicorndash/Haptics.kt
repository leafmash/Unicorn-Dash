package com.imora.unicorndash

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

private var vib: Vibrator? = null

fun initHaptics(ctx: Context) {
    vib = if (Build.VERSION.SDK_INT >= 31) {
        val m = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        m.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
}

fun buzz(ms: Int) {
    val v = vib ?: return
    if (!opt.vib || !v.hasVibrator()) return
    try {
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(ms.toLong())
        }
    } catch (e: Exception) {
    }
}

fun buzzPattern(pattern: LongArray) {
    val v = vib ?: return
    if (!opt.vib || !v.hasVibrator()) return
    try {
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(pattern, -1)
        }
    } catch (e: Exception) {
    }
}
