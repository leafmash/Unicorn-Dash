package com.imora.unicorndash

import kotlin.math.pow

private fun bl(vararg v: Double): DoubleArray = v

fun buildSfx(n: String, a: Double, em: Emitter) {
    when (n) {
        "jump" -> {
            em.tone(f = 340.0, to = 640.0, len = 0.17, vol = 0.1, att = 0.006)
            em.tone(f = 680.0, to = 1280.0, len = 0.12, vol = 0.028, type = OSC_TRI)
            em.puff(f = 1800.0, to = 700.0, len = 0.12, vol = 0.02, q = 0.8)
        }
        "djump" -> {
            val fs = bl(660.0, 880.0, 1320.0)
            for (i in fs.indices) em.tone(f = fs[i], at = i * 0.045, len = 0.24, vol = 0.055, att = 0.004)
            em.puff(f = 3000.0, to = 7000.0, len = 0.22, vol = 0.022, q = 1.2)
        }
        "land" -> {
            em.tone(f = 160.0, to = 60.0, len = 0.15, vol = 0.05 + 0.1 * a, type = OSC_SINE)
            em.puff(f = 500.0, len = 0.08, vol = 0.03 + 0.05 * a, q = 0.6)
        }
        "coin" -> {
            val steps = intArrayOf(0, 2, 4, 7, 9)
            val c = if (a == 0.0) 1.0 else a
            val idx = clampI((c - 1.0).toInt(), 0, 4)
            val f = 784.0 * 2.0.pow(steps[idx] / 12.0)
            em.tone(f = f, len = 0.34, vol = 0.075, att = 0.003)
            em.tone(f = f * 2.0, len = 0.22, vol = 0.026, att = 0.003)
            em.tone(f = f * 3.01, len = 0.12, vol = 0.01, att = 0.003)
        }
        "shield" -> em.bells(bl(392.0, 587.0, 784.0, 988.0), 0.06, 0.5, 0.05)
        "skill" -> {
            em.bells(bl(392.0, 523.0, 784.0, 1047.0), 0.045, 0.45, 0.06)
            em.puff(f = 1200.0, to = 5000.0, len = 0.3, vol = 0.04, q = 0.8)
        }
        "ready" -> em.bells(bl(988.0, 1319.0), 0.07, 0.4, 0.045)
        "life" -> em.bells(bl(659.0, 784.0, 988.0, 1319.0), 0.07, 0.5, 0.05)
        "rain" -> em.bells(bl(784.0, 988.0, 1175.0, 1568.0, 1976.0), 0.05, 0.5, 0.05)
        "wings" -> {
            em.bells(bl(330.0, 494.0, 659.0, 988.0, 1319.0), 0.06, 0.6, 0.05)
            em.puff(f = 2600.0, to = 6000.0, len = 0.3, vol = 0.03, q = 1.0)
        }
        "sx2" -> em.bells(bl(523.0, 659.0, 784.0, 1047.0, 1568.0), 0.05, 0.5, 0.05)
        "flap" -> {
            em.tone(f = 520.0, to = 780.0, len = 0.1, vol = 0.04, type = OSC_TRI)
            em.puff(f = 2400.0, to = 1200.0, len = 0.08, vol = 0.02, q = 0.8)
        }
        "revive" -> {
            em.bells(bl(392.0, 523.0, 659.0, 784.0, 1047.0, 1319.0), 0.07, 0.8, 0.06)
            em.puff(f = 800.0, to = 4000.0, len = 0.5, vol = 0.05, q = 0.6)
        }
        "magnet" -> em.bells(bl(440.0, 554.0, 659.0, 880.0), 0.06, 0.5, 0.05)
        "star" -> em.bells(bl(523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0), 0.05, 0.55, 0.05)
        "break" -> {
            em.puff(f = 1400.0, to = 260.0, len = 0.35, vol = 0.16, q = 0.7)
            em.tone(f = 260.0, to = 58.0, len = 0.35, vol = 0.13, type = OSC_TRI)
        }
        "die" -> {
            em.tone(f = 420.0, to = 70.0, len = 0.85, vol = 0.07, type = OSC_SAW, cut = 2200.0, cutTo = 200.0)
            em.tone(f = 110.0, to = 38.0, len = 0.7, vol = 0.28)
            em.puff(f = 3200.0, to = 200.0, len = 0.6, vol = 0.12, q = 0.7)
        }
        "click" -> em.tone(f = 900.0, to = 700.0, len = 0.06, vol = 0.05, type = OSC_TRI)
        "back" -> em.tone(f = 620.0, to = 430.0, len = 0.08, vol = 0.05, type = OSC_TRI)
        "buy" -> em.bells(bl(523.0, 659.0, 784.0, 1047.0), 0.07, 0.6, 0.06)
        "deny" -> {
            em.tone(f = 210.0, len = 0.12, vol = 0.05, type = OSC_SQUARE, cut = 900.0)
            em.tone(f = 160.0, at = 0.1, len = 0.16, vol = 0.05, type = OSC_SQUARE, cut = 800.0)
        }
        "mission" -> em.bells(bl(659.0, 784.0, 988.0, 1319.0), 0.09, 0.7, 0.06)
        "zone" -> {
            em.tone(f = 196.0, to = 392.0, len = 1.3, vol = 0.05, att = 0.5, det = 8.0)
            em.puff(f = 400.0, to = 3200.0, len = 1.0, vol = 0.04, att = 0.6, q = 0.5)
        }
        "milestone" -> em.bells(bl(784.0, 988.0, 1175.0), 0.08, 0.6, 0.05)
        "gift" -> em.bells(bl(523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0), 0.08, 0.7, 0.05)
        "slow" -> {
            em.tone(f = 900.0, to = 180.0, len = 0.55, vol = 0.07, type = OSC_TRI, cut = 2400.0, cutTo = 300.0)
            em.puff(f = 2400.0, to = 300.0, len = 0.5, vol = 0.03, q = 0.8)
        }
        "mini" -> {
            em.tone(f = 260.0, to = 1100.0, len = 0.3, vol = 0.06, type = OSC_TRI)
            em.bells(bl(1175.0, 1568.0), 0.06, 0.4, 0.04)
        }
        "coin2" -> em.bells(bl(880.0, 1175.0, 1760.0), 0.05, 0.5, 0.05)
        "near" -> {
            em.tone(f = 1300.0, to = 1900.0, len = 0.12, vol = 0.06, type = OSC_TRI)
            em.puff(f = 5000.0, to = 9000.0, len = 0.1, vol = 0.03, q = 1.0)
        }
        "fall" -> {
            em.tone(f = 700.0, to = 110.0, len = 0.9, vol = 0.06, type = OSC_SINE)
            em.puff(f = 1200.0, to = 200.0, len = 0.7, vol = 0.03, q = 0.6)
        }
        "zap" -> {
            em.tone(f = 1900.0, to = 260.0, len = 0.4, vol = 0.07, type = OSC_SAW, cut = 3200.0, cutTo = 400.0)
            em.puff(f = 6000.0, to = 500.0, len = 0.45, vol = 0.1, q = 0.6)
        }
        "neigh" -> {
            em.tone(f = 620.0, to = 1050.0, len = 0.22, vol = 0.06, type = OSC_SAW, cut = 2600.0, cutTo = 1200.0)
            em.tone(f = 1050.0, to = 560.0, at = 0.22, len = 0.4, vol = 0.06, type = OSC_SAW, cut = 2600.0, cutTo = 700.0)
            em.puff(f = 3000.0, to = 1500.0, len = 0.5, vol = 0.03, q = 0.8)
        }
        "fan3" -> {
            em.bells(bl(523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0, 2093.0), 0.08, 0.9, 0.06)
            em.tone(f = 131.0, len = 1.6, vol = 0.1, type = OSC_TRI, cut = 800.0)
            em.tone(f = 196.0, at = 0.3, len = 1.3, vol = 0.08, type = OSC_TRI, cut = 900.0)
            em.tone(f = 262.0, at = 0.6, len = 1.2, vol = 0.07, type = OSC_TRI, cut = 1000.0)
            em.puff(f = 6000.0, to = 12000.0, at = 0.5, len = 0.8, vol = 0.03, q = 1.0)
        }
        "fan2" -> {
            em.bells(bl(523.0, 659.0, 784.0, 1047.0, 1319.0), 0.1, 0.8, 0.055)
            em.tone(f = 131.0, len = 1.2, vol = 0.09, type = OSC_TRI, cut = 800.0)
            em.tone(f = 196.0, at = 0.3, len = 1.0, vol = 0.07, type = OSC_TRI, cut = 900.0)
        }
        "fan1" -> {
            em.bells(bl(523.0, 659.0, 784.0), 0.13, 0.7, 0.05)
            em.tone(f = 131.0, len = 0.9, vol = 0.08, type = OSC_TRI, cut = 800.0)
        }
        "tick" -> {
            val hi = a != 0.0
            em.tone(f = if (hi) 988.0 else 660.0, len = if (hi) 0.3 else 0.12, vol = 0.06, att = 0.004)
        }
        "pop" -> {
            val fs = bl(784.0, 988.0, 1319.0)
            em.bells(bl(fs[clampI(a.toInt(), 0, 2)]), 0.05, 0.6, 0.07)
            em.puff(f = 5000.0, to = 9000.0, len = 0.12, vol = 0.02, q = 1.0)
        }
        "win" -> {
            em.bells(bl(523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0, 2093.0), 0.09, 0.85, 0.055)
            em.tone(f = 131.0, len = 1.2, vol = 0.12, type = OSC_TRI, cut = 800.0)
            em.tone(f = 196.0, at = 0.35, len = 1.0, vol = 0.08, type = OSC_TRI, cut = 900.0)
        }
        "unlock" -> {
            em.bells(bl(392.0, 523.0, 659.0, 784.0, 1047.0, 1319.0), 0.1, 0.9, 0.06)
            em.tone(f = 130.0, to = 260.0, len = 1.1, vol = 0.07, att = 0.3, det = 8.0)
            em.puff(f = 600.0, to = 6000.0, len = 0.9, vol = 0.04, att = 0.5, q = 0.5)
        }
    }
}
