package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.max

fun inputDown(id: Int, sx: Double, sy: Double) {
    if (st == 6) swipe = Swipe(id, sx) else swipe = null
    val px = sx / u
    val py = sy / u - ty
    val hit = if (fadeDir > 0) "" else pick(px, py)
    if (hit == "skill") {
        useSkill()
        return
    }
    if (hit.isNotEmpty()) {
        ptrIds[id] = 'u'
        downId = hit
        hov = hit
        return
    }
    if (st != 1 || cd > 0.0) return
    if (px < L * 0.3) {
        ptrDuck = true
        ptrIds[id] = 'd'
        return
    }
    ptrIds[id] = 'j'
    ptrJumps++
    press()
}

fun inputUp(id: Int, sx: Double, sy: Double, cancelled: Boolean) {
    val s = ptrIds.remove(id)
    if (s == 'd') {
        ptrDuck = false
    } else if (s == 'j') {
        ptrJumps = max(0, ptrJumps - 1)
    } else if (s == 'u') {
        val sw = swipe
        if (sw != null && sw.id == id && st == 6 && !cancelled) {
            val dx = (sx - sw.x) / u
            if (abs(dx) > 40.0) {
                flip(if (dx < 0.0) 1 else -1)
                swipe = null
                downId = ""
                hov = ""
                return
            }
        }
        val hit = if (!cancelled) pick(sx / u, sy / u - ty) else ""
        if (hit.isNotEmpty() && hit == downId) act(hit)
        downId = ""
        hov = ""
    }
}

fun fitScreen(w: Int, h: Int, insetLeft: Int, insetRight: Int) {
    W = w.toDouble()
    H = h.toDouble()
    u = Math.min(H / 360.0, W / 520.0)
    L = W / u
    ty = (H / u - 360.0) / 2.0
    padL = insetLeft / u
    padR = insetRight / u
    ML = 22.0 + padL
    MR = 22.0 + padR
    p.x = max(90.0, L * 0.17)
}

fun backPressed(): Boolean {
    when (st) {
        1 -> pause()
        3 -> act("resume")
        14 -> act("skip")
        4, 5, 6, 7, 10, 11, 12, 13 -> act("back")
        2 -> act("menu")
        8 -> act(if (mode == "daily") "menu" else "lvls")
        9 -> act("cont")
        0 -> return false
    }
    return true
}
