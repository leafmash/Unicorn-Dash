package com.imora.unicorndash

import android.graphics.Shader
import kotlin.math.max
import kotlin.math.sin

val LABEL_STROKE = rgba(40, 20, 80, 0.45)
private val titleColors = IntArray(7)
private val titlePos = FloatArray(7) { it / 6f }

fun pill(x0: Double, y0: Double, w: Double, h: Double, r: Double) {
    x.beginPath()
    x.roundRect(x0, y0, w, h, r)
}

fun label(text: String, size: Double, px: Double, py: Double, color: Int, align: Int = ALIGN_CENTER, sc: Int = LABEL_STROKE, shader: Shader? = null) {
    val s = fmt(text)
    x.setFont(size)
    x.textAlign = align
    x.lineJoin = JOIN_ROUND
    x.lineWidth = max(2.0, size * 0.16)
    x.strokeStyle = sc
    x.strokeText(s, px, py)
    if (shader != null) x.fillShader = shader else x.fillStyle = color
    x.fillText(s, px, py)
}

fun title(text: String, size: Double, px: Double, py: Double) {
    val s = fmt(text)
    x.setFont(size)
    val w = x.measureText(s)
    x.halo(px, py, w * 0.5, 300.0, 100.0, 70.0, 0.16)
    for (i in 0 until 7) titleColors[i] = hsl((44.0 * i + clock * 40.0) % 360.0, 95.0, 68.0)
    val g = x.linN(px - w / 2.0, 0.0, px + w / 2.0, 0.0, titleColors, titlePos)
    label(text, size, px, py, 0, ALIGN_CENTER, LABEL_STROKE, g)
}

fun sparkle(px: Double, py: Double, s: Double, ph: Double) {
    val k = 0.5 + 0.5 * sin(clock * 3.0 + ph)
    val r = s * (0.4 + 0.6 * k)
    x.save()
    x.translate(px, py)
    x.rotate(clock * 0.4 + ph)
    x.fillStyle = rgba(255, 255, 255, 0.4 + 0.6 * k)
    x.beginPath()
    x.moveTo(0.0, -r)
    x.quadraticCurveTo(r * 0.12, -r * 0.12, r, 0.0)
    x.quadraticCurveTo(r * 0.12, r * 0.12, 0.0, r)
    x.quadraticCurveTo(-r * 0.12, r * 0.12, -r, 0.0)
    x.quadraticCurveTo(-r * 0.12, -r * 0.12, 0.0, -r)
    x.fill()
    x.restore()
    x.halo(px, py, r * 2.2, 50.0, 100.0, 80.0, 0.3 * k)
}

fun glass(x0: Double, y0: Double, w: Double, h: Double, r: Double, a: Double = 1.0) {
    val k = a
    pill(x0, y0, w, h, r)
    x.fillShader = x.lin(0.0, y0, 0.0, y0 + h, rgba(96, 66, 176, 0.8 * k), rgba(38, 22, 92, 0.84 * k))
    x.fill()
    x.strokeShader = x.lin(0.0, y0, 0.0, y0 + h, rgba(255, 255, 255, 0.42), rgba(255, 255, 255, 0.08))
    x.lineWidth = 1.4
    x.stroke()
}

fun panel(cx: Double, cy: Double, w: Double, h: Double) {
    for (i in 0 until 7) {
        val g = 3.0 + i * 4.0
        x.fillStyle = rgba(8, 0, 36, 0.07)
        pill(cx - w / 2.0 - g, cy - h / 2.0 - g + 8.0, w + g * 2.0, h + g * 2.0, 24.0 + g)
        x.fill()
    }
    glass(cx - w / 2.0, cy - h / 2.0, w, h, 24.0, 1.0)
}

fun heartPath(px: Double, py: Double, sz: Double) {
    x.beginPath()
    x.moveTo(px, py + sz * 0.9)
    x.bezierCurveTo(px - sz * 1.5, py - sz * 0.1, px - sz * 0.8, py - sz * 1.2, px, py - sz * 0.4)
    x.bezierCurveTo(px + sz * 0.8, py - sz * 1.2, px + sz * 1.5, py - sz * 0.1, px, py + sz * 0.9)
    x.closePath()
}
