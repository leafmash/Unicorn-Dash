package com.imora.unicorndash

fun rgb(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b

class ZoneDef(
    val name: String,
    val sky0: Int,
    val sky1: Int,
    val far: Int,
    val near: Int,
    val soil: Int,
    val edge: Int,
    val body: Int,
    val night: Double,
    val hue: Double,
    val fx: Int,
    val key: Int,
    val pr: Int,
    val tm: Double,
    val zs: String = ""
)

class ZoneObj(val i: Int, d: ZoneDef) {
    val night = d.night
    val hue = d.hue
    val fx = d.fx
    val key = d.key
    val pr = d.pr
    val tm = d.tm
    val zs = d.zs
    val top = d.sky0
    val bot = d.sky1
    val far = d.far
    val near = d.near
    val soil = d.soil
    val edge = d.edge
    val body = d.body
    val botClear = withAlpha(d.sky1, 0.0)
    val botHaze = withAlpha(d.sky1, 0.5)
    var skyShader: android.graphics.Shader? = null
}

val ZN: Array<ZoneDef> = arrayOf(
    ZoneDef("Rainbow Meadow", rgb(255, 150, 210), rgb(255, 232, 190), rgb(214, 170, 247), rgb(170, 140, 235), rgb(120, 214, 160), rgb(88, 190, 134), rgb(255, 244, 200), 0.0, 320.0, 0, 0, 0, 1.0),
    ZoneDef("Candy Clouds", rgb(255, 200, 235), rgb(255, 244, 214), rgb(255, 166, 208), rgb(255, 134, 186), rgb(255, 184, 216), rgb(236, 120, 170), rgb(255, 250, 230), 0.0, 290.0, 1, 2, 1, 1.05),
    ZoneDef("Starlight Night", rgb(16, 12, 48), rgb(84, 48, 128), rgb(52, 38, 100), rgb(38, 28, 80), rgb(40, 92, 104), rgb(26, 66, 82), rgb(232, 236, 255), 1.0, 185.0, 2, -3, 2, 1.12),
    ZoneDef("Frozen Peaks", rgb(10, 40, 90), rgb(150, 224, 244), rgb(110, 166, 222), rgb(186, 224, 246), rgb(222, 242, 252), rgb(255, 255, 255), rgb(255, 255, 255), 0.45, 200.0, 3, -5, 3, 1.0, "ice"),
    ZoneDef("Sunset Dunes", rgb(255, 112, 84), rgb(255, 214, 150), rgb(188, 88, 122), rgb(140, 58, 102), rgb(226, 160, 92), rgb(200, 120, 60), rgb(255, 236, 190), 0.0, 25.0, 4, 5, 1, 0.95),
    ZoneDef("Ember Realm", rgb(40, 10, 24), rgb(170, 54, 30), rgb(96, 30, 40), rgb(64, 22, 36), rgb(78, 44, 44), rgb(255, 112, 44), rgb(255, 170, 90), 0.6, 12.0, 5, -1, 2, 0.9, "fire"),
    ZoneDef("Crystal Caves", rgb(30, 12, 62), rgb(110, 60, 160), rgb(70, 40, 120), rgb(46, 28, 92), rgb(64, 44, 110), rgb(150, 100, 230), rgb(220, 190, 255), 0.7, 280.0, 10, 3, 0, 1.08),
    ZoneDef("Enchanted Forest", rgb(18, 60, 60), rgb(170, 230, 150), rgb(40, 110, 86), rgb(26, 84, 64), rgb(56, 140, 84), rgb(34, 104, 60), rgb(255, 250, 190), 0.25, 130.0, 0, -2, 1, 1.04),
    ZoneDef("Cloud Kingdom", rgb(110, 170, 255), rgb(255, 245, 230), rgb(200, 220, 255), rgb(236, 240, 255), rgb(250, 250, 255), rgb(200, 215, 250), rgb(255, 244, 200), 0.0, 210.0, 10, 7, 2, 0.96),
    ZoneDef("Neon City", rgb(10, 4, 40), rgb(120, 20, 120), rgb(40, 20, 90), rgb(24, 12, 60), rgb(26, 20, 56), rgb(0, 230, 255), rgb(255, 90, 220), 0.9, 300.0, 8, 4, 3, 0.88),
    ZoneDef("Deep Ocean", rgb(2, 24, 70), rgb(20, 120, 170), rgb(10, 70, 130), rgb(6, 48, 100), rgb(30, 110, 130), rgb(20, 160, 170), rgb(170, 240, 255), 0.5, 190.0, 6, -4, 0, 1.12, "jelly"),
    ZoneDef("Autumn Hills", rgb(255, 170, 90), rgb(255, 230, 170), rgb(220, 120, 70), rgb(180, 80, 50), rgb(170, 110, 60), rgb(210, 140, 60), rgb(255, 236, 180), 0.0, 25.0, 7, 1, 1, 1.0),
    ZoneDef("Desert Oasis", rgb(40, 160, 200), rgb(255, 236, 180), rgb(230, 190, 120), rgb(200, 150, 90), rgb(236, 200, 130), rgb(60, 170, 120), rgb(255, 250, 210), 0.0, 170.0, 4, 6, 2, 0.94),
    ZoneDef("Haunted Mist", rgb(24, 22, 44), rgb(110, 120, 140), rgb(70, 76, 100), rgb(48, 52, 76), rgb(54, 60, 70), rgb(100, 130, 110), rgb(220, 230, 245), 0.6, 270.0, 9, -6, 3, 1.15, "ghost"),
    ZoneDef("Space Rings", rgb(2, 2, 20), rgb(50, 30, 100), rgb(70, 50, 130), rgb(44, 30, 90), rgb(40, 40, 90), rgb(160, 140, 255), rgb(255, 220, 160), 1.0, 230.0, 10, 8, 0, 0.9),
    ZoneDef("Rainbow Waterfall", rgb(120, 200, 255), rgb(255, 230, 250), rgb(120, 190, 230), rgb(90, 160, 220), rgb(120, 220, 200), rgb(255, 170, 220), rgb(255, 255, 255), 0.0, 180.0, 12, 9, 1, 1.0),
    ZoneDef("Moon Garden", rgb(20, 20, 70), rgb(150, 150, 220), rgb(80, 80, 150), rgb(56, 60, 120), rgb(70, 110, 130), rgb(160, 230, 230), rgb(245, 248, 255), 0.8, 200.0, 11, -7, 2, 1.1),
    ZoneDef("Golden Temple", rgb(255, 190, 90), rgb(255, 244, 200), rgb(220, 150, 70), rgb(180, 110, 50), rgb(224, 180, 90), rgb(255, 215, 100), rgb(255, 252, 220), 0.0, 45.0, 11, 10, 3, 0.92)
)

val zoneCache = arrayOfNulls<ZoneObj>(ZN.size)

fun zoneObj(i: Int): ZoneObj {
    var z = zoneCache[i]
    if (z == null) {
        z = ZoneObj(i, ZN[i])
        zoneCache[i] = z
    }
    return z
}

val CH = arrayOf(intArrayOf(0, 3, 7), intArrayOf(-4, 0, 3), intArrayOf(3, 7, 10), intArrayOf(-2, 2, 5))

val MEL = arrayOf(
    arrayOf(intArrayOf(0, 12), intArrayOf(6, 15), intArrayOf(8, 14), intArrayOf(12, 10)),
    arrayOf(intArrayOf(0, 15), intArrayOf(6, 12), intArrayOf(10, 8), intArrayOf(12, 12)),
    arrayOf(intArrayOf(0, 19), intArrayOf(6, 15), intArrayOf(8, 14), intArrayOf(12, 15)),
    arrayOf(intArrayOf(0, 14), intArrayOf(4, 17), intArrayOf(8, 14), intArrayOf(12, 10))
)

val RHY = arrayOf(
    doubleArrayOf(1.0, 1.0, 1.2, 0.9),
    doubleArrayOf(1.1, 0.9, 1.1, 0.9, 1.3),
    doubleArrayOf(1.0, 1.3, 0.85, 1.15),
    doubleArrayOf(0.95, 1.2, 1.0, 1.2, 0.9),
    doubleArrayOf(1.25, 0.9, 0.9, 1.1)
)
