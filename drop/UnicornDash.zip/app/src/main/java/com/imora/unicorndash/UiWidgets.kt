package com.imora.unicorndash

import kotlin.math.round
import kotlin.math.sin

val PINK_TOP = hex(0xff9be0)
val PURPLE_BOT = hex(0x9a5cff)
val SOFT_WHITE = rgba(255, 255, 255, 0.4)
val RIM_WHITE = rgba(255, 255, 255, 0.75)
val SHADE_TEXT = rgba(40, 20, 80, 0.35)

fun uiScale(id: String, hot: Double, down: Double): Double {
    val prev = bsGet(id)
    val s = damp(prev, if (hov == id) (if (downId == id) down else hot) else 1.0, 18.0, fdt)
    bs[id] = s
    return s
}

fun ibtn(id: String, cx: Double, cy: Double, r: Double, icon: Icon) {
    uiPush(id, cx - r, cy - r, r * 2.0, r * 2.0)
    val s = uiScale(id, 1.1, 0.92)
    x.save()
    x.translate(cx, cy)
    x.scale(s, s)
    glass(-r, -r, r * 2.0, r * 2.0, r, 0.9)
    icon.draw(0.0, 0.0, r * 0.5)
    x.restore()
}

fun heartChip(cx: Double, cy: Double, w: Double, h: Double, text: String) {
    glass(cx - w / 2.0, cy - h / 2.0, w, h, h / 2.0, 0.85)
    heartPath(cx - w / 2.0 + h * 0.62, cy, h * 0.3)
    x.fillStyle = PINK_HEART
    x.fill()
    x.lineWidth = 1.4
    x.strokeStyle = WHITE
    x.stroke()
    label(text, h * 0.5, cx - w / 2.0 + h * 1.05, cy + 1.0, hex(0xffd0e0), ALIGN_LEFT)
}

fun chip(cx: Double, cy: Double, w: Double, h: Double, text: String, color: Int, coin: Boolean = false) {
    glass(cx - w / 2.0, cy - h / 2.0, w, h, h / 2.0, 0.85)
    if (coin) {
        iconCoin(cx - w / 2.0 + h / 2.0 + 1.0, cy, h * 0.3)
        label(text, h * 0.5, cx - w / 2.0 + h * 0.95, cy + 1.0, color, ALIGN_LEFT)
    } else {
        label(text, h * 0.5, cx, cy + 1.0, color)
    }
}

private val kindTop = intArrayOf(hex(0xff9be0), hex(0xffe58a), hex(0xff8a9a), rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1))
private val kindBot = intArrayOf(hex(0x9a5cff), hex(0xffa23f), hex(0xd23c5c), rgba(255, 255, 255, 0.08), rgba(255, 255, 255, 0.05))

private fun kindIndex(kind: Char): Int = when (kind) {
    'p' -> 0
    'g' -> 1
    'd' -> 2
    's' -> 3
    else -> 4
}

fun btn(id: String, text0: String, cx: Double, cy: Double, w: Double, h: Double, kind: Char, icon: String = "") {
    val text = fmt(text0)
    uiPush(id, cx - w / 2.0, cy - h / 2.0, w, h)
    val s = uiScale(id, 1.05, 0.94)
    val dis = kind == 'x'
    val x0 = -w / 2.0
    val y0 = -h / 2.0
    x.save()
    x.translate(cx, cy)
    x.scale(s, s)
    if (kind == 'p') x.halo(0.0, 0.0, w * 0.62, 320.0, 100.0, 70.0, 0.22 + 0.12 * sin(clock * 3.0))
    pill(x0, y0, w, h, h / 2.0)
    val ki = kindIndex(kind)
    x.fillShader = x.lin(0.0, y0, 0.0, y0 + h, kindTop[ki], kindBot[ki])
    x.fill()
    x.strokeStyle = if (kind == 's' || dis) SOFT_WHITE else RIM_WHITE
    x.lineWidth = 1.6
    x.stroke()
    if (!dis && kind != 's') {
        pill(x0 + 3.0, y0 + 2.5, w - 6.0, h * 0.44, h * 0.22)
        x.fillStyle = rgba(255, 255, 255, 0.22)
        x.fill()
    }
    val size = round(h * (if (kind == 's') 0.38 else 0.42))
    val tc = if (kind == 'g') hex(0x5a3000) else if (dis) rgba(255, 255, 255, 0.5) else WHITE
    val sc = if (kind == 'g') rgba(255, 255, 255, 0.4) else if (dis) 0 else SHADE_TEXT
    if (icon == "coin" || icon == "heart") {
        x.setFont(size)
        val tw = x.measureText(text)
        val off = size * 0.55
        if (icon == "coin") {
            iconCoin(off - tw / 2.0 - size * 0.55, 0.0, size * 0.48)
        } else {
            heartPath(off - tw / 2.0 - size * 0.55, 0.0, size * 0.4)
            x.fillStyle = PINK_HEART
            x.fill()
            x.lineWidth = 1.4
            x.strokeStyle = WHITE
            x.stroke()
        }
        label(text, size, off, 1.0, tc, ALIGN_CENTER, sc)
    } else {
        label(text, size, 0.0, 1.0, tc, ALIGN_CENTER, sc)
    }
    x.restore()
}

fun toggle(id: String, text: String, on: Boolean, cx: Double, cy: Double, w: Double, h: Double) {
    uiPush(id, cx - w / 2.0, cy - h / 2.0, w, h)
    val kk = "$id~"
    val k = damp(bsGetOr(kk, if (on) 1.0 else 0.0), if (on) 1.0 else 0.0, 16.0, fdt)
    bs[kk] = k
    if (hov == id) {
        pill(cx - w / 2.0, cy - h / 2.0, w, h, h / 2.0)
        x.fillStyle = rgba(255, 255, 255, 0.1)
        x.fill()
    }
    label(text, 14.0, cx - w / 2.0 + 16.0, cy + 1.0, WHITE, ALIGN_LEFT)
    val sw = 42.0
    val swh = 22.0
    val sx = cx + w / 2.0 - 14.0 - sw
    val sy = cy - swh / 2.0
    pill(sx, sy, sw, swh, swh / 2.0)
    x.fillStyle = rgba(255, 255, 255, 0.18)
    x.fill()
    x.save()
    x.alpha *= k
    pill(sx, sy, sw, swh, swh / 2.0)
    x.fillShader = x.lin(sx, 0.0, sx + sw, 0.0, PINK_TOP, PURPLE_BOT)
    x.fill()
    x.restore()
    x.fillStyle = WHITE
    x.beginPath()
    x.arc(sx + 11.0 + (sw - 22.0) * k, cy, 8.0, 0.0, 7.0)
    x.fill()
}

fun tile(cx: Double, cy: Double, w: Double, h: Double, head: String, value: String, color: Int) {
    pill(cx - w / 2.0, cy - h / 2.0, w, h, 12.0)
    x.fillStyle = rgba(255, 255, 255, 0.09)
    x.fill()
    label(head, 9.5, cx, cy - h * 0.26, hex(0xbfb2ec))
    label(value, 17.0, cx, cy + h * 0.16, color)
}

fun xpChip(cx: Double, cy: Double, w: Double, h: Double) {
    val v = lvOf(xp)
    val f = v.cur.toDouble() / v.need
    glass(cx - w / 2.0, cy - h / 2.0, w, h, h / 2.0, 0.85)
    x.save()
    pill(cx - w / 2.0, cy - h / 2.0, w, h, h / 2.0)
    x.clip()
    x.fillShader = x.lin(cx - w / 2.0, 0.0, cx + w / 2.0, 0.0, rgba(255, 155, 224, 0.6), rgba(154, 92, 255, 0.6))
    x.fillRect(cx - w / 2.0, cy - h / 2.0, w * f, h)
    x.restore()
    label(T("LV {0}", v.n), h * 0.5, cx, cy + 1.0, WHITE)
}

fun fitLabel(text: String, size: Double, px: Double, py: Double, color: Int, align: Int, maxw: Double) {
    val t2 = fmt(text)
    x.setFont(size)
    val w = x.measureText(t2)
    label(text, if (w > maxw) size * maxw / w else size, px, py, color, align)
}

fun veil(a: Double) {
    x.fillStyle = rgba(14, 7, 42, a)
    x.fillRect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
}
