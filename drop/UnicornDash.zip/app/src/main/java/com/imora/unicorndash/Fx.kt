package com.imora.unicorndash

import kotlin.math.cos
import kotlin.math.sin

fun rnd(): Double = Math.random()

fun spark(px: Double, py: Double, vx: Double, vy: Double, life: Double, size: Double, h: Double, sat: Double, lum: Double, a: Double, gr: Double) {
    val q = if (partPool.size > 0) partPool.removeAt(partPool.size - 1) else Part()
    q.x = px
    q.y = py
    q.vx = vx
    q.vy = vy
    q.life = life
    q.max = life
    q.s = size
    q.h = h
    q.sat = sat
    q.lum = lum
    q.a = a
    q.gr = gr
    parts.add(q)
}

fun burst(px: Double, py: Double, n: Int, hue: Double, power: Double = 170.0) {
    for (i in 0 until n) {
        val a = rnd() * 6.283
        val s = rnd() * power
        spark(px, py, cos(a) * s, sin(a) * s - 70.0, 0.5 + rnd() * 0.4, 4.0 + rnd() * 6.0, hue, if (hue == 0.0) 0.0 else 100.0, if (hue == 0.0) 100.0 else 70.0, 1.0, 1.0)
    }
}

fun stepParts(dt: Double) {
    var w = 0
    for (i in 0 until parts.size) {
        val q = parts[i]
        q.vy += 600.0 * dt * q.gr
        q.x += q.vx * dt
        q.y += q.vy * dt
        q.life -= dt
        if (q.life > 0.0) {
            parts[w++] = q
        } else {
            partPool.add(q)
        }
    }
    while (parts.size > w) parts.removeAt(parts.size - 1)
}

fun trailFx() {
    val f = TR[trailSel].fx
    if (f == "dust") return
    val px = p.x - 16.0
    val py = p.y - 20.0 + (rnd() - 0.5) * 10.0
    when (f) {
        "star" -> spark(px, py, -40.0 - rnd() * 30.0, (rnd() - 0.5) * 40.0, 0.7, 4.0 + rnd() * 3.0, 48.0, 100.0, 78.0, 0.9, 0.0)
        "heart" -> spark(px, py, -30.0 - rnd() * 30.0, -20.0 - rnd() * 20.0, 0.8, 4.0 + rnd() * 3.0, 335.0, 100.0, 80.0, 0.9, -0.1)
        "snow" -> spark(px, py, -30.0 - rnd() * 30.0, (rnd() - 0.5) * 20.0, 1.0, 3.0 + rnd() * 3.0, 200.0, 40.0, 96.0, 0.85, 0.15)
        "ember" -> spark(px, py, -30.0 - rnd() * 30.0, -10.0 - rnd() * 20.0, 0.7, 3.0 + rnd() * 3.0, 20.0, 100.0, 60.0, 0.9, -0.35)
        "spark" -> spark(px, py, -50.0 - rnd() * 30.0, (rnd() - 0.5) * 60.0, 0.5, 3.0 + rnd() * 3.0, if (rnd() < 0.5) 180.0 else 300.0, 100.0, 68.0, 0.9, 0.0)
        else -> spark(px, py, -40.0 - rnd() * 30.0, (rnd() - 0.5) * 30.0, 0.8, 4.0 + rnd() * 3.0, 45.0, 100.0, 72.0, 0.9, 0.05)
    }
}

fun ambInit() {
    amb.clear()
    for (i in 0 until 38) amb.add(Amb(rnd() * L, rnd() * G, 0.35 + rnd() * 0.65, rnd() * 9.0))
}

fun ambStep(dt: Double) {
    val m = Z.fx
    val run = if (st == 1) speed else if (st == 8 || st == 9) coast else 130.0
    for (a in amb) {
        a.x -= run * 0.22 * a.z * dt
        when (m) {
            0 -> {
                a.y -= 10.0 * a.z * dt
                a.x += sin(clock * 0.8 + a.ph) * 8.0 * dt
            }
            1 -> {
                a.y += 26.0 * a.z * dt
                a.x += sin(clock * 1.2 + a.ph) * 22.0 * dt
            }
            2 -> {
                a.y += sin(clock * 0.9 + a.ph) * 12.0 * dt
                a.x += cos(clock * 0.7 + a.ph) * 10.0 * dt
            }
            3 -> {
                a.y += 38.0 * a.z * dt
                a.x += sin(clock + a.ph) * 14.0 * dt - 18.0 * dt
            }
            4 -> {
                a.x -= run * 0.5 * a.z * dt
                a.y += sin(clock * 2.0 + a.ph) * 6.0 * dt
            }
            6 -> {
                a.y -= (14.0 + 16.0 * a.z) * dt
                a.x += sin(clock * 1.4 + a.ph) * 10.0 * dt
            }
            7 -> {
                a.y += 30.0 * a.z * dt
                a.x += sin(clock * 1.6 + a.ph) * 26.0 * dt - 16.0 * dt
            }
            8 -> a.y += 230.0 * a.z * dt
            9 -> {
                a.y += sin(clock * 0.5 + a.ph) * 5.0 * dt
                a.x += cos(clock * 0.4 + a.ph) * 6.0 * dt
            }
            10 -> a.y += sin(clock * 0.7 + a.ph) * 6.0 * dt
            11, 12 -> {
                a.y -= 12.0 * a.z * dt
                a.x += sin(clock + a.ph) * 10.0 * dt
            }
            else -> {
                a.y -= 34.0 * a.z * dt
                a.x += sin(clock * 2.0 + a.ph) * 16.0 * dt
            }
        }
        if (a.x < -20.0) a.x = L + 20.0
        if (a.x > L + 40.0) a.x = -10.0
        if (a.y > G - 4.0) a.y = -8.0
        if (a.y < -10.0) a.y = G - 6.0
    }
}

fun ambDraw() {
    val m = Z.fx
    for (a in amb) {
        val fl = 0.5 + 0.5 * sin(clock * 3.0 + a.ph * 5.0)
        when (m) {
            0 -> x.halo(a.x, a.y, 5.0 * a.z + 2.0, 48.0, 100.0, 78.0, 0.35 + 0.35 * fl)
            1 -> {
                x.save()
                x.translate(a.x, a.y)
                x.rotate(clock * 1.5 + a.ph)
                x.fillStyle = rgba(255, 200, 225, 0.85)
                x.beginPath()
                x.ellipse(0.0, 0.0, 4.0 * a.z + 1.0, 2.0 * a.z + 0.8, 0.0, 0.0, 7.0)
                x.fill()
                x.restore()
            }
            2 -> x.halo(a.x, a.y, 9.0 * a.z + 3.0, 62.0, 100.0, 70.0, 0.3 + 0.6 * fl)
            3 -> {
                x.fillStyle = rgba(255, 255, 255, 0.5 + 0.4 * a.z)
                x.beginPath()
                x.arc(a.x, a.y, 1.2 + 1.6 * a.z, 0.0, 7.0)
                x.fill()
            }
            4 -> x.halo(a.x, a.y, 8.0 * a.z + 2.0, 32.0, 70.0, 80.0, 0.18 * a.z)
            6 -> {
                x.strokeStyle = rgba(210, 245, 255, 0.35 + 0.4 * a.z)
                x.lineWidth = 1.1
                x.beginPath()
                x.arc(a.x, a.y, 2.0 + 4.0 * a.z, 0.0, 7.0)
                x.stroke()
                x.fillStyle = rgba(255, 255, 255, 0.6)
                x.fillRect(a.x - 1.0, a.y - 2.2 * a.z - 1.0, 1.4, 1.4)
            }
            7 -> {
                x.save()
                x.translate(a.x, a.y)
                x.rotate(clock * 1.8 + a.ph)
                x.fillStyle = hsl(Z.hue + (a.ph * 7.0) % 36.0, 85.0, 55.0, 0.9)
                x.beginPath()
                x.ellipse(0.0, 0.0, 4.5 * a.z + 1.5, 2.4 * a.z + 0.8, 0.0, 0.0, 7.0)
                x.fill()
                x.restore()
            }
            8 -> {
                x.strokeStyle = hsl(if (a.ph > 4.5) Z.hue + 160.0 else Z.hue, 100.0, 66.0, 0.35 + 0.4 * a.z)
                x.lineWidth = 1.2
                x.beginPath()
                x.moveTo(a.x, a.y)
                x.lineTo(a.x - 1.5, a.y + 6.0 + 8.0 * a.z)
                x.stroke()
            }
            9 -> x.halo(a.x, a.y * 0.6 + 90.0, 34.0 * a.z + 14.0, Z.hue, 30.0, 78.0, 0.06 + 0.05 * fl)
            10 -> x.halo(a.x, a.y, 5.0 * a.z + 2.0, Z.hue, 100.0, 86.0, 0.3 + 0.6 * fl)
            11 -> x.halo(a.x, a.y, 6.0 * a.z + 2.0, Z.hue, 100.0, 72.0, 0.35 + 0.5 * fl)
            12 -> x.halo(a.x, a.y, 6.0 * a.z + 2.0, (clock * 60.0 + a.ph * 40.0) % 360.0, 100.0, 72.0, 0.35 + 0.5 * fl)
            else -> x.halo(a.x, a.y, 6.0 * a.z + 2.0, 22.0, 100.0, 60.0, 0.35 + 0.5 * fl)
        }
    }
}
