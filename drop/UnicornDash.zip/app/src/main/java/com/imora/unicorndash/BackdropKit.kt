package com.imora.unicorndash

import kotlin.math.sin

inline fun layer(off: Double, cs: Double, seed: Int, fn: (Double, Double, Double) -> Unit) {
    val a = Math.floor(off / cs).toInt() - 1
    val b = Math.ceil((off + L) / cs).toInt() + 1
    for (i in a..b) {
        fn(
            i * cs + (hs((i * 3 + seed).toDouble()) - 0.5) * cs * 0.6 - off,
            hs((i * 7 + seed).toDouble()),
            hs((i * 13 + seed + 9).toDouble())
        )
    }
}

fun sway(a: Double, b: Double): Double = sin(t * a + b)

fun tri(px: Double, y: Double, h: Double, w: Double) {
    x.moveTo(px - w, y)
    x.lineTo(px, y - h)
    x.lineTo(px + w, y)
}

fun dome(px: Double, y: Double, r: Double, k: Double) {
    x.moveTo(px - r, y)
    x.ellipse(px, y, r, r * k, 0.0, PI, PI * 2.0)
}

fun disc(px: Double, py: Double, r: Double) {
    x.moveTo(px + r, py)
    x.arc(px, py, r, 0.0, 7.0)
}

fun oval(px: Double, py: Double, rx: Double, ry: Double) {
    x.moveTo(px + rx, py)
    x.ellipse(px, py, rx, ry, 0.0, 0.0, 7.0)
}

fun wave(rd: Double, y: Double, a: Double, b: Double, k: Double) {
    x.beginPath()
    x.moveTo(0.0, G)
    var i = 0.0
    while (i <= L + 12.0) {
        x.lineTo(i, y - a * sin((i + rd) / b) - a * 0.5 * sin((i + rd) / (b * k)))
        i += 12.0
    }
    x.lineTo(L + 12.0, G)
    x.fill()
}

fun pine(px: Double, y: Double, h: Double, w: Double) {
    tri(px, y - h * 0.18, h * 0.5, w)
    tri(px, y - h * 0.4, h * 0.45, w * 0.78)
    tri(px, y - h * 0.62, h * 0.38, w * 0.55)
    x.rect(px - 2.0, y - h * 0.18, 4.0, h * 0.18)
}

fun crys(px: Double, h: Double, w: Double) {
    x.moveTo(px - w, G)
    x.lineTo(px - w * 0.7, G - h * 0.65)
    x.lineTo(px, G - h)
    x.lineTo(px + w * 0.7, G - h * 0.65)
    x.lineTo(px + w, G)
}
