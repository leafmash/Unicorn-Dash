package com.imora.unicorndash

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var view: GameView
    private var lastBack = 0.0
    private var dialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        initSave(applicationContext)
        loadSave()
        daily()
        initHaptics(applicationContext)
        zi = lastZ
        setZone(lastZ)
        reset()
        stAt = nowMs()
        view = GameView(this)
        setContentView(view)
        backupRequest = { export -> runOnUiThread { showBackup(export) } }
        Audio.start()
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                OnBackInvokedCallback { handleBack() }
            )
        }
        immerse()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        handleBack()
    }

    private fun handleBack() {
        view.runOnGame {
            if (!backPressed()) {
                val now = nowMs()
                if (now - lastBack < 2000.0) {
                    runOnUiThread { finish() }
                } else {
                    lastBack = now
                    say("Press back again to exit")
                }
            }
        }
    }

    private fun immerse() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val c = window.insetsController
            if (c != null) {
                c.hide(android.view.WindowInsets.Type.systemBars())
                c.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            immerse()
        } else {
            view.runOnGame { pause() }
        }
    }

    override fun onResume() {
        super.onResume()
        Audio.resume()
        view.runOnGame { refreshDay() }
    }

    override fun onPause() {
        super.onPause()
        view.runOnGame {
            pause()
            save()
        }
        Audio.pause()
    }

    override fun onDestroy() {
        dialog?.dismiss()
        backupRequest = null
        Audio.stop()
        super.onDestroy()
    }

    private fun styledInput(text: String, readOnly: Boolean): EditText {
        val e = EditText(this)
        e.setText(text)
        e.setTextColor(Color.WHITE)
        e.setBackgroundColor(Color.argb(150, 10, 5, 40))
        e.textSize = 12f
        e.setPadding(24, 24, 24, 24)
        e.minLines = 4
        e.maxLines = 6
        e.gravity = Gravity.TOP or Gravity.START
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (readOnly) {
            e.keyListener = null
            e.setSelectAllOnFocus(true)
        }
        return e
    }

    private fun showBackup(export: Boolean) {
        dialog?.dismiss()
        if (export) {
            view.runOnGame {
                val code = makeCode()
                runOnUiThread { showExport(code) }
            }
        } else {
            showImport()
        }
    }

    private fun showExport(code: String) {
        val input = styledInput(code, true)
        val d = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(fmt(T("Backup code")))
            .setView(input)
            .setPositiveButton(fmt(T("Copy")), null)
            .setNegativeButton(fmt(T("Close")), null)
            .create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("backup", code))
            d.getButton(AlertDialog.BUTTON_POSITIVE).text = fmt(T("Copied"))
        }
        dialog = d
    }

    private fun showImport() {
        val input = styledInput("", false)
        val d = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(fmt(T("Paste your backup code here")))
            .setView(input)
            .setPositiveButton(fmt(T("IMPORT")), null)
            .setNegativeButton(fmt(T("Cancel")), null)
            .create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val text = input.text.toString()
            view.runOnGame {
                val ok = importCode(text)
                runOnUiThread {
                    if (ok) {
                        d.dismiss()
                    } else {
                        Toast.makeText(this, fmt(T("Invalid code")), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        dialog = d
    }
}
