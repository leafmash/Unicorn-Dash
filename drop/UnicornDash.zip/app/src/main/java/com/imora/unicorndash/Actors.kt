package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val lobbyCols = IntArray(4)
private val lobbyPos = floatArrayOf(0f, 0.0714f, 0.5857f, 1f)

fun lobbyTick(dt: Double) {
    val dx = lob.ptx - lob.px
    val moving = abs(dx) > 1.5
    if (moving) {
        val dir = if (dx > 0.0) 1.0 else -1.0
        lob.tg = dir
        if (abs(lob.fx - dir) < 0.4 && lob.hop <= 0.0) {
            val sp = 56.0 * clamp(abs(dx) / 18.0, 0.3, 1.0)
            lob.px += dir * min(abs(dx), sp * dt)
            lob.wph += sp * 0.0997 * dt
            lob.wk = damp(lob.wk, 1.0, 7.0, dt)
        } else {
            lob.wk = damp(lob.wk, 0.0, 9.0, dt)
        }
    } else {
        lob.wk = damp(lob.wk, 0.0, 6.0, dt)
        lob.wnext -= dt
        if (lob.wnext <= 0.0) {
            var tgt = (rnd() * 2.0 - 1.0) * 72.0
            if (abs(tgt - lob.px) < 34.0) tgt = if (lob.px > 0.0) -50.0 - rnd() * 20.0 else 50.0 + rnd() * 20.0
            lob.ptx = tgt
            lob.wnext = 2.2 + rnd() * 3.2
        }
    }
    lob.next -= dt
    if (lob.next <= 0.0) {
        val r = rnd()
        if (r < 0.38) {
            if (!moving) lob.tg = -lob.tg
            lob.next = 4.5 + rnd() * 3.0
        } else {
            lob.gt = if (rnd() < 0.5) 1.0 else -1.0
            lob.gh = 0.9
            lob.next = 2.4 + rnd() * 2.6
        }
    }
    if (lob.gh > 0.0) {
        lob.gh -= dt
        if (lob.gh <= 0.0) lob.gt = 0.0
    }
    lob.fx = damp(lob.fx, lob.tg, 4.2, dt)
    lob.g = damp(lob.g, lob.gt, 5.0, dt)
    if (lob.hop > 0.0) lob.hop = max(0.0, lob.hop - dt)
}

fun dreamAmbient() {
    for (i in 0 until 16) {
        val speed = 4.0 + (i % 4) * 2.5
        val px = (hs(i) * L + sin(clock * 0.2 + i) * 20.0 + clock * speed) % L
        val py = 30.0 + hs(i + 40) * 250.0 + sin(clock * 0.5 + i * 1.7) * 14.0
        val r = 6.0 + hs(i + 80) * 16.0
        val hue = (hs(i + 120) * 360.0 + clock * 10.0) % 360.0
        val a = 0.12 + 0.1 * sin(clock * 1.3 + i)
        x.halo(px, py, r * 2.0, hue, 90.0, 78.0, a)
    }
    for (i in 0 until 7) {
        val k = (clock * 0.12 + i / 7.0) % 1.0
        val px = L * (0.08 + 0.84 * hs(i + 200)) + sin(clock * 0.9 + i * 2.0) * 26.0
        val py = G + 6.0 - k * 300.0
        val a = sin(k * PI) * 0.7
        sparkle(px, py, 2.6 + (i % 3) * 1.1, i.toDouble() + clock)
        x.halo(px, py, 10.0, 300.0 - k * 120.0, 100.0, 80.0, a * 0.35)
    }
}

private fun rainbowArc(cx: Double, cy: Double) {
    x.lineCap = CAP_BUTT
    for (b in 0 until 7) {
        x.strokeStyle = hsl(b * 48.0 + (clock * 8.0) % 360.0, 95.0, 68.0, 0.13 + 0.04 * sin(clock * 0.8 + b))
        x.lineWidth = 9.0
        x.beginPath()
        x.arc(cx, cy, 196.0 - b * 8.5, PI, 0.0)
        x.stroke()
    }
}

fun lobbyScene(cx: Double) {
    val fy = 282.0
    x.fillShader = x.lin(0.0, 40.0, 0.0, fy, rgba(255, 255, 255, 0.0), rgba(255, 210, 255, 0.2))
    x.beginPath()
    x.moveTo(cx - 34.0, 40.0)
    x.lineTo(cx + 34.0, 40.0)
    x.lineTo(cx + 128.0, fy)
    x.lineTo(cx - 128.0, fy)
    x.closePath()
    x.fill()
    rainbowArc(cx, fy - 10.0)
    x.save()
    x.translate(cx, 190.0)
    x.rotate(clock * 0.08)
    x.fillStyle = rgba(255, 255, 255, 0.055)
    for (i in 0 until 12) {
        x.rotate(PI / 6.0)
        x.beginPath()
        x.moveTo(0.0, 0.0)
        x.lineTo(-18.0, -230.0)
        x.lineTo(18.0, -230.0)
        x.fill()
    }
    x.restore()
    x.halo(cx, 190.0, 150.0, (clock * 12.0 + 280.0) % 360.0, 100.0, 70.0, 0.3)
    lobbyCols[0] = rgba(255, 190, 255, 0.55)
    lobbyCols[1] = rgba(255, 190, 255, 0.55)
    lobbyCols[2] = rgba(150, 100, 255, 0.3)
    lobbyCols[3] = rgba(100, 60, 220, 0.0)
    x.fillShader = x.radN(cx, fy + 4.0, 140.0, lobbyCols, lobbyPos)
    x.beginPath()
    x.ellipse(cx, fy + 4.0, 140.0, 28.0, 0.0, 0.0, 7.0)
    x.fill()
    x.fillStyle = rgba(30, 14, 80, 0.55)
    x.beginPath()
    x.ellipse(cx, fy + 4.0, 104.0, 18.0, 0.0, 0.0, 7.0)
    x.fill()
    x.lineWidth = 2.0
    x.strokeStyle = rgba(255, 255, 255, 0.7)
    x.beginPath()
    x.ellipse(cx, fy + 4.0, 104.0, 18.0, 0.0, 0.0, 7.0)
    x.stroke()
    val pr = (clock * 0.5) % 1.0
    x.strokeStyle = rgba(255, 200, 255, 0.6 * (1.0 - pr))
    x.lineWidth = 2.2
    x.beginPath()
    x.ellipse(cx, fy + 4.0, 104.0 + 40.0 * pr, 18.0 + 8.0 * pr, 0.0, 0.0, 7.0)
    x.stroke()
    x.setLineDash(10.0, 9.0)
    x.dashOffset = -clock * 14.0
    x.strokeStyle = rgba(150, 240, 255, 0.75)
    x.lineWidth = 1.6
    x.beginPath()
    x.ellipse(cx, fy + 4.0, 122.0, 22.0, 0.0, 0.0, 7.0)
    x.stroke()
    x.clearLineDash()
    for (i in 0 until 9) {
        val a = clock * 0.35 + i * 6.2832 / 9.0
        val rr = 118.0 + 14.0 * sin(clock + i)
        val px = cx + cos(a) * rr
        val py = 186.0 + sin(a) * 66.0 + sin(clock * 1.4 + i) * 8.0
        if (sin(a) > -0.2 || i % 2 == 1) sparkle(px, py, 3.0 + i % 3 * 1.6, i.toDouble())
    }
}

private fun drawParts() {
    for (q in parts) {
        val l = q.life / q.max
        x.halo(q.x, q.y, q.s * 2.2, q.h, q.sat, q.lum, min(1.0, l * 1.2) * q.a)
    }
}

fun lobbyActors() {
    val cx = L / 2.0
    val fy = 282.0
    lobbyScene(cx)
    dreamAmbient()
    val ux = cx + lob.px
    val wk = lob.wk
    val hp = if (lob.hop > 0.0) sin(PI * (1.0 - lob.hop / 0.75)) else 0.0
    val br = sin(clock * 1.9)
    val bob = abs(sin(lob.wph)) * 1.6 * wk
    x.fillStyle = rgba(0, 0, 0, 0.3)
    x.beginPath()
    x.ellipse(ux, fy + 4.0, 64.0 * (1.0 - hp * 0.3), 9.0 * (1.0 - hp * 0.3), 0.0, 0.0, 7.0)
    x.fill()
    uq.clear()
    uq.x = ux
    uq.y = fy - hp * 46.0 - bob
    uq.ang = sin(clock * 0.7) * 0.012
    uq.sq = 1.0 + br * 0.011 + (if (lob.hop > 0.0) (if (hp < 0.12 || lob.hop < 0.1) -0.06 else 0.04) else 0.0)
    uq.dk = 0.0
    uq.air = hp > 0.15
    uq.stand = wk < 0.05
    uq.gait = if (wk > 0.02) 1 else 0
    uq.stride = 7.0 * wk
    uq.wph = lob.wph
    uq.tt = clock * 0.55
    uq.happy = lob.hop > 0.0
    uq.dead = false
    uq.sc = 2.25
    uq.hn = hornSel
    uq.fx = lob.fx
    uq.nod = lob.g * 0.2 + sin(clock * 0.8) * 0.03
    unicorn(uq, skin)
    drawParts()
}

fun menuActors() {
    dreamAmbient()
    val cx = L * 0.5
    val ph = clock * 13.6
    val bob = sin(ph * 2.0) * 0.9
    x.fillStyle = rgba(0, 0, 0, 0.26)
    x.beginPath()
    x.ellipse(cx, G + 4.0, 46.0, 7.0, 0.0, 0.0, 7.0)
    x.fill()
    ribbon(cx - 170.0, cx - 20.0, G - 44.0 + bob, trailSel, clock)
    for (i in 0 until 4) {
        val k = (clock * 2.2 + i * 0.25) % 1.0
        x.halo(cx - 26.0 - k * 64.0, G - 2.0 - k * 12.0, 5.0 + 10.0 * k, 40.0, 30.0, 85.0, 0.26 * (1.0 - k))
    }
    uq.clear()
    uq.x = cx
    uq.y = G + bob
    uq.sq = 1.0
    uq.tt = clock
    uq.gait = 2
    uq.stride = 10.0
    uq.wph = ph
    uq.sc = 1.4
    uq.hn = hornSel
    unicorn(uq, skin)
    val kind = PT[petSel].kind
    if (kind.isNotEmpty()) petDraw(kind, cx - 96.0, G - 70.0 + sin(clock * 2.2) * 7.0, 1.7, clock, false)
    drawParts()
}

fun shopActors() {
    val cx = L * 0.27
    val oSkin = skin
    val oHorn = hornSel
    val oTrail = trailSel
    when (shopTab) {
        0 -> skin = shopSel
        1 -> trailSel = shopSel
        2 -> hornSel = shopSel
    }
    val bob = sin(t * 40.0) * 0.9
    dreamAmbient()
    x.fillStyle = rgba(0, 0, 0, 0.26)
    x.beginPath()
    x.ellipse(cx, G + 4.0, 46.0, 7.0, 0.0, 0.0, 7.0)
    x.fill()
    ribbon(cx - 170.0, cx - 20.0, G - 44.0 + bob, trailSel, clock)
    uq.clear()
    uq.x = cx
    uq.y = G + bob
    uq.ang = 0.0
    uq.sq = 1.0
    uq.dk = 0.0
    uq.air = false
    uq.tt = t
    uq.gait = 2
    uq.stride = 12.0
    uq.wph = t * 20.0
    uq.sc = 1.4
    uq.hn = hornSel
    unicorn(uq, skin)
    val kind = if (shopTab == 3) PT[shopSel].kind else PT[petSel].kind
    if (kind.isNotEmpty()) petDraw(kind, cx - 96.0, G - 70.0 + sin(clock * 2.2) * 7.0, 1.7, clock, false)
    if (shopTab == 4) {
        val sk = SKL[shopSel]
        val gy = G - 150.0 + sin(clock * 2.0) * 5.0
        x.halo(cx + 20.0, gy, 90.0, sk.hue, 100.0, 70.0, 0.5 + 0.15 * sin(clock * 4.0))
        skillIcon(sk.k, cx + 20.0, gy, 3.0)
    }
    skin = oSkin
    hornSel = oHorn
    trailSel = oTrail
    drawParts()
}

fun actors(rs: Double) {
    if (st == 0) {
        lobbyActors()
        return
    }
    if (st == 4) {
        shopActors()
        return
    }
    if (st == 5 || st == 6 || st == 7 || (st >= 10 && st <= 13)) {
        menuActors()
        return
    }
    val py = p.y + (p.py - p.y) * (1.0 - alpha)
    val lift = min(1.0, max(0.0, 1.0 - (G - py) / 260.0))
    x.fillStyle = rgba(0, 0, 0, 0.22)
    x.beginPath()
    val pf = p.dead && p.fall
    x.ellipse(p.x, G + 4.0, if (pf) 0.0 else 24.0 * lift, if (pf) 0.0 else 4.5 * lift, 0.0, 0.0, 7.0)
    x.fill()

    if (trail.size > 2) {
        x.lineCap = CAP_ROUND
        x.lineJoin = JOIN_ROUND
        val tx0 = p.x - 14.0 - (t - trail[0].t) * speed * 0.45
        val lw = if (dash > 0.0) 5.6 else 4.2
        for (b in 0 until 6) {
            trailRgb(trailSel, b, t)
            x.strokeShader = x.lin(tx0, 0.0, p.x - 14.0, 0.0, trgbA(0.0), trgbA(if (dash > 0.0) 0.95 else 0.75))
            x.lineWidth = lw
            x.beginPath()
            for (j in 0 until trail.size) {
                val q = trail[j]
                val age = t - q.t
                val ptx = p.x - 14.0 - age * speed * 0.45
                val pty = q.y + (b - 2.5) * lw + sin(age * 20.0 + b) * 1.3
                if (j == 0) x.moveTo(ptx, pty) else x.lineTo(ptx, pty)
            }
            x.lineTo(p.x - 14.0, py - lerp(28.0, 16.0, p.dk) + (b - 2.5) * lw)
            x.stroke()
        }
    }

    val lv = lvl
    if (lv != null && (st == 1 || st == 2 || st == 3 || st == 8 || st == 9)) {
        val pxp = p.x + lv.len - runDist + rs
        if (pxp < L + 140.0 && pxp > -120.0) portalFx(pxp)
    }

    for (it in items) {
        val ix = it.x + rs
        if (it.k == "coin") coin(it, ix) else drawPower(it.k, ix, it.y + sin(t * 3.0 + it.ph) * 4.0, 1.0)
    }

    for (o in obs) {
        if (o.dead) continue
        val ox = o.x + rs
        when (o.type) {
            OT.crystal -> crystal(o, ox)
            OT.wisp -> wisp(o, ox)
            OT.pit -> pit(o, ox)
            OT.spin -> spin(o, ox)
            OT.bird -> bird(o, ox)
            OT.fire -> flames(o, ox)
            OT.pillar -> pillar(o, ox)
            OT.ice -> ice(o, ox)
            OT.spikes -> spikes(o, ox)
            OT.boulder -> boulder(o, ox)
            OT.wall -> wall(o, ox)
            OT.swing -> swing(o, ox)
            OT.laser -> laser(o, ox)
            else -> storm(o, ox, (if (o.type == OT.stormLow) G - 48.0 else G - 80.0) + sin(t * 3.0 + o.seed) * 3.0)
        }
    }

    if (dash > 0.0) x.halo(p.x + 4.0, py - 28.0, 64.0 + 6.0 * sin(t * 10.0), (clock * 240.0) % 360.0, 100.0, 65.0, 0.55)
    if (pwWing > 0.0 && !p.dead) {
        x.save()
        x.translate(p.x + 2.0, py - 30.0)
        x.fillStyle = rgba(255, 255, 255, 0.9)
        x.strokeStyle = rgba(190, 170, 255, 0.9)
        x.lineWidth = 1.5
        for (i in 0 until 2) {
            x.save()
            x.rotate(sin(t * 16.0) * 0.35 - i * 0.3)
            x.beginPath()
            x.moveTo(0.0, 0.0)
            x.quadraticCurveTo(-8.0, -26.0 - i * 4.0, -30.0 - i * 6.0, -30.0 - i * 8.0)
            x.quadraticCurveTo(-24.0, -12.0, -6.0, 2.0)
            x.closePath()
            x.fill()
            x.stroke()
            x.restore()
        }
        x.restore()
    }

    val gd = ghostD
    if (gd != null && !p.dead && (st == 1 || st == 3)) {
        val f = t * 10.0
        val i = Math.floor(f).toInt()
        if (i + 1 < gd.size) {
            val a = gd[i]
            val b = gd[i + 1]
            val h = lerp((a % 1000).toDouble(), (b % 1000).toDouble(), f - i) * 2.0
            x.save()
            x.alpha = 0.3
            uq.clear()
            uq.x = p.x - 38.0
            uq.y = G - h
            uq.ang = 0.0
            uq.sq = 1.0
            uq.dk = if (a >= 1000) 1.0 else 0.0
            uq.sit = if (a >= 1000) 1.0 else 0.0
            uq.air = h > 3.0
            uq.tt = t
            uq.dead = false
            uq.hn = hornSel
            uq.ghost = true
            unicorn(uq, skin)
            x.restore()
        }
    }
    x.save()
    if (p.dead && p.fall && p.hasPit) {
        x.beginPath()
        x.rect(0.0, -ty - 10.0, L, G + ty + 10.0)
        x.rect(p.pit0, G, p.pit1 - p.pit0, 400.0)
        x.clip()
        x.alpha = clamp(1.0 - (py - G) / 120.0, 0.0, 1.0)
    } else {
        x.alpha = if (grace > 0.0 && Math.floor(t * 16.0).toInt() % 2 != 0) 0.45 else 1.0
    }
    uq.clear()
    uq.x = p.x + p.jx
    uq.y = py + (if (p.air || p.dead || p.vic != 0) 0.0 else sin(t * 34.0) * 0.8)
    uq.ang = p.ang
    uq.sq = p.sq
    uq.dk = p.dk
    uq.air = p.air
    uq.tt = t
    uq.rt = p.rt
    uq.sit = if (p.vic != 0) 0.0 else p.dk
    uq.rear = p.rear
    uq.stand = p.stand != 0
    uq.happy = p.happy
    uq.dead = p.dead
    uq.sc = msc
    uq.hn = hornSel
    unicorn(uq, skin)
    x.restore()
    if (p.dead && p.kind == "zap" && p.hold > 0.0) {
        x.halo(p.x, p.y - 26.0, 70.0, 55.0, 100.0, 75.0, 0.8)
        x.strokeStyle = hex(0xfff6a8)
        x.lineWidth = 2.0
        x.lineJoin = JOIN_ROUND
        for (b in 0 until 3) {
            var bx0 = p.x + (rnd() - 0.5) * 20.0
            var by0 = p.y - 6.0 - rnd() * 10.0
            x.beginPath()
            x.moveTo(bx0, by0)
            for (i in 0 until 5) {
                bx0 += (rnd() - 0.5) * 26.0
                by0 -= 8.0 + rnd() * 8.0
                x.lineTo(bx0, by0)
            }
            x.stroke()
        }
    }

    if (buddyKind != "" && !p.dead) {
        val fairyOn = buddyKind == "fairy" && (magnet > 0.0 || dbl > 0.0 || slow > 0.0 || mini > 0.0 || pwSx > 0.0 || pwRain > 0.0 || pwWing > 0.0 || dash > 0.0)
        petDraw(buddyKind, p.x - 54.0, budY, 1.0, t, fairyOn)
    }
    if (skFxT >= 0.0) {
        val f = skFxT / 0.5
        val sk = SKL[skillSel]
        x.strokeStyle = hsl(sk.hue, 100.0, 75.0, 1.0 - f)
        x.lineWidth = 2.0 + 5.0 * (1.0 - f)
        x.beginPath()
        x.arc(p.x + 4.0, py - 26.0, 14.0 + easeOut(f) * (if (sk.k == "blast") 380.0 else 100.0), 0.0, 7.0)
        x.stroke()
    }
    if (shield > 0 || petGuard > 0) {
        x.strokeStyle = rgba(127, 227, 255, 0.6 + 0.3 * sin(t * 8.0))
        x.fillStyle = rgba(127, 227, 255, 0.12)
        x.lineWidth = 2.5
        x.beginPath()
        x.arc(p.x + 4.0, py - 28.0, 40.0, 0.0, 7.0)
        x.fill()
        x.stroke()
    }

    drawParts()
    for (q in pops) {
        x.save()
        x.alpha = min(1.0, q.life * 2.5)
        label(q.t, 13.0, q.x, q.y, hex(0xffe27a))
        x.restore()
    }
}
