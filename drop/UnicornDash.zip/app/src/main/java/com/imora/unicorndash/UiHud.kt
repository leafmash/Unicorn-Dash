package com.imora.unicorndash

import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val PU_KEYS = arrayOf("shield", "magnet", "star", "coin2", "slow", "mini", "rain", "wings", "sx2")
private val PU_HUES = doubleArrayOf(190.0, 340.0, 48.0, 50.0, 215.0, 285.0, 160.0, 255.0, 110.0)
private val PU_VALUES = DoubleArray(9)
private val RING_BG = rgba(255, 255, 255, 0.16)
private val RING_PANEL = rgba(30, 16, 80, 0.7)
private val SKILL_PANEL = rgba(30, 16, 80, 0.82)
private val HUD_SUB = hex(0xe9dcff)
private val HUD_GOLD = hex(0xffe27a)
private val HINT_NAMES = arrayOf("HOLD TO DUCK", "TAP TO JUMP", "DOWN = DUCK", "SPACE = JUMP")

fun skillBtn(live: Boolean) {
    val sk = SKL[skillSel]
    val cx = L - MR - 34.0
    val cy = 332.0
    val r = 26.0
    val l = lvl
    val off = l != null && l.boss
    val ready = !off && skCd <= 0.0 && skAct <= 0.0
    if (live) uiPush("skill", cx - r, cy - r, r * 2.0, r * 2.0)
    val f = if (off) 0.0 else if (skAct > 0.0) skAct / sk.dur else if (skCd > 0.0) 1.0 - skCd / sk.cd else 1.0
    if (ready || skFlash > 0.0) x.halo(cx, cy, r * (1.6 + skFlash), sk.hue, 100.0, 70.0, 0.3 + 0.15 * sin(clock * 6.0) + skFlash * 0.4)
    x.fillStyle = SKILL_PANEL
    x.beginPath()
    x.arc(cx, cy, r, 0.0, 7.0)
    x.fill()
    x.lineWidth = 4.0
    x.lineCap = CAP_ROUND
    x.strokeStyle = RING_BG
    x.beginPath()
    x.arc(cx, cy, r - 2.0, 0.0, 7.0)
    x.stroke()
    x.strokeStyle = if (skAct > 0.0) WHITE else hsl(sk.hue, 100.0, if (ready) 76.0 else 62.0)
    x.beginPath()
    x.arc(cx, cy, r - 2.0, -PI / 2.0, -PI / 2.0 + 6.283 * clamp(f, 0.0, 1.0))
    x.stroke()
    x.save()
    x.alpha *= if (ready || skAct > 0.0) 1.0 else 0.4
    skillIcon(sk.k, cx, cy, if (ready) 1.0 + 0.06 * sin(clock * 6.0) else 0.9)
    x.restore()
    if (!off && skCd > 0.0 && skAct <= 0.0) label(ceil(skCd).toInt().toString(), 16.0, cx, cy + 1.0, WHITE)
    if (!coarse) label("E", 10.0, cx, cy + r + 9.0, hex(0xd9ccff))
}

fun hud() {
    val a = if (st == 2 || st == 8) 1.0 - ovk else 1.0
    if (a <= 0.01) return
    val l = lvl
    x.save()
    x.alpha = a
    label(floor(shown).toInt().toString(), 32.0, ML, 32.0, WHITE, ALIGN_LEFT)
    val sub = if (l != null) (if (mode == "daily") T("DAILY") else T("LEVEL {0}", li + 1)) else T("BEST {0}", max(eb[zi], floor(score).toInt()))
    label(sub, 11.5, ML + 1.0, 56.0, HUD_SUB, ALIGN_LEFT)
    val cw = if (l != null) 96.0 else 80.0
    chip(ML + cw / 2.0, 78.0, cw, 22.0, if (l != null) "$got/${l.coins}" else coins.toString(), HUD_GOLD, true)
    PU_VALUES[0] = if (shield > 0 || petGuard > 0) 1.0 else 0.0
    PU_VALUES[1] = magnet / 8.0
    PU_VALUES[2] = dash / 6.0
    PU_VALUES[3] = dbl / 10.0
    PU_VALUES[4] = slow / 5.0
    PU_VALUES[5] = mini / 8.0
    PU_VALUES[6] = pwRain / 6.0
    PU_VALUES[7] = pwWing / 5.0
    PU_VALUES[8] = pwSx / 8.0
    var ci = 0
    for (e in 0 until 9) {
        val v = PU_VALUES[e]
        if (v <= 0.0) continue
        val px = ML + 16.0 + ci * 38.0
        val py = 112.0
        x.fillStyle = RING_PANEL
        x.beginPath()
        x.arc(px, py, 16.0, 0.0, 7.0)
        x.fill()
        x.lineWidth = 3.0
        x.lineCap = CAP_ROUND
        x.strokeStyle = RING_BG
        x.beginPath()
        x.arc(px, py, 16.0, 0.0, 7.0)
        x.stroke()
        x.strokeStyle = hsl(PU_HUES[e], 100.0, 72.0)
        x.beginPath()
        x.arc(px, py, 16.0, -PI / 2.0, -PI / 2.0 + 6.283 * min(1.0, v))
        x.stroke()
        drawPower(PU_KEYS[e], px, py, 0.55)
        ci++
    }
    if (st == 1) ibtn("pause", L - MR - 18.0, 32.0, 18.0, iconPause)
    if (st == 1 || st == 3) skillBtn(st == 1)
    label(T("{0} m", floor(runDist / 80.0).toInt()), 12.0, L - MR, 62.0, HUD_SUB, ALIGN_RIGHT)
    if (l == null) heartChip(L / 2.0, 30.0, 74.0, 24.0, "x$hearts")
    if (l != null) {
        val bw = 150.0
        val bx = L / 2.0 - bw / 2.0
        val f = clamp(runDist / l.len, 0.0, 1.0)
        pill(bx, 26.0, bw, 8.0, 4.0)
        x.fillStyle = rgba(255, 255, 255, 0.2)
        x.fill()
        if (f > 0.0) {
            pill(bx, 26.0, max(8.0, bw * f), 8.0, 4.0)
            x.fillShader = x.lin(bx, 0.0, bx + bw, 0.0, PINK_TOP, HUD_GOLD)
            x.fill()
        }
        iconStar(bx + bw + 10.0, 30.0, 8.0, f >= 1.0)
        if (l.rule.isNotEmpty()) {
            var txt = T(ruleLabel(l.rule))
            if (l.rule == "sprint") txt += "  " + max(0, ceil((l.len - runDist) / l.sp).toInt()) + "s"
            label(txt, 11.0, L / 2.0, 48.0, hex(0xffb0cf))
        }
    }
    if (st == 1 && combo > 1) {
        val px = p.x + 40.0
        val py = p.y - 88.0
        x.strokeStyle = rgba(255, 226, 122, 0.9)
        x.lineWidth = 3.0
        x.lineCap = CAP_ROUND
        x.beginPath()
        x.arc(px, py, 20.0, -PI / 2.0, -PI / 2.0 + 6.283 * clamp(comboT / 1.6, 0.0, 1.0))
        x.stroke()
        label("x$combo", 17.0 + combo, px, py + 1.0, HUD_GOLD)
    }
    if (banner.life > 0.0) {
        val k = banner.life / banner.max
        val al = min(clamp((1.0 - k) * 4.0, 0.0, 1.0), clamp(k * 2.5, 0.0, 1.0))
        x.alpha = a * al
        label(banner.sub, 12.0, L / 2.0, 100.0 - (1.0 - al) * 6.0, HUD_GOLD)
        title(banner.text, 30.0, L / 2.0, 128.0)
    }
    x.restore()
    if (st == 1 && cd <= 0.0 && hint > 0.0) {
        x.save()
        x.alpha = clamp(hint, 0.0, 1.0) * (0.7 + 0.3 * sin(clock * 5.0))
        for (h2 in 0 until 2) {
            val hx = if (h2 == 0) L * 0.14 else L * 0.64
            val name = HINT_NAMES[(if (coarse) 0 else 2) + h2]
            x.setFont(12.0)
            val w = x.measureText(fmt(name)) + 28.0
            glass(hx - w / 2.0, 311.0, w, 26.0, 13.0, 0.85)
            label(name, 12.0, hx, 324.0, WHITE)
        }
        x.restore()
    }
}

fun toastUI() {
    if (toast.life <= 0.0) return
    val k = toast.life / toast.max
    val inn = clamp((1.0 - k) * 8.0, 0.0, 1.0)
    val out = clamp(k * 5.0, 0.0, 1.0)
    val yy = if (st == 1) 62.0 else if (st == 4 || st == 6 || st == 7) 290.0 else 24.0
    x.save()
    x.alpha = min(inn, out)
    x.translate(0.0, (1.0 - easeOut(inn)) * -10.0)
    x.setFont(15.0)
    val w = x.measureText(fmt(toast.text)) + 36.0
    glass(L / 2.0 - w / 2.0, yy - 15.0, w, 30.0, 15.0, 0.92)
    label(toast.text, 15.0, L / 2.0, yy + 1.0, WHITE)
    x.restore()
}

fun countdown() {
    x.fillStyle = rgba(10, 5, 35, 0.28)
    x.fillRect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
    val n = ceil(cd).toInt()
    val f = n - cd
    val s = 1.5 - 0.5 * easeOut(f)
    x.save()
    x.alpha = 1.0 - ease(clamp((f - 0.6) / 0.4, 0.0, 1.0))
    x.translate(L / 2.0, 160.0)
    x.scale(s, s)
    label(n.toString(), 96.0, 0.0, 0.0, WHITE)
    x.restore()
    label("GET READY", 16.0, L / 2.0, 96.0, HUD_GOLD)
}
