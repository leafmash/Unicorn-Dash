package com.imora.unicorndash

import kotlin.math.ceil

var backupRequest: ((Boolean) -> Unit)? = null

fun nextTargetZone(): Int {
    if (li < CFG_LEVELS - 1) return zi
    if (zoneOpen(zi + 1)) return zi + 1
    return -1
}

fun nextTargetLevel(): Int = if (li < CFG_LEVELS - 1) li + 1 else 0

fun setOpt(k: String, v: Boolean) {
    when (k) {
        "music" -> opt.music = v
        "sfx" -> opt.sfx = v
        "vib" -> opt.vib = v
        "ghost" -> opt.ghost = v
    }
    Audio.applyOptions()
    save()
}

fun setLang(v: String) {
    opt.lang = v
    save()
}

private fun toZones(mode0: String, page: Int) {
    zmode = mode0
    zpage = page
    zoff = 0.0
    go(6)
}

private fun resetProgress() {
    best = 0
    bank = 0
    hearts = 0
    skin = 0
    mp = IntArray(3)
    md = IntArray(3)
    stats = Stats()
    own = IntArray(SK.size) { if (it == 0) 1 else 0 }
    ownT = IntArray(TR.size) { if (it == 0) 1 else 0 }
    ownH = IntArray(HR.size) { if (it == 0) 1 else 0 }
    ownP = IntArray(PT.size) { if (it == 0) 1 else 0 }
    ownS = IntArray(SKL.size) { if (it == 0) 1 else 0 }
    trailSel = 0
    hornSel = 0
    petSel = 0
    skillSel = 0
    xp = 0
    ach = IntArray(64)
    lb = Array(ZN.size) { ArrayList<LbEntry>() }
    gh.clear()
    spinDay = 0
    dcDone = 0
    dcBest = 0
    dcWins = 0
    dcRule = 0
    dcStreak = 0
    spinning = false
    spinIdx = -1
    prog = Array(ZN.size) { IntArray(CFG_LEVELS) }
    eb = IntArray(ZN.size)
    zi = 0
    setZone(0)
    streak = 1
    confirmAt = 0.0
    save()
    say("Progress reset")
    snd("deny")
}

private fun buy() {
    val tab = shopTab
    val i = shopSel
    val own = tabOwn(tab)
    val zone = itemZone(tab, i)
    val hc = itemHc(tab, i)
    val cost = itemCost(tab, i)
    if (own[i] != 0) {
        if (tabSel(tab) != i) {
            setSel(tab, i)
            snd("click")
        }
    } else if (zone >= 0) {
        say(T("Clear {0} levels in {1}  ({2}/{0})", CFG_NEED, zn(zone), cleared(zone)))
        snd("deny")
    } else if (if (hc > 0) hearts >= hc else bank >= cost) {
        if (hc > 0) hearts -= hc else bank -= cost
        own[i] = 1
        setSel(tab, i)
        snd("buy")
        say(T("{0} unlocked", T(itemName(tab, i))))
    } else {
        say(if (hc > 0) "Not enough hearts" else "Not enough coins")
        snd("deny")
    }
    checkAch()
    save()
}

fun act(id: String) {
    if (gift != null && st == 0 && id != "claim") return
    if (st == 8 && unl >= 0 && (id == "next" || id == "restart" || id == "lvls")) {
        pendAct = id
        snd("unlock")
        go(9)
        return
    }
    val cardIdx = if (id.startsWith("card")) id.substring(4).toIntOrNull() else null
    if (cardIdx != null) {
        shopSel = cardIdx
        snd("click")
        return
    }
    val zcIdx = if (id.startsWith("zc")) id.substring(2).toIntOrNull() else null
    if (zcIdx != null) {
        val i = zcIdx
        if (!zoneOpen(i)) {
            say("Finish the previous zone first")
            snd("deny")
            return
        }
        snd("click")
        if (zmode == "adv") {
            zi = i
            setZone(i)
            go(7)
        } else {
            launch("end", i, 0)
        }
        return
    }
    val lvIdx = if (id.startsWith("lv")) id.substring(2).toIntOrNull() else null
    if (lvIdx != null) {
        val i = lvIdx
        if (!lvlOpen(zi, i)) {
            say("Finish the previous level first")
            snd("deny")
            return
        }
        snd("click")
        launch("adv", zi, i)
        return
    }
    when (id) {
        "adv" -> {
            snd("click")
            toZones("adv", lastZ / CFG_PER_PAGE)
        }
        "end" -> {
            snd("click")
            toZones("end", lastZ / CFG_PER_PAGE)
        }
        "shop" -> {
            snd("click")
            shopTab = 0
            shopSel = skin
            shopPage = skin / 6
            go(4)
        }
        "pet" -> if (lob.hop <= 0.0) {
            lob.hop = 0.75
            burst(L / 2.0 + 10.0, 190.0, 14, 330.0, 150.0)
            snd("pop", 2.0)
            buzz(10)
        }
        "settings" -> {
            snd("click")
            go(5)
        }
        "back" -> {
            snd("back")
            go(if (st == 7) 6 else if (st == 13) 5 else 0)
        }
        "mute" -> {
            val on = !(opt.music || opt.sfx)
            setOpt("music", on)
            setOpt("sfx", on)
            if (on) snd("click")
        }
        "revive" -> if (st == 14 && nowMs() - stAt > 450.0) reviveNow()
        "skip" -> if (st == 14 && nowMs() - stAt > 450.0) {
            snd("click")
            reviveSkip()
        }
        "pause" -> pause()
        "skill" -> if (st == 1) useSkill()
        "resume" -> {
            snd("click")
            go(1)
            cd = 3.0
            cdLast = 4
        }
        "restart" -> {
            snd("click")
            startRun()
        }
        "menu" -> {
            snd("back")
            toMenu()
        }
        "lvls" -> {
            snd("back")
            toLevels()
        }
        "daily" -> {
            snd("click")
            val c = dcfg()
            dRunHome = lastZ
            launch("daily", c.z, c.l)
        }
        "next" -> {
            snd("click")
            if (mode == "daily") {
                toMenu()
            } else {
                val nz = nextTargetZone()
                if (nz >= 0) launch("adv", nz, nextTargetLevel()) else toZones("adv", zi / CFG_PER_PAGE)
            }
        }
        "cont" -> {
            val a = pendAct
            unl = -1
            pendAct = ""
            st = 8
            act(a)
        }
        "claim" -> {
            gift = null
            snd("gift")
        }
        "tmusic" -> {
            setOpt("music", !opt.music)
            snd("click")
        }
        "tsfx" -> {
            setOpt("sfx", !opt.sfx)
            snd("click")
        }
        "awards" -> {
            snd("click")
            apage = 0
            go(10)
        }
        "board" -> {
            snd("click")
            lbz = zi
            go(11)
        }
        "spin" -> {
            snd("click")
            go(12)
        }
        "dospin" -> startSpin()
        "aprev", "anext" -> {
            val n = clampI(apage + (if (id == "anext") 1 else -1), 0, ceil(ACH.size / 8.0).toInt() - 1)
            if (n != apage) {
                apage = n
                snd("click")
            }
        }
        "lprev", "lnext" -> {
            lbz = (lbz + (if (id == "lnext") 1 else ZN.size - 1)) % ZN.size
            snd("click")
        }
        "tghost" -> {
            setOpt("ghost", !opt.ghost)
            snd("click")
        }
        "tvib" -> {
            setOpt("vib", !opt.vib)
            buzz(20)
            snd("click")
        }
        "buy" -> buy()
        "tab0", "tab1", "tab2", "tab3", "tab4" -> {
            shopTab = id.substring(3).toInt()
            shopSel = tabSel(shopTab)
            shopPage = shopSel / 6
            snd("click")
        }
        "sprev", "snext" -> {
            val n = clampI(shopPage + (if (id == "snext") 1 else -1), 0, ceil(tabCount(shopTab) / 6.0).toInt() - 1)
            if (n != shopPage) {
                shopPage = n
                shopSel = n * 6
                snd("click")
            }
        }
        "tlang" -> {
            setLang(if (opt.lang == "bn") "en" else "bn")
            snd("click")
        }
        "stats" -> {
            snd("click")
            go(13)
        }
        "export" -> {
            snd("click")
            backupRequest?.invoke(true)
        }
        "import" -> {
            snd("click")
            backupRequest?.invoke(false)
        }
        "reset" -> if (nowMs() - confirmAt < 3000.0) {
            resetProgress()
        } else {
            confirmAt = nowMs()
            snd("click")
        }
    }
}

fun importCode(code: String): Boolean {
    val o = readCode(code) ?: return false
    try {
        applySave(o)
    } catch (e: Exception) {
        return false
    }
    zi = lastZ
    setZone(lastZ)
    save()
    say(T("Progress imported"))
    snd("buy")
    return true
}
