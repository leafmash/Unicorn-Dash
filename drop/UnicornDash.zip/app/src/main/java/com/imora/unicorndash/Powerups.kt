package com.imora.unicorndash

import kotlin.math.cos
import kotlin.math.sin

fun drawPower(k: String, px: Double, py: Double, s: Double) {
    val h = puHue(k)
    x.halo(px, py, 30.0 * s, h, 100.0, 65.0, 0.6)
    x.save()
    x.translate(px, py)
    x.scale(s, s)
    x.lineCap = CAP_ROUND
    x.lineJoin = JOIN_ROUND
    x.lineWidth = 3.0
    x.strokeStyle = hsl(h, 100.0, 75.0)
    when (k) {
        "shield" -> {
            x.fillStyle = rgba(127, 227, 255, 0.25)
            x.beginPath()
            x.moveTo(0.0, -13.0)
            x.lineTo(11.0, -8.0)
            x.lineTo(9.0, 5.0)
            x.quadraticCurveTo(6.0, 12.0, 0.0, 15.0)
            x.quadraticCurveTo(-6.0, 12.0, -9.0, 5.0)
            x.lineTo(-11.0, -8.0)
            x.closePath()
            x.fill()
            x.stroke()
        }
        "magnet" -> {
            x.beginPath()
            x.moveTo(-9.0, 11.0)
            x.lineTo(-9.0, -2.0)
            x.arc(0.0, -2.0, 9.0, PI, 0.0)
            x.lineTo(9.0, 11.0)
            x.stroke()
            x.strokeStyle = hex(0xffffff)
            x.beginPath()
            x.moveTo(-9.0, 11.0)
            x.lineTo(-9.0, 6.0)
            x.moveTo(9.0, 11.0)
            x.lineTo(9.0, 6.0)
            x.stroke()
        }
        "coin2" -> {
            x.fillStyle = rgba(255, 210, 63, 0.92)
            x.beginPath()
            x.arc(0.0, 0.0, 12.0, 0.0, 7.0)
            x.fill()
            x.stroke()
            label("x2", 11.0, 0.0, 1.0, hex(0x6a3d00), ALIGN_CENTER, rgba(255, 255, 255, 0.0))
        }
        "slow" -> {
            x.fillStyle = rgba(120, 170, 255, 0.25)
            x.beginPath()
            x.arc(0.0, 0.0, 12.0, 0.0, 7.0)
            x.fill()
            x.stroke()
            x.beginPath()
            x.moveTo(0.0, -7.0)
            x.lineTo(0.0, 0.0)
            x.lineTo(5.0, 3.0)
            x.stroke()
        }
        "mini" -> {
            x.fillStyle = rgba(255, 226, 122, 0.92)
            x.beginPath()
            x.moveTo(0.0, -13.0)
            x.lineTo(7.0, 7.0)
            x.lineTo(-7.0, 7.0)
            x.closePath()
            x.fill()
            x.stroke()
            x.fillStyle = hex(0xffffff)
            x.beginPath()
            x.arc(9.0, -8.0, 2.2, 0.0, 7.0)
            x.arc(-9.0, -3.0, 1.6, 0.0, 7.0)
            x.fill()
        }
        "life" -> {
            x.fillStyle = rgba(255, 90, 140, 0.96)
            heartPath(0.0, 1.0, 10.0)
            x.fill()
            x.stroke()
        }
        "rain" -> {
            x.fillStyle = rgba(150, 205, 255, 0.92)
            x.beginPath()
            x.arc(-6.0, -6.0, 6.0, 0.0, 7.0)
            x.arc(2.0, -9.0, 7.0, 0.0, 7.0)
            x.arc(9.0, -5.0, 5.0, 0.0, 7.0)
            x.fill()
            x.fillStyle = rgba(255, 210, 63, 0.95)
            for (i in 0 until 3) {
                x.beginPath()
                x.arc(-7.0 + i * 7.0, 4.0 + ((t * 18.0 + i * 5.0) % 9.0), 2.6, 0.0, 7.0)
                x.fill()
            }
        }
        "wings" -> {
            x.fillStyle = rgba(255, 255, 255, 0.92)
            val fl = sin(t * 8.0) * 0.25
            var sd = -1
            while (sd <= 1) {
                x.save()
                x.scale(sd.toDouble(), 1.0)
                x.rotate(-fl)
                x.beginPath()
                x.moveTo(1.0, 4.0)
                x.quadraticCurveTo(10.0, -14.0, 17.0, -6.0)
                x.quadraticCurveTo(14.0, -2.0, 15.0, 2.0)
                x.quadraticCurveTo(10.0, 0.0, 9.0, 5.0)
                x.quadraticCurveTo(5.0, 3.0, 1.0, 6.0)
                x.closePath()
                x.fill()
                x.stroke()
                x.restore()
                sd += 2
            }
        }
        "sx2" -> {
            x.fillStyle = rgba(168, 255, 140, 0.92)
            x.beginPath()
            x.moveTo(0.0, -14.0)
            x.lineTo(13.0, 0.0)
            x.lineTo(0.0, 14.0)
            x.lineTo(-13.0, 0.0)
            x.closePath()
            x.fill()
            x.stroke()
            label("x2", 10.0, 0.0, 1.0, hex(0x1d4d00), ALIGN_CENTER, rgba(255, 255, 255, 0.0))
        }
        else -> {
            x.rotate(sin(t * 2.0) * 0.2)
            x.fillStyle = rgba(255, 226, 122, 0.92)
            x.beginPath()
            for (i in 0 until 10) {
                val r = if (i % 2 == 1) 6.0 else 14.0
                val a = -PI / 2.0 + i * PI / 5.0
                x.lineTo(cos(a) * r, sin(a) * r)
            }
            x.closePath()
            x.fill()
            x.stroke()
        }
    }
    x.restore()
}

fun petDraw(kind: String, px: Double, py: Double, sc: Double, tt: Double, on: Boolean) {
    x.save()
    x.translate(px, py)
    x.scale(sc, sc)
    x.lineCap = CAP_ROUND
    x.lineJoin = JOIN_ROUND
    val fl = sin(tt * 14.0)
    if (kind == "fairy") {
        x.halo(0.0, 0.0, if (on) 46.0 else 20.0, 315.0, 100.0, if (on) 86.0 else 72.0, if (on) 0.85 else 0.35)
        if (on) {
            x.strokeStyle = rgba(255, 190, 240, 0.5 + 0.3 * sin(tt * 12.0))
            x.lineWidth = 2.0
            x.beginPath()
            x.arc(0.0, 0.0, 22.0 + 4.0 * sin(tt * 12.0), 0.0, 7.0)
            x.stroke()
        }
        x.fillStyle = rgba(255, 255, 255, 0.88)
        for (i in 0 until 2) {
            x.save()
            x.translate(-1.0, -2.0)
            x.rotate(-0.7 + i * 0.55 + fl * 0.35)
            x.beginPath()
            x.ellipse(-8.0, 0.0, 9.0, 3.6, 0.0, 0.0, 7.0)
            x.fill()
            x.restore()
        }
        x.fillStyle = hex(0xffd0f4)
        x.beginPath()
        x.arc(0.0, 0.0, 5.5, 0.0, 7.0)
        x.fill()
        x.fillStyle = hex(0xffffff)
        x.beginPath()
        x.arc(2.0, -1.5, 1.6, 0.0, 7.0)
        x.fill()
    } else if (kind == "dragon") {
        x.lineWidth = 1.6
        x.strokeStyle = hex(0x3aa874)
        x.save()
        x.translate(-2.0, -5.0)
        x.rotate(-0.5 + fl * 0.5)
        x.fillStyle = hex(0xb9f5d2)
        x.beginPath()
        x.ellipse(-7.0, -2.0, 9.0, 4.0, 0.0, 0.0, 7.0)
        x.fill()
        x.stroke()
        x.restore()
        x.strokeStyle = hex(0x5cc995)
        x.lineWidth = 3.0
        x.beginPath()
        x.moveTo(-8.0, 4.0)
        x.quadraticCurveTo(-17.0, 9.0, -20.0, 1.0 + fl * 2.0)
        x.stroke()
        x.lineWidth = 1.6
        x.strokeStyle = hex(0x3aa874)
        x.fillStyle = hex(0x7fe0a8)
        x.beginPath()
        x.ellipse(0.0, 2.0, 9.0, 7.0, 0.0, 0.0, 7.0)
        x.fill()
        x.stroke()
        x.beginPath()
        x.arc(8.0, -3.0, 5.5, 0.0, 7.0)
        x.fill()
        x.stroke()
        x.fillStyle = hex(0xffe27a)
        x.beginPath()
        x.moveTo(7.0, -8.0)
        x.lineTo(9.0, -13.0)
        x.lineTo(11.0, -8.0)
        x.closePath()
        x.fill()
        x.fillStyle = hex(0x2a1650)
        x.beginPath()
        x.arc(10.0, -4.0, 1.3, 0.0, 7.0)
        x.fill()
    } else if (kind == "cat") {
        x.translate(0.0, -9.0)
        val rn = sin(tt * 18.0)
        x.strokeStyle = hex(0xe0a468)
        x.lineWidth = 3.0
        x.beginPath()
        x.moveTo(-9.0, -1.0)
        x.quadraticCurveTo(-17.0, -4.0 + rn * 2.0, -15.0, -13.0)
        x.stroke()
        x.fillStyle = hex(0xffcf9c)
        x.beginPath()
        x.ellipse(-4.0 + rn * 2.5, 7.0, 3.2, 2.0, 0.0, 0.0, 7.0)
        x.ellipse(5.0 - rn * 2.5, 7.0, 3.2, 2.0, 0.0, 0.0, 7.0)
        x.fill()
        x.beginPath()
        x.ellipse(0.0, 0.0, 10.0, 7.0, 0.0, 0.0, 7.0)
        x.fill()
        x.beginPath()
        x.arc(9.0, -6.0, 6.0, 0.0, 7.0)
        x.fill()
        x.beginPath()
        x.moveTo(4.5, -10.0)
        x.lineTo(5.5, -16.0)
        x.lineTo(9.0, -11.5)
        x.moveTo(9.0, -11.5)
        x.lineTo(13.0, -16.0)
        x.lineTo(14.0, -9.5)
        x.fill()
        x.fillStyle = hex(0x2a1650)
        x.beginPath()
        x.arc(11.0, -7.0, 1.2, 0.0, 7.0)
        x.arc(7.0, -7.0, 1.2, 0.0, 7.0)
        x.fill()
        x.fillStyle = hex(0xff8aa8)
        x.beginPath()
        x.arc(9.5, -4.5, 1.0, 0.0, 7.0)
        x.fill()
    } else if (kind == "phoenix") {
        x.halo(0.0, 0.0, 34.0, 20.0, 100.0, 60.0, 0.5)
        x.lineWidth = 3.0
        for (i in 0 until 3) {
            x.strokeStyle = hsl(8.0 + i * 20.0, 100.0, 56.0)
            x.beginPath()
            x.moveTo(-6.0, 2.0)
            x.quadraticCurveTo(-16.0, 3.0 + i * 4.0 + fl * 2.0, -26.0, 7.0 + i * 6.0 + fl * 3.0)
            x.stroke()
        }
        x.save()
        x.translate(-1.0, -3.0)
        x.rotate(-0.6 + fl * 0.55)
        x.fillStyle = hex(0xffb347)
        x.beginPath()
        x.ellipse(-8.0, -2.0, 11.0, 5.0, 0.0, 0.0, 7.0)
        x.fill()
        x.restore()
        x.fillStyle = hex(0xff7a3d)
        x.beginPath()
        x.ellipse(0.0, 2.0, 8.0, 6.0, 0.0, 0.0, 7.0)
        x.fill()
        x.fillStyle = hex(0xff9a4d)
        x.beginPath()
        x.arc(7.0, -3.0, 4.6, 0.0, 7.0)
        x.fill()
        x.fillStyle = hex(0xffe27a)
        x.beginPath()
        x.moveTo(11.0, -4.0)
        x.lineTo(15.0, -2.5)
        x.lineTo(11.0, -1.0)
        x.closePath()
        x.fill()
        x.beginPath()
        x.moveTo(5.0, -7.0)
        x.lineTo(6.0, -12.0)
        x.lineTo(8.5, -7.0)
        x.closePath()
        x.fill()
        x.fillStyle = hex(0x2a1650)
        x.beginPath()
        x.arc(8.0, -4.0, 1.1, 0.0, 7.0)
        x.fill()
    }
    x.restore()
}

fun skillIcon(k: String, px: Double, py: Double, sc: Double) {
    x.save()
    x.translate(px, py)
    x.scale(sc, sc)
    x.lineCap = CAP_ROUND
    x.lineJoin = JOIN_ROUND
    x.lineWidth = 2.4
    x.strokeStyle = hex(0xffffff)
    when (k) {
        "dash" -> {
            x.fillStyle = hex(0xffe27a)
            x.beginPath()
            for (i in 0 until 10) {
                val r = if (i % 2 == 1) 5.0 else 12.0
                val a = -PI / 2.0 + i * PI / 5.0
                x.lineTo(cos(a) * r, sin(a) * r)
            }
            x.closePath()
            x.fill()
            x.stroke()
        }
        "blast" -> {
            x.fillStyle = hex(0xffd24a)
            x.beginPath()
            x.arc(0.0, 0.0, 6.0, 0.0, 7.0)
            x.fill()
            x.stroke()
            x.beginPath()
            for (i in 0 until 8) {
                val a = i * PI / 4.0
                x.moveTo(cos(a) * 9.0, sin(a) * 9.0)
                x.lineTo(cos(a) * 13.0, sin(a) * 13.0)
            }
            x.stroke()
        }
        "candy" -> {
            x.fillStyle = hex(0xff9bd0)
            x.beginPath()
            x.arc(0.0, 0.0, 6.5, 0.0, 7.0)
            x.fill()
            x.stroke()
            x.beginPath()
            x.moveTo(-6.5, 0.0)
            x.lineTo(-13.0, -5.0)
            x.lineTo(-13.0, 5.0)
            x.closePath()
            x.moveTo(6.5, 0.0)
            x.lineTo(13.0, -5.0)
            x.lineTo(13.0, 5.0)
            x.closePath()
            x.stroke()
        }
        "freeze" -> {
            x.strokeStyle = hex(0xbfeaff)
            x.beginPath()
            for (i in 0 until 3) {
                val a = i * PI / 3.0
                x.moveTo(cos(a) * 12.0, sin(a) * 12.0)
                x.lineTo(-cos(a) * 12.0, -sin(a) * 12.0)
            }
            x.stroke()
        }
        "warp" -> {
            x.strokeStyle = hex(0xd9b8ff)
            x.beginPath()
            x.moveTo(-10.0, -8.0)
            x.lineTo(-2.0, 0.0)
            x.lineTo(-10.0, 8.0)
            x.moveTo(1.0, -8.0)
            x.lineTo(9.0, 0.0)
            x.lineTo(1.0, 8.0)
            x.stroke()
        }
        "aura" -> {
            x.fillStyle = rgba(127, 255, 200, 0.4)
            x.strokeStyle = hex(0xa9ffe3)
            x.beginPath()
            x.moveTo(0.0, -13.0)
            x.lineTo(11.0, -8.0)
            x.lineTo(9.0, 5.0)
            x.quadraticCurveTo(6.0, 12.0, 0.0, 15.0)
            x.quadraticCurveTo(-6.0, 12.0, -9.0, 5.0)
            x.lineTo(-11.0, -8.0)
            x.closePath()
            x.fill()
            x.stroke()
        }
        "fire" -> {
            x.fillStyle = hex(0xff8a3c)
            x.strokeStyle = hex(0xffe0a0)
            x.beginPath()
            x.moveTo(0.0, -13.0)
            x.quadraticCurveTo(10.0, -3.0, 7.0, 6.0)
            x.quadraticCurveTo(4.0, 13.0, 0.0, 12.0)
            x.quadraticCurveTo(-8.0, 12.0, -8.0, 3.0)
            x.quadraticCurveTo(-8.0, -3.0, -2.0, -6.0)
            x.quadraticCurveTo(-2.0, -10.0, 0.0, -13.0)
            x.closePath()
            x.fill()
            x.stroke()
        }
        else -> {
            x.save()
            x.beginPath()
            x.arc(0.0, 0.0, 11.0, 0.0, 7.0)
            x.clip()
            x.beginPath()
            x.rect(-13.0, -13.0, 26.0, 26.0)
            x.moveTo(13.0, -2.0)
            x.arc(5.0, -2.0, 8.0, 0.0, 7.0)
            x.fillStyle = hex(0xe6ebff)
            x.fill(true)
            x.restore()
        }
    }
    x.restore()
}
