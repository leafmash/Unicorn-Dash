package com.imora.unicorndash

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun ScreenHeader(title: String, modifier: Modifier = Modifier, trailing: @Composable () -> Unit = {}) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RoundBtn(40.dp, onClick = { UiBridge.fire("back") }) { BackIcon(22.dp) }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { GradText(title, 26f) }
        Box(Modifier.widthIn(min = 40.dp), contentAlignment = Alignment.CenterEnd) { trailing() }
    }
}

@Composable
fun DimBackdrop(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xCC140A33), Color(0xE61A0E3D))))) { content() }
}

@Composable
fun SettingsScreen(s: Snap) {
    DimBackdrop {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScreenHeader("SETTINGS", Modifier.enter(0))
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Glass(Modifier.weight(1f).fillMaxSize().enter(1), 24.dp) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        ToggleRow("Music", s.music) { UiBridge.fire("tmusic") }
                        ToggleRow("Sound effects", s.sfx) { UiBridge.fire("tsfx") }
                        ToggleRow("Vibration", s.vib) { UiBridge.fire("tvib") }
                        ToggleRow("Ghost of your best run", s.ghost) { UiBridge.fire("tghost") }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .pressable(scaleTo = 0.97f) { UiBridge.fire("tlang") }
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x14FFFFFF))
                                .padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Tx("Language", 14f, weight = FontWeight.Bold)
                            Box(
                                Modifier.clip(RoundedCornerShape(14.dp)).background(PrimaryBrush).padding(horizontal = 14.dp, vertical = 5.dp)
                            ) { Tx(if (s.lang == "bn") "বাংলা" else "English", 13f) }
                        }
                    }
                }
                Glass(Modifier.width(190.dp).fillMaxSize().enter(2), 24.dp) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        GButton("STATS", Modifier.fillMaxWidth(), Kind.Soft, 38.dp, 13f) { UiBridge.fire("stats") }
                        GButton("EXPORT", Modifier.fillMaxWidth(), Kind.Soft, 38.dp, 13f) { UiBridge.fire("export") }
                        GButton("IMPORT", Modifier.fillMaxWidth(), Kind.Soft, 38.dp, 13f) { UiBridge.fire("import") }
                        Spacer(Modifier.weight(1f))
                        GButton(
                            if (s.confirmReset) "TAP AGAIN TO CONFIRM" else "RESET PROGRESS",
                            Modifier.fillMaxWidth(),
                            if (s.confirmReset) Kind.Danger else Kind.Soft,
                            38.dp,
                            11.5f
                        ) { UiBridge.fire("reset") }
                    }
                }
            }
        }
    }
}

private val STAT_TONES = arrayOf(
    Color.White, Pal.Lilac, Color.White, Pal.Cyan, Pal.Sun, Pal.Cyan, Color.White, Pal.Rose,
    Color.White, Color.White, Pal.Rose, Pal.Sun, Pal.Sun, Color.White, Color.White, Pal.Mint
)

@Composable
fun StatsScreen(s: Snap) {
    DimBackdrop {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ScreenHeader("STATISTICS", Modifier.enter(0))
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (r in 0 until 4) {
                    Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (c in 0 until 4) {
                            val i = r * 4 + c
                            if (i < s.statsList.size) {
                                val st2 = s.statsList[i]
                                Stat(st2.head, st2.value, STAT_TONES[st2.tone], Modifier.weight(1f).fillMaxSize().enter(i / 2))
                            } else {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AwardsScreen(s: Snap) {
    DimBackdrop {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScreenHeader("AWARDS", Modifier.enter(0)) {
                Pill(height = 30.dp) { Tx("${s.achDone}/${s.achTotal}", 12f, color = Pal.Sun) }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(s.achs.size) { i ->
                    val a = s.achs[i]
                    val shape = RoundedCornerShape(16.dp)
                    Column(
                        Modifier
                            .clip(shape)
                            .background(if (a.done) Color(0x247DFFD4) else Color(0x17FFFFFF))
                            .border(1.3.dp, if (a.done) Pal.Mint else Color(0x4DFFFFFF), shape)
                            .padding(horizontal = 12.dp, vertical = 9.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Tx(a.name, 12.5f, Modifier.weight(1f), color = if (a.done) Color(0xFFB8FFE6) else Color.White)
                            if (a.done) {
                                CheckIcon(14.dp, Pal.Mint)
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CoinIcon(12.dp)
                                    Spacer(Modifier.width(3.dp))
                                    Tx(a.reward.toString(), 11f, color = Pal.Sun)
                                }
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        Tx(a.desc, 10f, color = Pal.Lilac, weight = FontWeight.Bold, shadow = false)
                        Spacer(Modifier.height(6.dp))
                        Bar(a.value.toFloat() / a.max, Modifier.fillMaxWidth(), 5.dp, if (a.done) Brush.horizontalGradient(listOf(Pal.Mint, Pal.Mint)) else PrimaryBrush)
                    }
                }
            }
        }
    }
}

@Composable
fun BoardScreen(s: Snap) {
    DimBackdrop {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScreenHeader("LEADERBOARD", Modifier.enter(0))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                RoundBtn(34.dp, onClick = { UiBridge.fire("lprev") }) { ArrowIcon(18.dp, true) }
                Column(Modifier.width(220.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Tx(s.lbName, 18f)
                    Tx("ENDLESS  -  TOP 10", 10.5f, color = Pal.Lilac, shadow = false)
                }
                RoundBtn(34.dp, onClick = { UiBridge.fire("lnext") }) { ArrowIcon(18.dp, false) }
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Glass(Modifier.widthIn(max = 340.dp).fillMaxSize().enter(1), 22.dp) {
                    if (!s.lbOpen) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                LockIcon(28.dp, Pal.Dim)
                                Tx("Locked", 16f, color = Pal.Dim)
                            }
                        }
                    } else if (s.board.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Tx("No runs yet", 15f, color = Pal.Dim) }
                    } else {
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 8.dp)) {
                            items(s.board.size) { i ->
                                val e = s.board[i]
                                val col = if (i == 0) Color(0xFFFFD23F) else if (i == 1) Color(0xFFE4E8F4) else if (i == 2) Color(0xFFF0B27A) else Color.White
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Tx("#${i + 1}", 13f, Modifier.width(44.dp), color = col)
                                    Tx(e.score.toString(), 15f, Modifier.weight(1f), color = col)
                                    Tx(e.date, 11f, color = Color(0xFFBFB2EC), shadow = false)
                                }
                            }
                        }
                    }
                }
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Tx(if (s.ghostSaved) "Ghost saved" else "No ghost yet", 10.5f, color = Color(0xFFBFB2EC), shadow = false)
            }
        }
    }
}

@Composable
fun SpinScreen(s: Snap) {
    val segDeg = 360f / SPIN.size
    val angle by produceState(Math.toDegrees(s.spinA).toFloat(), s.spinning, s.spinT0) {
        if (!s.spinning) {
            value = Math.toDegrees(s.spinA).toFloat()
        } else {
            while (true) {
                withFrameNanos {
                    val k = ((nowMs() - s.spinT0) / 4200.0).coerceIn(0.0, 1.0)
                    val a = s.spinFrom + (s.spinTo - s.spinFrom) * (1.0 - Math.pow(1.0 - k, 4.0))
                    value = Math.toDegrees(a).toFloat()
                }
            }
        }
    }
    val canSpin = s.spinReady && !s.spinning
    val msg = if (s.spinning) "Good luck!"
    else if (s.spinReady) "Your free spin is ready"
    else if (s.spinWon && s.spinIdx >= 0) T(if (SPIN[s.spinIdx].hearts) "You won {0} hearts  -  come back tomorrow" else "You won {0} coins  -  come back tomorrow", SPIN[s.spinIdx].amount)
    else "Come back tomorrow for another spin"
    DimBackdrop {
        Row(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                RoundBtn(40.dp, onClick = { UiBridge.fire("back") }) { BackIcon(22.dp) }
            }
            Box(Modifier.size(240.dp).enter(0), contentAlignment = Alignment.Center) {
                PulseGlow(Pal.Purple, Modifier, 130.dp)
                Box(Modifier.size(214.dp).graphicsLayer { rotationZ = angle }, contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        for (i in SPIN.indices) {
                            drawArc(
                                hueColor((i * 45 + 280) % 360.0, 80.0, if (i % 2 == 1) 60.0 else 52.0),
                                -90f + i * segDeg,
                                segDeg,
                                true
                            )
                            drawArc(Color(0xB3FFFFFF), -90f + i * segDeg, segDeg, true, style = Stroke(1.5.dp.toPx()))
                        }
                        drawCircle(Color(0xD9FFFFFF), size.minDimension / 2f - 2.dp.toPx(), center, style = Stroke(4.dp.toPx()))
                    }
                    for (i in SPIN.indices) {
                        Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = (i + 0.5f) * segDeg }) {
                            Box(Modifier.align(Alignment.TopCenter).padding(top = 18.dp)) {
                                if (SPIN[i].hearts) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        HeartIcon(16.dp)
                                        Tx("x${SPIN[i].amount}", 13f)
                                    }
                                } else {
                                    Tx(SPIN[i].amount.toString(), 15f)
                                }
                            }
                        }
                    }
                }
                Box(Modifier.size(34.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color.White), contentAlignment = Alignment.Center) { CoinIcon(20.dp) }
                Canvas(Modifier.size(28.dp, 30.dp).align(Alignment.TopCenter)) {
                    val p = Path()
                    p.moveTo(0f, 0f)
                    p.lineTo(size.width, 0f)
                    p.lineTo(size.width / 2f, size.height)
                    p.close()
                    drawPath(p, Pal.Sun)
                    drawPath(p, Color(0xFFB87400), style = Stroke(1.5.dp.toPx()))
                }
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                GradText("DAILY SPIN", 24f)
                Tx(msg, 12.5f, Modifier.padding(horizontal = 8.dp), color = Pal.Sun, align = TextAlign.Center, maxLines = 3)
                GButton("SPIN", Modifier.width(150.dp), if (canSpin) Kind.Gold else Kind.Off, 46.dp, 18f) { UiBridge.fire("dospin") }
            }
        }
    }
}
