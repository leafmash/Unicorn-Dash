package com.imora.unicorndash

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

private val TAB_NAMES = arrayOf("UNICORNS", "TRAILS", "HORNS", "PETS", "SKILLS")

@Composable
fun ShopCard(tab: Int, i: Int, it: UItem, selected: Boolean) {
    val lift by animateDpAsState(if (selected) (-6).dp else 0.dp, spring(dampingRatio = 0.55f, stiffness = 500f), label = "lift")
    val shape = RoundedCornerShape(18.dp)
    val locked = !it.owned && it.lockZone.isNotEmpty()
    Box(
        Modifier
            .offset(y = lift)
            .width(92.dp)
            .fillMaxHeight()
            .heightIn(min = 150.dp, max = 210.dp)
            .pressable(scaleTo = 0.95f) { UiBridge.fire("card$i") }
            .clip(shape)
            .background(if (selected) Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x26FFFFFF))) else Brush.verticalGradient(listOf(Color(0x1FFFFFFF), Color(0x0FFFFFFF))))
            .border(if (it.equipped) 2.4.dp else 1.4.dp, if (it.equipped) Pal.Mint else if (selected) Color(0xCCFFFFFF) else Color(0x40FFFFFF), shape)
    ) {
        Column(Modifier.fillMaxSize().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Tx(it.name, 11.5f, Modifier.padding(horizontal = 4.dp), align = TextAlign.Center)
            PreviewImage("s:$tab:$i", Modifier.weight(1f).fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp).alpha(if (it.owned) 1f else 0.55f))
            Spacer(Modifier.height(4.dp))
            when {
                it.equipped -> Tx("EQUIPPED", 10f, color = Pal.Mint)
                it.owned -> Tx("OWNED", 10.5f, color = Color(0xFFB8FFE6))
                it.lockZone.isNotEmpty() -> Tx(it.lockZone, 9.5f, Modifier.padding(horizontal = 4.dp), color = Pal.Rose, align = TextAlign.Center, maxLines = 2)
                it.hearts > 0 -> Row(verticalAlignment = Alignment.CenterVertically) {
                    HeartIcon(14.dp)
                    Spacer(Modifier.width(4.dp))
                    Tx(it.hearts.toString(), 12f, color = Color(0xFFFFD0E0))
                }
                else -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CoinIcon(14.dp)
                    Spacer(Modifier.width(4.dp))
                    Tx(it.coins.toString(), 12f, color = Pal.Sun)
                }
            }
        }
        if (locked) {
            Box(Modifier.fillMaxSize().background(Color(0x73140A33)), contentAlignment = Alignment.Center) { LockIcon(24.dp) }
        }
    }
}

@Composable
fun ShopScreen(s: Snap) {
    val ls = rememberLazyListState()
    LaunchedEffect(s.shopTab) { ls.scrollToItem(0) }
    Row(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Column(Modifier.weight(0.4f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
            RoundBtn(40.dp, onClick = { UiBridge.fire("back") }) { BackIcon(22.dp) }
            if (s.shopNote.isNotEmpty()) {
                Glass(Modifier.padding(bottom = 4.dp).enter(2), 16.dp) {
                    Tx(s.shopNote, 11f, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Pal.Lilac, weight = FontWeight.Bold, maxLines = 3, shadow = false)
                }
            }
        }
        Glass(Modifier.weight(0.6f).fillMaxHeight().enter(0), 26.dp) {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    GradText("SHOP", 24f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HeartPill(s.hearts, height = 28.dp)
                        CoinPill(s.bank, height = 28.dp)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    for (k in 0 until 5) {
                        val on = k == s.shopTab
                        Box(
                            Modifier
                                .weight(1f)
                                .height(28.dp)
                                .pressable(scaleTo = 0.94f) { UiBridge.fire("tab$k") }
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (on) PrimaryBrush else Brush.verticalGradient(listOf(Color(0x24FFFFFF), Color(0x14FFFFFF))))
                                .border(1.dp, if (on) Color(0xCCFFFFFF) else Color(0x40FFFFFF), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) { Tx(TAB_NAMES[k], 10f) }
                    }
                }
                LazyRow(
                    state = ls,
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    items(s.items.size) { i ->
                        ShopCard(s.shopTab, i, s.items[i], i == s.shopSel)
                    }
                }
                val cur = if (s.shopSel < s.items.size) s.items[s.shopSel] else null
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tx(if (cur != null) cur.name else "", 15f, Modifier.weight(1f))
                    if (cur != null) {
                        val locked = !cur.owned && cur.lockZone.isNotEmpty()
                        if (cur.owned) {
                            GButton(if (cur.equipped) "EQUIPPED" else "EQUIP", Modifier.width(150.dp), if (cur.equipped) Kind.Off else Kind.Primary, 40.dp, 15f) { UiBridge.fire("buy") }
                        } else if (locked) {
                            GButton("LOCKED", Modifier.width(150.dp), Kind.Off, 40.dp, 15f) { UiBridge.fire("buy") }
                        } else if (cur.hearts > 0) {
                            GButton(T("BUY {0}", cur.hearts), Modifier.width(150.dp), Kind.Danger, 40.dp, 15f, heart = true) { UiBridge.fire("buy") }
                        } else {
                            GButton(T("BUY {0}", cur.coins), Modifier.width(150.dp), Kind.Gold, 40.dp, 15f, coin = true) { UiBridge.fire("buy") }
                        }
                    }
                }
            }
        }
    }
}
