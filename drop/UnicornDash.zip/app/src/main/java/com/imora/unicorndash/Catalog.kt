package com.imora.unicorndash

import kotlin.math.max

const val G = 290.0
const val STEP = 1.0 / 120.0
const val RISE_HELD = 1500.0
const val RISE_FREE = 2900.0
const val FALL = 2800.0

const val CFG_LEVELS = 10
const val CFG_NEED = 7
const val CFG_SPAN = 18
const val CFG_PER_PAGE = 6
const val CFG_COIN_PCT = 0.8

enum class OT { crystal, spin, fire, pit, pillar, ice, stormLow, stormHigh, wisp, bird, spikes, wall, swing, laser, boulder }

fun coinCount(t: OT): Int = when (t) {
    OT.crystal -> 5
    OT.spin -> 5
    OT.fire -> 5
    OT.pit -> 5
    OT.pillar -> 5
    OT.ice -> 5
    OT.stormLow -> 3
    OT.stormHigh -> 3
    OT.wisp -> 3
    OT.bird -> 3
    OT.spikes -> 5
    OT.wall -> 5
    OT.swing -> 3
    OT.laser -> 3
    OT.boulder -> 0
}

class ComboPart(val type: OT, val after: Double, val w: Int)

private fun cp(t: OT, a: Double, w: Int) = ComboPart(t, a, w)

val ECOMBOS: List<List<ComboPart>> = listOf(
    listOf(cp(OT.spikes, 0.0, 1), cp(OT.stormLow, 1.0, 1)),
    listOf(cp(OT.wall, 0.0, 1), cp(OT.spikes, 1.05, 1)),
    listOf(cp(OT.boulder, 0.0, 1), cp(OT.crystal, 1.3, 1)),
    listOf(cp(OT.laser, 0.0, 1), cp(OT.crystal, 1.0, 1)),
    listOf(cp(OT.swing, 0.0, 1), cp(OT.spikes, 1.15, 1)),
    listOf(cp(OT.crystal, 0.0, 1), cp(OT.crystal, 0.85, 1), cp(OT.bird, 1.1, 1)),
    listOf(cp(OT.spikes, 0.0, 1), cp(OT.wall, 0.95, 1), cp(OT.laser, 1.1, 1))
)

val COMBOS: List<List<ComboPart>> = listOf(
    listOf(cp(OT.pit, 0.0, 1), cp(OT.crystal, 1.05, 1)),
    listOf(cp(OT.pillar, 0.0, 1), cp(OT.bird, 1.0, 1)),
    listOf(cp(OT.spin, 0.0, 1), cp(OT.spin, 0.9, 1), cp(OT.stormLow, 1.1, 1)),
    listOf(cp(OT.fire, 0.0, 1), cp(OT.bird, 1.0, 1), cp(OT.crystal, 1.1, 1)),
    listOf(cp(OT.stormHigh, 0.0, 1), cp(OT.pit, 1.1, 2)),
    listOf(cp(OT.ice, 0.0, 1), cp(OT.pillar, 1.0, 1)),
    listOf(cp(OT.bird, 0.0, 1), cp(OT.pit, 1.05, 1), cp(OT.spin, 1.0, 1))
)

class Skin(
    val name: String,
    val cost: Int,
    val zone: Int,
    val hc: Int,
    val body: Int,
    val leg: Int,
    val back: Int,
    val h0: Double,
    val st: Double,
    val horn: Double
)

val SK: Array<Skin> = arrayOf(
    Skin("Classic", 0, -1, 0, hex(0xf6efff), hex(0xe6dafa), hex(0xcdb8ee), 0.0, 44.0, 48.0),
    Skin("Sunny", 1200, -1, 0, hex(0xfff0c4), hex(0xffe2a0), hex(0xf3cd84), 0.0, 11.0, 30.0),
    Skin("Candy", 2500, -1, 0, hex(0xffd6ec), hex(0xffc2e2), hex(0xf0a8cf), 300.0, 10.0, 330.0),
    Skin("Frost", 4000, -1, 0, hex(0xd8f4ff), hex(0xbfe8fa), hex(0xa5d6ee), 170.0, 16.0, 190.0),
    Skin("Galaxy", 7500, -1, 0, hex(0x6a58c8), hex(0x5a49b4), hex(0x4a3a9c), 250.0, 22.0, 280.0),
    Skin("Aurora", 12000, -1, 0, hex(0xc9ffe9), hex(0xa9f0d2), hex(0x8addbd), 120.0, 36.0, 150.0),
    Skin("Ember", 0, 4, 0, hex(0xffd9c2), hex(0xffc2a0), hex(0xf0a47e), 0.0, 12.0, 15.0),
    Skin("Moonlit", 0, 16, 0, hex(0xdfe6ff), hex(0xc9d4f8), hex(0xaab8ec), 215.0, 14.0, 230.0),
    Skin("Rose", 0, -1, 10, hex(0xffd1dc), hex(0xffb3c6), hex(0xf08aa8), 345.0, 12.0, 350.0),
    Skin("Ruby", 0, -1, 25, hex(0xff9bb0), hex(0xf27a96), hex(0xd85a7c), 355.0, 8.0, 350.0)
)

class Trail(val name: String, val cost: Int, val zone: Int, val hc: Int, val c: Array<DoubleArray>?, val cycle: Boolean, val fx: String)

private fun tc(vararg v: Double) = doubleArrayOf(v[0], v[1], v[2])

val TR: Array<Trail> = arrayOf(
    Trail("Rainbow", 0, -1, 0, null, false, "dust"),
    Trail("Stardust", 1000, -1, 0, arrayOf(tc(48.0, 100.0, 70.0), tc(40.0, 100.0, 66.0), tc(54.0, 100.0, 78.0), tc(44.0, 100.0, 62.0), tc(50.0, 100.0, 74.0), tc(38.0, 100.0, 68.0)), false, "star"),
    Trail("Candy", 1800, -1, 0, arrayOf(tc(330.0, 95.0, 72.0), tc(0.0, 0.0, 98.0), tc(330.0, 95.0, 72.0), tc(0.0, 0.0, 98.0), tc(330.0, 95.0, 72.0), tc(0.0, 0.0, 98.0)), false, "heart"),
    Trail("Frost", 0, 3, 0, arrayOf(tc(190.0, 100.0, 85.0), tc(200.0, 90.0, 76.0), tc(210.0, 85.0, 68.0), tc(195.0, 100.0, 90.0), tc(205.0, 90.0, 72.0), tc(185.0, 100.0, 80.0)), false, "snow"),
    Trail("Flame", 0, 5, 0, arrayOf(tc(55.0, 100.0, 70.0), tc(40.0, 100.0, 60.0), tc(28.0, 100.0, 55.0), tc(16.0, 100.0, 52.0), tc(8.0, 100.0, 48.0), tc(0.0, 95.0, 42.0)), false, "ember"),
    Trail("Aurora", 3500, -1, 0, null, true, "star"),
    Trail("Neon", 0, 9, 0, arrayOf(tc(300.0, 100.0, 65.0), tc(320.0, 100.0, 60.0), tc(180.0, 100.0, 60.0), tc(200.0, 100.0, 62.0), tc(280.0, 100.0, 66.0), tc(160.0, 100.0, 58.0)), false, "spark"),
    Trail("Golden", 0, 17, 0, arrayOf(tc(48.0, 100.0, 72.0), tc(45.0, 100.0, 64.0), tc(50.0, 100.0, 80.0), tc(42.0, 100.0, 58.0), tc(46.0, 100.0, 70.0), tc(52.0, 100.0, 76.0)), false, "gold"),
    Trail("Love", 0, -1, 6, arrayOf(tc(345.0, 100.0, 72.0), tc(330.0, 100.0, 76.0), tc(350.0, 95.0, 68.0), tc(340.0, 100.0, 80.0), tc(355.0, 90.0, 70.0), tc(325.0, 100.0, 74.0)), false, "heart")
)

class Horn(val name: String, val cost: Int, val zone: Int, val hc: Int, val type: String, val hue: Double)

val HR: Array<Horn> = arrayOf(
    Horn("Golden", 0, -1, 0, "gold", 48.0),
    Horn("Candy Cane", 1300, -1, 0, "candy", 340.0),
    Horn("Flame", 1900, -1, 0, "flame", 20.0),
    Horn("Rainbow", 2600, -1, 0, "rainbow", 300.0),
    Horn("Crystal", 0, 6, 0, "crystal", 190.0),
    Horn("Starlight", 0, 2, 0, "star", 60.0),
    Horn("Heartbeat", 0, -1, 8, "heart", 340.0)
)

class Pet(val name: String, val cost: Int, val zone: Int, val kind: String, val desc: String)

val PT: Array<Pet> = arrayOf(
    Pet("None", 0, -1, "", ""),
    Pet("Fairy", 2500, -1, "fairy", "Power-ups last 50% longer"),
    Pet("Kitten", 3800, -1, "cat", "More hearts, +5 coins every 10 coins"),
    Pet("Dragon", 5500, -1, "dragon", "+20% score"),
    Pet("Phoenix", 0, 5, "phoenix", "Free revive, clears the path")
)

class Skill(val k: String, val name: String, val desc: String, val cost: Int, val zone: Int, val cd: Double, val dur: Double, val hue: Double)

val SKL: Array<Skill> = arrayOf(
    Skill("dash", "Rainbow Flash", "Brief invincible dash", 0, -1, 20.0, 0.5, 48.0),
    Skill("candy", "Candy Shower", "Short burst of coin rain", 1200, -1, 24.0, 0.0, 330.0),
    Skill("aura", "Aurora Shield", "Blocks one hit", 2000, -1, 30.0, 0.0, 150.0),
    Skill("moon", "Moon Leap", "Low gravity and extra jumps", 3500, -1, 32.0, 4.0, 225.0),
    Skill("freeze", "Time Freeze", "Slows the world down", 5500, -1, 38.0, 2.5, 195.0),
    Skill("fire", "Flame Breath", "Burns obstacles ahead", 8000, -1, 40.0, 1.2, 20.0),
    Skill("blast", "Sun Blast", "Destroys obstacles ahead", 11000, -1, 45.0, 0.0, 38.0),
    Skill("warp", "Star Warp", "Teleports you forward", 15000, -1, 50.0, 0.0, 270.0)
)

class Mission(val t: String, val k: String, val n: Int, val r: Int, val run: Boolean)

val MS: Array<Mission> = arrayOf(
    Mission("Collect 40 coins in one run", "rcoins", 40, 40, true),
    Mission("Score 600 in one run", "score", 600, 60, true),
    Mission("Dodge 40 obstacles today", "dodge", 40, 40, false),
    Mission("Double jump 25 times today", "dj", 25, 30, false),
    Mission("Collect 120 coins today", "coins", 120, 50, false),
    Mission("Play 5 runs today", "runs", 5, 30, false),
    Mission("Hit a x5 coin combo 3 times", "c5", 3, 40, false),
    Mission("Grab 4 power-ups today", "pw", 4, 35, false)
)

class SpinSeg(val amount: Int, val weight: Int, val hearts: Boolean)

val SPIN: Array<SpinSeg> = arrayOf(
    SpinSeg(20, 18, false), SpinSeg(1, 14, true), SpinSeg(50, 12, false), SpinSeg(2, 7, true), SpinSeg(30, 16, false),
    SpinSeg(100, 7, false), SpinSeg(40, 12, false), SpinSeg(3, 2, true), SpinSeg(60, 9, false), SpinSeg(300, 1, false)
)

class Rule(val key: String, val label: String)

fun ruleLabel(rule: String): String = when (rule) {
    "noduck" -> "NO DUCKING"
    "nodj" -> "NO DOUBLE JUMP"
    "sprint" -> "30 SECOND SPRINT"
    else -> ""
}

fun puHue(k: String): Double = when (k) {
    "life" -> 350.0
    "shield" -> 190.0
    "magnet" -> 340.0
    "star" -> 48.0
    "coin2" -> 50.0
    "slow" -> 215.0
    "mini" -> 285.0
    "rain" -> 160.0
    "wings" -> 255.0
    "sx2" -> 110.0
    else -> 48.0
}

fun xpNeed(n: Int): Int = 100 + 50 * (n - 1)

class LvInfo(val n: Int, val cur: Int, val need: Int)

fun lvOf(v0: Int): LvInfo {
    var v = v0
    var n = 1
    while (v >= xpNeed(n)) {
        v -= xpNeed(n)
        n++
    }
    return LvInfo(n, v, xpNeed(n))
}

fun maxI(a: Int, b: Int): Int = max(a, b)
