package com.imora.unicorndash

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun ZoneCard(i: Int, z: UZone, endless: Boolean, modifier: Modifier) {
    val shape = RoundedCornerShape(18.dp)
    val border = if (z.full) Pal.Gold else if (z.current && z.open) Color(0xCCFFFFFF) else if (z.open) Color(0x80FFFFFF) else Color(0x33FFFFFF)
    Column(
        modifier
            .pressable(scaleTo = 0.95f) { UiBridge.fire("zc$i") }
            .clip(shape)
            .background(if (z.open) Brush.verticalGradient(listOf(Color(0x30FFFFFF), Color(0x14FFFFFF))) else Brush.verticalGradient(listOf(Color(0x14FFFFFF), Color(0x0AFFFFFF))))
            .border(if (z.full) 2.dp else 1.3.dp, border, shape)
            .padding(7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(150f / 84f).clip(RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            PreviewImage("z:$i", Modifier.fillMaxSize())
            if (!z.open) {
                Box(Modifier.fillMaxSize().background(Color(0xA3140A33)), contentAlignment = Alignment.Center) { LockIcon(24.dp) }
            }
        }
        Spacer(Modifier.height(4.dp))
        Tx(z.name, 11.5f, color = if (z.open) Color.White else Pal.Dim, align = TextAlign.Center)
        Spacer(Modifier.height(2.dp))
        if (!z.open) {
            Tx("Locked", 10f, color = Pal.Dim, shadow = false)
        } else if (!endless) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StarIcon(13.dp, z.stars > 0)
                Spacer(Modifier.width(4.dp))
                Tx("${z.stars}/${CFG_LEVELS * 3}", 10.5f, color = Pal.Sun)
            }
        } else {
            Tx(T("BEST {0}", z.best), 10.5f, color = Pal.Lilac, shadow = false)
        }
    }
}

@Composable
fun PageDots(count: Int, cur: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        for (k in 0 until count) {
            val w by animateDpAsState(if (k == cur) 18.dp else 6.dp, spring(dampingRatio = 0.7f, stiffness = 500f), label = "dot")
            Box(
                Modifier
                    .height(6.dp)
                    .width(w)
                    .clip(CircleShape)
                    .background(if (k == cur) Color.White else Color(0x4DFFFFFF))
            )
        }
    }
}

@Composable
fun ZonesScreen(s: Snap) {
    val endless = s.zmode == "end"
    val pages = (s.zones.size + CFG_PER_PAGE - 1) / CFG_PER_PAGE
    val pager = rememberPagerState(initialPage = s.zpage.coerceIn(0, if (pages > 0) pages - 1 else 0)) { if (pages > 0) pages else 1 }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xB3140A33), Color(0xCC1A0E3D))))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().enter(0), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(40.dp, onClick = { UiBridge.fire("back") }) { BackIcon(22.dp) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    GradText(if (endless) "ENDLESS" else "ADVENTURE", 26f)
                    Tx(if (endless) "Pick a zone to run forever" else "Pick a zone", 11.5f, color = Color(0xFFE9DCFF), weight = FontWeight.Bold, shadow = false)
                }
                if (endless) {
                    CoinPill(s.bank, height = 30.dp)
                } else {
                    Pill(height = 30.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StarIcon(16.dp, true)
                            Spacer(Modifier.width(5.dp))
                            Tx("${s.stars}/${s.starsMax}", 12f, color = Pal.Sun)
                        }
                    }
                }
            }
            HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth(), pageSpacing = 14.dp) { page ->
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (r in 0 until 2) {
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            for (c in 0 until 3) {
                                val idx = page * CFG_PER_PAGE + r * 3 + c
                                if (idx < s.zones.size) {
                                    ZoneCard(idx, s.zones[idx], endless, Modifier.weight(1f).enter(r * 3 + c))
                                } else {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { PageDots(pages, pager.currentPage) }
        }
    }
}

@Composable
fun LevelButton(l: ULevel, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    val brush = when {
        !l.open -> Brush.verticalGradient(listOf(Color(0x1FFFFFFF), Color(0x0DFFFFFF)))
        l.boss -> DangerBrush
        l.stars > 0 -> PrimaryBrush
        else -> Brush.verticalGradient(listOf(Color(0x4DFFFFFF), Color(0x1FFFFFFF)))
    }
    Box(modifier.size(66.dp), contentAlignment = Alignment.Center) {
        if (l.next) PulseGlow(if (l.boss) Pal.Ruby else Pal.Pink, Modifier, 56.dp)
        Box(
            Modifier
                .size(66.dp)
                .pressable(scaleTo = 0.9f) { UiBridge.fire("lv${l.n - 1}") }
                .clip(shape)
                .background(brush)
                .border(1.6.dp, if (l.open) Color(0xBFFFFFFF) else Color(0x40FFFFFF), shape),
            contentAlignment = Alignment.Center
        ) {
            if (!l.open) {
                LockIcon(24.dp)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (l.boss) Tx("BOSS", 9.5f, color = Color(0xFFFFF3C4))
                    Tx(l.n.toString(), 24f)
                    Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                        for (k in 0 until 3) StarIcon(13.dp, k < l.stars)
                    }
                }
            }
        }
    }
}

@Composable
fun LevelsScreen(s: Snap) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xB3140A33), Color(0xCC1A0E3D))))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth().enter(0), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(40.dp, onClick = { UiBridge.fire("back") }) { BackIcon(22.dp) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    GradText(s.zoneName, 26f)
                }
                var total = 0
                for (l in s.levels) total += l.stars
                Pill(height = 30.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StarIcon(16.dp, true)
                        Spacer(Modifier.width(5.dp))
                        Tx("$total/${CFG_LEVELS * 3}", 12f, color = Pal.Sun)
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                for (r in 0 until 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        for (c in 0 until 5) {
                            val idx = r * 5 + c
                            if (idx < s.levels.size) LevelButton(s.levels[idx], Modifier.enter(idx))
                        }
                    }
                    if (r == 0) Spacer(Modifier.height(16.dp))
                }
                Spacer(Modifier.height(18.dp))
                Glass(Modifier.enter(10), 16.dp) {
                    Tx(
                        s.levelsNote,
                        12f,
                        Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
                        color = if (s.levelsNoteOk) Pal.Mint else Color(0xFFE9DCFF),
                        weight = FontWeight.Bold,
                        shadow = false
                    )
                }
            }
        }
    }
}
