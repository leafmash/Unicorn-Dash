package com.imora.unicorndash


fun speedLines() {
    if (st != 1 || dash <= 0.0) return
    x.strokeStyle = rgba(255, 255, 255, 0.35)
    x.lineWidth = 1.6
    x.lineCap = CAP_ROUND
    x.beginPath()
    for (i in 0 until 12) {
        val lx = L - ((t * 1100.0 + i * 97.0) % (L + 120.0)) + 60.0
        val ly = 30.0 + (i * 53) % 250
        x.moveTo(lx, ly)
        x.lineTo(lx + 46.0, ly)
    }
    x.stroke()
}

fun overlay() {
    if (st == 1) {
        ovk = 0.0
        uiOn = true
        if (cd > 0.0) countdown()
        return
    }
    val k = ease(clamp((nowMs() - stAt) / 340.0, 0.0, 1.0))
    ovk = k
    uiOn = k > 0.6
    if (k <= 0.0) return
    x.save()
    x.alpha = k
    x.translate(0.0, (1.0 - k) * 16.0)
    when (st) {
        0 -> {
            menu()
            if (gift != null) giftUI()
        }
        2 -> over()
        3 -> pauseUI()
        4 -> shopUI()
        5 -> settingsUI()
        6 -> zonesUI()
        7 -> levelsUI()
        8 -> completeUI()
        9 -> unlockUI()
        10 -> awardsUI()
        11 -> boardUI()
        12 -> spinUI()
        13 -> statsUI()
        14 -> reviveUI()
    }
    x.restore()
}
