package com.imora.unicorndash

fun speedLines() {
    if (st != 1 || dash <= 0.0) return
    x.strokeStyle = rgba(255, 255, 255, 0.35)
    x.lineWidth = 1.6
    x.lineCap = CAP_ROUND
    x.beginPath()
    for (i in 0 until 12) {
        val lx = L - ((t * 1100.0 + i * 97.0) % (L + 120.0)) + 60.0
        val ly = 30.0 + (i * 53) % 250
        x.moveTo(lx, ly)
        x.lineTo(lx + 46.0, ly)
    }
    x.stroke()
}
