package com.imora.unicorndash

import kotlin.math.max
import kotlin.math.min

class Ach(val n: String, val d: String, val r: Int, val m: Int, val g: () -> Int)

fun cleared(z: Int): Int {
    var n = 0
    for (v in prog[z]) if (v > 0) n++
    return n
}

fun zoneOpen(i: Int): Boolean = i == 0 || (i > 0 && i < ZN.size && cleared(i - 1) >= CFG_NEED)

fun lvlOpen(z: Int, l: Int): Boolean = l == 0 || prog[z][l - 1] > 0

fun zStars(z: Int): Int {
    var n = 0
    for (v in prog[z]) n += v
    return n
}

fun totalStars(): Int {
    var n = 0
    for (i in ZN.indices) n += zStars(i)
    return n
}

fun openCount(): Int {
    var n = 0
    for (i in ZN.indices) if (zoneOpen(i)) n++
    return n
}

fun perfectCount(): Int {
    var n = 0
    for (z in prog) for (v in z) if (v == 3) n++
    return n
}

fun bossCount(): Int {
    var n = 0
    for (z in prog) if (z[CFG_LEVELS - 1] > 0) n++
    return n
}

fun clearedLevels(): Int {
    var n = 0
    for (z in prog) for (v in z) if (v > 0) n++
    return n
}

fun ownedSkins(): Int {
    var n = 0
    for (v in own) if (v != 0) n++
    return n
}

fun ebMax(): Int {
    var m = 0
    for (v in eb) m = max(m, v)
    return m
}

fun plv(): Int = lvOf(xp).n

val ACH: Array<Ach> = arrayOf(
    Ach("First Steps", "Finish a run", 20, 1) { stats.runs },
    Ach("Regular", "Play 50 runs", 60, 50) { stats.runs },
    Ach("Pocket Money", "Collect 500 coins in total", 40, 500) { stats.coins },
    Ach("Treasure Hunter", "Collect 5000 coins in total", 150, 5000) { stats.coins },
    Ach("Level Up!", "Clear any level", 20, 1) { clearedLevels() },
    Ach("First Zone Done", "Clear all levels of zone 1", 80, CFG_LEVELS) { cleared(0) },
    Ach("Explorer", "Unlock 5 zones", 60, 5) { openCount() },
    Ach("Globetrotter", "Unlock 10 zones", 120, 10) { openCount() },
    Ach("World Walker", "Unlock every zone", 250, ZN.size) { openCount() },
    Ach("Shiny", "Earn 3 stars on a level", 30, 1) { perfectCount() },
    Ach("Star Collector", "Earn 25 stars", 50, 25) { totalStars() },
    Ach("Star Hoarder", "Earn 100 stars", 120, 100) { totalStars() },
    Ach("Perfectionist", "Earn 3 stars on every level", 500, ZN.size * CFG_LEVELS) { perfectCount() },
    Ach("Boss Slayer", "Beat 3 final challenges", 80, 3) { bossCount() },
    Ach("Boss Crusher", "Beat 10 final challenges", 200, 10) { bossCount() },
    Ach("Close Call", "Make 10 near misses", 30, 10) { stats.near },
    Ach("Daredevil", "Make 100 near misses", 100, 100) { stats.near },
    Ach("Combo Master", "Reach a x5 coin combo", 30, 5) { stats.bc },
    Ach("Endless Beginner", "Score 1000 in Endless", 50, 1000) { ebMax() },
    Ach("Endless Hero", "Score 3000 in Endless", 150, 3000) { ebMax() },
    Ach("Dodger", "Dodge 500 obstacles", 50, 500) { stats.dodge },
    Ach("Marathon", "Run 5000 m in total", 80, 5000) { stats.dist },
    Ach("Rising Star", "Reach player level 5", 40, 5) { plv() },
    Ach("Veteran", "Reach player level 15", 150, 15) { plv() },
    Ach("Power Up", "Grab 25 power-ups", 40, 25) { stats.pw },
    Ach("Lucky", "Use the daily spin", 20, 1) { stats.spins },
    Ach("Fashionista", "Own 3 unicorn skins", 50, 3) { ownedSkins() },
    Ach("Rule Breaker", "Clear a daily challenge with a special rule", 60, 1) { dcRule },
    Ach("Loyal", "Reach a 7 day streak", 80, 7) { streak },
    Ach("Daily Hero", "Finish a daily challenge", 60, 1) { dcWins },
    Ach("Daily Streak", "Finish daily challenges 5 days in a row", 150, 5) { dcStreak }
)

fun checkAch() {
    for (i in ACH.indices) {
        val a = ACH[i]
        if (ach[i] == 0 && a.g() >= a.m) {
            ach[i] = 1
            bank += a.r
            say(T("Award: {0}  +{1}", T(a.n), a.r))
            snd("mission")
        }
    }
}

fun achDone(): Int {
    var n = 0
    for (i in ACH.indices) n += ach[i]
    return n
}

fun gainXp(a: Int) {
    val b = plv()
    xp += a
    runXp = a
    val e = plv()
    for (k in b + 1..e) {
        val r = 20 + 5 * k
        bank += r
        say(T("Level up! LV {0}  +{1}", k, r))
        snd("milestone")
    }
}

fun currentDay(): Int = Math.floor(System.currentTimeMillis() / 864.0e5).toInt()

fun daily() {
    val n = currentDay()
    val a = Math.floor(hs(n) * 8.0).toInt()
    todays = intArrayOf(a, (a + 3) % 8, (a + 5) % 8)
    if (day != n) {
        day = n
        mp = IntArray(3)
        md = IntArray(3)
    }
    if (lastDay != n) {
        streak = if (lastDay == n - 1) streak + 1 else 1
        lastDay = n
        val amt = 20 + 10 * min(streak, 7)
        bank += amt
        gift = GiftInfo(amt, streak)
        giftAt = nowMs() + 700.0
        save()
    }
}

fun refreshDay() {
    if (st == 1 || currentDay() == day) return
    daily()
}

fun dcfg(): DcCfg {
    val n = day
    val rr = hs(n * 7.13 + 3.0)
    return DcCfg(
        n % 9973,
        Math.floor(hs(n * 3.17 + 1.0) * ZN.size).toInt(),
        4 + Math.floor(hs(n * 5.31 + 2.0) * 5.0).toInt(),
        if (rr < 0.25) "" else if (rr < 0.5) "noduck" else if (rr < 0.75) "nodj" else "sprint"
    )
}

fun mprog(kind: String, v: Int) {
    for (i in 0 until 3) {
        val m = MS[todays[i]]
        if (m.k != kind || md[i] != 0) continue
        mp[i] = if (m.run) max(mp[i], v) else mp[i] + v
        if (mp[i] >= m.n) {
            md[i] = 1
            bank += m.r
            say(T("Mission done +{0}", m.r))
            snd("mission")
        }
    }
}

fun addLb(z: Int, sc: Int): Int {
    if (sc <= 0) return -1
    val e = LbEntry(sc, day)
    val l = lb[z]
    l.add(e)
    l.sortWith { a, b -> b.s - a.s }
    val i = l.indexOf(e)
    while (l.size > 10) l.removeAt(l.size - 1)
    return if (i in 0..9) i else -1
}

fun unlockCosmetics(silent: Boolean) {
    for (i in SK.indices) {
        val it = SK[i]
        if (own[i] == 0 && it.zone >= 0 && cleared(it.zone) >= CFG_NEED) {
            own[i] = 1
            if (!silent) {
                say(T("{0} unlocked", T(it.name)))
                snd("buy")
            }
        }
    }
    for (i in TR.indices) {
        val it = TR[i]
        if (ownT[i] == 0 && it.zone >= 0 && cleared(it.zone) >= CFG_NEED) {
            ownT[i] = 1
            if (!silent) {
                say(T("{0} unlocked", T(it.name)))
                snd("buy")
            }
        }
    }
    for (i in HR.indices) {
        val it = HR[i]
        if (ownH[i] == 0 && it.zone >= 0 && cleared(it.zone) >= CFG_NEED) {
            ownH[i] = 1
            if (!silent) {
                say(T("{0} unlocked", T(it.name)))
                snd("buy")
            }
        }
    }
    for (i in PT.indices) {
        val it = PT[i]
        if (ownP[i] == 0 && it.zone >= 0 && cleared(it.zone) >= CFG_NEED) {
            ownP[i] = 1
            if (!silent) {
                say(T("{0} unlocked", T(it.name)))
                snd("buy")
            }
        }
    }
}

fun setSel(tab: Int, i: Int) {
    when (tab) {
        0 -> skin = i
        1 -> trailSel = i
        2 -> hornSel = i
        3 -> petSel = i
        else -> skillSel = i
    }
}

class TabData(val count: Int, val own: IntArray, val sel: Int)

fun tabCount(k: Int): Int = when (k) {
    0 -> SK.size
    1 -> TR.size
    2 -> HR.size
    3 -> PT.size
    else -> SKL.size
}

fun tabOwn(k: Int): IntArray = when (k) {
    0 -> own
    1 -> ownT
    2 -> ownH
    3 -> ownP
    else -> ownS
}

fun tabSel(k: Int): Int = when (k) {
    0 -> skin
    1 -> trailSel
    2 -> hornSel
    3 -> petSel
    else -> skillSel
}

fun itemName(k: Int, i: Int): String = when (k) {
    0 -> SK[i].name
    1 -> TR[i].name
    2 -> HR[i].name
    3 -> PT[i].name
    else -> SKL[i].name
}

fun itemCost(k: Int, i: Int): Int = when (k) {
    0 -> SK[i].cost
    1 -> TR[i].cost
    2 -> HR[i].cost
    3 -> PT[i].cost
    else -> SKL[i].cost
}

fun itemZone(k: Int, i: Int): Int = when (k) {
    0 -> SK[i].zone
    1 -> TR[i].zone
    2 -> HR[i].zone
    3 -> PT[i].zone
    else -> SKL[i].zone
}

fun itemHc(k: Int, i: Int): Int = when (k) {
    0 -> SK[i].hc
    1 -> TR[i].hc
    2 -> HR[i].hc
    else -> 0
}
