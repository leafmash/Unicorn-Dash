package com.imora.unicorndash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private val LOAD_TIPS = arrayOf(
    "Hold the screen to jump higher",
    "Collect coins to unlock new unicorns",
    "Finish the daily challenge for a bonus",
    "Claim your awards from the Awards page",
    "Near misses build your combo"
)

@Composable
fun LoadingScreen() {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) { prog.animateTo(1f, tween(1700, easing = FastOutSlowInEasing)) }
    val tr = rememberInfiniteTransition(label = "load")
    val tw by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "tw")
    val stars = remember {
        val r = Random(11)
        List(54) { floatArrayOf(r.nextFloat(), r.nextFloat() * 0.75f, 0.8f + r.nextFloat() * 1.8f, r.nextFloat()) }
    }
    val tip = remember { LOAD_TIPS.random() }
    val bands = remember {
        listOf(Color(0xFFFF6B9D), Color(0xFFFFB86B), Color(0xFFFFE27A), Color(0xFF7DFFD4), Color(0xFF6BC4FF), Color(0xFF9A5CFF))
    }
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF140A33), Color(0xFF3B1F7A), Color(0xFFB0509F))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        val h = maxHeight
        Canvas(Modifier.fillMaxSize()) {
            for (s in stars) {
                val a = 0.2f + 0.8f * abs(sin((tw + s[3]) * 6.2832f))
                drawCircle(Color.White.copy(alpha = a), s[2].dp.toPx(), Offset(s[0] * size.width, s[1] * size.height))
            }
            val cx = size.width / 2f
            val base = size.height * 0.5f
            val r0 = min(size.width * 0.3f, size.height * 0.42f)
            val sweep = 180f * min(1f, prog.value * 1.2f)
            for (i in bands.indices) {
                val r = r0 - i * 9.dp.toPx()
                drawArc(
                    color = bands[i],
                    startAngle = 180f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = Offset(cx - r, base - r),
                    size = Size(r * 2f, r * 2f),
                    style = Stroke(8.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
        Column(
            Modifier.align(Alignment.TopCenter).padding(top = h * 0.53f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GradText("UNICORN DASH", 38f, brush = Brush.horizontalGradient(listOf(Pal.Pink, Pal.Sun, Pal.Mint, Pal.Cyan, Pal.Purple)))
            Spacer(Modifier.height(10.dp))
            Bar(prog.value, Modifier.width(240.dp), 8.dp)
            Spacer(Modifier.height(8.dp))
            Tx("Loading...", 11f, color = Pal.Lilac, shadow = false)
            Spacer(Modifier.height(4.dp))
            Tx(tip, 10.5f, color = Pal.Dim, weight = FontWeight.Bold, align = TextAlign.Center, shadow = false)
        }
    }
}
