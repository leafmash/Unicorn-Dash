package com.imora.unicorndash

interface Emitter {
    fun tone(
        f: Double,
        at: Double = 0.0,
        len: Double = 0.2,
        vol: Double = 0.1,
        type: Int = OSC_SINE,
        att: Double = 0.008,
        hold: Double = 0.0,
        cut: Double = 0.0,
        cutTo: Double = 0.0,
        det: Double = 0.0,
        to: Double = 0.0,
        bus: Int = BUS_FX
    )

    fun puff(
        f: Double = 2000.0,
        at: Double = 0.0,
        len: Double = 0.1,
        vol: Double = 0.05,
        to: Double = 0.0,
        att: Double = 0.004,
        q: Double = 1.0,
        ft: Int = FLT_BAND,
        bus: Int = BUS_FX
    )
}

fun Emitter.bells(list: DoubleArray, step: Double, len: Double, vol: Double) {
    for (i in list.indices) {
        val f = list[i]
        val at = i * step
        tone(f = f, at = at, len = len, vol = vol, type = OSC_SINE, att = 0.005)
        tone(f = f * 2.0, at = at, len = len * 0.6, vol = vol * 0.3, type = OSC_SINE, att = 0.004)
        tone(f = f * 1.005, at = at, len = len * 0.8, vol = vol * 0.4, type = OSC_TRI, att = 0.006)
    }
}

class Spec(
    val noise: Boolean,
    val f: Double,
    val at: Double,
    val len: Double,
    val vol: Double,
    val type: Int,
    val att: Double,
    val hold: Double,
    val cut: Double,
    val cutTo: Double,
    val det: Double,
    val to: Double,
    val q: Double,
    val ft: Int,
    val bus: Int
)

class QueueEmitter(private val sink: ArrayList<Spec>) : Emitter {
    override fun tone(f: Double, at: Double, len: Double, vol: Double, type: Int, att: Double, hold: Double, cut: Double, cutTo: Double, det: Double, to: Double, bus: Int) {
        sink.add(Spec(false, f, at, len, vol, type, att, hold, cut, cutTo, det, to, 1.0, FLT_NONE, bus))
    }

    override fun puff(f: Double, at: Double, len: Double, vol: Double, to: Double, att: Double, q: Double, ft: Int, bus: Int) {
        sink.add(Spec(true, f, at, len, vol, OSC_NOISE, att, 0.0, 0.0, 0.0, 0.0, to, q, ft, bus))
    }
}

class DirectEmitter(private val synth: Synth) : Emitter {
    override fun tone(f: Double, at: Double, len: Double, vol: Double, type: Int, att: Double, hold: Double, cut: Double, cutTo: Double, det: Double, to: Double, bus: Int) {
        synth.tone(f, (at * SR).toLong(), len, vol, type, att, hold, cut, cutTo, det, to, bus)
    }

    override fun puff(f: Double, at: Double, len: Double, vol: Double, to: Double, att: Double, q: Double, ft: Int, bus: Int) {
        synth.puff(f, (at * SR).toLong(), len, vol, to, att, q, ft, bus)
    }
}
