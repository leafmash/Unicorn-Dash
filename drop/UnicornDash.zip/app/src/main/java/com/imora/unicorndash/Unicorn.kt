package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

class UniQ {
    var x = 0.0
    var y = 0.0
    var ang = 0.0
    var sq = 1.0
    var dk = 0.0
    var air = false
    var stand = false
    var tt = 0.0
    var rt = Double.NaN
    var sit = 0.0
    var rear = 0.0
    var happy = false
    var dead = false
    var sc = 1.0
    var hn = 0
    var fx = 1.0
    var nod = 0.0
    var ghost = false
    var sc2 = 1.0

    fun clear() {
        x = 0.0
        y = 0.0
        ang = 0.0
        sq = 1.0
        dk = 0.0
        air = false
        stand = false
        tt = 0.0
        rt = Double.NaN
        sit = 0.0
        rear = 0.0
        happy = false
        dead = false
        sc = 1.0
        hn = 0
        fx = 1.0
        nod = 0.0
        ghost = false
    }
}

val uq = UniQ()
val trgb = DoubleArray(3)
private val hornCols = IntArray(2)

fun mane(si: Int, b: Int): Double = SK[si].h0 + SK[si].st * b

fun trailRgb(ti: Int, b: Int, tt: Double) {
    val c = TR[ti]
    if (c.c == null && !c.cycle) {
        trgb[0] = mane(skin, b)
        trgb[1] = 95.0
        trgb[2] = 62.0
        return
    }
    if (c.cycle) {
        trgb[0] = (140.0 + 80.0 * (1.0 + sin(tt * 1.6 + b * 0.9))) % 360.0
        trgb[1] = 90.0
        trgb[2] = 66.0
        return
    }
    val a = c.c!![b]
    trgb[0] = a[0]
    trgb[1] = a[1]
    trgb[2] = a[2]
}

fun trgbA(a: Double): Int = hsl(trgb[0], trgb[1], trgb[2], a)

fun ribbon(x0: Double, x1: Double, yc: Double, ti: Int, tt: Double) {
    x.lineCap = CAP_ROUND
    for (b in 0 until 6) {
        trailRgb(ti, b, tt)
        x.strokeShader = x.lin(x0, 0.0, x1, 0.0, trgbA(0.0), trgbA(0.9))
        x.lineWidth = 3.4
        x.beginPath()
        for (i in 0..14) {
            val px = lerp(x0, x1, i / 14.0)
            val py = yc + (b - 2.5) * 3.6 + sin(tt * 4.0 + i * 0.6 + b * 0.4) * 2.2
            if (i > 0) x.lineTo(px, py) else x.moveTo(px, py)
        }
        x.stroke()
    }
}

fun hornShape(hi: Int, tt: Double, gh: Double) {
    val hh = if (hi in HR.indices) HR[hi] else HR[0]
    var hue = if (hh.type == "gold") gh else hh.hue
    x.beginPath()
    x.moveTo(28.2, -48.4)
    x.lineTo(37.4, -70.2)
    x.lineTo(33.6, -46.6)
    if (hh.type == "candy") {
        x.save()
        x.clip()
        x.fillStyle = hex(0xffffff)
        x.fillRect(24.0, -74.0, 18.0, 30.0)
        x.strokeStyle = rgba(232, 40, 84, 0.95)
        x.lineWidth = 2.4
        for (i in 0 until 5) {
            x.beginPath()
            x.moveTo(26.0, -50.0 - i * 4.4)
            x.lineTo(42.0, -58.0 - i * 4.4)
            x.stroke()
        }
        x.restore()
    } else {
        when (hh.type) {
            "crystal" -> {
                hornCols[0] = hex(0x7fe3ff)
                hornCols[1] = hex(0xeafcff)
            }
            "flame" -> {
                val f = 0.5 + 0.5 * sin(tt * 14.0)
                hornCols[0] = hsl(8.0 + 8.0 * f, 100.0, 52.0)
                hornCols[1] = hsl(44.0 + 10.0 * f, 100.0, 72.0)
            }
            "heart" -> {
                hornCols[0] = hex(0xff4f86)
                hornCols[1] = hex(0xffc2d6)
            }
            "rainbow" -> {
                hue = (tt * 120.0) % 360.0
                hornCols[0] = hsl(hue, 100.0, 64.0)
                hornCols[1] = hsl((hue + 70.0) % 360.0, 100.0, 80.0)
            }
            else -> {
                hornCols[0] = hex(0xffe27a)
                hornCols[1] = hex(0xfff9d6)
            }
        }
        x.fillShader = x.lin(30.9, -47.5, 37.4, -70.2, hornCols[0], hornCols[1])
        x.fill()
        if (hh.type == "crystal") {
            x.strokeStyle = rgba(255, 255, 255, 0.9)
            x.lineWidth = 0.8
            x.beginPath()
            x.moveTo(33.0, -50.0)
            x.lineTo(36.3, -66.0)
            x.moveTo(30.5, -50.0)
            x.lineTo(35.3, -60.0)
            x.stroke()
        }
        if (hh.type == "heart") {
            heartPath(37.6, -74.0, 3.4)
            x.fillStyle = hex(0xfff0f5)
            x.fill()
        }
        if (hh.type == "star") {
            x.fillStyle = hex(0xfffbd0)
            x.beginPath()
            for (i in 0 until 10) {
                val r = if (i % 2 == 1) 1.8 else 4.0
                val a = -PI / 2.0 + i * PI / 5.0
                x.lineTo(37.6 + cos(a) * r, -73.0 + sin(a) * r)
            }
            x.closePath()
            x.fill()
        }
    }
    x.halo(37.4, -70.2, if (hh.type == "flame") 20.0 else 16.0, hue, 100.0, 70.0, 0.7)
}

fun leg(lx: Double, ph: Double, col: Int, air: Boolean) {
    val fx2: Double
    val fy: Double
    if (air) {
        fx2 = lx + (if (lx > 0.0) 12.0 else -10.0)
        fy = if (lx > 0.0) -12.0 else -9.0
    } else {
        fx2 = lx + sin(ph) * 9.0
        fy = -3.0 - max(0.0, cos(ph)) * 8.0
    }
    x.strokeStyle = col
    x.lineWidth = 5.0
    x.lineCap = CAP_ROUND
    x.beginPath()
    x.moveTo(lx, -20.0)
    x.quadraticCurveTo(lx + (fx2 - lx) * 0.3 + 3.0, -11.0, fx2, fy)
    x.stroke()
    x.fillStyle = hex(0x7a62a8)
    x.beginPath()
    x.arc(fx2, fy, 2.6, 0.0, 7.0)
    x.fill()
}

fun band(si: Int, b: Int, mw: Double) {
    x.strokeStyle = hsl(mane(si, b), 95.0, 62.0)
    x.lineWidth = mw
    x.lineCap = CAP_ROUND
}

fun straightLeg(lx: Double, col: Int) {
    x.strokeStyle = col
    x.lineWidth = 5.0
    x.lineCap = CAP_ROUND
    x.beginPath()
    x.moveTo(lx, -20.0)
    x.lineTo(lx + 1.0, -4.0)
    x.stroke()
    x.fillStyle = hex(0x7a62a8)
    x.beginPath()
    x.arc(lx + 1.0, -3.0, 2.6, 0.0, 7.0)
    x.fill()
}

fun hindLeg(lx: Double, col: Int) {
    x.fillStyle = col
    x.beginPath()
    x.ellipse(lx + 4.0, -12.0, 11.0, 6.5, -0.15, 0.0, 7.0)
    x.fill()
    x.fillStyle = hex(0x7a62a8)
    x.beginPath()
    x.arc(lx + 14.0, -5.0, 2.6, 0.0, 7.0)
    x.fill()
}

fun pawLeg(lx: Double, col: Int, tt: Double, ph: Double) {
    val k = sin(tt * 12.0 + ph) * 3.0
    x.strokeStyle = col
    x.lineWidth = 5.0
    x.lineCap = CAP_ROUND
    x.lineJoin = JOIN_ROUND
    x.beginPath()
    x.moveTo(lx, -20.0)
    x.lineTo(lx + 10.0, -24.0 + k)
    x.lineTo(lx + 15.0, -13.0 + k)
    x.stroke()
    x.fillStyle = hex(0x7a62a8)
    x.beginPath()
    x.arc(lx + 15.0, -12.0 + k, 2.6, 0.0, 7.0)
    x.fill()
}

fun limb(lx: Double, ph: Double, col: Int, air: Boolean, sit: Double, q: UniQ) {
    if (!air && q.rear > 0.02) {
        if (lx > 0.0) {
            pawLeg(lx, col, q.tt, ph)
        } else {
            x.save()
            x.translate(-12.0, -20.0)
            x.rotate(q.rear * 0.9)
            x.translate(12.0, 20.0)
            straightLeg(lx, col)
            x.restore()
        }
    } else if (!air && q.stand) {
        straightLeg(lx, col)
    } else if (sit > 0.5) {
        if (lx > 0.0) straightLeg(lx, col) else hindLeg(lx, col)
    } else {
        leg(lx, ph, col, air)
    }
}

fun unicorn(q: UniQ, si: Int) {
    if (!q.ghost && x.alpha > 0.99) {
        x.inkBegin()
        unicornBody(q, si)
        x.inkEnd()
    }
    unicornBody(q, si)
}

fun unicornBody(q: UniQ, si: Int) {
    val s = SK[si]
    val tt = q.tt
    val run = (if (q.rt.isNaN()) tt else q.rt) * 17.0
    val sc = q.sc
    val sit = q.sit
    x.save()
    x.translate(q.x, q.y)
    x.rotate(q.ang)
    val fl = if (abs(q.fx) < 0.04) 0.04 else q.fx
    x.scale(sc / q.sq * fl, sc * (1.0 - 0.36 * q.dk) * q.sq)
    if (sit > 0.0) {
        x.translate(0.0, sit * 6.0)
        x.rotate(-sit * 0.3)
    }
    if (q.rear > 0.0) {
        x.translate(-12.0, -20.0)
        x.rotate(-q.rear * 0.9)
        x.translate(12.0, 20.0)
    }
    x.halo(2.0, -28.0, 46.0, 300.0, 100.0, 70.0, 0.14)

    for (b in 0 until 6) {
        band(si, b, 3.2)
        val w = sin(tt * 9.0 + b * 0.6) * 4.0
        x.beginPath()
        x.moveTo(-18.0, -30.0 + b * 1.4)
        x.quadraticCurveTo(-32.0, -26.0 + w, -44.0 + w, -10.0 + b * 2.2 + w * 0.5)
        x.stroke()
    }

    limb(-12.0, run + 3.0, s.back, q.air, sit, q)
    limb(12.0, run + 3.1, s.back, q.air, sit, q)

    x.fillStyle = s.body
    x.beginPath()
    x.ellipse(0.0, -27.0, 20.0, 11.0, 0.0, 0.0, 7.0)
    x.fill()
    x.fillStyle = rgba(180, 150, 230, 0.35)
    x.beginPath()
    x.ellipse(0.0, -22.0, 17.0, 6.0, 0.0, 0.0, 7.0)
    x.fill()

    limb(-12.0, run, s.leg, q.air, sit, q)
    limb(12.0, run + 0.1, s.leg, q.air, sit, q)

    x.save()
    if (q.nod != 0.0) {
        x.translate(14.0, -34.0)
        x.rotate(q.nod)
        x.translate(-14.0, 34.0)
    }
    hornShape(q.hn, tt, s.horn)
    x.strokeStyle = s.body
    x.lineWidth = 10.0
    x.lineCap = CAP_ROUND
    x.beginPath()
    x.moveTo(13.0, -31.0)
    x.lineTo(22.0, -44.0)
    x.stroke()
    x.fillStyle = s.body
    x.beginPath()
    x.ellipse(27.0, -47.0, 8.5, 5.8, 0.4, 0.0, 7.0)
    x.fill()
    x.beginPath()
    x.moveTo(23.0, -51.0)
    x.lineTo(25.0, -59.0)
    x.lineTo(29.0, -52.0)
    x.fill()

    for (b in 0 until 6) {
        band(si, b, 3.0)
        val w = sin(tt * 10.0 + b * 0.7) * 3.0
        x.beginPath()
        x.moveTo(20.0, -50.0 + b * 0.8)
        x.quadraticCurveTo(8.0, -58.0 + w, -4.0 + w, -40.0 + b * 1.8)
        x.stroke()
    }

    x.fillStyle = rgba(255, 120, 170, 0.35)
    x.beginPath()
    x.ellipse(25.5, -45.5, 2.6, 1.8, 0.0, 0.0, 7.0)
    x.fill()
    if (q.dead) {
        x.strokeStyle = hex(0x3b2a5a)
        x.lineWidth = 1.2
        x.beginPath()
        x.moveTo(28.0, -50.0)
        x.lineTo(31.0, -47.0)
        x.moveTo(31.0, -50.0)
        x.lineTo(28.0, -47.0)
        x.stroke()
    } else if (q.happy) {
        x.strokeStyle = hex(0x3b2a5a)
        x.lineWidth = 1.5
        x.lineCap = CAP_ROUND
        x.beginPath()
        x.arc(29.5, -47.8, 2.2, PI, 0.0)
        x.stroke()
    } else if ((tt * 0.9 + si * 0.37) % 3.4 < 0.12) {
        x.strokeStyle = hex(0x3b2a5a)
        x.lineWidth = 1.2
        x.beginPath()
        x.moveTo(28.0, -48.5)
        x.lineTo(31.0, -48.5)
        x.stroke()
    } else {
        x.fillStyle = hex(0x3b2a5a)
        x.beginPath()
        x.arc(29.5, -48.5, 1.5, 0.0, 7.0)
        x.fill()
    }
    x.restore()
    x.restore()
}
