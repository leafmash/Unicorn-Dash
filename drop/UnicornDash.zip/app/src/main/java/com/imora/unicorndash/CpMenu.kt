package com.imora.unicorndash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Scrim(a: Float, strong: Boolean = false) {
    Box(
        Modifier
            .fillMaxSize()
            .alpha(a)
            .background(
                if (strong) Brush.verticalGradient(listOf(Color(0xE60E0626), Color(0xF21A0E3D)))
                else Brush.verticalGradient(listOf(Color(0x99140A33), Color(0xB31A0E3D)))
            )
    )
}

@Composable
fun ToggleRow(text: String, on: Boolean, modifier: Modifier = Modifier, onToggle: () -> Unit) {
    val k by animateFloatAsState(if (on) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "tog")
    Row(
        modifier
            .fillMaxWidth()
            .pressable(scaleTo = 0.97f, onClick = onToggle)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x14FFFFFF))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Tx(text, 14f, weight = FontWeight.Bold)
        Box(
            Modifier
                .width(46.dp)
                .height(26.dp)
                .clip(CircleShape)
                .background(if (on) PrimaryBrush else Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x30FFFFFF))))
        ) {
            Box(
                Modifier
                    .padding(start = 3.dp + 20.dp * k, top = 3.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color.White)
            )
        }
    }
}

@Composable
fun XpRow(s: Snap, modifier: Modifier = Modifier) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Tx(T("LV {0}   +{1} XP", s.lv, s.runXp), 10.5f, color = Pal.Lilac, weight = FontWeight.Bold)
            if (s.lbRank >= 0 && !s.levelMode) Tx(T("TOP 10  #{0}", s.lbRank + 1), 10.5f, color = Pal.Sun)
        }
        Spacer(Modifier.height(4.dp))
        Bar(s.xpCur.toFloat() / s.xpNeed, Modifier.fillMaxWidth(), 6.dp, GoldBrush)
    }
}

@Composable
fun Confetti(trigger: Any, modifier: Modifier = Modifier) {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(trigger) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(2600, easing = FastOutSlowInEasing))
    }
    Canvas(modifier.fillMaxSize()) {
        val p = prog.value
        if (p >= 1f) return@Canvas
        val cx = size.width / 2f
        val cy = size.height * 0.42f
        for (i in 0 until 46) {
            val a = (hs(i) * 6.283).toFloat()
            val sp = (0.35 + hs(i + 90) * 0.9).toFloat()
            val vx = cos(a) * sp * size.width * 0.5f
            val vy = sin(a) * sp * size.height * 0.5f - size.height * 0.25f
            val px = cx + vx * p
            val py = cy + vy * p + size.height * 0.9f * p * p
            val c = hueColor(hs(i + 33) * 360.0, 95.0, 66.0)
            val r = (3 + hs(i + 7) * 4).toFloat()
            drawCircle(c.copy(alpha = (1f - p).coerceIn(0f, 1f)), r, Offset(px, py))
        }
    }
}

@Composable
fun DockTile(label: String, badge: Boolean, modifier: Modifier = Modifier, index: Int, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Box(modifier.enter(index).pressable(onClick = onClick)) {
        Glass(Modifier.size(width = 76.dp, height = 58.dp), 18.dp) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                icon()
                Spacer(Modifier.height(4.dp))
                Tx(label, 10.5f)
            }
        }
        if (badge) {
            val tr = rememberInfiniteTransition(label = "badge")
            val k by tr.animateFloat(0.8f, 1.25f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "bk")
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(10.dp)
                    .graphicsLayer {
                        scaleX = k
                        scaleY = k
                    }
                    .clip(CircleShape)
                    .background(Color(0xFFFF6FAE))
            )
        }
    }
}

@Composable
fun MissionRow(m: UMission) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Tx(m.title, 10.5f, Modifier.weight(1f), color = if (m.done) Pal.Mint else Color(0xFFF4ECFF), weight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            if (m.done) CheckIcon(12.dp, Pal.Mint) else Tx("+${m.reward}", 10.5f, color = Pal.Sun)
        }
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Bar(m.prog.toFloat() / m.need, Modifier.weight(1f), 5.dp, if (m.done) Brush.horizontalGradient(listOf(Pal.Mint, Pal.Mint)) else GoldBrush)
            Spacer(Modifier.width(8.dp))
            Tx("${m.prog}/${m.need}", 9.5f, color = Color(0xFFC9BDF0), weight = FontWeight.Bold, shadow = false)
        }
    }
}

@Composable
fun MenuScreen(s: Snap) {
    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
        val compact = maxWidth < 700.dp
        Box(Modifier.align(Alignment.TopStart).enter(0)) {
            Glass(Modifier.width(196.dp), 20.dp) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(PrimaryBrush)
                            .border(1.5.dp, Color(0xCCFFFFFF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Tx(s.lv.toString(), 18f) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Tx("PLAYER", 10.5f, color = Pal.Sun)
                            Tx("${s.xpCur}/${s.xpNeed} XP", 9.5f, color = Pal.Lilac, weight = FontWeight.Bold, shadow = false)
                        }
                        Spacer(Modifier.height(5.dp))
                        Bar(s.xpCur.toFloat() / s.xpNeed, Modifier.fillMaxWidth(), 7.dp)
                        Spacer(Modifier.height(5.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StarIcon(13.dp, true)
                            Spacer(Modifier.width(4.dp))
                            Tx("${s.stars}/${s.starsMax}", 10.5f, color = Pal.Sun)
                        }
                    }
                }
            }
        }

        Column(Modifier.align(Alignment.TopStart).padding(top = 76.dp).enter(2)) {
            Glass(Modifier.width(196.dp), 20.dp) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Tx("DAILY MISSIONS", 10.5f, color = Pal.Sun)
                    for (m in s.missions) MissionRow(m)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Tx(T("Day {0} streak", s.streak), 9.5f, color = Pal.Rose, weight = FontWeight.Bold, shadow = false)
                        Tx(T("{0} of {1} awards", s.achDone, s.achTotal), 9.5f, color = Color(0xFFA9FFE3), weight = FontWeight.Bold, shadow = false)
                    }
                }
            }
        }

        if (!compact) {
            Column(Modifier.align(Alignment.TopCenter).enter(1), horizontalAlignment = Alignment.CenterHorizontally) {
                GradText("UNICORN DASH", 28f)
                Spacer(Modifier.height(4.dp))
                Pill(height = 22.dp) { Tx(s.zoneName, 11f, color = Pal.Lilac) }
            }
        }

        Row(
            Modifier.align(Alignment.TopEnd).enter(0),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Pill(height = 30.dp) { Tx(T("BEST {0}", s.best), 12f, color = Color(0xFFF0E4FF)) }
            HeartPill(s.hearts)
            CoinPill(s.bank)
            RoundBtn(34.dp, onClick = { UiBridge.fire("settings") }) { GearIcon(18.dp) }
            RoundBtn(34.dp, onClick = { UiBridge.fire("mute") }) { SoundIcon(18.dp, s.music || s.sfx) }
        }

        Column(
            Modifier.align(Alignment.TopEnd).padding(top = 48.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DockTile("SHOP", false, index = 1, onClick = { UiBridge.fire("shop") }) { BagIcon(22.dp) }
                DockTile("AWARDS", false, index = 2, onClick = { UiBridge.fire("awards") }) { MedalIcon(22.dp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DockTile("BOARD", false, index = 3, onClick = { UiBridge.fire("board") }) { BoardIcon(22.dp) }
                DockTile("SPIN", s.spinReady, index = 4, onClick = { UiBridge.fire("spin") }) { SpinIcon(22.dp) }
            }
            Box(Modifier.enter(5).pressable(onClick = { UiBridge.fire("daily") })) {
                Glass(
                    Modifier.width(160.dp),
                    18.dp,
                    if (s.dailyDone) GlassBrush else Brush.verticalGradient(listOf(Color(0xE0FFC24A), Color(0xE0D9791A)))
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        CalendarIcon(24.dp, if (s.dailyDone) Pal.Mint else Color(0xFF5A3000))
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Tx("DAILY CHALLENGE", 10.5f, color = if (s.dailyDone) Color.White else Color(0xFF5A3000), shadow = !s.dailyDone)
                            Tx(
                                s.dailyText,
                                9.5f,
                                color = if (s.dailyDone) Pal.Mint else Color(0xFF7A4500),
                                weight = FontWeight.Bold,
                                shadow = false
                            )
                        }
                    }
                }
            }
        }

        Box(
            Modifier
                .align(Alignment.Center)
                .padding(bottom = 30.dp)
                .size(width = 190.dp, height = 190.dp)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { UiBridge.fire("pet") }
        )

        Row(
            Modifier.align(Alignment.BottomCenter).enter(3, 30f),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GButton("ADVENTURE", Modifier.width(190.dp), height = 54.dp, textSize = 18f, lead = { PlayIcon(20.dp) }) { UiBridge.fire("adv") }
            GButton("ENDLESS", Modifier.width(190.dp), height = 54.dp, textSize = 18f, lead = { LoopIcon(22.dp) }) { UiBridge.fire("end") }
        }
    }
}

@Composable
fun GiftDialog(s: Snap) {
    if (!s.giftOn || s.st != 0) return
    val shown by animateFloatAsState(s.giftAmt.toFloat(), tween(900, 250, FastOutSlowInEasing), label = "gift")
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Scrim(1f)
        Glass(Modifier.width(300.dp).popIn(), 28.dp) {
            Column(
                Modifier.padding(horizontal = 20.dp, vertical = 18.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GradText("DAILY GIFT", 26f)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CoinIcon(44.dp)
                    Spacer(Modifier.width(12.dp))
                    Tx("+${shown.toInt()}", 44f, color = Pal.Sun)
                }
                Spacer(Modifier.height(8.dp))
                Tx(T("Day {0} streak", s.giftStreak), 13f, color = Pal.Rose)
                Tx("Come back tomorrow for more", 11.5f, color = Pal.Lilac, weight = FontWeight.Bold, shadow = false)
                Spacer(Modifier.height(14.dp))
                GButton("CLAIM", Modifier.width(170.dp), Kind.Gold, 44.dp) { UiBridge.fire("claim") }
            }
        }
        Confetti(s.giftAmt)
    }
}

@Composable
fun PauseScreen(s: Snap) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Scrim(1f)
        Glass(Modifier.width(320.dp).popIn(), 28.dp) {
            Column(
                Modifier.padding(horizontal = 22.dp, vertical = 16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GradText("PAUSED", 30f)
                GButton("RESUME", Modifier.fillMaxWidth(), height = 48.dp, lead = { PlayIcon(18.dp) }) { UiBridge.fire("resume") }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GButton("RESTART", Modifier.weight(1f), Kind.Soft, 38.dp, 13f) { UiBridge.fire("restart") }
                    GButton("MENU", Modifier.weight(1f), Kind.Soft, 38.dp, 13f) { UiBridge.fire("menu") }
                }
                ToggleRow("Music", s.music) { UiBridge.fire("tmusic") }
                ToggleRow("Sound effects", s.sfx) { UiBridge.fire("tsfx") }
            }
        }
    }
}

@Composable
fun CountUp(target: Int, size: Float, color: Color = Color.White) {
    val v by animateFloatAsState(target.toFloat(), tween(1000, 150, FastOutSlowInEasing), label = "cu")
    Tx(v.toInt().toString(), size, color = color)
}

@Composable
fun OverScreen(s: Snap) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Scrim(0.9f)
        Glass(Modifier.widthIn(max = 410.dp).fillMaxWidth(0.62f).popIn(), 28.dp) {
            Column(
                Modifier.padding(horizontal = 20.dp, vertical = 14.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                GradText(if (s.levelMode) "LEVEL FAILED" else if (s.newBest) "NEW BEST!" else "GAME OVER", 28f)
                if (s.levelMode) {
                    CountUp(s.pct, 46f)
                    Tx(
                        if (s.daily) T("DAILY CHALLENGE") + "  -  " + zn(s.zi) else T("{0}  -  Level {1}", zn(s.zi), s.li + 1),
                        12f, color = Pal.Lilac, weight = FontWeight.Bold, shadow = false
                    )
                } else {
                    CountUp(s.scoreF, 46f)
                    Tx(
                        if (s.newBest) T("NEW BEST  -  {0}", zn(s.zi)) else T("{0} pts to beat your best  -  {1}", s.toBeat, zn(s.zi)),
                        12f, color = Pal.Lilac, weight = FontWeight.Bold, shadow = false
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (s.levelMode) {
                        Stat("COINS", "${s.got}/${s.levelCoins}", Pal.Sun, Modifier.weight(1f))
                        Stat("DISTANCE", T("{0} m", s.dist), Pal.Cyan, Modifier.weight(1f))
                        Stat("SCORE", s.scoreF.toString(), Pal.Rose, Modifier.weight(1f))
                    } else {
                        Stat("COINS", s.runCoins.toString(), Pal.Sun, Modifier.weight(1f))
                        Stat("DISTANCE", T("{0} m", s.dist), Pal.Cyan, Modifier.weight(1f))
                        Stat("BEST COMBO", "x${s.runCombo}", Pal.Rose, Modifier.weight(1f))
                    }
                }
                XpRow(s, Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GButton("RETRY", Modifier.weight(1f), height = 44.dp, lead = { LoopIcon(18.dp) }) { UiBridge.fire("restart") }
                    if (s.levelMode && !s.daily) {
                        GButton("LEVELS", Modifier.weight(1f), Kind.Soft, 44.dp) { UiBridge.fire("lvls") }
                    } else {
                        GButton("MENU", Modifier.weight(1f), Kind.Soft, 44.dp) { UiBridge.fire("menu") }
                    }
                }
            }
        }
        if (s.newBest && !s.levelMode) Confetti(s.stAtMs)
    }
}

@Composable
fun StarPop(on: Boolean, index: Int, stamp: Double, label: String) {
    val a = remember(stamp) { Animatable(0f) }
    LaunchedEffect(stamp, on) {
        a.snapTo(0f)
        if (on) {
            delay(450L + index * 420L)
            a.animateTo(1f, spring(dampingRatio = 0.34f, stiffness = 260f))
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) {
            StarIcon(48.dp, false)
            if (on) {
                Box(
                    Modifier
                        .size(58.dp)
                        .graphicsLayer {
                            val v = a.value
                            scaleX = v
                            scaleY = v
                            rotationZ = (1f - v) * -50f
                            alpha = if (v > 1f) 1f else if (v < 0f) 0f else v
                        },
                    contentAlignment = Alignment.Center
                ) {
                    PulseGlow(Pal.Gold, Modifier.alpha(0.7f), 34.dp)
                    StarIcon(52.dp, true)
                }
            }
        }
        Tx(label, 10.5f, color = if (on) Pal.Mint else Pal.Dim, weight = FontWeight.Bold, shadow = false)
    }
}

@Composable
fun CompleteScreen(s: Snap) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Scrim(0.88f)
        Glass(Modifier.widthIn(max = 420.dp).fillMaxWidth(0.64f).popIn(), 28.dp) {
            Column(
                Modifier.padding(horizontal = 20.dp, vertical = 14.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                GradText(if (s.resDaily) "DAILY COMPLETE" else "LEVEL COMPLETE", 26f)
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    StarPop(s.resStars[0], 0, s.stAtMs, "Finish")
                    StarPop(s.resStars[1], 1, s.stAtMs, T("{0}% coins", (CFG_COIN_PCT * 100.0).toInt()))
                    StarPop(s.resStars[2], 2, s.stAtMs, "No damage")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("COINS", "${s.resGot}/${s.resTotal}", Pal.Sun, Modifier.weight(1f))
                    Stat("SCORE", s.scoreF.toString(), Pal.Cyan, Modifier.weight(1f))
                    Stat(if (s.resFirst) "FIRST CLEAR" else "BONUS", "+${s.resBonus}", Pal.Rose, Modifier.weight(1f))
                }
                XpRow(s, Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (s.resDaily) {
                        GButton("RETRY", Modifier.weight(1f), Kind.Soft, 44.dp) { UiBridge.fire("restart") }
                        GButton("MENU", Modifier.weight(1f), height = 44.dp) { UiBridge.fire("menu") }
                    } else {
                        GButton("RETRY", Modifier.weight(1f), Kind.Soft, 42.dp, 14f) { UiBridge.fire("restart") }
                        GButton("NEXT", Modifier.weight(1.2f), height = 44.dp, lead = { PlayIcon(16.dp) }) { UiBridge.fire("next") }
                        GButton("LEVELS", Modifier.weight(1f), Kind.Soft, 42.dp, 14f) { UiBridge.fire("lvls") }
                    }
                }
            }
        }
        Confetti(s.stAtMs)
    }
}

@Composable
fun UnlockScreen(s: Snap) {
    val z = if (s.unlockZone >= 0) s.unlockZone else return
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Scrim(1f, true)
        Glass(Modifier.width(340.dp).popIn(), 28.dp) {
            Column(
                Modifier.padding(horizontal = 20.dp, vertical = 16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GradText("ZONE UNLOCKED", 26f)
                Box(contentAlignment = Alignment.Center) {
                    PulseGlow(hueColor(ZN[z].hue), Modifier, 90.dp)
                    PreviewImage("z:$z", Modifier.size(width = 150.dp, height = 84.dp).clip(RoundedCornerShape(16.dp)).border(2.dp, Color(0xD9FFFFFF), RoundedCornerShape(16.dp)))
                }
                Tx(zn(z), 20f)
                GButton("CONTINUE", Modifier.width(180.dp), Kind.Gold, 44.dp) { UiBridge.fire("cont") }
            }
        }
        Confetti(z)
    }
}

@Composable
fun ReviveScreen(s: Snap) {
    val tr = rememberInfiniteTransition(label = "rev")
    val pulse by tr.animateFloat(0.94f, 1.08f, infiniteRepeatable(tween(550), RepeatMode.Reverse), label = "rp")
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Scrim(0.7f)
        Glass(Modifier.width(330.dp).popIn(), 28.dp) {
            Column(
                Modifier.padding(horizontal = 22.dp, vertical = 16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                GradText("REVIVE?", 28f)
                Box(
                    Modifier
                        .size(92.dp)
                        .graphicsLayer {
                            scaleX = pulse
                            scaleY = pulse
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val sw = 6.dp.toPx()
                        drawArc(Color(0x29FFFFFF), 0f, 360f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
                        drawArc(
                            Pal.Heart,
                            -90f,
                            360f * s.reviveF.toFloat(),
                            false,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                        )
                    }
                    HeartIcon(54.dp)
                }
                Tx(T("Hearts {0}   Cost {1}", s.hearts, s.reviveCost), 12.5f, color = Color(0xFFFFD0E0), weight = FontWeight.Bold)
                GButton("REVIVE", Modifier.fillMaxWidth(), Kind.Gold, 46.dp, heart = true) { UiBridge.fire("revive") }
                GButton("NO THANKS", Modifier.width(150.dp), Kind.Soft, 34.dp, 13f) { UiBridge.fire("skip") }
            }
        }
    }
}

@Composable
fun PreviewImage(key: String, modifier: Modifier = Modifier) {
    val ver = Previews.version.intValue
    LaunchedEffect(key) { Previews.request(key) }
    val bmp = remember(key, ver) { Previews.bitmaps[key]?.asImageBitmap() }
    val a by animateFloatAsState(if (bmp != null) 1f else 0f, tween(260), label = "pv")
    Box(modifier.alpha(a)) {
        if (bmp != null) {
            androidx.compose.foundation.Image(
                bitmap = bmp,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
        }
    }
}
