package com.imora.unicorndash

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

val bx = arrayOf(DoubleArray(4), DoubleArray(4))
val meBox = DoubleArray(4)

val LP: Array<DoubleArray> = Array(15) { i ->
    when (i) {
        0 -> doubleArrayOf(38.0, -70.0)
        1 -> doubleArrayOf(35.0, -45.0)
        2 -> doubleArrayOf(27.0, -52.0)
        3 -> doubleArrayOf(-44.0, -10.0)
        4 -> doubleArrayOf(-32.0, -26.0)
        5 -> doubleArrayOf(13.0, 0.0)
        6 -> doubleArrayOf(-12.0, 0.0)
        else -> {
            val k = (i - 7).toDouble()
            doubleArrayOf(20.0 * cos(k * PI / 4.0), -27.0 + 11.0 * sin(k * PI / 4.0))
        }
    }
}

fun go(n: Int, delay: Double = 0.0) {
    st = n
    stAt = nowMs() + delay
}

fun cover(cb: () -> Unit) {
    if (fadeDir > 0) return
    fadeDir = 1
    fadeCb = cb
}

fun skOn(k: String): Boolean = skAct > 0.0 && SKL[skillSel].k == k

fun ruleIs(r: String): Boolean {
    val l = lvl
    return l != null && l.rule == r
}

fun reset() {
    p = Player()
    p.x = max(90.0, L * 0.17)
    obs.clear()
    items.clear()
    for (q in parts) partPool.add(q)
    parts.clear()
    trail.clear()
    toast.text = ""
    toast.life = 0.0
    toast.max = 1.8
    banner.text = ""
    banner.sub = ""
    banner.life = 0.0
    banner.max = 2.8
    score = 0.0
    shown = 0.0
    coins = 0
    combo = 0
    comboT = 0.0
    shield = 0
    magnet = 0.0
    dash = 0.0
    grace = 0.0
    mile = 0
    buffer = 0.0
    runDist = 0.0
    runDodge = 0
    runCombo = 0
    dustT = 0.0
    hurt = 0
    lq = 0
    got = 0
    dbl = 0.0
    slow = 0.0
    mini = 0.0
    runNear = 0
    gAcc = 0.0
    runXp = 0
    pwRain = 0.0
    pwWing = 0.0
    pwSx = 0.0
    pwRainT = 0.0
    buddyKind = PT[petSel].kind
    buddyRevive = if (buddyKind == "phoenix") 1 else 0
    budY = if (buddyKind == "cat") G else G - 60.0
    skCd = 0.0
    skAct = 0.0
    skFlash = 0.0
    skFxT = -1.0
    lifeAt = 1500.0
    revUsed = 0
    revT = 0.0
    pendHit = null
    petGuard = 0
    catN = 0
    lastT = null
    lastT2 = null
    msc = 1.0
    pops.clear()
    recN = 0
    ghostD = null
    lbRank = -1
    speed = lvl?.sp ?: 320.0
    boost = 1.0
    gap = 520.0
    dist = 0.0
    t = 0.0
    shake = 0.0
    flash = 0.0
    acc = 0.0
    cd = 0.0
    newBest = false
    hint = if (stats.runs < 3) 5.0 else 0.0
}

fun nearMiss() {
    runNear++
    stats.near++
    score += 15.0
    punch = max(punch, 0.7)
    pops.add(Pop("Close call! +15", p.x + 14.0, p.y - 74.0, 1.1))
    snd("near")
}

fun spinAvail(): Boolean = spinDay != day

fun startSpin() {
    if (spinning) return
    if (!spinAvail()) {
        say("Come back tomorrow")
        snd("deny")
        return
    }
    val seg = TAU / SPIN.size
    var total = 0
    for (e in SPIN) total += e.weight
    var q = rnd() * total
    spinIdx = 0
    for (i in SPIN.indices) {
        q -= SPIN[i].weight
        if (q <= 0.0) {
            spinIdx = i
            break
        }
    }
    val a = (spinIdx + 0.15 + rnd() * 0.7) * seg
    spinFrom = spinA % TAU
    val tail = (((TAU - a - spinFrom) % TAU) + TAU) % TAU
    spinTo = spinFrom + TAU * (5 + Math.floor(rnd() * 2.0)) + tail
    spinT0 = nowMs()
    spinTick = Math.floor(spinFrom / seg).toInt()
    spinning = true
    spinDay = day
    if (SPIN[spinIdx].hearts) hearts += SPIN[spinIdx].amount else bank += SPIN[spinIdx].amount
    stats.spins++
    checkAch()
    save()
}

fun jump(): Boolean {
    if (p.dead) return false
    if (!p.air) {
        p.vy = -700.0
        p.air = true
        p.jumps = 1
        p.sq = 1.18
        snd("jump")
        buzz(8)
        for (i in 0 until 4) spark(p.x - 10.0 + i * 5.0, G - 2.0, -40.0 - rnd() * 60.0, -20.0 - rnd() * 30.0, 0.4, 3.0 + rnd() * 3.0, 40.0, 30.0, 88.0, 0.6, 0.2)
        return true
    }
    if (pwWing > 0.0 && !ruleIs("nodj")) {
        p.vy = -430.0
        p.sq = 1.12
        p.jumps = 1
        for (i in 0 until 6) spark(p.x - 8.0, p.y - 24.0, -60.0 - rnd() * 80.0, 10.0 + rnd() * 40.0, 0.45, 3.0 + rnd() * 3.0, 170.0, 60.0, 85.0, 0.7, 0.1)
        snd("flap")
        return true
    }
    if ((p.jumps < 2 || (skOn("moon") && p.jumps < 4)) && !ruleIs("nodj")) {
        p.vy = -620.0
        p.jumps = max(2, p.jumps + 1)
        mprog("dj", 1)
        p.sq = 1.14
        burst(p.x - 8.0, p.y - 10.0, 12, 300.0, 130.0)
        snd("djump")
        return true
    }
    return false
}

fun useSkill(): Boolean {
    if (st != 1 || cd > 0.0 || p.dead || skCd > 0.0 || skAct > 0.0) return false
    val sk = SKL[skillSel]
    val cy = p.y - 24.0
    val l = lvl
    if (l != null && l.boss) {
        say("Skills are off in final challenges")
        snd("deny")
        return false
    }
    if (sk.k == "aura" && shield > 0) {
        say("Shield already active")
        snd("deny")
        return false
    }
    if (sk.k == "moon" && ruleIs("nodj")) {
        say("Skill blocked here")
        snd("deny")
        return false
    }
    when (sk.k) {
        "dash" -> {
            dash = max(dash, sk.dur)
            shake = 4.0
        }
        "blast" -> {
            for (o in obs) {
                if (!o.dead && o.x > p.x - 20.0 && o.x < p.x + 420.0) {
                    o.dead = true
                    burst(o.x, G - 24.0, 12, 40.0, 220.0)
                }
            }
            shake = 8.0
            punch = 1.0
        }
        "candy" -> {
            pwRain = max(pwRain, 3.0)
            pwRainT = 0.0
            burst(p.x, cy, 16, 330.0, 200.0)
        }
        "warp" -> {
            val hop = 280.0
            burst(p.x, cy, 18, 270.0, 240.0)
            for (it in items) {
                if (it.x > p.x - 20.0 && it.x < p.x + hop) {
                    collect(it)
                    it.gone = true
                }
            }
            items.removeAll { it.gone }
            for (o in obs) o.x -= hop
            for (it in items) it.x -= hop
            for (o in obs) {
                val hw = o.pw / 2.0
                if (o.x + hw > p.x - 60.0 && o.x - hw < p.x + 160.0) o.dead = true
            }
            runDist += hop
            dist += hop
            if (lvl == null) gap -= hop
            grace = max(grace, 1.0)
            burst(p.x + 30.0, cy, 18, 270.0, 240.0)
            shake = 5.0
        }
        "aura" -> {
            shield = 1
            burst(p.x, cy, 18, 150.0, 200.0)
        }
    }
    if (sk.dur > 0.0) skAct = sk.dur else skCd = sk.cd
    skFxT = 0.0
    say(sk.name)
    snd("skill")
    buzz(25)
    return true
}

fun press() {
    if (st == 1 && cd <= 0.0 && !jump()) buffer = 0.12
}

fun clearPointers() {
    ptrIds.clear()
    ptrJumps = 0
    ptrDuck = false
    keyJump = false
    keyDuck = false
}

fun pause() {
    clearPointers()
    if (st == 1) go(3)
}

fun beginRun() {
    setZone(zi)
    lvl = if (mode == "adv") buildLevel(zi, li, null) else if (mode == "daily") buildLevel(zi, li, dcfg()) else null
    reset()
    val gk = if (mode == "daily") "D" else if (lvl != null) "L" + zi + "_" + li else "E" + zi
    val g = gh[gk]
    ghostD = if (opt.ghost && g != null && (mode != "daily" || g.day == day)) g.d else null
    val l = lvl
    val sb = StringBuilder()
    if (l != null) {
        sb.append(if (mode == "daily") T("DAILY CHALLENGE") else T("LEVEL {0}", li + 1))
        if (l.boss) sb.append(" - ").append(T("FINAL CHALLENGE"))
        if (l.rule != "") sb.append(" - ").append(T(ruleLabel(l.rule)))
    } else {
        sb.append(T("ENDLESS"))
    }
    banner.text = ZN[zi].name
    banner.sub = sb.toString()
    val hasRule = l != null && l.rule != ""
    banner.life = if (hasRule) 3.4 else 2.8
    banner.max = banner.life
    snd("zone")
    save()
    go(1)
}

fun startRun() {
    cover { beginRun() }
}

fun launch(m: String, z: Int, l: Int) {
    mode = m
    zi = z
    li = l
    startRun()
}

fun setZone(i: Int) {
    Z = zoneObj(i)
    lastZ = i
    ambInit()
}

fun toMenu() {
    cover {
        if (dRunHome >= 0) {
            zi = dRunHome
            setZone(dRunHome)
            dRunHome = -1
        }
        lvl = null
        reset()
        go(0)
    }
}

fun toLevels() {
    cover {
        lvl = null
        setZone(zi)
        reset()
        go(7)
    }
}

fun placeObs(at: Double, type: OT, w: Int, seed: Double, dx: Double) {
    val ox = if (lvl != null) p.x + at - runDist else L + 50.0 + dx
    val v = if (type == OT.bird) 1.12 else if (type == OT.fire) 1.1 else if (type == OT.boulder) 1.4 else 1.0
    val o = Obs(ox, type, w, seed, v)
    if (type == OT.pit) o.pw = 100.0 + 60.0 * (w - 1)
    obs.add(o)
    when (type) {
        OT.crystal, OT.spin, OT.fire, OT.spikes -> {
            for (i in 0 until 5) items.add(Item("coin", ox - 60.0 + i * 30.0, G - 38.0 - 90.0 * sin(PI * i / 4.0), i.toDouble(), v, false))
        }
        OT.pit -> {
            for (i in 0 until 5) items.add(Item("coin", ox - o.pw / 2.0 + i * o.pw / 4.0, G - 40.0 - 80.0 * sin(PI * i / 4.0), i.toDouble(), v, false))
        }
        OT.pillar, OT.wall -> {
            for (i in 0 until 5) items.add(Item("coin", ox - 60.0 + i * 30.0, G - 70.0 - 80.0 * sin(PI * i / 4.0), i.toDouble(), v, false))
        }
        OT.ice -> {
            for (i in 0 until 5) items.add(Item("coin", ox - 60.0 + i * 30.0, G - 16.0, i.toDouble(), v, false))
        }
        OT.boulder -> {
        }
        else -> {
            for (i in 0 until 3) items.add(Item("coin", ox - 30.0 + i * 30.0, G - 16.0, i.toDouble(), v, false))
        }
    }
}

fun place(e: Ev) {
    if (e.pu != null) {
        items.add(Item(e.pu, p.x + e.at - runDist, G - 62.0, rnd() * 6.0, 1.0, false))
        return
    }
    val tp = e.type ?: return
    placeObs(e.at, tp, e.w, e.seed, 0.0)
}

private val spawnList = OT.values()
private val spawnW = DoubleArray(OT.values().size)

fun spawn() {
    val d = min(score / 2500.0, 1.0)
    val zs = ZN[zi].zs
    val w = spawnW
    for (i in w.indices) w[i] = 0.0
    w[OT.crystal.ordinal] = 0.55
    w[OT.spikes.ordinal] = if (score > 15.0) 0.5 else 0.0
    w[OT.boulder.ordinal] = if (score > 100.0) 0.35 else 0.0
    w[OT.stormLow.ordinal] = if (score > 80.0) 0.3 + 0.1 * d else 0.0
    w[OT.stormHigh.ordinal] = if (score > 80.0) 0.2 + 0.12 * d else 0.0
    w[OT.swing.ordinal] = if (score > 180.0) 0.38 else 0.0
    w[OT.laser.ordinal] = if (score > 220.0) 0.38 else 0.0
    w[OT.wisp.ordinal] = if (score > 300.0) 0.14 else 0.0
    w[OT.pit.ordinal] = if (score > 120.0) 0.18 else 0.0
    w[OT.spin.ordinal] = if (score > 200.0) 0.15 else 0.0
    w[OT.bird.ordinal] = if (score > 260.0) 0.15 else 0.0
    w[OT.wall.ordinal] = if (score > 260.0) 0.33 else 0.0
    w[OT.pillar.ordinal] = if (score > 350.0) 0.12 else 0.0
    w[OT.ice.ordinal] = if (zs == "ice" && score > 60.0) 0.2 else 0.0
    w[OT.fire.ordinal] = if (zs == "fire" && score > 60.0) 0.3 else 0.0
    for (k in spawnList) {
        if (k == lastT) w[k.ordinal] *= 0.15
        else if (k == lastT2) w[k.ordinal] *= 0.55
    }
    if (score > 250.0 && rnd() < 0.12 + 0.16 * d) {
        val pool = ArrayList<List<ComboPart>>()
        for (c in COMBOS) {
            var ok = true
            for (e in c) if (!(w[e.type.ordinal] > 0.0 || e.type == lastT)) ok = false
            if (ok) pool.add(c)
        }
        for (c in ECOMBOS) {
            var ok = true
            for (e in c) if (!(w[e.type.ordinal] > 0.0 || e.type == lastT)) ok = false
            if (ok) pool.add(c)
        }
        if (pool.size > 0) {
            val c = pool[Math.floor(rnd() * pool.size).toInt()]
            var dx = 0.0
            for (i in c.indices) {
                val e = c[i]
                if (i > 0) dx += speed * e.after
                placeObs(0.0, e.type, e.w, rnd() * 99.0, dx)
            }
            lastT2 = if (c.size > 1) c[c.size - 2].type else lastT
            lastT = c[c.size - 1].type
            gap = dx + speed * (1.0 - 0.25 * d) + rnd() * speed * 0.6
            return
        }
    }
    var total = 0.0
    for (v in w) total += v
    var q = rnd() * total
    var type = OT.crystal
    for (k in spawnList) {
        q -= w[k.ordinal]
        if (q <= 0.0) {
            type = k
            break
        }
    }
    lastT2 = lastT
    lastT = type
    val wd = if ((type == OT.crystal && rnd() < 0.3 + 0.3 * d) || (type == OT.pit && rnd() < 0.3 + 0.3 * d)) 2 else 1
    placeObs(0.0, type, wd, rnd() * 99.0, 0.0)
    gap = speed * (0.92 - 0.28 * d) + rnd() * speed * 0.6 + (if (type == OT.pit) (if (wd == 2) 160.0 else 100.0) else 0.0)
    if (score > 150.0 && rnd() < 0.14) {
        val lv = if (score > 400.0) 9 else if (score > 250.0) 4 else 2
        items.add(Item(pickPu({ rnd() }, lv, false, score > 250.0), L + 50.0 + gap * 0.5, G - 62.0, rnd() * 6.0, 1.0, false))
    }
}

fun swingX(o: Obs): Double {
    val a = 0.85 * sin(t * 2.3 + o.seed)
    return o.x + 105.0 * sin(a)
}

fun swingY(o: Obs): Double {
    val a = 0.85 * sin(t * 2.3 + o.seed)
    return G - 140.0 + 105.0 * cos(a)
}

fun laserOn(o: Obs): Boolean = (t * 0.5 + o.seed) % 1.0 < 0.5

fun wispY(o: Obs): Double = G - 62.0 + sin(t * 3.2 + o.seed) * 34.0

private fun setBox(i: Int, a: Double, b: Double, c: Double, d: Double) {
    val r = bx[i]
    r[0] = a
    r[1] = b
    r[2] = c
    r[3] = d
}

fun boxes(o: Obs): Int {
    when (o.type) {
        OT.crystal -> {
            val hw = if (o.w == 2) 26.0 else 9.0
            setBox(0, o.x - hw, G - 32.0, o.x + hw, G)
            return 1
        }
        OT.spin -> {
            setBox(0, o.x - 14.0, G - 31.0, o.x + 14.0, G)
            return 1
        }
        OT.fire -> {
            setBox(0, o.x - 22.0, G - 30.0, o.x + 22.0, G)
            return 1
        }
        OT.pillar -> {
            setBox(0, o.x - 28.0, G - 26.0, o.x - 2.0, G)
            setBox(1, o.x - 2.0, G - 54.0, o.x + 24.0, G)
            return 2
        }
        OT.bird -> {
            setBox(0, o.x - 13.0, G - 53.0, o.x + 13.0, G - 35.0)
            return 1
        }
        OT.spikes -> {
            setBox(0, o.x - 34.0, G - 22.0, o.x + 34.0, G)
            return 1
        }
        OT.boulder -> {
            setBox(0, o.x - 15.0, G - 32.0, o.x + 15.0, G)
            return 1
        }
        OT.wall -> {
            setBox(0, o.x - 9.0, G - 80.0, o.x + 9.0, G)
            return 1
        }
        OT.swing -> {
            val bxx = swingX(o)
            val byy = swingY(o)
            setBox(0, bxx - 11.0, byy - 11.0, bxx + 11.0, byy + 11.0)
            return 1
        }
        OT.laser -> {
            if (!laserOn(o)) return 0
            setBox(0, o.x - 36.0, G - 36.0, o.x + 36.0, G - 28.0)
            return 1
        }
        else -> {
            val cy = if (o.type == OT.wisp) wispY(o) else if (o.type == OT.stormLow) G - 48.0 else G - 80.0
            setBox(0, o.x - 12.0, cy - 10.0, o.x + 12.0, cy + 10.0)
            return 1
        }
    }
}

fun collect(it: Item) {
    val pd = if (buddyKind == "fairy") 1.5 else 1.0
    if (it.k == "coin") {
        val prev = combo
        combo = if (comboT > 0.0) min(combo + 1, 5) else 1
        comboT = 1.6
        runCombo = max(runCombo, combo)
        if (combo == 5 && prev != 5) mprog("c5", 1)
        if ((combo == 3 || combo == 5) && prev != combo) {
            pops.add(Pop("x" + combo, p.x + 24.0, p.y - 60.0, 0.9))
            punch = max(punch, 0.6)
        }
        if (!it.bonus) got++
        coins += if (dbl > 0.0) 2 else 1
        if (buddyKind == "cat") {
            catN++
            if (catN % 10 == 0) {
                coins += 5
                pops.add(Pop("+5", p.x + 24.0, p.y - 84.0, 1.0))
                burst(p.x - 54.0, budY, 10, 330.0, 140.0)
            }
        }
        mprog("rcoins", coins)
        mprog("coins", 1)
        score += 5.0 * combo * (if (pwSx > 0.0) 2.0 else 1.0) * (if (buddyKind == "dragon") 1.2 else 1.0)
        burst(it.x, it.y, 7, 45.0, 120.0)
        snd("coin", combo.toDouble())
        return
    }
    mprog("pw", 1)
    stats.pw++
    when (it.k) {
        "shield" -> {
            shield = 1
            say("Shield ready")
            snd("shield")
        }
        "magnet" -> {
            magnet = 8.0 * pd
            say("Magnet on")
            snd("magnet")
        }
        "coin2" -> {
            dbl = 10.0 * pd
            say("Double coins")
            snd("coin2")
        }
        "slow" -> {
            slow = 5.0 * pd
            say("Slow motion")
            snd("slow")
        }
        "mini" -> {
            mini = 8.0 * pd
            say("Mini unicorn")
            snd("mini")
        }
        "rain" -> {
            pwRain = 6.0 * pd
            pwRainT = 0.0
            say("Coin rain")
            snd("rain")
        }
        "wings" -> {
            pwWing = 5.0 * pd
            say("Wings - tap to flap")
            snd("wings")
        }
        "life" -> {
            hearts++
            say("Heart +1")
            snd("life")
            save()
        }
        "sx2" -> {
            pwSx = 8.0 * pd
            say("Double score")
            snd("sx2")
        }
        else -> {
            dash = 6.0 * pd
            say("Rainbow Dash")
            snd("star")
            shake = 5.0
        }
    }
    burst(it.x, it.y, 16, puHue(it.k), 180.0)
    punch = 1.0
    buzz(20)
}

fun finishStats() {
    stats.runs++
    stats.coins += coins
    stats.dist += Math.floor(runDist / 80.0).toInt()
    stats.dodge += runDodge
    stats.bc = max(stats.bc, runCombo)
    mprog("score", Math.floor(score).toInt())
    mprog("runs", 1)
    unlockCosmetics(false)
    checkAch()
}

fun crash(o: Obs) {
    if (lvl != null || revUsed >= 3 || hearts < (1 shl revUsed)) {
        die(o)
        return
    }
    pendHit = o
    revT = 5.4
    go(14)
    clearPointers()
    shake = 10.0
    flash = 0.7
    punch = 1.0
    burst(p.x, p.y - 22.0, 22, 350.0, 240.0)
    snd("break")
    buzzPattern(longArrayOf(40, 30, 80))
}

fun reviveNow() {
    val o = pendHit
    pendHit = null
    hearts -= 1 shl revUsed
    revUsed++
    save()
    grace = 2.4
    buffer = 0.0
    if (o != null && o.type == OT.pit) {
        p.vy = -760.0
        p.air = true
        p.jumps = 1
    } else if (o != null) {
        o.dead = true
    }
    shake = 6.0
    punch = 1.0
    flash = 0.0
    burst(p.x, p.y - 22.0, 28, 335.0, 260.0)
    snd("revive")
    say("Heart used")
    buzz(60)
    go(1)
    cd = 3.0
    cdLast = 4
}

fun reviveSkip() {
    val o = pendHit
    pendHit = null
    die(o)
}

fun reviveTick(dt: Double) {
    revT -= dt
    if (revT <= 0.0) reviveSkip()
}

fun rescue(o: Obs): Boolean {
    if (buddyRevive == 0) return false
    buddyRevive = 0
    grace = 2.4
    for (q in obs) if (!q.dead && q.type != OT.pit && q.x < p.x + 520.0) q.dead = true
    if (o.type == OT.pit) {
        p.vy = -760.0
        p.air = true
        p.jumps = 1
    } else {
        o.dead = true
    }
    shake = 8.0
    punch = 1.0
    burst(p.x, p.y - 22.0, 26, 20.0, 260.0)
    snd("revive")
    say("Phoenix saved you")
    buzz(60)
    return true
}

fun die(o: Obs?) {
    val ty2 = o?.type
    val k = if (ty2 == OT.pit) "pit" else if (ty2 == OT.stormLow || ty2 == OT.stormHigh || ty2 == OT.wisp) "zap" else if (ty2 == OT.bird) "bird" else if (ty2 == OT.fire) "fire" else "impact"
    go(2, if (k == "zap") 1150.0 else 800.0)
    endAt = nowMs()
    p.dead = true
    punch = 1.2
    p.kind = k
    p.hy = p.y
    p.hold = 0.0
    p.rest = false
    p.landed = false
    p.bounces = 0
    p.endAng = -2.6
    p.spin = -7.0
    p.vx = -90.0
    p.vy = -380.0
    p.fall = false
    p.jx = 0.0
    shake = 12.0
    flash = 1.0
    burst(p.x, p.y - 22.0, 22, 330.0, 260.0)
    if (k == "pit" && o != null) {
        p.fall = true
        p.hasPit = true
        p.pit0 = o.x - o.pw / 2.0
        p.pit1 = o.x + o.pw / 2.0
        p.vy = 40.0
        p.vx = 0.0
        p.spin = -1.8
        shake = 5.0
        flash = 0.5
        for (i in 0 until 12) spark(p.x + (rnd() - 0.5) * 30.0, G - 2.0, (rnd() - 0.5) * 150.0, -30.0 - rnd() * 70.0, 0.5, 4.0 + rnd() * 5.0, 36.0, 28.0, 80.0, 0.7, 0.3)
        snd("fall")
    } else if (k == "zap") {
        p.hold = 0.38
        p.vy = -40.0
        p.vx = -30.0
        p.spin = -3.2
        shake = 7.0
        burst(p.x, p.y - 24.0, 26, 55.0, 280.0)
        snd("zap")
    } else if (k == "bird") {
        p.vx = -170.0
        p.vy = -260.0
        p.spin = -12.0
        for (i in 0 until 16) spark(p.x, p.y - 30.0, (rnd() - 0.5) * 220.0, -rnd() * 170.0, 0.9, 3.0 + rnd() * 4.0, 260.0, 30.0, 30.0, 0.9, 0.6)
        snd("break")
    } else if (k == "fire") {
        p.vx = -70.0
        p.vy = -300.0
        p.spin = -5.0
        burst(p.x, p.y - 20.0, 22, 22.0, 260.0)
    } else if (o != null) {
        if (ty2 == OT.crystal) {
            o.dead = true
            burst(o.x, G - 18.0, 18, (Z.hue + 40.0) % 360.0, 260.0)
            snd("break")
        } else if (ty2 == OT.spin) {
            burst(o.x, G - 16.0, 16, 50.0, 260.0)
        } else if (ty2 == OT.pillar) {
            p.vx = -150.0
            p.vy = -230.0
            for (i in 0 until 14) spark(o.x, G - 30.0, (rnd() - 0.5) * 200.0, -rnd() * 150.0, 0.7, 4.0 + rnd() * 5.0, 30.0, 20.0, 70.0, 0.7, 0.5)
        }
    }
    snd("die")
    buzzPattern(longArrayOf(40, 30, 120))
    bank += coins
    val sc = Math.floor(score).toInt()
    if (lvl != null) {
        newBest = false
    } else {
        newBest = sc > eb[zi]
        if (newBest) {
            eb[zi] = sc
            gh["E" + zi] = Ghost(sc.toDouble(), rec.copyOf(recN), 0)
        }
        if (sc > best) best = sc
        lbRank = addLb(zi, sc)
    }
    gainXp(Math.floor(sc / 10.0).toInt() + coins)
    finishStats()
    save()
}

fun win() {
    val l = lvl ?: return
    coast = speed
    p.vic = 1
    p.vt = 0.0
    p.vstart = max(speed, 1.0)
    p.happy = false
    p.rear = 0.0
    p.stand = 0
    p.apex = false
    p.neigh = false
    val all = got >= ceil(l.coins * CFG_COIN_PCT).toInt()
    val stars = booleanArrayOf(true, all, hurt == 0)
    var n = 0
    for (s in stars) if (s) n++
    val dly = mode == "daily"
    val prev = if (dly) 0 else prog[zi][li]
    val first = if (dly) dcDone != day else prev == 0
    val was = zoneOpen(zi + 1)
    val bonus: Int
    if (dly) {
        if (first) {
            dcStreak = if (dcDone == day - 1) dcStreak + 1 else 1
            dcDone = day
            dcBest = n
            dcWins++
            if (l.rule != "") dcRule++
        } else {
            dcBest = max(dcBest, n)
        }
        bonus = if (first) 60 + 20 * n + 10 * min(dcStreak, 7) else 10
    } else {
        prog[zi][li] = max(prev, n)
        bonus = if (first) 20 + zi * 5 + li * 2 else 5
    }
    bank += coins + bonus
    val tm = Math.round(t * 10.0) / 10.0
    val gk = if (dly) "D" else "L" + zi + "_" + li
    val old = gh[gk]
    if (dly) {
        if (old == null || old.day != day || tm < old.s) gh["D"] = Ghost(tm, rec.copyOf(recN), day)
    } else if (old == null || tm < old.s) {
        gh[gk] = Ghost(tm, rec.copyOf(recN), 0)
    }
    res = ResInfo(stars, n, bonus, first, l.coins, got, dly)
    unl = if (!dly && zi + 1 < ZN.size && !was && zoneOpen(zi + 1)) zi + 1 else -1
    stSnd = 0
    gainXp(40 + n * 25 + coins + (if (first) 60 else 0))
    finishStats()
    obs.clear()
    items.clear()
    trail.clear()
    for (i in 0 until 6) burst(p.x + 60.0, p.y - 40.0, 10, i * 60.0, 260.0)
    shake = 6.0
    punch = 0.8
    snd(if (n == 3) "fan3" else if (n == 2) "fan2" else "fan1")
    buzzPattern(longArrayOf(30, 40, 30, 40, 80))
    go(8, 2900.0)
    save()
}

fun landFx(imp: Double) {
    val cnt = 8 + Math.round(10.0 * imp).toInt()
    for (i in 0 until cnt) spark(p.x + (rnd() - 0.5) * 34.0, G - 2.0, (rnd() - 0.5) * (120.0 + 200.0 * imp), -20.0 - rnd() * (50.0 + 90.0 * imp), 0.55, 4.0 + rnd() * (4.0 + 4.0 * imp), 36.0, 28.0, 80.0, 0.65, 0.25)
    shake = max(shake, 3.0 + 7.0 * imp)
    snd("land", imp)
}

fun lowY(th: Double): Double {
    val c = cos(th)
    val sn = sin(th)
    var m = 0.0
    for (q in LP) m = max(m, q[0] * sn + q[1] * c)
    return m
}

fun settle(dt: Double) {
    p.py = p.y
    p.vt += dt
    val v = p.vic
    if (v == 1) {
        p.rt += dt * clamp(coast / p.vstart, 0.0, 1.0)
        if (p.vt > 0.6 && !p.air && coast < p.vstart * 0.18) {
            p.vic = 2
            p.vt = 0.0
            p.stand = 1
        }
    } else if (v == 2) {
        p.sq = lerp(1.0, 0.78, ease(clamp(p.vt / 0.2, 0.0, 1.0)))
        if (p.vt >= 0.2) {
            p.vic = 3
            p.vt = 0.0
            p.vy = -760.0
            p.air = true
            p.jumps = 1
            p.sq = 1.22
            p.happy = true
            for (i in 0 until 6) burst(p.x, p.y - 24.0, 6, i * 60.0 + 20.0, 220.0)
            snd("djump")
            buzz(20)
        }
    } else if (v == 3) {
        p.ang = lerp(-0.4, 0.32, ease(clamp(p.vt / 0.9, 0.0, 1.0)))
        if (!p.apex && p.vy > 0.0) {
            p.apex = true
            for (i in 0 until 8) burst(p.x + 8.0, p.y - 40.0, 6, i * 45.0 + 10.0, 200.0)
            snd("pop", 2.0)
        }
    } else if (v == 4) {
        val uu = p.vt
        p.rear = if (uu < 0.28) ease(uu / 0.28) else if (uu < 0.83) 1.0 + 0.04 * sin((uu - 0.28) * 14.0) else 1.0 - ease(clamp((uu - 0.83) / 0.25, 0.0, 1.0))
        if (uu >= 0.28 && !p.neigh) {
            p.neigh = true
            snd("neigh")
            for (i in 0 until 6) burst(p.x - 10.0, p.y - 80.0, 6, i * 60.0 + 10.0, 220.0)
        }
        if (uu >= 1.08) {
            p.vic = 5
            p.vt = 0.0
            p.rear = 0.0
            landFx(0.2)
        }
    }
    p.vy += (if (v == 3) 1700.0 else FALL) * dt
    p.y += p.vy * dt
    if (p.y >= G) {
        if (p.air && v == 3) {
            p.vic = 4
            p.vt = 0.0
            p.neigh = false
            p.sq = 0.8
            p.ang = 0.0
            landFx(0.5)
            snd("pop", 1.0)
            for (i in 0 until 3) burst(p.x + 10.0, p.y - 30.0, 6, i * 110.0 + 20.0, 180.0)
        }
        p.y = G
        p.vy = 0.0
        p.air = false
    }
    if (p.vic != 3) p.ang = damp(p.ang, 0.0, 10.0, dt)
    if (p.vic == 5 && rnd() < dt * 3.0) spark(p.x + (rnd() - 0.5) * 60.0, p.y - 30.0 - rnd() * 40.0, 0.0, -20.0, 0.8, 5.0, 48.0, 100.0, 78.0, 0.8, 0.0)
    p.dk = damp(p.dk, 0.0, 14.0, dt)
    if (p.vic != 2) p.sq = damp(p.sq, 1.0, 14.0, dt)
}

fun deadStep(dt: Double) {
    val k = lerp(0.25, 1.0, easeOut(clamp((nowMs() - endAt) / 700.0, 0.0, 1.0)))
    val d = dt * k
    p.py = p.y
    if (p.fall) {
        p.vy += 1900.0 * d
        p.y += p.vy * d
        p.x = damp(p.x, clamp(p.x, p.pit0 + 20.0, p.pit1 - 20.0), 9.0, d)
        p.ang += p.spin * d
        if (p.y > G + 140.0) {
            p.y = G + 140.0
            p.vy = 0.0
        }
        p.air = true
        return
    }
    if (p.rest) {
        p.x += p.vx * d
        p.vx = damp(p.vx, 0.0, 6.0, d)
        p.ang = damp(p.ang, p.endAng, 7.0, d)
        p.y = G - lowY(p.ang)
        p.air = false
        return
    }
    if (p.hold > 0.0) {
        p.hold -= d
        p.y = p.hy - 4.0 + sin(clock * 60.0) * 2.4
        p.jx = sin(clock * 90.0) * 2.5
        p.ang = sin(clock * 55.0) * 0.14
        p.vy = -40.0
        if (p.hold <= 0.0) {
            p.jx = 0.0
            p.ang = 0.0
            p.vy = 0.0
        }
        p.air = true
        return
    }
    p.vy += 2200.0 * d
    p.y += p.vy * d
    p.x += p.vx * d
    p.vx = damp(p.vx, 0.0, 3.0, d)
    p.ang += p.spin * d
    val gy = G - lowY(p.ang)
    if (p.y >= gy) {
        p.y = gy
        landFx(clamp(p.vy / 1100.0, 0.0, 1.0))
        if (p.vy > 260.0 && p.bounces < 1) {
            p.bounces++
            p.vy *= -0.3
            p.spin *= 0.5
        } else {
            p.vy = 0.0
            p.rest = true
            p.landed = true
            p.ang = p.endAng + Math.round((p.ang - p.endAng) / 6.2832) * 6.2832
        }
    }
    p.air = !p.rest
}

fun effects(dt: Double) {
    shown += (score - shown) * (1.0 - exp(-dt * 12.0))
    shake *= exp(-dt * 9.0)
    punch *= exp(-dt * 9.0)
    flash = max(0.0, flash - dt * 2.0)
    toast.life = max(0.0, toast.life - dt)
    if (toast.life <= 0.0 && tq.size > 0) {
        toast.text = tq.removeAt(0)
        toast.life = 1.8
        toast.max = 1.8
    }
    banner.life = max(0.0, banner.life - dt)
    var w = 0
    for (i in 0 until pops.size) {
        val q = pops[i]
        q.life -= dt
        q.y -= 34.0 * dt
        if (q.life > 0.0) pops[w++] = q
    }
    while (pops.size > w) pops.removeAt(pops.size - 1)
    if (st == 2 && p.dead && !p.fall && nowMs() - endAt < 2600.0) {
        if ((p.kind == "fire" || p.kind == "zap") && rnd() < dt * 22.0) spark(p.x + (rnd() - 0.5) * 24.0, p.y - 14.0 - rnd() * 14.0, (rnd() - 0.5) * 16.0, -26.0 - rnd() * 24.0, 1.1, 6.0 + rnd() * 4.0, 0.0, 0.0, 50.0 + rnd() * 18.0, 0.42, -0.25)
        if (p.kind == "fire" && rnd() < dt * 30.0) spark(p.x + (rnd() - 0.5) * 26.0, p.y - 10.0 - rnd() * 16.0, (rnd() - 0.5) * 30.0, -40.0 - rnd() * 40.0, 0.8, 3.0 + rnd() * 2.0, 24.0, 100.0, 60.0, 0.9, -0.35)
    }
    stepParts(dt)
}

fun nearOnIce(): Boolean {
    if (p.air) return false
    for (o in obs) if (o.type == OT.ice && abs(o.x - p.x) < 66.0) return true
    return false
}

fun update(dt: Double) {
    t += dt
    frame++
    val onIce = nearOnIce()
    val bt = if (skOn("freeze")) 0.3 else if (dash > 0.0) 1.4 else if (slow > 0.0) 0.7 else if (onIce) 1.28 else 1.0
    boost = damp(boost, bt, if (skOn("freeze")) 8.0 else 3.2, dt)
    val l = lvl
    speed = (if (l != null) l.sp else 320.0 + 360.0 * (1.0 - exp(-score / 3000.0)) + 140.0 * (1.0 - exp(-max(0.0, score - 1500.0) / 8000.0))) * boost
    dist += speed * dt
    runDist += speed * dt
    score += speed * dt * 0.05 * (if (dash > 0.0) 1.4 else 1.0) * (if (pwSx > 0.0) 2.0 else 1.0) * (if (buddyKind == "dragon") 1.2 else 1.0)
    hint = max(0.0, hint - dt)
    gAcc += dt
    while (gAcc >= 0.1) {
        gAcc -= 0.1
        if (recN < 1500) {
            rec[recN++] = Math.round(clamp(G - p.y, 0.0, 300.0) / 2.0).toInt() + (if (p.duck) 1000 else 0)
        }
    }
    p.duck = (keyDuck || ptrDuck) && !ruleIs("noduck")
    p.dk = damp(p.dk, if (p.duck) 1.0 else 0.0, 24.0, dt)
    val held = keyJump || ptrJumps > 0

    p.py = p.y
    var g = FALL
    if (p.vy < 0.0) g = if (held) RISE_HELD else RISE_FREE
    else if (p.duck && p.air) g = FALL * 2.0
    if (pwWing > 0.0) g = if (p.duck) 1800.0 else 1250.0
    if (skOn("moon")) g *= 0.5
    p.vy += g * dt
    p.y += p.vy * dt
    if ((pwWing > 0.0 || skOn("moon")) && p.y < G - 170.0) {
        p.y = G - 170.0
        if (p.vy < 0.0) p.vy = 0.0
    }
    if (p.y >= G) {
        if (p.air) {
            val imp = clamp(p.vy / 1100.0, 0.0, 1.0)
            p.sq = 0.9 - 0.12 * imp
            for (i in 0 until 6) spark(p.x + (rnd() - 0.5) * 18.0, G - 2.0, (rnd() - 0.5) * 160.0, -20.0 - rnd() * 50.0, 0.45, 3.0 + rnd() * 3.0, 40.0, 30.0, 88.0, 0.6, 0.25)
            snd("land", imp)
        }
        p.y = G
        p.vy = 0.0
        p.air = false
        p.jumps = 0
        if (buffer > 0.0) jump()
    }
    buffer = max(0.0, buffer - dt)
    p.rt += dt
    stats.time += dt
    p.sq = damp(p.sq, 1.0, 14.0, dt)
    p.ang = damp(p.ang, clamp(p.vy * 0.0004, -0.28, 0.28), 12.0, dt)
    budY = damp(budY, if (buddyKind == "cat") G - (G - p.y) * 0.72 else p.y - 62.0 + sin(t * 5.0) * 7.0, 9.0, dt)

    dustT -= dt
    if (!p.air && dustT <= 0.0) {
        dustT = 0.075
        spark(p.x - 14.0, G - 2.0, -speed * 0.18 - rnd() * 30.0, -16.0 - rnd() * 24.0, 0.42, 3.0 + rnd() * 3.0, 40.0, 30.0, 88.0, 0.5, 0.2)
    }

    trailT -= dt
    if (trailT <= 0.0) {
        trailT = 0.05
        trailFx()
    }
    if (frame % 2 == 0) trail.add(TrailPt(p.y - lerp(28.0, 16.0, p.dk), t))
    while (trail.size > 0 && t - trail[0].t > 0.4) trail.removeAt(0)

    if (l != null) {
        while (lq < l.ev.size && p.x + l.ev[lq].at - runDist <= L + 50.0) {
            place(l.ev[lq])
            lq++
        }
    } else {
        gap -= speed * dt
        if (gap <= 0.0) spawn()
    }
    for (o in obs) o.x -= speed * dt * o.v
    for (o in obs) {
        if (!o.passed && o.x < p.x - 30.0) {
            o.passed = true
            runDodge++
            mprog("dodge", 1)
            if (o.nm && !o.dead) nearMiss()
        }
    }
    obs.removeAll { !(it.x > -60.0 && !it.dead) }

    if (pwRain > 0.0) {
        pwRainT -= dt
        while (pwRainT <= 0.0) {
            pwRainT += 0.11
            items.add(Item("coin", L + 30.0 + rnd() * 40.0, G - 24.0 - rnd() * 150.0, rnd() * 6.0, 1.0, true))
        }
    }
    val cx = p.x
    val cy = p.y - 22.0
    val pull = magnet > 0.0 || dash > 0.0
    for (it in items) {
        it.x -= speed * dt * it.v
        if (pull && it.k == "coin") {
            val dx = cx - it.x
            val dy = cy - it.y
            val d = hypot(dx, dy)
            if (d < 210.0 && d > 1.0) {
                val sp = 950.0 * (1.0 - d / 260.0) + 300.0
                it.x += dx / d * sp * dt
                it.y += dy / d * sp * dt
            }
        }
        if (hypot(cx - it.x, cy - it.y) < 28.0) {
            collect(it)
            it.gone = true
        }
    }
    items.removeAll { it.gone || !(it.x > -30.0) }

    if (skOn("fire")) {
        for (o in obs) {
            if (!o.dead && o.type != OT.pit && o.type != OT.ice && o.x > p.x - 25.0 && o.x < p.x + 200.0) {
                o.dead = true
                burst(o.x, G - 26.0, 12, 22.0, 240.0)
                snd("break")
            }
        }
        for (i in 0 until 2) spark(p.x + 24.0 + rnd() * 10.0, p.y - 30.0 + rnd() * 10.0, 220.0 + rnd() * 180.0, -rnd() * 50.0, 0.35 + rnd() * 0.2, 5.0 + rnd() * 5.0, 15.0 + rnd() * 35.0, 100.0, 60.0, 0.9, -0.1)
    }
    if (skOn("freeze")) {
        for (i in 0 until 2) spark(rnd() * L, -10.0, -30.0, 80.0 + rnd() * 60.0, 1.4, 3.0 + rnd() * 2.0, 195.0, 80.0, 90.0, 0.8, 0.15)
    }
    if (mini > 0.0) {
        meBox[0] = p.x - 7.0
        meBox[1] = p.y - lerp(27.0, 15.0, p.dk)
        meBox[2] = p.x + 7.0
        meBox[3] = p.y - 5.0
    } else {
        meBox[0] = p.x - 11.0
        meBox[1] = p.y - lerp(42.0, 22.0, p.dk)
        meBox[2] = p.x + 11.0
        meBox[3] = p.y - 7.0
    }
    for (o in obs) {
        if (o.dead || o.type == OT.ice) continue
        if (o.type == OT.pit) {
            if (!p.air && dash <= 0.0 && grace <= 0.0 && p.x + 8.0 > o.x - o.pw / 2.0 && p.x - 8.0 < o.x + o.pw / 2.0) {
                if (rescue(o)) continue
                crash(o)
                return
            }
            continue
        }
        val bn = boxes(o)
        var hit = false
        for (i in 0 until bn) {
            val b = bx[i]
            if (meBox[0] < b[2] && meBox[2] > b[0] && meBox[1] < b[3] && meBox[3] > b[1]) hit = true
        }
        if (!hit) {
            if (!o.nm) {
                for (i in 0 until bn) {
                    val b = bx[i]
                    val dx = max(b[0] - meBox[2], meBox[0] - b[2])
                    val dy = max(b[1] - meBox[3], meBox[1] - b[3])
                    if (dx < 0.0 && dy >= 0.0 && dy < 8.0) o.nm = true
                }
            }
            continue
        }
        if (dash > 0.0) {
            o.dead = true
            score += if (buddyKind == "dragon") 24.0 else 20.0
            shake = 5.0
            burst(o.x, (bx[0][1] + bx[0][3]) / 2.0, 14, 48.0, 220.0)
            snd("break")
            buzz(18)
        } else if (grace > 0.0) {
            continue
        } else if (petGuard > 0) {
            petGuard = 0
            grace = 1.2
            o.dead = true
            shake = 8.0
            burst(p.x, p.y - 22.0, 20, 190.0, 220.0)
            snd("break")
            buzz(50)
        } else if (shield > 0) {
            shield = 0
            grace = 1.2
            hurt = 1
            o.dead = true
            shake = 8.0
            burst(p.x, p.y - 22.0, 20, 190.0, 220.0)
            snd("break")
            buzz(50)
            say("Shield broken")
        } else if (rescue(o)) {
            continue
        } else {
            crash(o)
            return
        }
    }

    comboT -= dt
    if (comboT <= 0.0) combo = 0
    magnet = max(0.0, magnet - dt)
    dbl = max(0.0, dbl - dt)
    slow = max(0.0, slow - dt)
    mini = max(0.0, mini - dt)
    pwRain = max(0.0, pwRain - dt)
    pwSx = max(0.0, pwSx - dt)
    if (l == null && score >= lifeAt) {
        lifeAt += 2000.0
        hearts++
        say("Bonus life")
        snd("life")
        save()
    }
    if (skAct > 0.0) {
        skAct = max(0.0, skAct - dt)
        if (skAct <= 0.0) skCd = SKL[skillSel].cd
    } else if (skCd > 0.0) {
        skCd = max(0.0, skCd - dt)
        if (skCd <= 0.0) {
            skFlash = 0.7
            snd("ready")
        }
    }
    skFlash = max(0.0, skFlash - dt)
    if (skFxT >= 0.0) {
        skFxT += dt
        if (skFxT > 0.5) skFxT = -1.0
    }
    val wasWing = pwWing > 0.0
    pwWing = max(0.0, pwWing - dt)
    if (wasWing && pwWing <= 0.0) grace = max(grace, 0.8)
    msc = damp(msc, if (mini > 0.0) 0.62 else 1.0, 10.0, dt)
    val wasDash = dash > 0.0
    dash = max(0.0, dash - dt)
    if (wasDash && dash <= 0.0) grace = 1.0
    grace = max(0.0, grace - dt)

    if (l == null) {
        val m = Math.floor(score / 250.0).toInt()
        if (m > mile) {
            mile = m
            val msgs = arrayOf("", "Nice run", "Rainbow speed", "Unstoppable", "Legend")
            say(msgs[min(m, 4)])
            snd("milestone")
        }
    } else if (runDist >= l.len) {
        win()
    }
}
