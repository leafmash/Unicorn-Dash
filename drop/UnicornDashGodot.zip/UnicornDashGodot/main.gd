extends Node2D

const VW := 1280.0
const VH := 576.0
const WIDE := 2800.0
const FLOOR := 474.0
const UNI_X := 250.0
const UNI_SCALE := 0.42
const FEET := 350.0
const GRAVITY := 2700.0
const JUMP_V := -820.0
const HOLD_G := 0.6
const MAX_JUMPS := 2
const START_SPEED := 430.0
const MAX_SPEED := 980.0
const TAIL_DX := -38.0
const TAIL_DY := -66.0
const TRAIL_LEN := 280.0


const OBS := {
	"rock": {"w": 70.0, "h": 52.0},
	"crystal": {"w": 48.0, "h": 86.0},
	"bush": {"w": 76.0, "h": 44.0}
}

enum State { READY, PLAYING, DEAD }

var rainbow: Array = [
	Color("ff5f8d"), Color("ffb05f"), Color("ffe066"),
	Color("6fe3a5"), Color("5fb8ff"), Color("a56bff")
]
var state: int = State.READY
var speed := START_SPEED
var distance := 0.0
var score := 0
var coins := 0
var best := 0
var uy := FLOOR
var vy := 0.0
var jumps := 0
var held := false
var spawn_gap := 600.0
var run_time := 0.0
var shake := 0.0
var fps_timer := 0.0

var bg: Node2D
var world: Node2D
var uni: AnimatedSprite2D
var sparks: CPUParticles2D
var lines: Array[Line2D] = []
var trail: Array[Vector2] = []
var layers: Array = []
var clouds: Array = []
var obstacles: Array = []
var items: Array = []

var ui: CanvasLayer
var score_label: Label
var coin_label: Label
var fps_label: Label
var ready_box: Control
var ready_label: Label
var over_panel: PanelContainer
var over_score: Label
var over_best: Label


func _ready() -> void:
	randomize()
	Engine.max_fps = 0
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
	load_best()
	build_background()
	build_world()
	build_ui()
	show_ready()


func build_background() -> void:
	bg = Node2D.new()
	add_child(bg)

	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	g.colors = PackedColorArray([Color("6a46b8"), Color("d77fcf"), Color("ffc9b8")])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.width = 8
	gt.height = 256
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	var sky := Sprite2D.new()
	sky.texture = gt
	sky.centered = false
	sky.scale = Vector2(WIDE / 8.0, (VH + 400.0) / 256.0)
	bg.add_child(sky)

	var sun := Sprite2D.new()
	sun.texture = load("res://art/sun.png")
	sun.position = Vector2(980, 150)
	sun.scale = Vector2(1.1, 1.1)
	sun.modulate = Color(1, 1, 1, 0.85)
	bg.add_child(sun)

	make_layer("res://art/rainbow.png", FLOOR - 440.0 + 40.0, 0.03)

	for i in 5:
		var c := Sprite2D.new()
		c.texture = load("res://art/cloud%d.png" % (i % 3))
		c.position = Vector2(randf_range(0, VW + 300), randf_range(40, 230))
		var s := randf_range(0.6, 1.1)
		c.scale = Vector2(s, s)
		c.modulate = Color(1, 1, 1, randf_range(0.45, 0.8))
		bg.add_child(c)
		clouds.append({"node": c, "f": randf_range(0.03, 0.12)})

	make_layer("res://art/far.png", FLOOR - 330.0 + 40.0, 0.07)
	make_layer("res://art/mid.png", FLOOR - 250.0 + 30.0, 0.16)
	make_layer("res://art/near.png", FLOOR - 190.0 + 34.0, 0.42)
	make_layer("res://art/ground.png", FLOOR - 14.0, 1.0)


func make_layer(path: String, y: float, factor: float) -> void:
	var tex: Texture2D = load(path)
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	s.position = Vector2(0, y)
	s.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	s.region_enabled = true
	s.region_rect = Rect2(0, 0, WIDE, tex.get_height())
	bg.add_child(s)
	layers.append({"node": s, "f": factor, "w": float(tex.get_width()), "h": float(tex.get_height()), "off": 0.0})


func build_world() -> void:
	world = Node2D.new()
	add_child(world)

	for k in 6:
		var ln := Line2D.new()
		ln.width = 8.6
		ln.begin_cap_mode = Line2D.LINE_CAP_ROUND
		ln.end_cap_mode = Line2D.LINE_CAP_ROUND
		ln.joint_mode = Line2D.LINE_JOINT_ROUND
		ln.antialiased = true
		var gr := Gradient.new()
		var c: Color = rainbow[k]
		gr.offsets = PackedFloat32Array([0.0, 0.7, 1.0])
		gr.colors = PackedColorArray([Color(c.r, c.g, c.b, 0.0), Color(c.r, c.g, c.b, 0.85), c])
		ln.gradient = gr
		world.add_child(ln)
		lines.append(ln)

	sparks = CPUParticles2D.new()
	sparks.texture = load("res://art/spark.png")
	sparks.amount = 28
	sparks.lifetime = 0.7
	sparks.local_coords = false
	sparks.direction = Vector2(-1, 0)
	sparks.spread = 35.0
	sparks.gravity = Vector2.ZERO
	sparks.initial_velocity_min = 60.0
	sparks.initial_velocity_max = 160.0
	sparks.scale_amount_min = 0.15
	sparks.scale_amount_max = 0.4
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 1, 0.85, 1), Color(1, 0.7, 1, 0)])
	sparks.color_ramp = cg
	sparks.emitting = false
	world.add_child(sparks)

	uni = AnimatedSprite2D.new()
	uni.sprite_frames = build_frames()
	uni.centered = false
	uni.offset = Vector2(-192, -FEET)
	uni.scale = Vector2(UNI_SCALE, UNI_SCALE)
	uni.position = Vector2(UNI_X, uy)
	world.add_child(uni)
	uni.play("run")


func build_frames() -> SpriteFrames:
	var sheet: Texture2D = load("res://art/unicorn.png")
	var sf := SpriteFrames.new()
	sf.add_animation("run")
	sf.set_animation_speed("run", 12.0)
	sf.set_animation_loop("run", true)
	for i in 4:
		var a := AtlasTexture.new()
		a.atlas = sheet
		a.region = Rect2(i * 384, 0, 384, 384)
		sf.add_frame("run", a)
	sf.add_animation("jump")
	sf.set_animation_speed("jump", 1.0)
	sf.set_animation_loop("jump", false)
	var j := AtlasTexture.new()
	j.atlas = sheet
	j.region = Rect2(4 * 384, 0, 384, 384)
	sf.add_frame("jump", j)
	return sf


func make_label(size: int, color: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color("2a1670"))
	l.add_theme_constant_override("outline_size", 10)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)

	score_label = make_label(36, Color.WHITE)
	score_label.position = Vector2(36, 16)
	ui.add_child(score_label)

	coin_label = make_label(36, Color("ffe27a"))
	coin_label.anchor_left = 1.0
	coin_label.anchor_right = 1.0
	coin_label.offset_left = -300.0
	coin_label.offset_right = -36.0
	coin_label.offset_top = 16.0
	coin_label.offset_bottom = 70.0
	coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ui.add_child(coin_label)

	fps_label = make_label(16, Color("c9b8ff"))
	fps_label.anchor_left = 0.5
	fps_label.anchor_right = 0.5
	fps_label.offset_left = -80.0
	fps_label.offset_right = 80.0
	fps_label.offset_top = 8.0
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(fps_label)

	ready_box = Control.new()
	ready_box.set_anchors_preset(Control.PRESET_FULL_RECT)
	ready_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(ready_box)

	var title := make_label(78, Color("ffffff"))
	title.text = "UNICORN DASH"
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	title.grow_horizontal = Control.GROW_DIRECTION_BOTH
	title.offset_top = 70.0
	ready_box.add_child(title)

	ready_label = make_label(40, Color("ffe27a"))
	ready_label.text = "TAP TO RUN"
	ready_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	ready_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	ready_label.offset_top = 170.0
	ready_box.add_child(ready_label)

	var hint := make_label(22, Color("e6dcff"))
	hint.text = "Hold to jump higher  -  tap again in the air for a double jump"
	hint.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hint.grow_horizontal = Control.GROW_DIRECTION_BOTH
	hint.offset_top = 230.0
	ready_box.add_child(hint)

	over_panel = PanelContainer.new()
	over_panel.set_anchors_preset(Control.PRESET_CENTER)
	over_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	over_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.17, 0.08, 0.4, 0.95)
	sb.set_corner_radius_all(30)
	sb.set_border_width_all(3)
	sb.border_color = Color("9a7bd9")
	sb.content_margin_left = 48
	sb.content_margin_right = 48
	sb.content_margin_top = 28
	sb.content_margin_bottom = 32
	over_panel.add_theme_stylebox_override("panel", sb)
	ui.add_child(over_panel)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	over_panel.add_child(box)

	var ot := make_label(54, Color("ff8fc7"))
	ot.text = "GAME OVER"
	ot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(ot)

	over_score = make_label(32, Color.WHITE)
	over_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_score)

	over_best = make_label(26, Color("ffe27a"))
	over_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_best)

	var btn := Button.new()
	btn.text = "RETRY"
	btn.custom_minimum_size = Vector2(280, 68)
	btn.add_theme_font_size_override("font_size", 32)
	btn.add_theme_color_override("font_color", Color.WHITE)
	btn.add_theme_color_override("font_hover_color", Color.WHITE)
	btn.add_theme_color_override("font_pressed_color", Color.WHITE)
	btn.add_theme_stylebox_override("normal", button_style(Color("b45cff")))
	btn.add_theme_stylebox_override("hover", button_style(Color("c27cff")))
	btn.add_theme_stylebox_override("pressed", button_style(Color("8f3fe0")))
	btn.add_theme_stylebox_override("focus", button_style(Color("b45cff")))
	btn.pressed.connect(on_retry)
	box.add_child(btn)


func button_style(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(24)
	s.set_border_width_all(3)
	s.border_color = Color("e9d2ff")
	return s


func show_ready() -> void:
	state = State.READY
	ready_box.visible = true
	over_panel.visible = false
	update_hud()


func start_run() -> void:
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	trail.clear()
	speed = START_SPEED
	distance = 0.0
	score = 0
	coins = 0
	uy = FLOOR
	vy = 0.0
	jumps = 0
	spawn_gap = 700.0
	shake = 0.0
	world.position = Vector2.ZERO
	state = State.PLAYING
	ready_box.visible = false
	over_panel.visible = false
	sparks.emitting = true
	update_hud()


func on_retry() -> void:
	start_run()


func press() -> void:
	if state == State.READY:
		start_run()
		do_jump()
	elif state == State.PLAYING:
		do_jump()


func do_jump() -> void:
	if jumps >= MAX_JUMPS:
		return
	vy = JUMP_V if jumps == 0 else JUMP_V * 0.92
	jumps += 1
	pop(Vector2(UNI_X - 20.0, uy - 6.0), 8, 0.6)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		held = event.pressed
		if event.pressed:
			press()
	elif event is InputEventKey and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_UP:
			held = event.pressed
			if event.pressed:
				press()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		held = false


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	run_time += delta
	if state == State.PLAYING:
		update_play(delta)
	elif state == State.READY:
		scroll_layers(START_SPEED * 0.35 * delta)
	scroll_clouds(delta)
	update_visuals(delta)
	fps_timer += delta
	if fps_timer >= 0.5:
		fps_timer = 0.0
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()


func update_play(delta: float) -> void:
	speed = minf(MAX_SPEED, START_SPEED + distance * 0.02)
	var dx := speed * delta
	distance += dx
	var new_score := int(distance / 10.0)
	if new_score != score:
		score = new_score
		update_hud()
	var g := GRAVITY
	if held and vy < 0.0:
		g *= HOLD_G
	vy += g * delta
	uy += vy * delta
	if uy >= FLOOR:
		if vy > 300.0:
			pop(Vector2(UNI_X, FLOOR), 6, 0.5)
		uy = FLOOR
		vy = 0.0
		jumps = 0
	scroll_layers(dx)
	move_things(dx)
	spawn_gap -= dx
	if spawn_gap <= 0.0:
		spawn_pattern()
	check_hits()
	update_trail(dx)
	sparks.position = Vector2(UNI_X + TAIL_DX, uy + TAIL_DY)
	sparks.initial_velocity_min = speed * 0.6
	sparks.initial_velocity_max = speed * 1.0 + 60.0


func scroll_layers(dx: float) -> void:
	for l in layers:
		var off: float = fmod(l["off"] + dx * l["f"], l["w"])
		l["off"] = off
		var s: Sprite2D = l["node"]
		s.region_rect = Rect2(off, 0.0, WIDE, l["h"])


func scroll_clouds(delta: float) -> void:
	var base := speed if state == State.PLAYING else START_SPEED * 0.35
	for c in clouds:
		var n: Sprite2D = c["node"]
		n.position.x -= (base * c["f"] + 10.0) * delta
		if n.position.x < -380.0:
			n.position.x = get_viewport_rect().size.x + randf_range(40.0, 300.0)
			n.position.y = randf_range(40.0, 230.0)


func move_things(dx: float) -> void:
	for i in range(obstacles.size() - 1, -1, -1):
		var o: Dictionary = obstacles[i]
		var n: Sprite2D = o["node"]
		n.position.x -= dx
		if n.position.x < -200.0:
			n.queue_free()
			obstacles.remove_at(i)
	for i in range(items.size() - 1, -1, -1):
		var it: Dictionary = items[i]
		var n: Sprite2D = it["node"]
		n.position.x -= dx
		if n.position.x < -80.0:
			n.queue_free()
			items.remove_at(i)


func spawn_pattern() -> void:
	var x := get_viewport_rect().size.x + 140.0
	var r := randf()
	var extra := 0.0
	if r < 0.5:
		add_obstacle(pick_kind(), x)
		add_coin_arc(x, 5, 130.0)
	elif r < 0.78:
		add_obstacle(pick_kind(), x)
		add_obstacle(pick_kind(), x + 250.0)
		add_coin_arc(x + 125.0, 7, 170.0)
		extra = 250.0
	else:
		add_coin_line(x, 8, FLOOR - 70.0 - randf() * 90.0)
		extra = 0.0
	spawn_gap = speed * randf_range(0.95, 1.45) + 280.0 + extra


func pick_kind() -> String:
	var keys := OBS.keys()
	return keys[randi() % keys.size()]


func add_obstacle(kind: String, x: float) -> void:
	var s := Sprite2D.new()
	s.texture = load("res://art/%s.png" % kind)
	s.centered = false
	s.offset = Vector2(-128, -250)
	s.scale = Vector2(0.5, 0.5)
	s.position = Vector2(x, FLOOR + 2.0)
	world.add_child(s)
	world.move_child(s, uni.get_index())
	obstacles.append({"node": s, "w": OBS[kind]["w"], "h": OBS[kind]["h"]})


func add_coin(x: float, y: float) -> void:
	var s := Sprite2D.new()
	s.texture = load("res://art/coin.png")
	s.scale = Vector2(0.3, 0.3)
	s.position = Vector2(x, y)
	world.add_child(s)
	items.append({"node": s, "ph": randf() * 6.28, "y": y})


func add_coin_arc(cx: float, count: int, height: float) -> void:
	for i in count:
		var t := float(i) / float(count - 1)
		add_coin(cx - 120.0 + t * 240.0, FLOOR - 50.0 - sin(t * PI) * height)


func add_coin_line(x: float, count: int, y: float) -> void:
	for i in count:
		add_coin(x + i * 62.0, y)


func check_hits() -> void:
	var ur := Rect2(UNI_X - 34.0, uy - 82.0, 66.0, 76.0)
	for o in obstacles:
		var n: Sprite2D = o["node"]
		var w: float = o["w"]
		var h: float = o["h"]
		var orect := Rect2(n.position.x - w * 0.5, FLOOR - h, w, h)
		if ur.intersects(orect):
			die()
			return
	var center := Vector2(UNI_X, uy - 58.0)
	for i in range(items.size() - 1, -1, -1):
		var n: Sprite2D = items[i]["node"]
		if n.position.distance_to(center) < 52.0:
			pop(n.position, 10, 1.0)
			n.queue_free()
			items.remove_at(i)
			coins += 1
			update_hud()


func die() -> void:
	state = State.DEAD
	shake = 18.0
	sparks.emitting = false
	if score > best:
		best = score
		save_best()
	over_score.text = "Score  %d" % score
	over_best.text = "Best  %d     Coins  %d" % [best, coins]
	over_panel.visible = true
	uni.play("jump")
	pop(Vector2(UNI_X, uy - 50.0), 18, 1.4)


func update_trail(dx: float) -> void:
	for i in trail.size():
		trail[i] = Vector2(trail[i].x - dx, trail[i].y)
	var anchor_x := UNI_X + TAIL_DX
	trail.append(Vector2(anchor_x, uy + TAIL_DY))
	while trail.size() > 0 and trail[0].x < anchor_x - TRAIL_LEN:
		trail.remove_at(0)
	var n := trail.size()
	for k in 6:
		var pts := PackedVector2Array()
		for i in n:
			var p := trail[i]
			var age := 1.0 - float(i) / float(maxi(n - 1, 1))
			var wave := sin(p.x * 0.028 + run_time * 9.0) * 7.0 * age
			pts.append(Vector2(p.x, p.y + (float(k) - 2.5) * 7.6 + wave))
		lines[k].points = pts


func update_visuals(delta: float) -> void:
	uni.position = Vector2(UNI_X, uy)
	if state == State.PLAYING:
		if uy < FLOOR - 1.0:
			if uni.animation != "jump":
				uni.play("jump")
		else:
			if uni.animation != "run" or not uni.is_playing():
				uni.play("run")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
	elif state == State.READY:
		if uni.animation != "run" or not uni.is_playing():
			uni.play("run")
		uni.speed_scale = 0.6
		if lines.size() > 0:
			for ln in lines:
				ln.points = PackedVector2Array()
	for it in items:
		var n: Sprite2D = it["node"]
		n.scale.x = 0.3 * absf(cos(run_time * 5.0 + it["ph"])) + 0.05
		n.position.y = float(it["y"]) + sin(run_time * 4.0 + it["ph"]) * 5.0
	if shake > 0.2:
		shake = lerpf(shake, 0.0, minf(1.0, delta * 9.0))
		world.position = Vector2(randf_range(-shake, shake), randf_range(-shake, shake))
	else:
		world.position = Vector2.ZERO
	if state == State.READY:
		ready_label.modulate.a = 0.55 + 0.45 * absf(sin(run_time * 3.0))


func update_hud() -> void:
	score_label.text = "%d" % score
	coin_label.text = "%d" % coins
	score_label.visible = state != State.READY
	coin_label.visible = state != State.READY


func pop(pos: Vector2, count: int, power: float) -> void:
	var p := CPUParticles2D.new()
	p.texture = load("res://art/spark.png")
	p.position = pos
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = count
	p.lifetime = 0.6
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 80.0 * power
	p.initial_velocity_max = 220.0 * power
	p.scale_amount_min = 0.2
	p.scale_amount_max = 0.5
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 0.95, 0.6, 1), Color(1, 0.6, 1, 0)])
	p.color_ramp = cg
	world.add_child(p)
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func load_best() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save.cfg") == OK:
		best = int(cf.get_value("run", "best", 0))


func save_best() -> void:
	var cf := ConfigFile.new()
	cf.set_value("run", "best", best)
	cf.save("user://save.cfg")
