extends Node2D

const Cp := preload("res://cp_kit.gd")
const CpHome := preload("res://cp_home.gd")
const CpLoading := preload("res://cp_loading.gd")
const MENU_FEET := 440.0
const MENU_SCALE := 0.56
const VW := 1280.0
const VH := 576.0
const WIDE := 2800.0
const FLOOR := 474.0
const UNI_X := 250.0
const UNI_SCALE := 0.42
const FEET := 352.0
const UNI_ANCHOR := 230.0
const S := 1.68
const GRAVITY := 2700.0
const JUMP_V := -820.0
const HOLD_G := 0.6
const DUCK_FALL := 2.0
const MAX_JUMPS := 2
const START_SPEED := 430.0
const MAX_SPEED := 980.0
const TAIL_DX := -72.0
const TAIL_DY := -24.0
const TRAIL_LEN := 280.0
const FR := 384
const LEVELS_PER_ZONE := 10
const ZONE_NEED := 7
const PER_PAGE := 6
const ICE_BOOST := 1.3

const KIT_COLORS: Dictionary = {
	"pink": "ff5fa8",
	"blue": "4a86e8",
	"green": "3fc98a",
	"orange": "f2a93c",
	"purple": "b45cff",
	"red": "ff6b6b",
	"indigo": "5a3cb0",
	"rose": "ff5f8d",
	"grey": "574780",
	"dark": "473d66"
}

const POWER_POOL: Array = ["shield", "shield", "shield", "magnet", "magnet", "magnet", "x2", "x2", "x2", "slow", "slow", "heart"]

const SKINS: Array = [
	{"name": "Classic", "cost": 0, "body": "ffffff", "hue": 0.0},
	{"name": "Rose", "cost": 100, "body": "ffcfe6", "hue": 0.0},
	{"name": "Mint", "cost": 150, "body": "c9ffe2", "hue": 0.3},
	{"name": "Sky", "cost": 200, "body": "cfe6ff", "hue": -0.3},
	{"name": "Sunny", "cost": 300, "body": "fff0b0", "hue": 0.12},
	{"name": "Midnight", "cost": 500, "body": "8f86cc", "hue": 0.55}
]

const TRAILS: Array = [
	{"name": "Rainbow", "cost": 0, "c": ["ff5f8d", "ffb05f", "ffe066", "6fe3a5", "5fb8ff", "a56bff"]},
	{"name": "Fire", "cost": 80, "c": ["ff2d2d", "ff5a1f", "ff8a1f", "ffb81f", "ffd84a", "fff08a"]},
	{"name": "Ocean", "cost": 120, "c": ["0a4682", "0f6e9e", "1c9ac0", "3cc4d0", "7ae4dc", "c4f6f0"]},
	{"name": "Candy", "cost": 160, "c": ["ff5fa8", "ff8cc4", "ffb3d9", "ffd0ea", "c9a8ff", "a58bff"]},
	{"name": "Neon", "cost": 240, "c": ["00f0ff", "00ffa8", "a8ff00", "ffee00", "ff2fd2", "a82fff"]},
	{"name": "Gold", "cost": 400, "c": ["8a5a10", "b8801c", "e0a828", "ffc83c", "ffe27a", "fff4c4"]}
]

const HORNS: Array = [
	{"name": "Classic", "cost": 0, "c": "ffffff", "n": 0},
	{"name": "Starlight", "cost": 120, "c": "fff2a0", "n": 14},
	{"name": "Flame", "cost": 180, "c": "ff8a3c", "n": 18},
	{"name": "Frost", "cost": 240, "c": "9fe8ff", "n": 16},
	{"name": "Heart", "cost": 320, "c": "ff7ac8", "n": 14}
]

const PETS: Array = [
	{"name": "Bunny", "cost": 150, "desc": "Pulls nearby coins"},
	{"name": "Fox", "cost": 300, "desc": "Every 5th coin pays +1"},
	{"name": "Owl", "cost": 500, "desc": "Starts runs with a shield"},
	{"name": "Dragon", "cost": 800, "desc": "+1 heart every run"}
]

const SKILLS: Array = [
	{"id": "magnet", "name": "Magnet Time", "desc": "+2s magnet", "base": 100},
	{"id": "shield", "name": "Shield Time", "desc": "+2s shield", "base": 100},
	{"id": "x2", "name": "Coin Boost", "desc": "+3s coins x2", "base": 100},
	{"id": "slow", "name": "Slow Time", "desc": "+1.5s slow", "base": 100},
	{"id": "life", "name": "Extra Heart", "desc": "+1 starting heart", "base": 250},
	{"id": "luck", "name": "Power Luck", "desc": "More power-ups", "base": 150},
	{"id": "combo", "name": "Combo Time", "desc": "+0.4s combo window", "base": 120},
	{"id": "float", "name": "Float Jump", "desc": "Higher held jump", "base": 150}
]

const SKIN_SHADER := """shader_type canvas_item;
uniform vec4 body : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float hue = 0.0;
void fragment() {
	vec4 c = texture(TEXTURE, UV);
	float a_mod = COLOR.a;
	float mx = max(c.r, max(c.g, c.b));
	float mn = min(c.r, min(c.g, c.b));
	float w = 1.0 - smoothstep(0.06, 0.26, mx - mn);
	float a = hue * 6.28318;
	float cs = cos(a);
	float sn = sin(a);
	mat3 m = mat3(
		vec3(0.299 + 0.701 * cs + 0.168 * sn, 0.587 - 0.587 * cs + 0.330 * sn, 0.114 - 0.114 * cs - 0.497 * sn),
		vec3(0.299 - 0.299 * cs - 0.328 * sn, 0.587 + 0.413 * cs + 0.035 * sn, 0.114 - 0.114 * cs + 0.292 * sn),
		vec3(0.299 - 0.300 * cs + 1.250 * sn, 0.587 - 0.588 * cs - 1.050 * sn, 0.114 + 0.886 * cs - 0.203 * sn));
	vec3 rot = c.rgb * m;
	vec3 tinted = c.rgb * body.rgb;
	COLOR = vec4(mix(clamp(rot, 0.0, 1.0), tinted, w), c.a * a_mod);
}
"""

const KINDS := {
	"crystal1": {"n": 1, "fps": 1.0, "sheet": "crystal1", "boxes": [[-9.0, 9.0, 0.0, 32.0]], "v": 1.0, "lift": 0.0},
	"crystal2": {"n": 1, "fps": 1.0, "sheet": "crystal2", "boxes": [[-26.0, 26.0, 0.0, 32.0]], "v": 1.0, "lift": 0.0},
	"spikes": {"n": 1, "fps": 1.0, "sheet": "spikes", "boxes": [[-34.0, 34.0, 0.0, 22.0]], "v": 1.0, "lift": 0.0},
	"boulder": {"n": 8, "fps": 10.0, "sheet": "boulder", "boxes": [[-15.0, 15.0, 0.0, 32.0]], "v": 1.4, "lift": 0.0},
	"wall": {"n": 1, "fps": 1.0, "sheet": "wall", "boxes": [[-9.0, 9.0, 0.0, 80.0]], "v": 1.0, "lift": 0.0},
	"pillar": {"n": 1, "fps": 1.0, "sheet": "pillar", "boxes": [[-28.0, -2.0, 0.0, 26.0], [-2.0, 24.0, 0.0, 54.0]], "v": 1.0, "lift": 0.0},
	"bird": {"n": 6, "fps": 14.0, "sheet": "bird", "boxes": [[-13.0, 13.0, 35.0, 53.0]], "v": 1.12, "lift": 0.0},
	"storm_low": {"n": 8, "fps": 11.0, "sheet": "storm_low", "boxes": [[-12.0, 12.0, 38.0, 58.0]], "v": 1.0, "lift": 0.0},
	"storm_high": {"n": 8, "fps": 11.0, "sheet": "storm_low", "boxes": [[-12.0, 12.0, 70.0, 90.0]], "v": 1.0, "lift": 32.0},
	"spin": {"n": 8, "fps": 11.0, "sheet": "spin", "boxes": [[-14.0, 14.0, 0.0, 31.0]], "v": 1.0, "lift": 0.0},
	"fire": {"n": 8, "fps": 11.0, "sheet": "fire", "boxes": [[-22.0, 22.0, 0.0, 30.0]], "v": 1.1, "lift": 0.0},
	"ice": {"n": 1, "fps": 1.0, "sheet": "ice", "boxes": [], "v": 1.0, "lift": 0.0},
	"pit": {"n": 1, "fps": 1.0, "sheet": "pit", "boxes": [], "v": 1.0, "lift": 0.0},
	"swing": {"n": 1, "fps": 1.0, "sheet": "swing", "boxes": [], "v": 1.0, "lift": 0.0},
	"laser": {"n": 2, "fps": 1.0, "sheet": "laser", "boxes": [[-5.0, 5.0, 0.0, 64.0]], "v": 1.0, "lift": 0.0},
	"wisp": {"n": 8, "fps": 12.0, "sheet": "wisp", "boxes": [], "v": 1.0, "lift": 0.0}
}

const ZONES: Array = [
	{"name": "Rainbow Meadow", "sky": ["6a46b8", "d77fcf", "ffc9b8"], "far": ["c8a0ee", "d7b7f5"], "near": ["8c64d2", "a888e6"], "gr": ["3f9a74", "86e29c"], "night": 0.0, "fx": "none", "zs": "", "raw": true},
	{"name": "Candy Clouds", "sky": ["ff9ed8", "ffd0ea", "fff1d6"], "far": ["e87fb8", "ffb3d9"], "near": ["d65f9e", "ff8fc4"], "gr": ["d4679f", "ffc2de"], "night": 0.0, "fx": "petal", "zs": ""},
	{"name": "Starlight Night", "sky": ["120c38", "3a2478", "7a4aa8"], "far": ["2a1f66", "4a3a96"], "near": ["1c1448", "34286e"], "gr": ["143a4a", "2a7a86"], "night": 1.0, "fx": "firefly", "zs": ""},
	{"name": "Frozen Peaks", "sky": ["12356b", "6fb4e0", "d6f0fa"], "far": ["6f9fd6", "bcdcf2"], "near": ["a8cbe8", "eaf6ff"], "gr": ["b8d8ec", "ffffff"], "night": 0.35, "fx": "snow", "zs": "ice"},
	{"name": "Sunset Dunes", "sky": ["ff7054", "ffa070", "ffd9a0"], "far": ["b45878", "e58a7a"], "near": ["8c3a66", "c46a70"], "gr": ["c8803c", "f0b868"], "night": 0.0, "fx": "dust", "zs": ""},
	{"name": "Ember Realm", "sky": ["280818", "8a2a1e", "e0642a"], "far": ["5a1c2c", "8c3040"], "near": ["3c1424", "662038"], "gr": ["3a1c1c", "ff7030"], "night": 0.5, "fx": "ember", "zs": "fire"},
	{"name": "Crystal Caves", "sky": ["1c0a40", "5a2e90", "a070d0"], "far": ["462a80", "7a52b8"], "near": ["30205f", "5c3d98"], "gr": ["3c2a70", "a070f0"], "night": 0.7, "fx": "sparkle", "zs": ""},
	{"name": "Enchanted Forest", "sky": ["0e3c40", "3a8a6a", "b8e8a0"], "far": ["1f6a52", "3f9a72"], "near": ["124c3c", "2a7a52"], "gr": ["1e5a38", "58c070"], "night": 0.25, "fx": "firefly", "zs": ""},
	{"name": "Cloud Kingdom", "sky": ["6aaaff", "b8d4ff", "fff0e0"], "far": ["a8c4f0", "e0ecff"], "near": ["d0dcf8", "ffffff"], "gr": ["dfe8fb", "ffffff"], "night": 0.0, "fx": "sparkle", "zs": ""},
	{"name": "Neon City", "sky": ["08022c", "601070", "c0309a"], "far": ["28105a", "5a2aa0"], "near": ["180a3c", "3a1c78"], "gr": ["140c38", "00e0ff"], "night": 0.9, "fx": "sparkle", "zs": ""},
	{"name": "Deep Ocean", "sky": ["021850", "0f6e9e", "3cb4c8"], "far": ["0a4682", "1c78b0"], "near": ["06306a", "14609a"], "gr": ["14606e", "30c0b8"], "night": 0.5, "fx": "bubble", "zs": "jelly"},
	{"name": "Autumn Hills", "sky": ["ff9a50", "ffc88a", "ffe8b8"], "far": ["c8643c", "e8905a"], "near": ["a04630", "d0703c"], "gr": ["8a5a2a", "e0a040"], "night": 0.0, "fx": "leaf", "zs": ""},
	{"name": "Desert Oasis", "sky": ["2a9cc8", "90d0d0", "fff0c0"], "far": ["d8b070", "f0d090"], "near": ["c09058", "e4b878"], "gr": ["d4a860", "58c090"], "night": 0.0, "fx": "dust", "zs": ""},
	{"name": "Haunted Mist", "sky": ["14122c", "505a78", "a0acc0"], "far": ["3c4468", "5a6690"], "near": ["283050", "44507a"], "gr": ["303846", "76a088"], "night": 0.6, "fx": "mist", "zs": "ghost"},
	{"name": "Space Rings", "sky": ["02020e", "30206a", "6a4aa8"], "far": ["463482", "7a62c8"], "near": ["2a1c62", "4a38a0"], "gr": ["262658", "a094ff"], "night": 1.0, "fx": "sparkle", "zs": ""},
	{"name": "Rainbow Waterfall", "sky": ["78c8ff", "d0e8ff", "ffe6fa"], "far": ["68b0e0", "a0dcf0"], "near": ["4c90d4", "80c8e8"], "gr": ["60d0b8", "ffaadc"], "night": 0.0, "fx": "bubble", "zs": ""},
	{"name": "Moon Garden", "sky": ["141448", "5a5aa8", "b0b0e8"], "far": ["4a4a94", "7878c0"], "near": ["36407a", "5c68a8"], "gr": ["3c6a80", "a0e8e8"], "night": 0.8, "fx": "firefly", "zs": ""},
	{"name": "Golden Temple", "sky": ["ffae50", "ffd890", "fff4cc"], "far": ["d0884a", "f0b868"], "near": ["a8643a", "d8943e"], "gr": ["c8963c", "ffd668"], "night": 0.0, "fx": "sparkle", "zs": ""}
]

const LUM := {
	"far": [0.58, 0.70],
	"mid": [0.625, 0.75],
	"near": [0.37, 0.49],
	"ground": [0.34, 0.76]
}

const FX := {
	"snow": {"pf": [0.6, -0.04], "ef": [0.75, 0.02], "dir": [0.0, 1.0], "spread": 25.0, "grav": [-40.0, 70.0], "v0": 20.0, "v1": 55.0, "s0": 0.1, "s1": 0.28, "life": 6.5, "n": 70, "col": "ffffff", "a": 0.9, "add": false},
	"petal": {"pf": [0.6, -0.04], "ef": [0.75, 0.02], "dir": [0.0, 1.0], "spread": 30.0, "grav": [-60.0, 50.0], "v0": 15.0, "v1": 45.0, "s0": 0.12, "s1": 0.3, "life": 7.0, "n": 26, "col": "ffb8dc", "a": 0.85, "add": false},
	"leaf": {"pf": [0.6, -0.04], "ef": [0.75, 0.02], "dir": [0.0, 1.0], "spread": 40.0, "grav": [-90.0, 60.0], "v0": 20.0, "v1": 60.0, "s0": 0.14, "s1": 0.3, "life": 6.0, "n": 22, "col": "e0782c", "a": 0.9, "add": false},
	"ember": {"pf": [0.5, 1.04], "ef": [0.6, 0.02], "dir": [0.0, -1.0], "spread": 30.0, "grav": [-60.0, -40.0], "v0": 40.0, "v1": 110.0, "s0": 0.1, "s1": 0.3, "life": 3.5, "n": 50, "col": "ff8a3c", "a": 1.0, "add": true},
	"bubble": {"pf": [0.5, 1.04], "ef": [0.6, 0.02], "dir": [0.0, -1.0], "spread": 20.0, "grav": [-20.0, -30.0], "v0": 20.0, "v1": 60.0, "s0": 0.12, "s1": 0.4, "life": 6.0, "n": 30, "col": "b8f0ff", "a": 0.55, "add": false},
	"firefly": {"pf": [0.5, 0.45], "ef": [0.6, 0.3], "dir": [0.0, -1.0], "spread": 180.0, "grav": [-10.0, 0.0], "v0": 6.0, "v1": 22.0, "s0": 0.1, "s1": 0.26, "life": 3.5, "n": 30, "col": "eaff7a", "a": 1.0, "add": true},
	"sparkle": {"pf": [0.5, 0.4], "ef": [0.6, 0.35], "dir": [0.0, -1.0], "spread": 180.0, "grav": [-20.0, 0.0], "v0": 5.0, "v1": 25.0, "s0": 0.1, "s1": 0.3, "life": 2.4, "n": 34, "col": "ffd6f6", "a": 1.0, "add": true},
	"dust": {"pf": [1.02, 0.6], "ef": [0.02, 0.3], "dir": [-1.0, 0.0], "spread": 8.0, "grav": [0.0, 0.0], "v0": 160.0, "v1": 320.0, "s0": 0.08, "s1": 0.22, "life": 4.0, "n": 26, "col": "ffe4b0", "a": 0.4, "add": false},
	"mist": {"pf": [1.05, 0.7], "ef": [0.03, 0.25], "dir": [-1.0, 0.0], "spread": 10.0, "grav": [0.0, 0.0], "v0": 30.0, "v1": 70.0, "s0": 1.0, "s1": 2.2, "life": 16.0, "n": 12, "col": "dfe8f5", "a": 0.12, "add": false}
}

const RHYTHMS: Array = [
	[1.0, 1.0, 1.2, 0.9],
	[1.1, 0.9, 1.1, 0.9, 1.3],
	[1.0, 1.3, 0.85, 1.15],
	[0.95, 1.2, 1.0, 1.2, 0.9],
	[1.25, 0.9, 0.9, 1.1]
]

const COMBOS: Array = [
	[["spikes", 0.0], ["storm_low", 1.0]],
	[["wall", 0.0], ["spikes", 1.1]],
	[["crystal2", 0.0], ["crystal2", 0.9], ["bird", 1.1]],
	[["pit", 0.0], ["crystal1", 1.05]],
	[["storm_high", 0.0], ["pit", 1.1]],
	[["spin", 0.0], ["spin", 0.9], ["storm_low", 1.1]],
	[["swing", 0.0], ["spikes", 1.15]],
	[["laser", 0.0], ["crystal1", 1.0]],
	[["boulder", 0.0], ["crystal2", 1.3]],
	[["fire", 0.0], ["bird", 1.0], ["crystal1", 1.1]],
	[["wisp", 0.0], ["spikes", 1.0]],
	[["pillar", 0.0], ["bird", 1.0]]
]

const LAYER_SHADER := """shader_type canvas_item;
uniform vec4 c_dark : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform vec4 c_light : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float l0 = 0.0;
uniform float l1 = 1.0;
void fragment() {
	vec4 t = texture(TEXTURE, UV);
	float l = dot(t.rgb, vec3(0.299, 0.587, 0.114));
	float k = clamp((l - l0) / max(l1 - l0, 0.001), 0.0, 1.0);
	COLOR = vec4(mix(c_dark.rgb, c_light.rgb, k), t.a);
}
"""

const MISSION_REWARD := 50
const SPIN_COST := 60
const SPIN_PRIZES: Array = [20, 50, 30, 100, 40, 200, 60, 500]
const SPIN_WEIGHTS: Array = [25, 15, 20, 8, 15, 5, 10, 2]
const SPIN_COLORS: Array = ["ff5fa8", "4a86e8", "3fc98a", "f2a93c", "b45cff", "ff6b6b", "2ec4b6", "ffd23f"]

const MISSION_TYPES: Array = [
	{"t": "coins", "d": "Collect %d coins", "lo": 60, "hi": 160, "step": 10},
	{"t": "score", "d": "Score %d points in total", "lo": 800, "hi": 2400, "step": 100},
	{"t": "levels", "d": "Clear %d levels", "lo": 2, "hi": 4, "step": 1},
	{"t": "powers", "d": "Collect %d power-ups", "lo": 3, "hi": 7, "step": 1},
	{"t": "combo", "d": "Reach a x%d combo", "lo": 8, "hi": 16, "step": 1},
	{"t": "runs", "d": "Play %d runs", "lo": 4, "hi": 8, "step": 1}
]

const ACHS: Array = [
	{"id": "runs1", "n": "First Steps", "d": "Play 1 run", "s": "runs", "t": 1, "r": 20},
	{"id": "coin1", "n": "Coin Collector", "d": "Collect 500 coins", "s": "coins", "t": 500, "r": 50},
	{"id": "coin2", "n": "Coin Hoarder", "d": "Collect 5000 coins", "s": "coins", "t": 5000, "r": 200},
	{"id": "dist1", "n": "Marathon", "d": "Score 10000 points in total", "s": "score", "t": 10000, "r": 100},
	{"id": "lvl1", "n": "Level Climber", "d": "Clear 10 levels", "s": "cleared", "t": 10, "r": 60},
	{"id": "star1", "n": "Star Hunter", "d": "Earn 50 stars", "s": "stars", "t": 50, "r": 120},
	{"id": "zone1", "n": "Zone Hopper", "d": "Unlock 5 zones", "s": "zones", "t": 5, "r": 100},
	{"id": "boss1", "n": "Boss Slayer", "d": "Beat 3 zone bosses", "s": "bosses", "t": 3, "r": 150},
	{"id": "combo1", "n": "Combo King", "d": "Reach a x20 combo", "s": "combo", "t": 20, "r": 80},
	{"id": "pow1", "n": "Power Player", "d": "Collect 30 power-ups", "s": "powers", "t": 30, "r": 80},
	{"id": "pet1", "n": "Pet Owner", "d": "Own a pet", "s": "pets", "t": 1, "r": 60},
	{"id": "style1", "n": "Fashionista", "d": "Own 5 style items", "s": "style", "t": 5, "r": 100},
	{"id": "spin1", "n": "Lucky Spinner", "d": "Spin the wheel 5 times", "s": "spins", "t": 5, "r": 60},
	{"id": "daily1", "n": "Daily Hero", "d": "Finish 5 daily challenges", "s": "daily", "t": 5, "r": 150},
	{"id": "end1", "n": "Endless Champion", "d": "Score 3000 in Endless", "s": "best", "t": 3000, "r": 150},
	{"id": "lvl10", "n": "Rising Star", "d": "Reach player level 10", "s": "plevel", "t": 10, "r": 200}
]

const BN := {
	"UNICORN DASH": "ইউনিকর্ন ড্যাশ",
	"%d/%d XP": "%d/%d এক্সপি",
	"DAILY MISSIONS": "দৈনিক মিশন",
	"Day %d streak": "%d দিনের স্ট্রিক",
	"BEST %d": "সেরা %d",
	"DONE": "সম্পন্ন",
	"PLAYER": "প্লেয়ার",
	"BOARD": "র‍্যাংক",
	"Loading...": "লোড হচ্ছে...",
	"Hold the screen to jump higher": "স্ক্রিন চেপে ধরলে লাফ উঁচু হয়",
	"Collect coins to unlock new unicorns": "কয়েন জমিয়ে নতুন ইউনিকর্ন আনলক করো",
	"Finish the daily challenge for a bonus": "দৈনিক চ্যালেঞ্জ শেষ করলে বোনাস মেলে",
	"Claim your awards from the Awards page": "পুরস্কার পেজ থেকে অ্যাওয়ার্ড ক্লেম করো",
	"Near misses build your combo": "কাছাকাছি এড়ালে কম্বো বাড়ে",
	"ADVENTURE": "অ্যাডভেঞ্চার",
	"ENDLESS": "অন্তহীন",
	"SHOP": "দোকান",
	"MISSIONS": "মিশন",
	"DAILY": "দৈনিক",
	"SPIN": "স্পিন",
	"AWARDS": "পুরস্কার",
	"STATS": "পরিসংখ্যান",
	"SETTINGS": "সেটিংস",
	"BACK": "পিছনে",
	"TAP TO RUN": "দৌড় শুরু করতে ট্যাপ করুন",
	"Right side: tap to jump, hold higher, tap again for double jump  -  Left side: hold to duck": "ডান পাশ: ট্যাপে লাফ, চেপে ধরলে উঁচু, আবার ট্যাপে ডাবল জাম্প  -  বাম পাশ: চেপে ধরলে নিচু",
	"GAME OVER": "খেলা শেষ",
	"LEVEL FAILED": "লেভেল ব্যর্থ",
	"REVIVE": "আবার বাঁচুন",
	"REVIVE   -%d": "আবার বাঁচুন   -%d",
	"RETRY": "আবার চেষ্টা",
	"LEVELS": "লেভেল",
	"ZONES": "জোন",
	"MENU": "মেনু",
	"PAUSED": "বিরতি",
	"RESUME": "চালিয়ে যান",
	"RESTART": "নতুন করে শুরু",
	"LEVEL COMPLETE": "লেভেল সম্পূর্ণ",
	"ZONE BOSS DEFEATED": "জোন বস পরাজিত",
	"NEXT": "পরেরটি",
	"Stars  %d / %d": "তারা  %d / %d",
	"LOCKED": "বন্ধ",
	"Clear %d levels in": "%dটি লেভেল শেষ করুন:",
	"%d / %d cleared   %d stars": "%d / %d শেষ   %d তারা",
	"Best  %d": "সেরা  %d",
	"BOSS": "বস",
	"FINAL CHALLENGE": "চূড়ান্ত চ্যালেঞ্জ",
	"DAILY CHALLENGE": "দৈনিক চ্যালেঞ্জ",
	"LEVEL %d": "লেভেল %d",
	"Score  %d": "স্কোর  %d",
	"Best  %d     Coins  %d     Combo  x%d": "সেরা  %d     কয়েন  %d     কম্বো  x%d",
	"Progress  %d%%": "অগ্রগতি  %d%%",
	"Coins  %d     Pickups  %d / %d": "কয়েন  %d     সংগ্রহ  %d / %d",
	"Coins  %d     Pickups  %d / %d  (%d%%)": "কয়েন  %d     সংগ্রহ  %d / %d  (%d%%)",
	"ZONE UNLOCKED  -  %s": "জোন খুলেছে  -  %s",
	"COMBO x%d": "কম্বো x%d",
	"Not enough coins": "কয়েন যথেষ্ট নেই",
	"EQUIPPED": "ব্যবহার হচ্ছে",
	"Tap to equip": "ব্যবহার করতে ট্যাপ করুন",
	"Buy  %d": "কিনুন  %d",
	"Upgrade  %d": "আপগ্রেড  %d",
	"MAX": "সর্বোচ্চ",
	"Lv %d/%d": "লেভেল %d/%d",
	"SKINS": "স্কিন",
	"TRAILS": "ট্রেইল",
	"HORNS": "শিং",
	"PETS": "সঙ্গী",
	"SKILLS": "স্কিল",
	"Rainbow Meadow": "রংধনু মাঠ",
	"Candy Clouds": "ক্যান্ডি মেঘ",
	"Starlight Night": "তারার রাত",
	"Frozen Peaks": "বরফ চূড়া",
	"Sunset Dunes": "সূর্যাস্তের বালিয়াড়ি",
	"Ember Realm": "অঙ্গার রাজ্য",
	"Crystal Caves": "স্ফটিক গুহা",
	"Enchanted Forest": "জাদুর বন",
	"Cloud Kingdom": "মেঘের রাজ্য",
	"Neon City": "নিয়ন শহর",
	"Deep Ocean": "গভীর সাগর",
	"Autumn Hills": "শরতের পাহাড়",
	"Desert Oasis": "মরুদ্যান",
	"Haunted Mist": "ভুতুড়ে কুয়াশা",
	"Space Rings": "মহাকাশ বলয়",
	"Rainbow Waterfall": "রংধনু ঝরনা",
	"Moon Garden": "চাঁদের বাগান",
	"Golden Temple": "সোনালি মন্দির",
	"Classic": "ক্লাসিক",
	"Rose": "গোলাপি",
	"Mint": "পুদিনা",
	"Sky": "আকাশি",
	"Sunny": "রৌদ্র",
	"Midnight": "মধ্যরাত",
	"Rainbow": "রংধনু",
	"Fire": "আগুন",
	"Ocean": "সাগর",
	"Candy": "ক্যান্ডি",
	"Neon": "নিয়ন",
	"Gold": "সোনা",
	"Starlight": "তারার আলো",
	"Flame": "শিখা",
	"Frost": "তুষার",
	"Heart": "হৃদয়",
	"Bunny": "খরগোশ",
	"Fox": "শিয়াল",
	"Owl": "পেঁচা",
	"Dragon": "ড্রাগন",
	"Pulls nearby coins": "কাছের কয়েন টানে",
	"Every 5th coin pays +1": "প্রতি ৫ম কয়েনে +১",
	"Starts runs with a shield": "শুরুতেই ঢাল দেয়",
	"+1 heart every run": "প্রতি রানে +১ হার্ট",
	"Magnet Time": "চুম্বকের সময়",
	"Shield Time": "ঢালের সময়",
	"Coin Boost": "কয়েন বুস্ট",
	"Slow Time": "স্লো-এর সময়",
	"Extra Heart": "অতিরিক্ত হার্ট",
	"Power Luck": "পাওয়ার ভাগ্য",
	"Combo Time": "কম্বোর সময়",
	"Float Jump": "ভাসমান লাফ",
	"+2s magnet": "+২ সেকেন্ড চুম্বক",
	"+2s shield": "+২ সেকেন্ড ঢাল",
	"+3s coins x2": "+৩ সেকেন্ড কয়েন x2",
	"+1.5s slow": "+১.৫ সেকেন্ড স্লো",
	"+1 starting heart": "শুরুতে +১ হার্ট",
	"More power-ups": "বেশি পাওয়ার-আপ",
	"+0.4s combo window": "+০.৪ সেকেন্ড কম্বো সময়",
	"Higher held jump": "চেপে ধরলে আরও উঁচু লাফ",
	"Daily Missions": "দৈনিক মিশন",
	"Daily Challenge": "দৈনিক চ্যালেঞ্জ",
	"Lucky Spin": "ভাগ্যের স্পিন",
	"Awards": "পুরস্কার",
	"Statistics": "পরিসংখ্যান",
	"Settings": "সেটিংস",
	"Sound  %s": "শব্দ  %s",
	"Music  %s": "গান  %s",
	"Vibration  %s": "কম্পন  %s",
	"FPS counter  %s": "FPS দেখান  %s",
	"Language  %s": "ভাষা  %s",
	"ON": "চালু",
	"OFF": "বন্ধ",
	"Collect %d coins": "%dটি কয়েন সংগ্রহ করুন",
	"Score %d points in total": "মোট %d পয়েন্ট স্কোর করুন",
	"Clear %d levels": "%dটি লেভেল শেষ করুন",
	"Collect %d power-ups": "%dটি পাওয়ার-আপ সংগ্রহ করুন",
	"Reach a x%d combo": "x%d কম্বোতে পৌঁছান",
	"Play %d runs": "%dটি রান খেলুন",
	"CLAIM": "নিন",
	"CLAIMED": "নেওয়া হয়েছে",
	"Zone  %s": "জোন  %s",
	"Reward  %d coins": "পুরস্কার  %d কয়েন",
	"Streak  %d days": "টানা  %d দিন",
	"START": "শুরু",
	"COMPLETED": "সম্পন্ন",
	"Daily reward  +%d": "দৈনিক পুরস্কার  +%d",
	"FREE SPIN": "ফ্রি স্পিন",
	"SPIN  -%d": "স্পিন  -%d",
	"You won %d coins!": "আপনি %d কয়েন জিতেছেন!",
	"Spin the wheel!": "চাকা ঘোরান!",
	"First Steps": "প্রথম পদক্ষেপ",
	"Coin Collector": "কয়েন সংগ্রাহক",
	"Coin Hoarder": "কয়েনের ভান্ডার",
	"Marathon": "ম্যারাথন",
	"Level Climber": "লেভেল পর্বতারোহী",
	"Star Hunter": "তারা শিকারি",
	"Zone Hopper": "জোন ভ্রমণকারী",
	"Boss Slayer": "বস বিজয়ী",
	"Combo King": "কম্বো সম্রাট",
	"Power Player": "পাওয়ার খেলোয়াড়",
	"Pet Owner": "পোষা সঙ্গীর মালিক",
	"Fashionista": "ফ্যাশন প্রেমী",
	"Lucky Spinner": "ভাগ্যবান স্পিনার",
	"Daily Hero": "দৈনিক নায়ক",
	"Endless Champion": "অন্তহীন চ্যাম্পিয়ন",
	"Rising Star": "উদীয়মান তারকা",
	"Play 1 run": "১টি রান খেলুন",
	"Collect 500 coins": "৫০০ কয়েন সংগ্রহ করুন",
	"Collect 5000 coins": "৫০০০ কয়েন সংগ্রহ করুন",
	"Score 10000 points in total": "মোট ১০০০০ পয়েন্ট স্কোর করুন",
	"Clear 10 levels": "১০টি লেভেল শেষ করুন",
	"Earn 50 stars": "৫০টি তারা অর্জন করুন",
	"Unlock 5 zones": "৫টি জোন খুলুন",
	"Beat 3 zone bosses": "৩টি জোন বস হারান",
	"Reach a x20 combo": "x20 কম্বোতে পৌঁছান",
	"Collect 30 power-ups": "৩০টি পাওয়ার-আপ সংগ্রহ করুন",
	"Own a pet": "একটি সঙ্গী কিনুন",
	"Own 5 style items": "৫টি স্টাইল আইটেম কিনুন",
	"Spin the wheel 5 times": "চাকা ৫ বার ঘোরান",
	"Finish 5 daily challenges": "৫টি দৈনিক চ্যালেঞ্জ শেষ করুন",
	"Score 3000 in Endless": "অন্তহীনে ৩০০০ স্কোর করুন",
	"Reach player level 10": "খেলোয়াড় লেভেল ১০-এ পৌঁছান",
	"Player level  %d": "খেলোয়াড় লেভেল  %d",
	"XP  %d / %d": "XP  %d / %d",
	"Runs  %d": "রান  %d",
	"Total coins  %d": "মোট কয়েন  %d",
	"Total score  %d": "মোট স্কোর  %d",
	"Best combo  x%d": "সেরা কম্বো  x%d",
	"Levels cleared  %d": "শেষ করা লেভেল  %d",
	"Play time  %s": "খেলার সময়  %s",
	"Daily challenges  %d": "দৈনিক চ্যালেঞ্জ  %d",
	"Power-ups  %d": "পাওয়ার-আপ  %d",
	"Top scores": "সেরা স্কোর",
	"No records yet": "এখনো কোনো রেকর্ড নেই",
	"Level up!  Player level %d": "লেভেল আপ!  খেলোয়াড় লেভেল %d"
}

enum State { READY, PLAYING, DEAD, PAUSED, MENU, WIN }
enum Mode { ADVENTURE, ENDLESS }

var rainbow: Array = [
	Color("ff5f8d"), Color("ffb05f"), Color("ffe066"),
	Color("6fe3a5"), Color("5fb8ff"), Color("a56bff")
]
var state: int = State.MENU
var mode: int = Mode.ENDLESS
var screen := "home"
var zone := 0
var level := 0
var zone_mode: int = Mode.ADVENTURE
var cur_page := 0
var busy := false
var speed := START_SPEED
var distance := 0.0
var score := 0
var coins := 0
var uy := FLOOR
var vy := 0.0
var jumps := 0
var held := false
var ducking := false
var falling := false
var dk := 0.0
var duck_ids: Dictionary = {}
var jump_ids: Dictionary = {}
var spawn_gap := 600.0
var run_time := 0.0
var shake := 0.0
var fps_timer := 0.0
var combo := 0
var combo_t := 0.0
var best_combo := 0
var last_kind := ""
var last_kind2 := ""
var bank := 0
var prog: Array = []
var eb: Array = []
var lv: Dictionary = {}
var lv_ev: Array = []
var lv_len := 1.0
var lv_total := 0
var ev_i := 0
var storm_sheet := "storm_low"
var finish_node: Sprite2D = null
var banner_tw: Tween = null

var bg: Node2D
var world: Node2D
var uni: AnimatedSprite2D
var sparks: CPUParticles2D
var ambient: CPUParticles2D
var sky_g: Gradient
var sun_node: Sprite2D
var stars_node: Node2D
var layer_shader: Shader
var star_list: Array = []
var lines: Array[Line2D] = []
var trail: Array[Vector2] = []
var layers: Array = []
var clouds: Array = []
var obstacles: Array = []
var items: Array = []
var tex_cache: Dictionary = {}
var touch_buttons: Array = []
var lives := 1
var invuln := 0.0
var shield_t := 0.0
var magnet_t := 0.0
var x2_t := 0.0
var slow_t := 0.0
var revives := 0
var banked := 0
var picked := 0
var coin_n := 0
var power_cd := 5
var owned: Array = []
var skills: Dictionary = {}
var eq_skin := 0
var eq_trail := 0
var eq_horn := 0
var eq_pet := -1
var shop_tab := 0
var prng := RandomNumberGenerator.new()
var skin_mat: ShaderMaterial
var horn_fx: CPUParticles2D
var pet_node: Sprite2D
var shield_fx: Sprite2D
var hearts: Array = []
var pu_slots: Dictionary = {}
var hearts_row: HBoxContainer
var power_row: HBoxContainer
var shop_box: Control
var shop_grid: GridContainer
var shop_tab_btns: Array = []
var over_revive: Button
var toast_label: Label
var toast_tw: Tween = null
var lang := "en"
var snd_on := true
var mus_on := true
var vib_on := true
var show_fps := true
var reopen := ""
var stats: Dictionary = {}
var xp := 0
var dstate: Dictionary = {}
var ach_claimed: Array = []
var records: Array = []
var ghosts: Dictionary = {}
var ghost_data: Dictionary = {}
var rec_d := PackedFloat32Array()
var rec_y := PackedFloat32Array()
var rec_t := 0.0
var run_clock := 0.0
var ghost_sprite: Sprite2D
var ghost_tex_run: AtlasTexture
var ghost_tex_jump: AtlasTexture
var daily_run := false
var spinning := false
var spin_idx := 0
var awards_page := 0
var sfx: Dictionary = {}
var music: AudioStreamPlayer
var cp_home: Control
var loading_on := false
var pet_t := 0.0
var settings_box: Control
var settings_col: VBoxContainer
var missions_box: Control
var missions_list: VBoxContainer
var daily_box: Control
var daily_zone_label: Label
var daily_info: Label
var daily_streak: Label
var daily_btn: Button
var spin_box: Control
var spin_label: Label
var wheel: Control
var spin_btn: Button
var awards_box: Control
var awards_grid: GridContainer
var awards_page_label: Label
var stats_box: Control
var stats_left: Label
var stats_right: Label

var ui: CanvasLayer
var score_label: Label
var coin_label: Label
var fps_label: Label
var combo_label: Label
var pause_btn: Button
var progress_bar: ProgressBar
var pause_panel: PanelContainer
var ready_box: Control
var ready_title: Label
var ready_sub: Label
var ready_label: Label
var over_panel: PanelContainer
var over_title: Label
var over_score: Label
var over_best: Label
var over_nav: Button
var win_panel: PanelContainer
var win_title: Label
var win_stars: Array = []
var win_info: Label
var win_note: Label
var win_next: Button
var home_box: Control
var zone_box: Control
var zone_title: Label
var zone_grid: GridContainer
var page_label: Label
var prev_btn: Button
var next_btn: Button
var level_box: Control
var level_title: Label
var level_grid: GridContainer
var banner_box: Control
var banner_title: Label
var banner_sub: Label
var bank_row: PanelContainer
var bank_label: Label
var fade: ColorRect
var ui_font: FontFile


func _ready() -> void:
	randomize()
	prng.randomize()
	Engine.max_fps = 0
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
	init_progress()
	load_save()
	setup_fonts()
	build_background()
	build_world()
	build_ui()
	apply_zone(zone)
	apply_loadout()
	setup_audio()
	fps_label.visible = show_fps
	ensure_day()
	start_loading()
	if reopen == "settings":
		reopen = ""
		show_settings()
	else:
		show_menu()


func start_loading() -> void:
	var tips: Array = ["Hold the screen to jump higher", "Collect coins to unlock new unicorns", "Finish the daily challenge for a bonus", "Claim your awards from the Awards page", "Near misses build your combo"]
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	var ld: Control = CpLoading.new()
	layer.add_child(ld)
	ld.setup(T("UNICORN DASH"), T("Loading..."), T(String(tips[randi() % tips.size()])))
	loading_on = true
	ld.finished.connect(on_loading_done.bind(layer))


func on_loading_done(layer: CanvasLayer) -> void:
	loading_on = false
	layer.queue_free()


func get_tex(path: String) -> Texture2D:
	if not tex_cache.has(path):
		tex_cache[path] = load(path)
	return tex_cache[path]


func hc(v: Variant) -> Color:
	return Color(String(v))


func build_background() -> void:
	bg = Node2D.new()
	add_child(bg)

	layer_shader = Shader.new()
	layer_shader.code = LAYER_SHADER

	sky_g = Gradient.new()
	sky_g.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	sky_g.colors = PackedColorArray([Color("6a46b8"), Color("d77fcf"), Color("ffc9b8")])
	var gt := GradientTexture2D.new()
	gt.gradient = sky_g
	gt.width = 8
	gt.height = 256
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	var sky := Sprite2D.new()
	sky.texture = gt
	sky.centered = false
	sky.scale = Vector2(WIDE / 8.0, (VH + 400.0) / 256.0)
	bg.add_child(sky)

	stars_node = Node2D.new()
	stars_node.visible = false
	bg.add_child(stars_node)
	for i in 46:
		var st := Sprite2D.new()
		st.texture = load("res://art/spark.png")
		st.position = Vector2(randf_range(0.0, WIDE), randf_range(10.0, 300.0))
		var ss := randf_range(0.08, 0.22)
		st.scale = Vector2(ss, ss)
		var base_a := randf_range(0.5, 1.0)
		st.modulate = Color(1, 1, 1, base_a)
		stars_node.add_child(st)
		star_list.append({"node": st, "ph": randf() * 6.28, "a": base_a})

	sun_node = Sprite2D.new()
	sun_node.texture = load("res://art/sun.png")
	sun_node.position = Vector2(980, 150)
	sun_node.scale = Vector2(1.1, 1.1)
	sun_node.modulate = Color(1, 1, 1, 0.85)
	bg.add_child(sun_node)

	make_layer("res://art/rainbow.png", FLOOR - 440.0 + 40.0, 0.03, "rainbow")

	for i in 5:
		var c := Sprite2D.new()
		c.texture = load("res://art/cloud%d.png" % (i % 3))
		c.position = Vector2(randf_range(0, VW + 300), randf_range(40, 230))
		var s := randf_range(0.6, 1.1)
		c.scale = Vector2(s, s)
		var ca := randf_range(0.45, 0.8)
		c.modulate = Color(1, 1, 1, ca)
		bg.add_child(c)
		clouds.append({"node": c, "f": randf_range(0.03, 0.12), "a": ca})

	make_layer("res://art/far.png", FLOOR - 330.0 + 40.0, 0.07, "far")
	make_layer("res://art/mid.png", FLOOR - 250.0 + 30.0, 0.16, "mid")
	make_layer("res://art/near.png", FLOOR - 190.0 + 34.0, 0.42, "near")
	make_layer("res://art/ground.png", FLOOR - 14.0, 1.0, "ground")


func make_layer(path: String, y: float, factor: float, key: String) -> void:
	var tex: Texture2D = load(path)
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	s.position = Vector2(0, y)
	s.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	s.region_enabled = true
	s.region_rect = Rect2(0, 0, WIDE, tex.get_height())
	bg.add_child(s)
	var mat: ShaderMaterial = null
	if key != "rainbow":
		mat = ShaderMaterial.new()
		mat.shader = layer_shader
	layers.append({"node": s, "f": factor, "w": float(tex.get_width()), "h": float(tex.get_height()), "off": 0.0, "key": key, "mat": mat})


func layer_palette(zd: Dictionary, key: String) -> Array:
	var far_c: Array = zd["far"]
	var near_c: Array = zd["near"]
	var gr_c: Array = zd["gr"]
	if key == "far":
		return [hc(far_c[0]), hc(far_c[1])]
	if key == "near":
		return [hc(near_c[0]), hc(near_c[1])]
	if key == "ground":
		return [hc(gr_c[0]), hc(gr_c[1])]
	return [hc(far_c[0]).lerp(hc(near_c[0]), 0.5), hc(far_c[1]).lerp(hc(near_c[1]), 0.5)]


func apply_zone(z: int) -> void:
	zone = z
	var zd: Dictionary = ZONES[z]
	var sky: Array = zd["sky"]
	sky_g.colors = PackedColorArray([hc(sky[0]), hc(sky[1]), hc(sky[2])])
	var night: float = zd["night"]
	var raw: bool = zd.get("raw", false)
	for l in layers:
		var key: String = l["key"]
		var s: Sprite2D = l["node"]
		if key == "rainbow":
			s.modulate = Color(1, 1, 1, clampf(1.0 - night, 0.0, 1.0))
			continue
		if raw:
			s.material = null
			continue
		var pal: Array = layer_palette(zd, key)
		var mat: ShaderMaterial = l["mat"]
		var lum: Array = LUM[key]
		mat.set_shader_parameter("c_dark", pal[0])
		mat.set_shader_parameter("c_light", pal[1])
		mat.set_shader_parameter("l0", float(lum[0]))
		mat.set_shader_parameter("l1", float(lum[1]))
		s.material = mat
	var tint := Color(1, 1, 1)
	if not raw:
		tint = hc(sky[2]).lightened(0.5)
	for c in clouds:
		var n: Sprite2D = c["node"]
		n.modulate = Color(tint.r, tint.g, tint.b, float(c["a"]) * (1.0 - 0.65 * night))
	if raw:
		sun_node.modulate = Color(1, 1, 1, 0.85)
	elif night >= 0.5:
		sun_node.modulate = Color(0.86, 0.9, 1.0, 0.9)
	else:
		sun_node.modulate = Color(1, 0.96, 0.85, 0.85)
	stars_node.visible = night >= 0.45
	stars_node.modulate.a = clampf((night - 0.3) / 0.5, 0.0, 1.0)
	var zs: String = zd["zs"]
	storm_sheet = "storm_low"
	if zs == "jelly":
		storm_sheet = "jelly"
	elif zs == "ghost":
		storm_sheet = "ghost"
	apply_fx(String(zd["fx"]))


func fade_ramp() -> Gradient:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.2, 0.75, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
	return g


func apply_fx(kind: String) -> void:
	ambient.emitting = false
	if not FX.has(kind):
		return
	var f: Dictionary = FX[kind]
	var vs := get_viewport_rect().size
	var pf: Array = f["pf"]
	var ef: Array = f["ef"]
	var dr: Array = f["dir"]
	var gv: Array = f["grav"]
	ambient.position = Vector2(vs.x * float(pf[0]), vs.y * float(pf[1]))
	ambient.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	ambient.emission_rect_extents = Vector2(vs.x * float(ef[0]), vs.y * float(ef[1]))
	ambient.direction = Vector2(float(dr[0]), float(dr[1]))
	ambient.spread = float(f["spread"])
	ambient.gravity = Vector2(float(gv[0]), float(gv[1]))
	ambient.initial_velocity_min = float(f["v0"])
	ambient.initial_velocity_max = float(f["v1"])
	ambient.scale_amount_min = float(f["s0"])
	ambient.scale_amount_max = float(f["s1"])
	ambient.lifetime = float(f["life"])
	ambient.amount = int(f["n"])
	ambient.preprocess = float(f["life"])
	var c := hc(f["col"])
	ambient.color = Color(c.r, c.g, c.b, float(f["a"]))
	ambient.color_ramp = fade_ramp()
	if bool(f["add"]):
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		ambient.material = m
	else:
		ambient.material = null
	ambient.restart()
	ambient.emitting = true


func build_world() -> void:
	world = Node2D.new()
	add_child(world)

	ambient = CPUParticles2D.new()
	ambient.texture = load("res://art/spark.png")
	ambient.local_coords = false
	ambient.emitting = false
	world.add_child(ambient)

	for k in 6:
		var ln := Line2D.new()
		ln.width = 8.6
		ln.begin_cap_mode = Line2D.LINE_CAP_ROUND
		ln.end_cap_mode = Line2D.LINE_CAP_ROUND
		ln.joint_mode = Line2D.LINE_JOINT_ROUND
		ln.antialiased = true
		var gr := Gradient.new()
		var c: Color = rainbow[k]
		gr.offsets = PackedFloat32Array([0.0, 0.7, 1.0])
		gr.colors = PackedColorArray([Color(c.r, c.g, c.b, 0.0), Color(c.r, c.g, c.b, 0.85), c])
		ln.gradient = gr
		world.add_child(ln)
		lines.append(ln)

	sparks = CPUParticles2D.new()
	sparks.texture = load("res://art/spark.png")
	sparks.amount = 28
	sparks.lifetime = 0.7
	sparks.local_coords = false
	sparks.direction = Vector2(-1, 0)
	sparks.spread = 35.0
	sparks.gravity = Vector2.ZERO
	sparks.initial_velocity_min = 60.0
	sparks.initial_velocity_max = 160.0
	sparks.scale_amount_min = 0.15
	sparks.scale_amount_max = 0.4
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 1, 0.85, 1), Color(1, 0.7, 1, 0)])
	sparks.color_ramp = cg
	sparks.emitting = false
	world.add_child(sparks)

	uni = AnimatedSprite2D.new()
	uni.sprite_frames = build_frames()
	uni.centered = false
	uni.offset = Vector2(-UNI_ANCHOR, -FEET)
	uni.scale = Vector2(UNI_SCALE, UNI_SCALE)
	uni.position = Vector2(UNI_X, uy)
	world.add_child(uni)
	uni.play("run")

	var gsheet: Texture2D = load("res://art/unicorn2.png")
	ghost_tex_run = AtlasTexture.new()
	ghost_tex_run.atlas = gsheet
	ghost_tex_run.region = Rect2(2 * FR, 0, FR, FR)
	ghost_tex_jump = AtlasTexture.new()
	ghost_tex_jump.atlas = gsheet
	ghost_tex_jump.region = Rect2(8 * FR, 0, FR, FR)
	ghost_sprite = Sprite2D.new()
	ghost_sprite.texture = ghost_tex_run
	ghost_sprite.centered = false
	ghost_sprite.offset = Vector2(-UNI_ANCHOR, -FEET)
	ghost_sprite.scale = Vector2(UNI_SCALE, UNI_SCALE)
	ghost_sprite.modulate = Color(1, 1, 1, 0.38)
	ghost_sprite.visible = false
	world.add_child(ghost_sprite)
	world.move_child(ghost_sprite, uni.get_index())

	skin_mat = ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = SKIN_SHADER
	skin_mat.shader = sh

	horn_fx = CPUParticles2D.new()
	horn_fx.texture = load("res://art/spark.png")
	horn_fx.local_coords = false
	horn_fx.lifetime = 0.6
	horn_fx.direction = Vector2(0, -1)
	horn_fx.spread = 180.0
	horn_fx.gravity = Vector2(-40.0, -20.0)
	horn_fx.initial_velocity_min = 15.0
	horn_fx.initial_velocity_max = 60.0
	horn_fx.scale_amount_min = 0.1
	horn_fx.scale_amount_max = 0.28
	horn_fx.color_ramp = fade_ramp()
	var hm := CanvasItemMaterial.new()
	hm.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	horn_fx.material = hm
	horn_fx.emitting = false
	world.add_child(horn_fx)

	pet_node = Sprite2D.new()
	pet_node.scale = Vector2(0.7, 0.7)
	pet_node.visible = false
	world.add_child(pet_node)

	shield_fx = Sprite2D.new()
	shield_fx.texture = load("res://art/fx_shield.png")
	shield_fx.scale = Vector2(0.62, 0.62)
	shield_fx.visible = false
	world.add_child(shield_fx)


func add_anim(sf: SpriteFrames, anim: String, sheet: Texture2D, first: int, count: int, fps: float, loop: bool) -> void:
	sf.add_animation(anim)
	sf.set_animation_speed(anim, fps)
	sf.set_animation_loop(anim, loop)
	for i in count:
		var a := AtlasTexture.new()
		a.atlas = sheet
		a.region = Rect2((first + i) * FR, 0, FR, FR)
		sf.add_frame(anim, a)


func build_frames() -> SpriteFrames:
	var sheet: Texture2D = load("res://art/unicorn2.png")
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	add_anim(sf, "run", sheet, 0, 8, 17.0, true)
	add_anim(sf, "jump", sheet, 8, 1, 1.0, false)
	add_anim(sf, "duck", sheet, 9, 4, 14.0, true)
	add_anim(sf, "dead", sheet, 13, 1, 1.0, false)
	return sf


func kit_tex(name: String) -> Texture2D:
	return get_tex("res://art/ui/%s.png" % name)


func kit_box(name: String, m: Array, cm: Array) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = kit_tex(name)
	sb.texture_margin_left = float(m[0])
	sb.texture_margin_top = float(m[1])
	sb.texture_margin_right = float(m[2])
	sb.texture_margin_bottom = float(m[3])
	sb.content_margin_left = float(cm[0])
	sb.content_margin_top = float(cm[1])
	sb.content_margin_right = float(cm[2])
	sb.content_margin_bottom = float(cm[3])
	return sb


func kit_pick(c: Color) -> String:
	var best := ""
	var bd := 1000.0
	for k in KIT_COLORS:
		var kc := Color(String(KIT_COLORS[k]))
		var d := (kc.r - c.r) * (kc.r - c.r) + (kc.g - c.g) * (kc.g - c.g) + (kc.b - c.b) * (kc.b - c.b)
		if d < bd:
			bd = d
			best = String(k)
	if bd > 0.02:
		return ""
	return best


func make_label(size: int, color: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", ui_font)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color("2a1670"))
	l.add_theme_constant_override("outline_size", 9)
	l.add_theme_color_override("font_shadow_color", Color(0.08, 0.02, 0.28, 0.6))
	l.add_theme_constant_override("shadow_offset_x", 0)
	l.add_theme_constant_override("shadow_offset_y", 4)
	l.add_theme_constant_override("shadow_outline_size", 9)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func make_button(text: String, size: Vector2, fsize: int, col: Color) -> Button:
	var btn := Button.new()
	var large := size.y >= 100.0
	btn.text = T(text)
	btn.custom_minimum_size = size
	btn.add_theme_font_override("font", ui_font)
	btn.add_theme_font_size_override("font_size", fsize)
	btn.add_theme_color_override("font_color", Color.WHITE)
	btn.add_theme_color_override("font_hover_color", Color.WHITE)
	btn.add_theme_color_override("font_pressed_color", Color.WHITE)
	btn.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.6))
	btn.add_theme_color_override("font_outline_color", col.darkened(0.55))
	btn.add_theme_constant_override("outline_size", maxi(4, int(float(fsize) * 0.2)))
	btn.add_theme_stylebox_override("normal", button_style(col, large))
	btn.add_theme_stylebox_override("hover", button_style(col, large, 1.08))
	btn.add_theme_stylebox_override("pressed", button_style(col, large, 0.86))
	btn.add_theme_stylebox_override("disabled", button_style(col, large))
	btn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if kit_pick(col) == "":
		btn.add_child(make_gloss(large))
	touch_buttons.append(btn)
	return btn


func make_gloss(large: bool) -> NinePatchRect:
	var g := NinePatchRect.new()
	g.texture = kit_tex("btn_l_gloss" if large else "btn_s_gloss")
	var m: Array = [44, 42, 44, 58] if large else [22, 22, 22, 30]
	g.patch_margin_left = int(m[0])
	g.patch_margin_top = int(m[1])
	g.patch_margin_right = int(m[2])
	g.patch_margin_bottom = int(m[3])
	g.set_anchors_preset(Control.PRESET_FULL_RECT)
	g.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return g


func make_panel() -> PanelContainer:
	var pc := PanelContainer.new()
	pc.set_anchors_preset(Control.PRESET_CENTER)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.grow_vertical = Control.GROW_DIRECTION_BOTH
	pc.add_theme_stylebox_override("panel", kit_box("panel", [44, 44, 44, 52], [44, 30, 44, 42]))
	watch_show(pc, "pop")
	return pc


func button_style(c: Color, large: bool = false, shade: float = 1.0) -> StyleBoxTexture:
	var pick := kit_pick(c)
	var base := "btn_l" if large else "btn_s"
	var nm := base if pick == "" else "%s_%s" % [base, pick]
	var s: StyleBoxTexture
	if large:
		s = kit_box(nm, [44, 42, 44, 58], [16, 4, 16, 22])
	else:
		s = kit_box(nm, [22, 22, 22, 30], [12, 0, 12, 12])
	if pick == "":
		s.modulate_color = Color(c.r * shade, c.g * shade, c.b * shade, 1.0)
	else:
		s.modulate_color = Color(shade, shade, shade, 1.0)
	return s


func bar_style(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(10)
	s.set_border_width_all(3)
	if c.a > 0.9:
		s.border_color = c.darkened(0.5)
	else:
		s.border_color = Color(0.74, 0.62, 1.0, 0.55)
	s.shadow_size = 3
	s.shadow_color = Color(0.04, 0.0, 0.16, 0.35)
	s.shadow_offset = Vector2(0, 2)
	return s


func watch_show(n: Control, kind: String) -> void:
	n.visibility_changed.connect(on_shown.bind(n, kind))


func on_shown(n: Control, kind: String) -> void:
	if not is_instance_valid(n) or not n.visible:
		return
	n.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(n):
		return
	if not n.visible:
		n.modulate.a = 1.0
		return
	play_intro(n, kind)


func play_intro(n: Control, kind: String) -> void:
	if n.has_meta("intro"):
		var old: Tween = n.get_meta("intro")
		if old != null and old.is_valid():
			old.kill()
	n.pivot_offset = n.size * 0.5
	var tw := n.create_tween()
	n.set_meta("intro", tw)
	tw.set_parallel(true)
	if kind == "pop":
		n.scale = Vector2(0.82, 0.82)
		tw.tween_property(n, "modulate:a", 1.0, 0.16)
		tw.tween_property(n, "scale", Vector2.ONE, 0.42).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	else:
		n.scale = Vector2(1.04, 1.04)
		tw.tween_property(n, "modulate:a", 1.0, 0.22)
		tw.tween_property(n, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


func punch(n: Control) -> void:
	n.pivot_offset = n.size * 0.5
	n.scale = Vector2(0.92, 0.92)
	var tw := n.create_tween()
	tw.tween_property(n, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func make_full_rect() -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func make_center_label(text: String, size: int, color: Color, top: float, parent: Control) -> Label:
	var l := make_label(size, color)
	l.text = T(text)
	l.set_anchors_preset(Control.PRESET_CENTER_TOP)
	l.grow_horizontal = Control.GROW_DIRECTION_BOTH
	l.offset_top = top
	parent.add_child(l)
	return l


func make_star_row(size: float, parent: Control) -> Array:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(row)
	var out: Array = []
	for i in 3:
		var tr := TextureRect.new()
		tr.texture = get_tex("res://art/star_off.png")
		tr.custom_minimum_size = Vector2(size, size)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(tr)
		out.append(tr)
	return out


func build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)

	score_label = make_label(36, Color.WHITE)
	score_label.position = Vector2(36, 16)
	ui.add_child(score_label)

	coin_label = make_label(36, Color("ffe27a"))
	coin_label.anchor_left = 1.0
	coin_label.anchor_right = 1.0
	coin_label.offset_left = -420.0
	coin_label.offset_right = -120.0
	coin_label.offset_top = 16.0
	coin_label.offset_bottom = 70.0
	coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ui.add_child(coin_label)

	combo_label = make_label(34, Color("ffe27a"))
	combo_label.anchor_left = 0.5
	combo_label.anchor_right = 0.5
	combo_label.offset_left = -200.0
	combo_label.offset_right = 200.0
	combo_label.offset_top = 84.0
	combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_label.visible = false
	ui.add_child(combo_label)

	fps_label = make_label(16, Color("c9b8ff"))
	fps_label.anchor_left = 0.5
	fps_label.anchor_right = 0.5
	fps_label.offset_left = -80.0
	fps_label.offset_right = 80.0
	fps_label.offset_top = 8.0
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(fps_label)

	progress_bar = ProgressBar.new()
	progress_bar.min_value = 0.0
	progress_bar.max_value = 1.0
	progress_bar.show_percentage = false
	progress_bar.custom_minimum_size = Vector2(520, 16)
	progress_bar.anchor_left = 0.5
	progress_bar.anchor_right = 0.5
	progress_bar.offset_left = -260.0
	progress_bar.offset_right = 260.0
	progress_bar.offset_top = 46.0
	progress_bar.offset_bottom = 62.0
	progress_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	progress_bar.add_theme_stylebox_override("background", bar_style(Color(0.1, 0.05, 0.3, 0.55)))
	progress_bar.add_theme_stylebox_override("fill", bar_style(Color("ffe27a")))
	progress_bar.visible = false
	ui.add_child(progress_bar)

	pause_btn = make_button("II", Vector2(76, 76), 34, Color("5a3cb0"))
	pause_btn.anchor_left = 1.0
	pause_btn.anchor_right = 1.0
	pause_btn.offset_left = -104.0
	pause_btn.offset_right = -28.0
	pause_btn.offset_top = 14.0
	pause_btn.offset_bottom = 90.0
	pause_btn.pressed.connect(pause_game)
	ui.add_child(pause_btn)

	hearts_row = HBoxContainer.new()
	hearts_row.position = Vector2(36, 62)
	hearts_row.add_theme_constant_override("separation", 4)
	hearts_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(hearts_row)
	for i in 5:
		var h := TextureRect.new()
		h.texture = get_tex("res://art/pu_heart.png")
		h.custom_minimum_size = Vector2(44, 44)
		h.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		h.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hearts_row.add_child(h)
		hearts.append(h)

	power_row = HBoxContainer.new()
	power_row.position = Vector2(36, 112)
	power_row.add_theme_constant_override("separation", 14)
	power_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(power_row)
	for t in ["shield", "magnet", "x2", "slow"]:
		var slot := HBoxContainer.new()
		slot.add_theme_constant_override("separation", 4)
		slot.visible = false
		slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var ic := TextureRect.new()
		ic.texture = get_tex("res://art/pu_%s.png" % t)
		ic.custom_minimum_size = Vector2(42, 42)
		ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slot.add_child(ic)
		var lb := make_label(26, Color.WHITE)
		slot.add_child(lb)
		power_row.add_child(slot)
		pu_slots[t] = {"box": slot, "label": lb}

	banner_box = make_full_rect()
	ui.add_child(banner_box)
	banner_title = make_center_label("", 68, Color.WHITE, 120.0, banner_box)
	banner_sub = make_center_label("", 32, Color("ffe27a"), 205.0, banner_box)
	banner_box.modulate.a = 0.0

	ready_box = make_full_rect()
	ui.add_child(ready_box)
	ready_title = make_center_label("", 78, Color.WHITE, 56.0, ready_box)
	ready_sub = make_center_label("", 36, Color("c9b8ff"), 152.0, ready_box)
	ready_label = make_center_label("TAP TO RUN", 40, Color("ffe27a"), 212.0, ready_box)
	make_center_label("Right side: tap to jump, hold higher, tap again for double jump  -  Left side: hold to duck", 22, Color("e6dcff"), 276.0, ready_box)
	var rb := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	rb.position = Vector2(24, 16)
	rb.pressed.connect(go_back)
	ready_box.add_child(rb)

	over_panel = make_panel()
	ui.add_child(over_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	over_panel.add_child(box)

	over_title = make_label(54, Color("ff8fc7"))
	over_title.text = "GAME OVER"
	over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_title)

	over_score = make_label(32, Color.WHITE)
	over_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_score)

	over_best = make_label(26, Color("ffe27a"))
	over_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_best)

	over_revive = make_button("REVIVE", Vector2(300, 60), 30, Color("f2a93c"))
	over_revive.pressed.connect(on_revive)
	box.add_child(over_revive)
	var btn := make_button("RETRY", Vector2(300, 60), 30, Color("b45cff"))
	btn.pressed.connect(on_retry)
	box.add_child(btn)
	over_nav = make_button("LEVELS", Vector2(300, 54), 28, Color("3fc98a"))
	over_nav.pressed.connect(to_select)
	box.add_child(over_nav)
	var mbtn := make_button("MENU", Vector2(300, 54), 28, Color("4a86e8"))
	mbtn.pressed.connect(to_menu)
	box.add_child(mbtn)

	pause_panel = make_panel()
	ui.add_child(pause_panel)
	var pbox := VBoxContainer.new()
	pbox.add_theme_constant_override("separation", 14)
	pause_panel.add_child(pbox)
	var pt := make_label(54, Color.WHITE)
	pt.text = T("PAUSED")
	pt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pbox.add_child(pt)
	var b1 := make_button("RESUME", Vector2(280, 64), 30, Color("3fc98a"))
	b1.pressed.connect(resume_game)
	pbox.add_child(b1)
	var b2 := make_button("RESTART", Vector2(280, 64), 30, Color("b45cff"))
	b2.pressed.connect(on_retry)
	pbox.add_child(b2)
	var b3 := make_button("MENU", Vector2(280, 64), 30, Color("4a86e8"))
	b3.pressed.connect(to_menu)
	pbox.add_child(b3)

	win_panel = make_panel()
	ui.add_child(win_panel)
	var wbox := VBoxContainer.new()
	wbox.add_theme_constant_override("separation", 10)
	win_panel.add_child(wbox)
	win_title = make_label(50, Color("7fe8b0"))
	win_title.text = "LEVEL COMPLETE"
	win_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	wbox.add_child(win_title)
	win_stars = make_star_row(84.0, wbox)
	win_info = make_label(28, Color.WHITE)
	win_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	wbox.add_child(win_info)
	win_note = make_label(26, Color("ffe27a"))
	win_note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	wbox.add_child(win_note)
	win_next = make_button("NEXT", Vector2(300, 66), 32, Color("3fc98a"))
	win_next.pressed.connect(on_next)
	wbox.add_child(win_next)
	var wr := make_button("RETRY", Vector2(300, 58), 28, Color("b45cff"))
	wr.pressed.connect(on_retry)
	wbox.add_child(wr)
	var wl := make_button("LEVELS", Vector2(300, 58), 28, Color("4a86e8"))
	wl.pressed.connect(to_select)
	wbox.add_child(wl)

	build_home()
	build_zone_screen()
	build_level_screen()
	build_shop_screen()
	build_extra_screens()

	bank_row = PanelContainer.new()
	bank_row.add_theme_stylebox_override("panel", kit_box("chip", [32, 30, 32, 30], [16, 4, 22, 8]))
	bank_row.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	bank_row.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	bank_row.offset_top = 12.0
	bank_row.offset_right = -24.0
	bank_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bank_inner := HBoxContainer.new()
	bank_inner.add_theme_constant_override("separation", 8)
	bank_inner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bank_row.add_child(bank_inner)
	var ci := TextureRect.new()
	ci.texture = get_tex("res://art/coin.png")
	ci.custom_minimum_size = Vector2(50, 50)
	ci.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ci.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ci.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bank_inner.add_child(ci)
	bank_label = make_label(34, Color("ffe27a"))
	bank_inner.add_child(bank_label)
	ui.add_child(bank_row)

	toast_label = make_label(30, Color("ffe27a"))
	toast_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	toast_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast_label.grow_vertical = Control.GROW_DIRECTION_BEGIN
	toast_label.offset_bottom = -30.0
	toast_label.modulate.a = 0.0
	ui.add_child(toast_label)

	fade = ColorRect.new()
	fade.color = Color(0.07, 0.04, 0.2, 0.0)
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(fade)

	for n in [home_box, zone_box, level_box, shop_box, settings_box, missions_box, daily_box, spin_box, awards_box, stats_box, ready_box]:
		watch_show(n, "screen")


func build_home() -> void:
	home_box = make_full_rect()
	ui.add_child(home_box)
	cp_home = CpHome.new()
	home_box.add_child(cp_home)
	cp_home.setup(self)
	cp_home.action.connect(on_cp_action)
	cp_home.built.connect(on_cp_built)


func on_cp_built(list: Array) -> void:
	for b in list:
		touch_buttons.append(b)


func on_cp_action(key: String) -> void:
	if key == "adv":
		on_home_adventure()
	elif key == "end":
		on_home_endless()
	elif key == "shop":
		on_home_shop()
	elif key == "board":
		go(show_stats)
	elif key == "mute":
		on_mute()
	elif key == "pet":
		pet_t = 0.5
		play_sfx("neigh")
	else:
		on_home_extra(key)


func on_mute() -> void:
	var any := snd_on or mus_on
	snd_on = not any
	mus_on = not any
	update_music()
	save_game()
	cp_home.refresh(false)


func streak_now() -> int:
	var last := String(dstate.get("last", ""))
	if last == today_str() or last == yesterday_str():
		return int(dstate.get("streak", 0))
	return 0


func on_home_extra(key: String) -> void:
	if key == "missions":
		go(show_missions)
	elif key == "daily":
		go(show_daily)
	elif key == "spin":
		go(show_spin)
	elif key == "awards":
		go(show_awards)
	elif key == "stats":
		go(show_stats)
	else:
		go(show_settings)


func build_zone_screen() -> void:
	zone_box = make_full_rect()
	ui.add_child(zone_box)
	zone_title = make_center_label("", 48, Color.WHITE, 12.0, zone_box)
	var back := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	back.position = Vector2(24, 14)
	back.pressed.connect(go_back)
	zone_box.add_child(back)

	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	zone_box.add_child(cc)
	zone_grid = GridContainer.new()
	zone_grid.columns = 3
	zone_grid.add_theme_constant_override("h_separation", 18)
	zone_grid.add_theme_constant_override("v_separation", 18)
	cc.add_child(zone_grid)

	var nav := HBoxContainer.new()
	nav.add_theme_constant_override("separation", 24)
	nav.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	nav.grow_horizontal = Control.GROW_DIRECTION_BOTH
	nav.grow_vertical = Control.GROW_DIRECTION_BEGIN
	nav.offset_bottom = -16.0
	nav.mouse_filter = Control.MOUSE_FILTER_IGNORE
	zone_box.add_child(nav)
	prev_btn = make_button("<", Vector2(96, 64), 36, Color("5a3cb0"))
	prev_btn.pressed.connect(on_page.bind(-1))
	nav.add_child(prev_btn)
	page_label = make_label(32, Color.WHITE)
	nav.add_child(page_label)
	next_btn = make_button(">", Vector2(96, 64), 36, Color("5a3cb0"))
	next_btn.pressed.connect(on_page.bind(1))
	nav.add_child(next_btn)


func build_level_screen() -> void:
	level_box = make_full_rect()
	ui.add_child(level_box)
	level_title = make_center_label("", 48, Color.WHITE, 12.0, level_box)
	var back := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	back.position = Vector2(24, 14)
	back.pressed.connect(go_back)
	level_box.add_child(back)

	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	level_box.add_child(cc)
	level_grid = GridContainer.new()
	level_grid.columns = 5
	level_grid.add_theme_constant_override("h_separation", 14)
	level_grid.add_theme_constant_override("v_separation", 14)
	cc.add_child(level_grid)


func hide_screens() -> void:
	home_box.visible = false
	zone_box.visible = false
	level_box.visible = false
	shop_box.visible = false
	settings_box.visible = false
	missions_box.visible = false
	daily_box.visible = false
	spin_box.visible = false
	awards_box.visible = false
	stats_box.visible = false
	ready_box.visible = false
	over_panel.visible = false
	pause_panel.visible = false
	win_panel.visible = false
	pause_btn.visible = false
	progress_bar.visible = false
	bank_row.visible = false


func refresh_bank() -> void:
	bank_label.text = "%d" % bank


func page_count() -> int:
	return ceili(float(ZONES.size()) / float(PER_PAGE))


func show_menu() -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = "home"
	refresh_bank()
	bank_row.visible = false
	home_box.visible = true
	home_marks()
	update_hud()


func show_zones(m: int) -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = "zones"
	zone_mode = m
	zone_title.text = T("ADVENTURE") if m == Mode.ADVENTURE else T("ENDLESS")
	cur_page = floori(float(zone) / float(PER_PAGE))
	refresh_zones()
	refresh_bank()
	bank_row.visible = true
	zone_box.visible = true
	update_hud()


func show_levels(z: int) -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = "levels"
	apply_zone(z)
	var nm: String = ZONES[z]["name"]
	level_title.text = T(nm)
	refresh_levels(z)
	refresh_bank()
	bank_row.visible = true
	level_box.visible = true
	update_hud()


func refresh_zones() -> void:
	for c in zone_grid.get_children():
		zone_grid.remove_child(c)
		c.queue_free()
	var first := cur_page * PER_PAGE
	for i in PER_PAGE:
		var z := first + i
		if z >= ZONES.size():
			break
		zone_grid.add_child(make_zone_card(z))
	page_label.text = "%d / %d" % [cur_page + 1, page_count()]
	prev_btn.disabled = cur_page <= 0
	next_btn.disabled = cur_page >= page_count() - 1


func make_zone_card(z: int) -> Button:
	var zd: Dictionary = ZONES[z]
	var sky: Array = zd["sky"]
	var nm: String = zd["name"]
	var is_open := zone_open(z)
	var txt := ""
	if not is_open:
		var prev_nm: String = ZONES[z - 1]["name"]
		txt = T("LOCKED") + "\n" + T("Clear %d levels in") % ZONE_NEED + "\n" + T(prev_nm)
	elif zone_mode == Mode.ADVENTURE:
		txt = T(nm) + "\n" + T("%d / %d cleared   %d stars") % [cleared(z), LEVELS_PER_ZONE, zone_stars(z)]
	else:
		txt = T(nm) + "\n" + T("Best  %d") % int(eb[z])
	var base := hc(sky[1]).darkened(0.4)
	if not is_open:
		base = Color(0.28, 0.24, 0.4)
	var btn := make_button(txt, Vector2(380, 150), 26, base)
	btn.disabled = not is_open
	if not is_open:
		btn.icon = get_tex("res://art/lock.png")
		btn.add_theme_constant_override("icon_max_width", 48)
	btn.pressed.connect(on_zone_card.bind(z))
	return btn


func refresh_levels(z: int) -> void:
	for c in level_grid.get_children():
		level_grid.remove_child(c)
		c.queue_free()
	for l in LEVELS_PER_ZONE:
		level_grid.add_child(make_level_tile(z, l))


func make_level_tile(z: int, l: int) -> Button:
	var boss := l == LEVELS_PER_ZONE - 1
	var is_open := level_open(z, l)
	var base := Color("b45cff")
	if boss:
		base = Color("ff5f8d")
	if not is_open:
		base = Color(0.28, 0.24, 0.4)
	var btn := make_button("", Vector2(188, 168), 40, base)
	btn.disabled = not is_open
	var num := make_label(60, Color.WHITE)
	num.text = "%d" % (l + 1)
	num.set_anchors_preset(Control.PRESET_CENTER_TOP)
	num.grow_horizontal = Control.GROW_DIRECTION_BOTH
	num.offset_top = 26.0 if boss else 14.0
	btn.add_child(num)
	if boss:
		var bl := make_label(22, Color("ffe27a"))
		bl.text = T("BOSS")
		bl.set_anchors_preset(Control.PRESET_CENTER_TOP)
		bl.grow_horizontal = Control.GROW_DIRECTION_BOTH
		bl.offset_top = 6.0
		btn.add_child(bl)
	if is_open:
		var got := stars_of(z, l)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 4)
		row.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
		row.grow_horizontal = Control.GROW_DIRECTION_BOTH
		row.grow_vertical = Control.GROW_DIRECTION_BEGIN
		row.offset_bottom = -12.0
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.add_child(row)
		for i in 3:
			var tr := TextureRect.new()
			tr.texture = get_tex("res://art/star_on.png" if i < got else "res://art/star_off.png")
			tr.custom_minimum_size = Vector2(44, 44)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
			row.add_child(tr)
	else:
		var lk := TextureRect.new()
		lk.texture = get_tex("res://art/lock.png")
		lk.set_anchors_preset(Control.PRESET_CENTER)
		lk.grow_horizontal = Control.GROW_DIRECTION_BOTH
		lk.grow_vertical = Control.GROW_DIRECTION_BOTH
		lk.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.add_child(lk)
	btn.pressed.connect(on_level_tile.bind(z, l))
	return btn


func on_home_adventure() -> void:
	go(show_zones.bind(Mode.ADVENTURE))


func on_home_endless() -> void:
	go(show_zones.bind(Mode.ENDLESS))


func on_page(d: int) -> void:
	cur_page = clampi(cur_page + d, 0, page_count() - 1)
	refresh_zones()


func on_zone_card(z: int) -> void:
	if zone_mode == Mode.ADVENTURE:
		go(show_levels.bind(z))
	else:
		go(start_endless.bind(z))


func on_level_tile(z: int, l: int) -> void:
	go(select_level.bind(z, l))


func start_endless(z: int) -> void:
	mode = Mode.ENDLESS
	daily_run = false
	apply_zone(z)
	show_ready()


func select_level(z: int, l: int) -> void:
	mode = Mode.ADVENTURE
	daily_run = false
	level = l
	apply_zone(z)
	show_ready()


func go(cb: Callable) -> void:
	if busy:
		return
	busy = true
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.14)
	tw.tween_callback(cb)
	tw.tween_property(fade, "color:a", 0.0, 0.2)
	tw.tween_callback(unbusy)


func unbusy() -> void:
	busy = false


func go_back() -> void:
	if busy:
		return
	if state == State.PLAYING:
		pause_game()
	elif state == State.PAUSED:
		resume_game()
	elif state == State.READY or state == State.DEAD or state == State.WIN:
		to_select()
	elif state == State.MENU:
		if screen == "levels":
			go(show_zones.bind(Mode.ADVENTURE))
		elif screen != "home":
			go(show_menu)


func to_select() -> void:
	if daily_run:
		go(show_menu)
	elif mode == Mode.ADVENTURE:
		go(show_levels.bind(zone))
	else:
		go(show_zones.bind(Mode.ENDLESS))


func to_menu() -> void:
	go(show_menu)


func show_banner(title: String, sub: String) -> void:
	banner_title.text = title
	banner_sub.text = sub
	if banner_tw != null and banner_tw.is_valid():
		banner_tw.kill()
	banner_box.modulate.a = 1.0
	banner_tw = create_tween()
	banner_tw.tween_property(banner_box, "modulate:a", 0.0, 0.6).set_delay(1.5)


func level_title_text() -> String:
	if mode == Mode.ENDLESS:
		return T("ENDLESS")
	if daily_run:
		return T("DAILY CHALLENGE")
	if level == LEVELS_PER_ZONE - 1:
		return T("FINAL CHALLENGE")
	return T("LEVEL %d") % (level + 1)


func show_ready() -> void:
	reset_run_state()
	hide_screens()
	state = State.READY
	screen = "ready"
	var nm: String = ZONES[zone]["name"]
	ready_title.text = level_title_text()
	ready_sub.text = T(nm)
	ready_box.visible = true
	play_sfx("ready")
	update_hud()


func init_progress() -> void:
	prog.clear()
	eb.clear()
	for z in ZONES.size():
		var row: Array = []
		for l in LEVELS_PER_ZONE:
			row.append(0)
		prog.append(row)
		eb.append(0)
	owned = ["skin0", "trail0", "horn0"]
	skills.clear()
	for sd in SKILLS:
		skills[String(sd["id"])] = 0


func stars_of(z: int, l: int) -> int:
	return int(prog[z][l])


func cleared(z: int) -> int:
	var n := 0
	for l in LEVELS_PER_ZONE:
		if stars_of(z, l) > 0:
			n += 1
	return n


func zone_stars(z: int) -> int:
	var n := 0
	for l in LEVELS_PER_ZONE:
		n += stars_of(z, l)
	return n


func total_stars() -> int:
	var n := 0
	for z in ZONES.size():
		n += zone_stars(z)
	return n


func zone_open(z: int) -> bool:
	return z == 0 or cleared(z - 1) >= ZONE_NEED


func level_open(z: int, l: int) -> bool:
	return zone_open(z) and (l == 0 or stars_of(z, l - 1) > 0)


func next_target() -> Vector2i:
	if level < LEVELS_PER_ZONE - 1:
		return Vector2i(zone, level + 1)
	if zone + 1 < ZONES.size() and zone_open(zone + 1):
		return Vector2i(zone + 1, 0)
	return Vector2i(-1, -1)


func reset_run_state() -> void:
	clear_run()
	if banner_tw != null and banner_tw.is_valid():
		banner_tw.kill()
	banner_box.modulate.a = 0.0
	uni.modulate.a = 1.0
	shield_t = 0.0
	magnet_t = 0.0
	x2_t = 0.0
	slow_t = 0.0
	invuln = 0.0
	sparks.emitting = false
	ducking = false
	held = false
	falling = false
	dk = 0.0
	duck_ids.clear()
	jump_ids.clear()
	jumps = 0
	uy = FLOOR
	vy = 0.0
	combo = 0
	shake = 0.0
	world.position = Vector2.ZERO


func clear_run() -> void:
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	trail.clear()
	if finish_node != null and is_instance_valid(finish_node):
		finish_node.queue_free()
	finish_node = null


func start_run() -> void:
	clear_run()
	distance = 0.0
	score = 0
	coins = 0
	combo = 0
	combo_t = 0.0
	best_combo = 0
	uy = FLOOR
	vy = 0.0
	jumps = 0
	dk = 0.0
	falling = false
	last_kind = ""
	last_kind2 = ""
	spawn_gap = 700.0
	shake = 0.0
	ev_i = 0
	lives = start_lives()
	invuln = 0.0
	shield_t = 6.0 if eq_pet == 2 else 0.0
	magnet_t = 0.0
	x2_t = 0.0
	slow_t = 0.0
	revives = 0
	banked = 0
	picked = 0
	coin_n = 0
	power_cd = prng.randi_range(4, 6)
	run_clock = 0.0
	rec_t = 0.0
	rec_d = PackedFloat32Array()
	rec_y = PackedFloat32Array()
	ghost_data = {}
	ghost_sprite.visible = false
	if mode == Mode.ENDLESS and ghosts.has(str(zone)):
		ghost_data = ghosts[str(zone)]
	stat_add("runs", 1)
	mission_event("runs", 1)
	world.position = Vector2.ZERO
	if mode == Mode.ADVENTURE:
		lv = build_level(zone, level, day_index() if daily_run else 0)
		lv_ev = lv["ev"]
		lv_len = float(lv["len"])
		lv_total = int(lv["coins"])
		speed = float(lv["sp"])
	else:
		lv_ev = []
		lv_len = 1.0
		lv_total = 0
		speed = START_SPEED
	hide_screens()
	state = State.PLAYING
	screen = "play"
	pause_btn.visible = true
	progress_bar.visible = mode == Mode.ADVENTURE
	progress_bar.value = 0.0
	sparks.emitting = true
	var nm: String = ZONES[zone]["name"]
	if mode == Mode.ADVENTURE:
		show_banner(level_title_text(), T(nm))
	else:
		show_banner(T(nm), T("ENDLESS"))
	update_hud()


func on_retry() -> void:
	start_run()


func on_next() -> void:
	var t := next_target()
	if t.x < 0:
		return
	mode = Mode.ADVENTURE
	daily_run = false
	level = t.y
	apply_zone(t.x)
	start_run()


func pause_game() -> void:
	if state != State.PLAYING:
		return
	state = State.PAUSED
	pause_panel.visible = true
	sparks.emitting = false
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()


func resume_game() -> void:
	if state != State.PAUSED:
		return
	state = State.PLAYING
	pause_panel.visible = false
	sparks.emitting = true


func press() -> void:
	if state == State.READY:
		start_run()
		do_jump()
	elif state == State.PLAYING:
		do_jump()


func do_jump() -> void:
	if jumps >= MAX_JUMPS:
		return
	vy = JUMP_V if jumps == 0 else JUMP_V * 0.92
	jumps += 1
	play_sfx("jump" if jumps == 1 else "djump")
	pop(Vector2(UNI_X - 20.0, uy - 6.0), 8, 0.6)


func touch_down(index: int, pos: Vector2) -> void:
	if state != State.READY and state != State.PLAYING:
		return
	var w := get_viewport_rect().size.x
	if state == State.PLAYING and pos.x < w * 0.3:
		duck_ids[index] = true
		ducking = true
	else:
		jump_ids[index] = true
		held = true
		press()


func touch_up(index: int) -> void:
	if duck_ids.has(index):
		duck_ids.erase(index)
		ducking = not duck_ids.is_empty()
	if jump_ids.has(index):
		jump_ids.erase(index)
		held = not jump_ids.is_empty()


func _input(event: InputEvent) -> void:
	if loading_on:
		get_viewport().set_input_as_handled()
		return
	if event is InputEventScreenTouch and event.pressed:
		if tap_button(event.position):
			get_viewport().set_input_as_handled()


func tap_button(pos: Vector2) -> bool:
	for i in range(touch_buttons.size() - 1, -1, -1):
		if not is_instance_valid(touch_buttons[i]):
			touch_buttons.remove_at(i)
			continue
		var b: Button = touch_buttons[i]
		if b.is_visible_in_tree() and not b.disabled and b.get_global_rect().has_point(pos):
			if not b.has_meta("quiet"):
				play_sfx("click")
			if b.has_meta("cp_press"):
				Cp.press(b)
			elif not b.has_meta("quiet"):
				punch(b)
			b.pressed.emit()
			return true
	return false


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_down(event.index, event.position)
		else:
			touch_up(event.index)
	elif event is InputEventKey and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_UP or event.keycode == KEY_W:
			held = event.pressed
			if event.pressed:
				press()
		elif event.keycode == KEY_DOWN or event.keycode == KEY_S:
			ducking = event.pressed
		elif event.pressed and (event.keycode == KEY_P or event.keycode == KEY_ESCAPE):
			if state == State.PLAYING:
				pause_game()
			elif state == State.PAUSED:
				resume_game()
			elif event.keycode == KEY_ESCAPE:
				go_back()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		held = false
		ducking = false
		duck_ids.clear()
		jump_ids.clear()
		pause_game()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		go_back()


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	audio_tick(delta)
	if state != State.PAUSED:
		run_time += delta
	if state == State.PLAYING:
		update_play(delta)
	elif state == State.READY or state == State.MENU:
		scroll_layers(START_SPEED * 0.35 * delta)
	elif state == State.DEAD:
		update_dead(delta)
	elif state == State.WIN:
		update_win(delta)
	if state != State.PAUSED:
		scroll_clouds(delta)
	update_visuals(delta)
	update_stars()
	fps_timer += delta
	if fps_timer >= 0.5:
		fps_timer = 0.0
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()


func on_ice() -> bool:
	if uy < FLOOR - 4.0:
		return false
	for o in obstacles:
		if o["kind"] == "ice":
			var n: Node2D = o["node"]
			if absf(n.position.x - UNI_X) < 80.0:
				return true
	return false


func update_play(delta: float) -> void:
	run_clock += delta
	stats["time"] = float(stats.get("time", 0.0)) + delta
	if mode == Mode.ENDLESS:
		speed = minf(MAX_SPEED, START_SPEED + distance * 0.02)
	var boost := ICE_BOOST if on_ice() else 1.0
	var slow := 0.7 if slow_t > 0.0 else 1.0
	var dx := speed * delta * boost * slow
	distance += dx
	var new_score := int(distance / 10.0)
	if new_score != score:
		score = new_score
		update_hud()
	dk = move_toward(dk, 1.0 if ducking else 0.0, delta * 9.0)
	var g := GRAVITY
	if held and vy < 0.0:
		g *= hold_g()
	elif ducking and uy < FLOOR - 1.0:
		g *= DUCK_FALL
	vy += g * delta
	uy += vy * delta
	if uy >= FLOOR:
		if vy > 300.0:
			pop(Vector2(UNI_X, FLOOR), 6, 0.5)
			play_sfx("land", clampf((vy - 300.0) / 700.0, 0.0, 1.0))
		uy = FLOOR
		vy = 0.0
		jumps = 0
	tick_powers(delta)
	scroll_layers(dx)
	move_things(delta, dx)
	if mode == Mode.ENDLESS:
		spawn_gap -= dx
		if spawn_gap <= 0.0:
			spawn_pattern()
	else:
		spawn_events()
	pull_coins(delta)
	check_hits()
	if state != State.PLAYING:
		return
	if mode == Mode.ADVENTURE:
		progress_bar.value = clampf(distance / lv_len, 0.0, 1.0)
		if finish_node != null and finish_node.position.x <= UNI_X:
			win()
			return
	update_power_hud()
	if mode == Mode.ENDLESS:
		record_ghost(delta)
		update_ghost()
	update_trail(dx)
	combo_t -= delta
	if combo_t <= 0.0 and combo > 0:
		combo = 0
		update_hud()
	sparks.position = Vector2(UNI_X + TAIL_DX, uy + TAIL_DY)
	sparks.initial_velocity_min = speed * 0.6
	sparks.initial_velocity_max = speed * 1.0 + 60.0


func update_dead(delta: float) -> void:
	if falling:
		vy += GRAVITY * delta * 0.9
		uy += vy * delta


func update_win(delta: float) -> void:
	var dx := speed * 0.6 * delta
	scroll_layers(dx)
	if uy < FLOOR or vy != 0.0:
		vy += GRAVITY * delta
		uy += vy * delta
		if uy >= FLOOR:
			uy = FLOOR
			vy = 0.0
			jumps = 0
	update_trail(dx)
	sparks.position = Vector2(UNI_X + TAIL_DX, uy + TAIL_DY)


func scroll_layers(dx: float) -> void:
	for l in layers:
		var off: float = fmod(l["off"] + dx * l["f"], l["w"])
		l["off"] = off
		var s: Sprite2D = l["node"]
		s.region_rect = Rect2(off, 0.0, WIDE, l["h"])


func scroll_clouds(delta: float) -> void:
	var base := speed if state == State.PLAYING else START_SPEED * 0.35
	for c in clouds:
		var n: Sprite2D = c["node"]
		n.position.x -= (base * c["f"] + 10.0) * delta
		if n.position.x < -380.0:
			n.position.x = get_viewport_rect().size.x + randf_range(40.0, 300.0)
			n.position.y = randf_range(40.0, 230.0)


func update_stars() -> void:
	if not stars_node.visible:
		return
	for i in 14:
		var d: Dictionary = star_list[i]
		var n: Sprite2D = d["node"]
		n.modulate.a = float(d["a"]) * (0.55 + 0.45 * sin(run_time * 2.4 + float(d["ph"])))


func move_things(_delta: float, dx: float) -> void:
	for i in range(obstacles.size() - 1, -1, -1):
		var o: Dictionary = obstacles[i]
		var n: Node2D = o["node"]
		n.position.x -= dx * float(o["v"])
		if n.position.x < -260.0:
			n.queue_free()
			obstacles.remove_at(i)
	for i in range(items.size() - 1, -1, -1):
		var it: Dictionary = items[i]
		var n: Sprite2D = it["node"]
		n.position.x -= dx * float(it["v"])
		if n.position.x < -80.0:
			n.queue_free()
			items.remove_at(i)
	if finish_node != null:
		finish_node.position.x -= dx


func kind_weights() -> Dictionary:
	var sc := float(score)
	var d := minf(sc / 2500.0, 1.0)
	var w := {"crystal1": 0.35, "crystal2": 0.25}
	if sc > 15.0:
		w["spikes"] = 0.5
	if sc > 60.0:
		w["fire"] = 0.12
	if sc > 80.0:
		w["storm_low"] = 0.3 + 0.1 * d
		w["storm_high"] = 0.2 + 0.12 * d
	if sc > 100.0:
		w["boulder"] = 0.35
	if sc > 120.0:
		w["pit"] = 0.25
	if sc > 200.0:
		w["spin"] = 0.15
	if sc > 260.0:
		w["bird"] = 0.15
		w["wall"] = 0.33
	if sc > 300.0:
		w["swing"] = 0.16
	if sc > 350.0:
		w["pillar"] = 0.12
	if sc > 380.0:
		w["laser"] = 0.14
	if sc > 450.0:
		w["wisp"] = 0.14
	var zs: String = ZONES[zone]["zs"]
	if zs == "ice" and sc > 30.0:
		w["ice"] = 0.3
	if last_kind != "" and w.has(last_kind):
		w[last_kind] *= 0.15
	if last_kind2 != "" and w.has(last_kind2):
		w[last_kind2] *= 0.55
	return w


func pick_kind() -> String:
	var w := kind_weights()
	var total := 0.0
	for k in w:
		total += float(w[k])
	var r := randf() * total
	for k in w:
		r -= float(w[k])
		if r <= 0.0:
			last_kind2 = last_kind
			last_kind = k
			return k
	return "crystal1"


func spawn_pattern() -> void:
	var x := get_viewport_rect().size.x + 140.0
	var r := randf()
	var extra := 0.0
	if r < 0.55:
		var k := pick_kind()
		add_obstacle(k, x, k == "pit" and randf() < 0.3)
		coins_for(k, x)
	elif r < 0.82 and score > 40:
		var k1 := pick_kind()
		var k2 := pick_kind()
		var off := 330.0
		if k1 == "pit" or k1 == "swing":
			off = 470.0
		add_obstacle(k1, x)
		add_obstacle(k2, x + off)
		coins_for(k1, x)
		coins_for(k2, x + off)
		extra = off
	else:
		add_coin_line(x, 8, FLOOR - 70.0 - randf() * 90.0)
	spawn_gap = speed * randf_range(0.95, 1.4) + 300.0 + extra
	power_cd -= 1
	if power_cd <= 0:
		power_cd = maxi(3, prng.randi_range(5, 8) - skill_lv("luck"))
		var pt := pick_power(prng)
		if pt == "heart" and lives >= 5:
			pt = "shield"
		add_power(x + spawn_gap * 0.5, FLOOR - 95.0, pt)


func coin_count(kind: String) -> int:
	match kind:
		"boulder":
			return 0
		"bird", "storm_low", "storm_high", "wisp":
			return 3
		"ice":
			return 4
	return 5


func coins_for(kind: String, x: float) -> void:
	var v: float = KINDS[kind]["v"]
	match kind:
		"boulder":
			pass
		"wall", "pillar":
			add_coin_arc(x, 5, 230.0, v)
		"bird", "storm_low", "storm_high", "wisp":
			add_coin_line(x - 60.0, 3, FLOOR - 40.0, v)
		"ice":
			add_coin_line(x - 90.0, 4, FLOOR - 45.0, v)
		"laser":
			add_coin_arc(x, 5, 200.0, v)
		_:
			add_coin_arc(x, 5, 150.0, v)


func level_weights(z: int, l: int, d: float) -> Dictionary:
	var gi := z * LEVELS_PER_ZONE + l
	var zs: String = ZONES[z]["zs"]
	var w := {"crystal1": 0.7, "crystal2": 0.5}
	if gi >= 1:
		w["spikes"] = 0.4 + 0.3 * d
	if gi >= 4:
		w["storm_low"] = 0.3 + 0.3 * d
	if gi >= 6:
		w["boulder"] = 0.25 + 0.2 * d
	if gi >= 8:
		w["storm_high"] = 0.25 + 0.25 * d
	if gi >= 10:
		w["pit"] = 0.25 + 0.3 * d
	if gi >= 12:
		w["spin"] = 0.2 + 0.2 * d
	if gi >= 14:
		w["wall"] = 0.2 + 0.2 * d
	if gi >= 16:
		w["swing"] = 0.2 + 0.25 * d
	if gi >= 20:
		w["laser"] = 0.2 + 0.25 * d
	if gi >= 22:
		w["bird"] = 0.2 + 0.2 * d
	if gi >= 24:
		w["wisp"] = 0.2 + 0.2 * d
	if gi >= 28:
		w["pillar"] = 0.2 + 0.2 * d
	if zs == "ice" and l >= 1:
		w["ice"] = 0.35
	if zs == "fire" and l >= 1:
		w["fire"] = 0.4
	return w


func pick_weighted(w: Dictionary, total: float, rng: RandomNumberGenerator) -> String:
	var r := rng.randf() * total
	for k in w:
		r -= float(w[k])
		if r <= 0.0:
			return String(k)
	return "crystal1"


func push_ev(ev: Array, st: Dictionary, kind: String, rng: RandomNumberGenerator) -> void:
	var wide := false
	var half := 0.0
	if kind == "pit":
		wide = rng.randf() < 0.3
		half = 80.0 if wide else 50.0
	st["at"] = float(st["at"]) + half
	ev.append({"at": float(st["at"]), "kind": kind, "wide": wide})
	st["coins"] = int(st["coins"]) + coin_count(kind)
	st["at"] = float(st["at"]) + half


func build_level(z: int, l: int, salt: int = 0) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = z * 1009 + l * 131 + 17 + salt * 7
	var boss := l == LEVELS_PER_ZONE - 1
	var gi := z * LEVELS_PER_ZONE + l
	var d := clampf(0.05 + float(gi) / float(ZONES.size() * LEVELS_PER_ZONE) * 0.95 + (0.12 if boss else 0.0), 0.0, 1.0)
	var sp := minf(390.0 + float(z) * 9.0 + float(l) * 13.0 + (30.0 if boss else 0.0), 780.0)
	var secs := 30.0 + float(l) * 3.0 + (6.0 if boss else 0.0)
	var length := roundf(sp * secs)
	var w := level_weights(z, l, d)
	var total_w := 0.0
	for key in w:
		total_w += float(w[key])
	var rh: Array = RHYTHMS[rng.randi() % RHYTHMS.size()]
	var combos: Array = []
	if boss or l >= 5:
		for c in COMBOS:
			var ok := true
			for part in c:
				if not w.has(part[0]):
					ok = false
			if ok:
				combos.append(c)
	var ev: Array = []
	var st := {"at": 1500.0, "coins": 0}
	var idx := 0
	var last_k := ""
	var since_power := 0
	var power_thr := maxi(3, 6 - skill_lv("luck"))
	var end_at := length - sp * 1.6
	while float(st["at"]) < end_at:
		if combos.size() > 0 and float(st["at"]) + sp * 3.4 < end_at and rng.randf() < (0.38 if boss else 0.14):
			var cb: Array = combos[rng.randi() % combos.size()]
			for part in cb:
				st["at"] = float(st["at"]) + sp * float(part[1])
				push_ev(ev, st, String(part[0]), rng)
			last_k = ""
		else:
			var kind := pick_weighted(w, total_w, rng)
			var tries := 0
			while tries < 3 and kind == last_k:
				kind = pick_weighted(w, total_w, rng)
				tries += 1
			last_k = kind
			push_ev(ev, st, kind, rng)
		var gap := sp * (1.0 - 0.25 * d) * float(rh[idx % rh.size()]) + rng.randf() * sp * 0.45 + 180.0
		if gap > 640.0 and rng.randf() < 0.2:
			ev.append({"at": float(st["at"]) + gap * 0.3, "kind": "coinline", "y": FLOOR - 70.0 - rng.randf() * 90.0})
			st["coins"] = int(st["coins"]) + 8
		since_power += 1
		if since_power >= power_thr and gap > 520.0:
			ev.append({"at": float(st["at"]) + gap * 0.55, "kind": "power", "pu": pick_power(rng), "y": FLOOR - 95.0})
			since_power = 0
		st["at"] = float(st["at"]) + gap
		idx += 1
	ev.append({"at": length, "kind": "finish"})
	return {"sp": sp, "len": length, "ev": ev, "coins": int(st["coins"]), "boss": boss, "d": d}


func spawn_events() -> void:
	var limit := get_viewport_rect().size.x + 140.0
	while ev_i < lv_ev.size():
		var e: Dictionary = lv_ev[ev_i]
		var x := UNI_X + float(e["at"]) - distance
		if x > limit:
			break
		spawn_event(e, x)
		ev_i += 1


func spawn_event(e: Dictionary, x: float) -> void:
	var k: String = e["kind"]
	if k == "finish":
		add_finish(x)
	elif k == "coinline":
		add_coin_line(x, 8, float(e["y"]))
	elif k == "power":
		add_power(x, float(e["y"]), String(e["pu"]))
	else:
		add_obstacle(k, x, bool(e["wide"]))
		coins_for(k, x)


func win() -> void:
	state = State.WIN
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()
	pause_btn.visible = false
	progress_bar.visible = false
	combo_label.visible = false
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	if finish_node != null:
		finish_node.queue_free()
		finish_node = null
	var pct := 1.0
	if lv_total > 0:
		pct = float(picked) / float(lv_total)
	var got := 1
	if pct >= 0.6:
		got = 2
	if pct >= 0.9:
		got = 3
	var before := cleared(zone)
	var note := ""
	if daily_run:
		var rw := daily_reward()
		var ns := next_streak()
		dstate["streak"] = ns
		dstate["last"] = today_str()
		dstate["chal"] = true
		bank += rw
		stat_add("daily", 1)
		note = T("Daily reward  +%d") % rw
	else:
		if level == LEVELS_PER_ZONE - 1 and stars_of(zone, level) == 0:
			stat_add("bosses", 1)
		if got > stars_of(zone, level):
			prog[zone][level] = got
		mission_event("levels", 1)
	bank_run()
	end_run_stats()
	play_sfx("win")
	vibrate(80)
	gain_xp(40 + got * 20 + (60 if daily_run else 0))
	save_game()
	if not daily_run and before < ZONE_NEED and cleared(zone) >= ZONE_NEED and zone + 1 < ZONES.size():
		var nz: String = ZONES[zone + 1]["name"]
		note = T("ZONE UNLOCKED  -  %s") % T(nz)
	win_title.text = T("LEVEL COMPLETE") if daily_run or level < LEVELS_PER_ZONE - 1 else T("ZONE BOSS DEFEATED")
	win_info.text = T("Coins  %d     Pickups  %d / %d  (%d%%)") % [coins, picked, lv_total, int(pct * 100.0)]
	win_note.text = note
	win_note.visible = note != ""
	win_next.visible = next_target().x >= 0 and not daily_run
	for i in 3:
		var tr: TextureRect = win_stars[i]
		tr.texture = get_tex("res://art/star_on.png" if i < got else "res://art/star_off.png")
		tr.modulate.a = 0.0
		var tw := create_tween()
		tw.tween_property(tr, "modulate:a", 1.0, 0.25).set_delay(0.5 + 0.25 * float(i))
	pop(Vector2(UNI_X + 40.0, uy - 60.0), 24, 1.6)
	win_panel.visible = false
	get_tree().create_timer(0.9).timeout.connect(reveal_win)


func reveal_win() -> void:
	if state == State.WIN:
		win_panel.visible = true


func die(pit: bool = false) -> void:
	state = State.DEAD
	falling = pit
	shake = 8.0 if pit else 18.0
	sparks.emitting = false
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()
	pause_btn.visible = false
	progress_bar.visible = false
	combo_label.visible = false
	lives = 0
	bank_run()
	play_sfx("fall" if pit else "die")
	vibrate(120)
	end_run_stats()
	if mode == Mode.ENDLESS:
		add_record(score)
		if score > int(eb[zone]):
			eb[zone] = score
			ghosts[str(zone)] = {"d": rec_d, "y": rec_y}
		over_title.text = T("GAME OVER")
		over_score.text = T("Score  %d") % score
		over_best.text = T("Best  %d     Coins  %d     Combo  x%d") % [int(eb[zone]), coins, best_combo]
		over_nav.text = T("ZONES")
	else:
		var pct := int(clampf(distance / lv_len, 0.0, 1.0) * 100.0)
		over_title.text = T("LEVEL FAILED")
		over_score.text = T("Progress  %d%%") % pct
		over_best.text = T("Coins  %d     Pickups  %d / %d") % [coins, picked, lv_total]
		over_nav.text = T("LEVELS")
	over_revive.visible = revives < 2
	over_revive.text = T("REVIVE   -%d") % revive_cost()
	save_game()
	over_panel.visible = true
	if not pit:
		pop(Vector2(UNI_X, uy - 50.0), 18, 1.4)


func add_obstacle(kind: String, x: float, wide: bool = false) -> void:
	if kind == "swing":
		add_swing(x)
		return
	var info: Dictionary = KINDS[kind]
	var sheet: String = info["sheet"]
	if kind.begins_with("storm"):
		sheet = storm_sheet
	var s := Sprite2D.new()
	var tex: Texture2D = get_tex("res://art/obs_%s.png" % sheet)
	s.texture = tex
	s.hframes = maxi(1, int(tex.get_width() / FR))
	s.frame = 0
	s.centered = false
	s.offset = Vector2(-192, -FEET)
	var sx := UNI_SCALE
	var half := 0.0
	if kind == "pit":
		half = 80.0 if wide else 50.0
		sx = UNI_SCALE * (1.6 if wide else 1.0)
	s.scale = Vector2(sx, UNI_SCALE)
	s.position = Vector2(x, FLOOR - float(info["lift"]) * S)
	world.add_child(s)
	world.move_child(s, uni.get_index())
	obstacles.append({"node": s, "kind": kind, "v": info["v"], "n": info["n"], "fps": info["fps"], "ph": randf() * 4.0, "nm": false, "passed": false, "half": half})


func add_swing(x: float) -> void:
	var tex: Texture2D = get_tex("res://art/obs_swing.png")
	var root := Node2D.new()
	root.position = Vector2(x, FLOOR - 250.0)
	var chain := Line2D.new()
	chain.width = 5.0
	chain.default_color = Color("d9c8f5")
	chain.add_point(Vector2.ZERO)
	chain.add_point(Vector2(0.0, 200.0))
	root.add_child(chain)
	var mount := Sprite2D.new()
	mount.texture = tex
	mount.hframes = 2
	mount.frame = 1
	mount.scale = Vector2(UNI_SCALE, UNI_SCALE)
	mount.position = Vector2(0.0, -20.0 * UNI_SCALE)
	root.add_child(mount)
	var ball := Sprite2D.new()
	ball.texture = tex
	ball.hframes = 2
	ball.frame = 0
	ball.scale = Vector2(UNI_SCALE, UNI_SCALE)
	ball.position = Vector2(0.0, 200.0)
	root.add_child(ball)
	world.add_child(root)
	world.move_child(root, uni.get_index())
	obstacles.append({"node": root, "kind": "swing", "v": 1.0, "n": 1, "fps": 1.0, "ph": randf() * 6.28, "nm": false, "passed": false, "half": 0.0, "ball": ball, "chain": chain, "len": 200.0, "amp": 0.95, "freq": 2.3 + randf() * 0.4})


func add_finish(x: float) -> void:
	var s := Sprite2D.new()
	s.texture = get_tex("res://art/finish.png")
	s.centered = false
	s.offset = Vector2(-192, -FEET)
	s.scale = Vector2(UNI_SCALE, UNI_SCALE)
	s.position = Vector2(x, FLOOR)
	world.add_child(s)
	world.move_child(s, uni.get_index())
	finish_node = s


func add_coin(x: float, y: float, v: float = 1.0) -> void:
	var s := Sprite2D.new()
	s.texture = get_tex("res://art/coin.png")
	s.scale = Vector2(0.3, 0.3)
	s.position = Vector2(x, y)
	world.add_child(s)
	items.append({"node": s, "ph": randf() * 6.28, "y": y, "v": v})


func add_coin_arc(cx: float, count: int, height: float, v: float = 1.0) -> void:
	for i in count:
		var t := float(i) / float(count - 1)
		add_coin(cx - 120.0 + t * 240.0, FLOOR - 50.0 - sin(t * PI) * height, v)


func add_coin_line(x: float, count: int, y: float, v: float = 1.0) -> void:
	for i in count:
		add_coin(x + i * 62.0, y, v)


func player_rect() -> Rect2:
	var top := uy - lerpf(42.0, 22.0, dk) * S
	var bottom := uy - 7.0 * S
	return Rect2(UNI_X - 11.0 * S, top, 22.0 * S, bottom - top)


func wisp_center(o: Dictionary) -> float:
	return 38.0 + sin(run_time * 3.2 + float(o["ph"]) * 2.0) * 20.0


func laser_on(o: Dictionary) -> bool:
	return fmod(run_time * 0.5 + float(o["ph"]), 1.0) < 0.5


func swing_ball(o: Dictionary) -> Vector2:
	var n: Node2D = o["node"]
	var a := float(o["amp"]) * sin(run_time * float(o["freq"]) + float(o["ph"]))
	return n.position + Vector2(sin(a), cos(a)) * float(o["len"])


func circle_hits_rect(c: Vector2, r: float, rc: Rect2) -> bool:
	var px := clampf(c.x, rc.position.x, rc.end.x)
	var py := clampf(c.y, rc.position.y, rc.end.y)
	return c.distance_to(Vector2(px, py)) < r


func obstacle_boxes(o: Dictionary) -> Array:
	var k: String = o["kind"]
	if k == "wisp":
		var c := wisp_center(o)
		return [[-9.0, 9.0, c - 9.0, c + 9.0]]
	if k == "laser" and not laser_on(o):
		return []
	return KINDS[k]["boxes"]


func check_hits() -> void:
	var ur := player_rect()
	for o in obstacles:
		var n: Node2D = o["node"]
		var k: String = o["kind"]
		var hit := false
		var near := false
		if k == "swing":
			hit = circle_hits_rect(swing_ball(o), 26.0, ur)
		elif k == "pit":
			if invuln <= 0.0 and uy >= FLOOR - 3.0 and absf(n.position.x - UNI_X) < float(o["half"]) - 12.0:
				hurt(true)
				if state != State.PLAYING:
					return
		else:
			for b in obstacle_boxes(o):
				var orect := Rect2(n.position.x + float(b[0]) * S, FLOOR - float(b[3]) * S, (float(b[1]) - float(b[0])) * S, (float(b[3]) - float(b[2])) * S)
				if ur.intersects(orect):
					hit = true
				else:
					var gx := maxf(orect.position.x - ur.end.x, ur.position.x - orect.end.x)
					var gy := maxf(orect.position.y - ur.end.y, ur.position.y - orect.end.y)
					if gx < 0.0 and gy >= 0.0 and gy < 14.0:
						near = true
		if hit and invuln <= 0.0:
			hurt(false)
			if state != State.PLAYING:
				return
		if near:
			o["nm"] = true
		if not o["passed"] and n.position.x < UNI_X - 60.0:
			o["passed"] = true
			if o["nm"]:
				play_sfx("near")
				add_combo(2)
				pop(Vector2(UNI_X + 30.0, uy - 70.0), 6, 0.5)
	var center := Vector2(UNI_X, uy - 58.0 + dk * 20.0)
	for i in range(items.size() - 1, -1, -1):
		var it: Dictionary = items[i]
		var n: Sprite2D = it["node"]
		if n.position.distance_to(center) < 56.0:
			if it.has("pu"):
				apply_power(String(it["pu"]))
				pop(n.position, 14, 1.2)
			else:
				pop(n.position, 10, 1.0)
				picked += 1
				var val := 2 if x2_t > 0.0 else 1
				coin_n += 1
				if eq_pet == 1 and coin_n % 5 == 0:
					val += 1
				coins += val
				add_combo(1)
				play_sfx("coin", float(combo))
			n.queue_free()
			items.remove_at(i)
			update_hud()


func add_combo(n: int) -> void:
	combo += n
	combo_t = combo_window()
	best_combo = maxi(best_combo, combo)
	if combo >= 4 and mode == Mode.ENDLESS:
		distance += 3.0 * float(n) * 10.0
	update_hud()


func update_trail(dx: float) -> void:
	for i in trail.size():
		trail[i] = Vector2(trail[i].x - dx, trail[i].y)
	var anchor_x := UNI_X + TAIL_DX
	trail.append(Vector2(anchor_x, uy + TAIL_DY + dk * 14.0))
	while trail.size() > 0 and trail[0].x < anchor_x - TRAIL_LEN:
		trail.remove_at(0)
	var n := trail.size()
	for k in 6:
		var pts := PackedVector2Array()
		for i in n:
			var p := trail[i]
			var age := 1.0 - float(i) / float(maxi(n - 1, 1))
			var wave := sin(p.x * 0.028 + run_time * 9.0) * 7.0 * age
			pts.append(Vector2(p.x, p.y + (float(k) - 2.5) * 6.4 + wave))
		lines[k].points = pts


func update_swing(o: Dictionary) -> void:
	var root: Node2D = o["node"]
	var local := swing_ball(o) - root.position
	var ball: Sprite2D = o["ball"]
	var chain: Line2D = o["chain"]
	ball.position = local
	ball.rotation = local.x * 0.02
	chain.set_point_position(1, local)


func update_visuals(delta: float) -> void:
	if state == State.MENU and screen == "home":
		pet_t = maxf(pet_t - delta, 0.0)
		var hop := 0.0
		if pet_t > 0.0:
			hop = sin(PI * (1.0 - pet_t / 0.5)) * 64.0
		uni.position = Vector2(get_viewport_rect().size.x * 0.5, MENU_FEET - hop)
		uni.scale = Vector2(MENU_SCALE, MENU_SCALE)
	else:
		uni.position = Vector2(UNI_X, uy)
		uni.scale = Vector2(UNI_SCALE, UNI_SCALE)
	if state == State.PLAYING or state == State.WIN:
		if uy < FLOOR - 1.0:
			if uni.animation != "jump":
				uni.play("jump")
		elif dk > 0.5 and state == State.PLAYING:
			if uni.animation != "duck" or not uni.is_playing():
				uni.play("duck")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
		else:
			if uni.animation != "run" or not uni.is_playing():
				uni.play("run")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
	elif state == State.DEAD:
		if uni.animation != "dead":
			uni.play("dead")
	elif state == State.READY or state == State.MENU:
		if uni.animation != "run" or not uni.is_playing():
			uni.play("run")
		uni.speed_scale = 0.6
		if lines.size() > 0:
			for ln in lines:
				ln.points = PackedVector2Array()
	if state == State.PAUSED:
		uni.pause()
	if state != State.PAUSED:
		for o in obstacles:
			var n: Node2D = o["node"]
			var k: String = o["kind"]
			if k == "swing":
				update_swing(o)
				continue
			var sp := n as Sprite2D
			if k == "laser":
				sp.frame = 1 if laser_on(o) else 0
				continue
			if k == "wisp":
				sp.frame = int((run_time + float(o["ph"])) * float(o["fps"])) % int(o["n"])
				sp.position.y = FLOOR - (wisp_center(o) - 40.0) * S
				continue
			if int(o["n"]) > 1:
				sp.frame = int((run_time + float(o["ph"])) * float(o["fps"])) % int(o["n"])
			var bob := 0.0
			if k == "bird" or k == "storm_low" or k == "storm_high":
				bob = sin(run_time * 3.2 + float(o["ph"]) * 2.0) * 4.0
			sp.position.y = FLOOR - float(KINDS[k]["lift"]) * S + bob
		for it in items:
			var n: Sprite2D = it["node"]
			if it.has("pu"):
				var pulse := 0.55 + 0.05 * sin(run_time * 6.0 + float(it["ph"]))
				n.scale = Vector2(pulse, pulse)
				n.position.y = float(it["y"]) + sin(run_time * 3.0 + float(it["ph"])) * 8.0
			else:
				n.scale.x = 0.3 * absf(cos(run_time * 5.0 + it["ph"])) + 0.05
				n.position.y = float(it["y"]) + sin(run_time * 4.0 + it["ph"]) * 5.0
	if state != State.PLAYING:
		ghost_sprite.visible = false
	update_companions(delta)
	if shake > 0.2:
		shake = lerpf(shake, 0.0, minf(1.0, delta * 9.0))
		world.position = Vector2(randf_range(-shake, shake), randf_range(-shake, shake))
	else:
		world.position = Vector2.ZERO
	if state == State.READY:
		ready_label.modulate.a = 0.55 + 0.45 * absf(sin(run_time * 3.0))


func update_hud() -> void:
	score_label.text = "%d" % score
	coin_label.text = "%d" % coins
	var playing := state == State.PLAYING or state == State.PAUSED or state == State.DEAD or state == State.WIN
	score_label.visible = playing
	coin_label.visible = playing
	combo_label.visible = playing and combo >= 2
	combo_label.text = T("COMBO x%d") % combo
	hearts_row.visible = playing
	power_row.visible = playing
	for i in 5:
		var hh: TextureRect = hearts[i]
		hh.visible = i < lives


func pop(pos: Vector2, count: int, power: float) -> void:
	var p := CPUParticles2D.new()
	p.texture = get_tex("res://art/spark.png")
	p.position = pos
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = count
	p.lifetime = 0.6
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 80.0 * power
	p.initial_velocity_max = 220.0 * power
	p.scale_amount_min = 0.2
	p.scale_amount_max = 0.5
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 0.95, 0.6, 1), Color(1, 0.6, 1, 0)])
	p.color_ramp = cg
	world.add_child(p)
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func load_save() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save.cfg") != OK:
		return
	bank = int(cf.get_value("wallet", "bank", 0))
	var flat: Array = cf.get_value("adv", "stars", [])
	if flat.size() == ZONES.size() * LEVELS_PER_ZONE:
		for z in ZONES.size():
			for l in LEVELS_PER_ZONE:
				prog[z][l] = clampi(int(flat[z * LEVELS_PER_ZONE + l]), 0, 3)
	var ebs: Array = cf.get_value("end", "best", [])
	for z in mini(ebs.size(), ZONES.size()):
		eb[z] = int(ebs[z])
	if ebs.is_empty():
		eb[0] = int(cf.get_value("run", "best", 0))
	var own: Array = cf.get_value("shop", "owned", [])
	for key in own:
		if not owned.has(String(key)):
			owned.append(String(key))
	var sk: Dictionary = cf.get_value("shop", "skills", {})
	for id in sk:
		if skills.has(String(id)):
			skills[String(id)] = clampi(int(sk[id]), 0, 3)
	eq_skin = clampi(int(cf.get_value("shop", "skin", 0)), 0, SKINS.size() - 1)
	eq_trail = clampi(int(cf.get_value("shop", "trail", 0)), 0, TRAILS.size() - 1)
	eq_horn = clampi(int(cf.get_value("shop", "horn", 0)), 0, HORNS.size() - 1)
	eq_pet = clampi(int(cf.get_value("shop", "pet", -1)), -1, PETS.size() - 1)
	lang = String(cf.get_value("app", "lang", "en"))
	snd_on = bool(cf.get_value("app", "snd", true))
	mus_on = bool(cf.get_value("app", "mus", true))
	vib_on = bool(cf.get_value("app", "vib", true))
	show_fps = bool(cf.get_value("app", "fps", true))
	reopen = String(cf.get_value("app", "reopen", ""))
	stats = cf.get_value("meta", "stats", {})
	xp = int(cf.get_value("meta", "xp", 0))
	dstate = cf.get_value("meta", "daily", {})
	ach_claimed = cf.get_value("meta", "ach", [])
	records = cf.get_value("meta", "records", [])
	ghosts = cf.get_value("meta", "ghosts", {})
	zone = clampi(int(cf.get_value("run", "zone", 0)), 0, ZONES.size() - 1)
	if not zone_open(zone):
		zone = 0


func save_game() -> void:
	var cf := ConfigFile.new()
	var flat: Array = []
	for z in ZONES.size():
		for l in LEVELS_PER_ZONE:
			flat.append(stars_of(z, l))
	cf.set_value("adv", "stars", flat)
	cf.set_value("end", "best", eb)
	cf.set_value("wallet", "bank", bank)
	cf.set_value("run", "zone", zone)
	cf.set_value("shop", "owned", owned)
	cf.set_value("shop", "skills", skills)
	cf.set_value("shop", "skin", eq_skin)
	cf.set_value("shop", "trail", eq_trail)
	cf.set_value("shop", "horn", eq_horn)
	cf.set_value("shop", "pet", eq_pet)
	cf.set_value("app", "lang", lang)
	cf.set_value("app", "snd", snd_on)
	cf.set_value("app", "mus", mus_on)
	cf.set_value("app", "vib", vib_on)
	cf.set_value("app", "fps", show_fps)
	cf.set_value("app", "reopen", reopen)
	cf.set_value("meta", "stats", stats)
	cf.set_value("meta", "xp", xp)
	cf.set_value("meta", "daily", dstate)
	cf.set_value("meta", "ach", ach_claimed)
	cf.set_value("meta", "records", records)
	cf.set_value("meta", "ghosts", ghosts)
	cf.save("user://save.cfg")


func skill_lv(id: String) -> int:
	return int(skills.get(id, 0))


func skill_max(id: String) -> int:
	return 2 if id == "life" else 3


func skill_cost(i: int) -> int:
	var id: String = SKILLS[i]["id"]
	return int(SKILLS[i]["base"]) * (skill_lv(id) + 1)


func start_lives() -> int:
	return 1 + skill_lv("life") + (1 if eq_pet == 3 else 0)


func hold_g() -> float:
	return HOLD_G - 0.05 * float(skill_lv("float"))


func combo_window() -> float:
	return 1.6 + 0.4 * float(skill_lv("combo"))


func revive_cost() -> int:
	return 40 * (revives + 1)


func pick_power(rng: RandomNumberGenerator) -> String:
	var t: String = POWER_POOL[rng.randi() % POWER_POOL.size()]
	return t


func bank_run() -> void:
	var gain := coins - banked
	bank += gain
	banked = coins
	stat_add("coins", gain)
	mission_event("coins", gain)


func add_power(x: float, y: float, t: String) -> void:
	var s := Sprite2D.new()
	s.texture = get_tex("res://art/pu_%s.png" % t)
	s.scale = Vector2(0.55, 0.55)
	s.position = Vector2(x, y)
	world.add_child(s)
	items.append({"node": s, "ph": randf() * 6.28, "y": y, "v": 1.0, "pu": t})


func apply_power(t: String) -> void:
	var pk: String = {"shield": "shield", "magnet": "magnet", "x2": "sx2", "slow": "slow", "heart": "life"}.get(t, "shield")
	play_sfx(pk)
	stat_add("powers", 1)
	mission_event("powers", 1)
	if t == "shield":
		shield_t = 8.0 + 2.0 * float(skill_lv("shield"))
	elif t == "magnet":
		magnet_t = 8.0 + 2.0 * float(skill_lv("magnet"))
	elif t == "x2":
		x2_t = 10.0 + 3.0 * float(skill_lv("x2"))
	elif t == "slow":
		slow_t = 6.0 + 1.5 * float(skill_lv("slow"))
	elif t == "heart":
		lives = mini(lives + 1, 5)
	update_hud()


func tick_powers(delta: float) -> void:
	invuln = maxf(invuln - delta, 0.0)
	shield_t = maxf(shield_t - delta, 0.0)
	magnet_t = maxf(magnet_t - delta, 0.0)
	x2_t = maxf(x2_t - delta, 0.0)
	slow_t = maxf(slow_t - delta, 0.0)


func pull_coins(delta: float) -> void:
	var radius := 0.0
	if magnet_t > 0.0:
		radius = 380.0
	elif eq_pet == 0:
		radius = 150.0
	if radius <= 0.0:
		return
	var center := Vector2(UNI_X, uy - 58.0)
	for it in items:
		if it.has("pu"):
			continue
		var n: Sprite2D = it["node"]
		var d := center - Vector2(n.position.x, float(it["y"]))
		var dist := d.length()
		if dist < radius and dist > 1.0:
			var step := d / dist * minf(dist, 900.0 * delta)
			n.position.x += step.x
			it["y"] = float(it["y"]) + step.y


func update_power_hud() -> void:
	var tl := {"shield": shield_t, "magnet": magnet_t, "x2": x2_t, "slow": slow_t}
	for t in tl:
		var d: Dictionary = pu_slots[t]
		var box: HBoxContainer = d["box"]
		var v: float = tl[t]
		box.visible = v > 0.0
		if v > 0.0:
			var lb: Label = d["label"]
			lb.text = "%d" % ceili(v)


func hurt(pit: bool) -> void:
	if invuln > 0.0:
		return
	if shield_t > 0.0 or lives > 1:
		play_sfx("break")
	vibrate(40)
	if shield_t > 0.0:
		shield_t = 0.0
		invuln = 1.2
		shake = 8.0
		pop(Vector2(UNI_X, uy - 58.0), 16, 1.2)
		if pit:
			bounce()
		update_hud()
		return
	if lives > 1:
		lives -= 1
		invuln = 1.8
		shake = 12.0
		pop(Vector2(UNI_X, uy - 58.0), 14, 1.0)
		if pit:
			bounce()
		update_hud()
		return
	die(pit)


func bounce() -> void:
	uy = FLOOR - 4.0
	vy = JUMP_V
	jumps = 1


func on_revive() -> void:
	var cost := revive_cost()
	if bank < cost:
		toast("Not enough coins")
		play_sfx("deny")
		return
	bank -= cost
	play_sfx("revive")
	revives += 1
	lives = 1
	invuln = 2.5
	for i in range(obstacles.size() - 1, -1, -1):
		var o: Dictionary = obstacles[i]
		var n: Node2D = o["node"]
		if n.position.x < UNI_X + 650.0:
			n.queue_free()
			obstacles.remove_at(i)
	uy = FLOOR
	vy = 0.0
	dk = 0.0
	jumps = 0
	falling = false
	shake = 0.0
	state = State.PLAYING
	over_panel.visible = false
	pause_btn.visible = true
	progress_bar.visible = mode == Mode.ADVENTURE
	sparks.emitting = true
	save_game()
	update_hud()


func update_companions(delta: float) -> void:
	var ux := uni.position.x
	var uyy := uni.position.y
	var ks := uni.scale.x / UNI_SCALE
	var c := Vector2(ux, uyy - 58.0 * ks + dk * 20.0)
	shield_fx.visible = shield_t > 0.0 and state != State.DEAD
	if shield_fx.visible:
		shield_fx.position = c
		var vis := shield_t > 2.0 or fmod(run_time * 8.0, 1.0) < 0.6
		shield_fx.modulate.a = 1.0 if vis else 0.3
		var sc := 0.62 * (1.0 + 0.04 * sin(run_time * 6.0))
		shield_fx.scale = Vector2(sc, sc)
	if eq_pet >= 0:
		pet_node.visible = true
		if state != State.DEAD and state != State.PAUSED:
			var target := Vector2(ux - 120.0 * ks, uyy - 150.0 * ks + sin(run_time * 4.0) * 10.0)
			pet_node.position = pet_node.position.lerp(target, minf(1.0, delta * 8.0))
	else:
		pet_node.visible = false
	if eq_horn > 0:
		var off := Vector2(60.0, -118.0).lerp(Vector2(26.0, -78.0), dk)
		if uy < FLOOR - 1.0:
			off = Vector2(52.0, -131.0)
		horn_fx.position = Vector2(ux, uyy) + off * ks
		horn_fx.emitting = state != State.PAUSED and state != State.DEAD
	else:
		horn_fx.emitting = false
	var flick := state == State.PLAYING and invuln > 0.0 and fmod(run_time * 10.0, 1.0) < 0.5
	uni.modulate.a = 0.35 if flick else 1.0


func apply_skin() -> void:
	if eq_skin == 0:
		uni.material = null
		return
	var sk: Dictionary = SKINS[eq_skin]
	skin_mat.set_shader_parameter("body", hc(sk["body"]))
	skin_mat.set_shader_parameter("hue", float(sk["hue"]))
	uni.material = skin_mat


func apply_trail() -> void:
	var cols: Array = TRAILS[eq_trail]["c"]
	for k in 6:
		var c := hc(cols[k])
		var gr := Gradient.new()
		gr.offsets = PackedFloat32Array([0.0, 0.7, 1.0])
		gr.colors = PackedColorArray([Color(c.r, c.g, c.b, 0.0), Color(c.r, c.g, c.b, 0.85), c])
		lines[k].gradient = gr


func apply_horn() -> void:
	horn_fx.emitting = false
	if eq_horn <= 0:
		return
	var hd: Dictionary = HORNS[eq_horn]
	var c := hc(hd["c"])
	horn_fx.amount = int(hd["n"])
	horn_fx.color = c
	horn_fx.restart()


func apply_pet() -> void:
	if eq_pet < 0:
		pet_node.visible = false
		return
	pet_node.texture = get_tex("res://art/pet_%d.png" % eq_pet)
	pet_node.visible = true
	pet_node.position = Vector2(UNI_X - 120.0, uy - 150.0)


func apply_loadout() -> void:
	apply_skin()
	apply_trail()
	apply_horn()
	apply_pet()


func toast(t: String) -> void:
	toast_label.text = T(t)
	if toast_tw != null and toast_tw.is_valid():
		toast_tw.kill()
	toast_label.modulate.a = 1.0
	toast_tw = create_tween()
	toast_tw.tween_property(toast_label, "modulate:a", 0.0, 0.5).set_delay(1.2)


func shop_list(tab: int) -> Array:
	if tab == 0:
		return SKINS
	if tab == 1:
		return TRAILS
	if tab == 2:
		return HORNS
	if tab == 3:
		return PETS
	return SKILLS


func item_key(tab: int, i: int) -> String:
	var kinds := ["skin", "trail", "horn", "pet"]
	return "%s%d" % [kinds[tab], i]


func is_owned(tab: int, i: int) -> bool:
	return owned.has(item_key(tab, i))


func is_equipped(tab: int, i: int) -> bool:
	if tab == 0:
		return eq_skin == i
	if tab == 1:
		return eq_trail == i
	if tab == 2:
		return eq_horn == i
	return eq_pet == i


func equip(tab: int, i: int) -> void:
	if tab == 0:
		eq_skin = i
	elif tab == 1:
		eq_trail = i
	elif tab == 2:
		eq_horn = i
	elif tab == 3:
		eq_pet = -1 if eq_pet == i else i
	apply_loadout()


func show_shop() -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = "shop"
	refresh_shop()
	refresh_bank()
	bank_row.visible = true
	shop_box.visible = true
	update_hud()


func on_home_shop() -> void:
	go(show_shop)


func on_shop_tab(i: int) -> void:
	shop_tab = i
	refresh_shop()


func build_shop_screen() -> void:
	shop_box = make_full_rect()
	ui.add_child(shop_box)
	make_center_label("SHOP", 48, Color.WHITE, 12.0, shop_box)
	var back := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	back.position = Vector2(24, 14)
	back.pressed.connect(go_back)
	shop_box.add_child(back)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 10)
	tabs.set_anchors_preset(Control.PRESET_CENTER_TOP)
	tabs.grow_horizontal = Control.GROW_DIRECTION_BOTH
	tabs.offset_top = 84.0
	tabs.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shop_box.add_child(tabs)
	var names := ["SKINS", "TRAILS", "HORNS", "PETS", "SKILLS"]
	for i in 5:
		var tb := make_button(names[i], Vector2(180, 54), 24, Color("5a3cb0"))
		tb.pressed.connect(on_shop_tab.bind(i))
		tabs.add_child(tb)
		shop_tab_btns.append(tb)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.offset_top = 150.0
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shop_box.add_child(cc)
	shop_grid = GridContainer.new()
	shop_grid.columns = 4
	shop_grid.add_theme_constant_override("h_separation", 14)
	shop_grid.add_theme_constant_override("v_separation", 14)
	cc.add_child(shop_grid)


func refresh_shop() -> void:
	for i in 5:
		var tb: Button = shop_tab_btns[i]
		var tcol := Color("5a3cb0")
		if i == shop_tab:
			tcol = Color("ff5fa8")
		tb.add_theme_stylebox_override("normal", button_style(tcol))
	for c in shop_grid.get_children():
		shop_grid.remove_child(c)
		c.queue_free()
	var list := shop_list(shop_tab)
	for i in list.size():
		shop_grid.add_child(make_shop_card(shop_tab, i))


func add_swatches(btn: Button, colors: Array) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	row.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	row.grow_horizontal = Control.GROW_DIRECTION_BOTH
	row.grow_vertical = Control.GROW_DIRECTION_BEGIN
	row.offset_bottom = -10.0
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.add_child(row)
	for c in colors:
		var r := ColorRect.new()
		r.color = hc(c)
		r.custom_minimum_size = Vector2(20, 20)
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(r)


func make_shop_card(tab: int, i: int) -> Button:
	var it: Dictionary = shop_list(tab)[i]
	var nm: String = it["name"]
	var txt := T(nm)
	var col := Color("5a3cb0")
	if tab == 4:
		var id: String = it["id"]
		var lv := skill_lv(id)
		var mx := skill_max(id)
		var desc: String = it["desc"]
		if lv >= mx:
			txt = "%s  %s\n%s" % [T(nm), T("MAX"), T(desc)]
			col = Color("3fc98a")
		else:
			var cost := skill_cost(i)
			txt = "%s  %s\n%s\n%s" % [T(nm), T("Lv %d/%d") % [lv, mx], T(desc), T("Upgrade  %d") % cost]
			col = Color("4a86e8") if bank >= cost else Color(0.34, 0.28, 0.5)
	else:
		if tab == 3:
			txt = "%s\n%s" % [T(nm), T(String(it["desc"]))]
		if is_equipped(tab, i):
			txt += "\n" + T("EQUIPPED")
			col = Color("3fc98a")
		elif is_owned(tab, i):
			txt += "\n" + T("Tap to equip")
			col = Color("b45cff")
		else:
			var cost2 := int(it["cost"])
			txt += "\n" + T("Buy  %d") % cost2
			col = Color("4a86e8") if bank >= cost2 else Color(0.34, 0.28, 0.5)
	var btn := make_button(txt, Vector2(290, 128), 22, col)
	if tab == 0:
		add_swatches(btn, [it["body"]])
	elif tab == 1:
		add_swatches(btn, it["c"])
	btn.pressed.connect(on_shop_card.bind(tab, i))
	return btn


func on_shop_card(tab: int, i: int) -> void:
	if tab == 4:
		var sd: Dictionary = SKILLS[i]
		var id: String = sd["id"]
		var lv := skill_lv(id)
		if lv >= skill_max(id):
			return
		var cost := skill_cost(i)
		if bank < cost:
			toast("Not enough coins")
			play_sfx("deny")
			return
		bank -= cost
		play_sfx("buy")
		skills[id] = lv + 1
	else:
		var it: Dictionary = shop_list(tab)[i]
		if not is_owned(tab, i):
			var cost2 := int(it["cost"])
			if bank < cost2:
				toast("Not enough coins")
				play_sfx("deny")
				return
			bank -= cost2
			play_sfx("buy")
			owned.append(item_key(tab, i))
		equip(tab, i)
	save_game()
	refresh_bank()
	refresh_shop()


func T(s: String) -> String:
	if lang == "bn" and BN.has(s):
		return BN[s]
	return s


func setup_fonts() -> void:
	var latin: FontFile = load("res://fonts/Poppins-Medium.ttf")
	var bold: FontFile = load("res://fonts/Poppins-Bold.ttf")
	var bn: FontFile = load("res://fonts/FreeSans.ttf")
	latin.fallbacks = [bn]
	bold.fallbacks = [bn]
	ui_font = bold
	Cp.font = bold


const MUSIC_DB := -5.0
const SFX_DB := -2.0
const SFX_ALIAS := {"hit": "break", "power": "shield", "lose": "die", "claim": "mission", "spin": "tick_lo"}
const SFX_TRIM := {"click": -7.0, "back": -7.0, "tick_lo": -7.0, "tick_hi": -5.0, "flap": -3.0, "near": -3.0, "land_soft": -3.0, "pop_0": -4.0, "pop_1": -4.0, "pop_2": -4.0, "jump": -2.0}
const SFX_PRELOAD := ["jump", "djump", "land_soft", "land_hard", "coin_1", "coin_2", "coin_3", "coin_4", "coin_5", "click", "break", "die", "fall", "shield", "magnet", "sx2", "slow", "life", "near", "win", "star", "mission", "buy", "deny", "revive", "ready", "tick_lo", "tick_hi", "pop_0", "pop_1", "pop_2"]

var music_bus := 0
var music_lp: AudioEffectLowPassFilter
var music_key := ""
var music_want := ""
var music_vol := 0.0
var music_cut := 18000.0
var music_streams: Dictionary = {}


func setup_audio() -> void:
	music_bus = AudioServer.get_bus_index("Music")
	if music_bus < 0:
		AudioServer.add_bus()
		music_bus = AudioServer.bus_count - 1
		AudioServer.set_bus_name(music_bus, "Music")
		AudioServer.set_bus_send(music_bus, "Master")
		var fx := AudioEffectLowPassFilter.new()
		fx.cutoff_hz = 18000.0
		fx.resonance = 0.6
		AudioServer.add_bus_effect(music_bus, fx)
	music_lp = AudioServer.get_bus_effect(music_bus, 0) as AudioEffectLowPassFilter
	music = AudioStreamPlayer.new()
	music.bus = "Music"
	music.volume_db = -80.0
	add_child(music)
	music_key = ""
	music_vol = 0.0
	music_cut = 18000.0
	for n in SFX_PRELOAD:
		sfx_pool(n)


func sfx_pool(key: String) -> Dictionary:
	if sfx.has(key):
		return sfx[key]
	var path := "res://audio/%s.ogg" % key
	if not ResourceLoader.exists(path):
		sfx[key] = {}
		return sfx[key]
	var st: AudioStream = load(path)
	var arr: Array = []
	var cnt := 4 if key.begins_with("coin_") else 2
	for i in cnt:
		var pl := AudioStreamPlayer.new()
		pl.stream = st
		pl.volume_db = SFX_DB + float(SFX_TRIM.get(key, 0.0))
		add_child(pl)
		arr.append(pl)
	sfx[key] = {"p": arr, "i": 0}
	return sfx[key]


func sfx_key(n: String, a: float) -> String:
	if SFX_ALIAS.has(n):
		return String(SFX_ALIAS[n])
	if n == "coin":
		return "coin_%d" % clampi(int(a), 1, 5)
	if n == "land":
		return "land_hard" if a > 0.55 else "land_soft"
	if n == "tick":
		return "tick_hi" if a != 0.0 else "tick_lo"
	if n == "pop":
		return "pop_%d" % clampi(int(a), 0, 2)
	return n


func play_sfx(n: String, a: float = 0.0) -> void:
	if not snd_on:
		return
	var pool := sfx_pool(sfx_key(n, a))
	if pool.is_empty():
		return
	var arr: Array = pool["p"]
	var i: int = pool["i"]
	pool["i"] = (i + 1) % arr.size()
	var pl: AudioStreamPlayer = arr[i]
	pl.play()


func music_stream(key: String) -> AudioStream:
	if music_streams.has(key):
		return music_streams[key]
	var st: AudioStream = null
	var path := "res://audio/%s.ogg" % key
	if ResourceLoader.exists(path):
		st = load(path)
		if st is AudioStreamOggVorbis:
			var o: AudioStreamOggVorbis = st
			o.loop = true
			o.loop_offset = 0.0
	music_streams[key] = st
	return st


func music_target() -> Array:
	if not mus_on:
		return ["", 0.0, 18000.0]
	if state == State.PLAYING:
		return ["music_z%d" % zone, 1.0, 18000.0]
	if state == State.PAUSED:
		return ["music_z%d" % zone, 0.7, 650.0]
	if state == State.DEAD:
		return ["music_z%d" % zone, 0.45, 650.0]
	return ["music_menu", 1.0, 18000.0]


func update_music() -> void:
	if not mus_on and music != null:
		music.stop()
		music_key = ""
		music_vol = 0.0


func audio_tick(delta: float) -> void:
	if music == null:
		return
	var tg := music_target()
	var want: String = tg[0]
	var vol_t: float = tg[1]
	if want != music_key:
		vol_t = 0.0
	music_vol = move_toward(music_vol, vol_t, delta * 4.0)
	if want != music_key and music_vol <= 0.01:
		music_key = want
		if want == "":
			music.stop()
		else:
			var st := music_stream(want)
			if st != null:
				music.stream = st
				music.play()
			else:
				music_key = ""
	music_cut = lerpf(music_cut, float(tg[2]), 1.0 - exp(-delta * 7.0))
	if music_lp != null:
		music_lp.cutoff_hz = music_cut
	music.volume_db = MUSIC_DB + linear_to_db(maxf(music_vol, 0.0001))


func vibrate(ms: int) -> void:
	if vib_on:
		Input.vibrate_handheld(ms)


func stat_add(key: String, n: int) -> void:
	stats[key] = int(stats.get(key, 0)) + n


func stat_max(key: String, v: int) -> void:
	stats[key] = maxi(int(stats.get(key, 0)), v)


func xp_need(l: int) -> int:
	return 120 + 40 * (l - 1)


func player_level() -> int:
	var l := 1
	var rest := xp
	while rest >= xp_need(l):
		rest -= xp_need(l)
		l += 1
	return l


func xp_into() -> int:
	var l := 1
	var rest := xp
	while rest >= xp_need(l):
		rest -= xp_need(l)
		l += 1
	return rest


func gain_xp(n: int) -> void:
	var before := player_level()
	xp += n
	var after := player_level()
	if after > before:
		for l in range(before + 1, after + 1):
			bank += 30 * l
		toast(T("Level up!  Player level %d") % after)


func stat_value(s: String) -> int:
	if s == "cleared":
		var n := 0
		for z in ZONES.size():
			n += cleared(z)
		return n
	if s == "stars":
		return total_stars()
	if s == "zones":
		var n2 := 0
		for z in ZONES.size():
			if zone_open(z):
				n2 += 1
		return n2
	if s == "pets":
		var n3 := 0
		for i in PETS.size():
			if owned.has(item_key(3, i)):
				n3 += 1
		return n3
	if s == "style":
		var n4 := 0
		for key in owned:
			var ks := String(key)
			if ks.begins_with("skin") or ks.begins_with("trail") or ks.begins_with("horn"):
				n4 += 1
		return maxi(n4 - 3, 0)
	if s == "best":
		var b := 0
		for v in eb:
			b = maxi(b, int(v))
		return b
	if s == "plevel":
		return player_level()
	return int(stats.get(s, 0))


func local_unix() -> int:
	var bias := int(Time.get_time_zone_from_system()["bias"])
	return int(Time.get_unix_time_from_system()) + bias * 60


func today_str() -> String:
	return Time.get_date_string_from_unix_time(local_unix())


func yesterday_str() -> String:
	return Time.get_date_string_from_unix_time(local_unix() - 86400)


func day_index() -> int:
	return floori(float(local_unix()) / 86400.0)


func ensure_day() -> void:
	var t := today_str()
	if String(dstate.get("date", "")) == t and dstate.has("m"):
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = day_index() * 7919 + 13
	var types: Array = []
	for i in MISSION_TYPES.size():
		types.append(i)
	var ms: Array = []
	for k in 3:
		var j := rng.randi() % types.size()
		var ti: int = types[j]
		types.remove_at(j)
		var mt: Dictionary = MISSION_TYPES[ti]
		var steps := floori(float(int(mt["hi"]) - int(mt["lo"])) / float(int(mt["step"]))) + 1
		var target := int(mt["lo"]) + (rng.randi() % steps) * int(mt["step"])
		ms.append({"i": ti, "target": target, "got": 0, "claimed": false})
	dstate["date"] = t
	dstate["m"] = ms
	dstate["spun"] = false
	dstate["chal"] = false


func mission_event(t: String, n: int, as_max: bool = false) -> void:
	ensure_day()
	var ms: Array = dstate["m"]
	for m in ms:
		var mt: Dictionary = MISSION_TYPES[int(m["i"])]
		if String(mt["t"]) == t:
			if as_max:
				m["got"] = maxi(int(m["got"]), n)
			else:
				m["got"] = int(m["got"]) + n


func next_streak() -> int:
	var last := String(dstate.get("last", ""))
	var st := int(dstate.get("streak", 0))
	if last == today_str():
		return st
	if last == yesterday_str():
		return st + 1
	return 1


func daily_reward() -> int:
	return 100 + 20 * mini(next_streak() - 1, 6)


func daily_zone() -> int:
	return day_index() % ZONES.size()


func daily_level() -> int:
	return 3 + day_index() % 5


func attention(kind: String) -> bool:
	ensure_day()
	if kind == "missions":
		var ms: Array = dstate["m"]
		for m in ms:
			if not bool(m["claimed"]) and int(m["got"]) >= int(m["target"]):
				return true
		return false
	if kind == "daily":
		return not bool(dstate["chal"])
	if kind == "spin":
		return not bool(dstate["spun"])
	for a in ACHS:
		if not ach_claimed.has(String(a["id"])) and stat_value(String(a["s"])) >= int(a["t"]):
			return true
	return false


func home_marks() -> void:
	cp_home.refresh(false)


func make_screen(title: String) -> Control:
	var box := make_full_rect()
	ui.add_child(box)
	make_center_label(title, 48, Color.WHITE, 12.0, box)
	var back := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	back.position = Vector2(24, 14)
	back.pressed.connect(go_back)
	box.add_child(back)
	return box


func row_style() -> StyleBoxTexture:
	return kit_box("row", [30, 30, 30, 34], [26, 12, 26, 18])


func make_center_box(parent: Control, top: float) -> CenterContainer:
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.offset_top = top
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(cc)
	return cc


func build_extra_screens() -> void:
	settings_box = make_screen("Settings")
	var scc := make_center_box(settings_box, 60.0)
	settings_col = VBoxContainer.new()
	settings_col.add_theme_constant_override("separation", 14)
	scc.add_child(settings_col)

	missions_box = make_screen("Daily Missions")
	var mcc := make_center_box(missions_box, 70.0)
	missions_list = VBoxContainer.new()
	missions_list.add_theme_constant_override("separation", 14)
	mcc.add_child(missions_list)

	daily_box = make_screen("Daily Challenge")
	var dcc := make_center_box(daily_box, 50.0)
	var dcol := VBoxContainer.new()
	dcol.add_theme_constant_override("separation", 16)
	dcc.add_child(dcol)
	daily_zone_label = make_label(40, Color.WHITE)
	daily_zone_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dcol.add_child(daily_zone_label)
	daily_info = make_label(32, Color("ffe27a"))
	daily_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dcol.add_child(daily_info)
	daily_streak = make_label(30, Color("c9b8ff"))
	daily_streak.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dcol.add_child(daily_streak)
	daily_btn = make_button("START", Vector2(360, 84), 40, Color("ff5fa8"))
	daily_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	daily_btn.pressed.connect(start_daily)
	dcol.add_child(daily_btn)

	spin_box = make_screen("Lucky Spin")
	spin_label = make_center_label("", 30, Color("ffe27a"), 78.0, spin_box)
	wheel = Control.new()
	wheel.set_anchors_preset(Control.PRESET_CENTER)
	wheel.offset_left = -165.0
	wheel.offset_right = 165.0
	wheel.offset_top = -135.0
	wheel.offset_bottom = 195.0
	wheel.pivot_offset = Vector2(165, 165)
	wheel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wheel.draw.connect(draw_wheel)
	spin_box.add_child(wheel)
	var pointer := Control.new()
	pointer.set_anchors_preset(Control.PRESET_CENTER)
	pointer.offset_left = -24.0
	pointer.offset_right = 24.0
	pointer.offset_top = -172.0
	pointer.offset_bottom = -126.0
	pointer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pointer.draw.connect(func() -> void: pointer.draw_colored_polygon(PackedVector2Array([Vector2(2, 2), Vector2(46, 2), Vector2(24, 44)]), Color("ffd23f")))
	spin_box.add_child(pointer)
	spin_btn = make_button("SPIN", Vector2(300, 62), 32, Color("ff5fa8"))
	spin_btn.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	spin_btn.grow_horizontal = Control.GROW_DIRECTION_BOTH
	spin_btn.grow_vertical = Control.GROW_DIRECTION_BEGIN
	spin_btn.offset_bottom = -12.0
	spin_btn.pressed.connect(on_spin)
	spin_box.add_child(spin_btn)

	awards_box = make_screen("Awards")
	var acc := make_center_box(awards_box, 0.0)
	awards_grid = GridContainer.new()
	awards_grid.columns = 3
	awards_grid.add_theme_constant_override("h_separation", 18)
	awards_grid.add_theme_constant_override("v_separation", 18)
	acc.add_child(awards_grid)
	var anav := HBoxContainer.new()
	anav.add_theme_constant_override("separation", 24)
	anav.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	anav.grow_horizontal = Control.GROW_DIRECTION_BOTH
	anav.grow_vertical = Control.GROW_DIRECTION_BEGIN
	anav.offset_bottom = -16.0
	anav.mouse_filter = Control.MOUSE_FILTER_IGNORE
	awards_box.add_child(anav)
	var ap := make_button("<", Vector2(96, 64), 36, Color("5a3cb0"))
	ap.pressed.connect(on_awards_page.bind(-1))
	anav.add_child(ap)
	awards_page_label = make_label(32, Color.WHITE)
	anav.add_child(awards_page_label)
	var an := make_button(">", Vector2(96, 64), 36, Color("5a3cb0"))
	an.pressed.connect(on_awards_page.bind(1))
	anav.add_child(an)

	stats_box = make_screen("Statistics")
	var tcc := make_center_box(stats_box, 60.0)
	var thb := HBoxContainer.new()
	thb.add_theme_constant_override("separation", 80)
	tcc.add_child(thb)
	stats_left = make_label(30, Color.WHITE)
	thb.add_child(stats_left)
	stats_right = make_label(30, Color("ffe27a"))
	thb.add_child(stats_right)


func show_simple(box: Control, scr: String, with_bank: bool) -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = scr
	refresh_bank()
	bank_row.visible = with_bank
	box.visible = true
	update_hud()


func show_settings() -> void:
	show_simple(settings_box, "settings", false)
	refresh_settings()


func refresh_settings() -> void:
	for c in settings_col.get_children():
		settings_col.remove_child(c)
		c.queue_free()
	var rows := [
		["Sound  %s", snd_on, "snd"],
		["Music  %s", mus_on, "mus"],
		["Vibration  %s", vib_on, "vib"],
		["FPS counter  %s", show_fps, "fps"]
	]
	for it in rows:
		var on: bool = it[1]
		var b := make_button(T(String(it[0])) % T("ON" if on else "OFF"), Vector2(560, 64), 30, Color("3fc98a") if on else Color(0.34, 0.28, 0.5))
		b.pressed.connect(on_setting.bind(String(it[2])))
		settings_col.add_child(b)
	var lname := "English" if lang == "en" else "বাংলা"
	var lb := make_button(T("Language  %s") % lname, Vector2(560, 64), 30, Color("4a86e8"))
	lb.pressed.connect(on_setting.bind("lang"))
	settings_col.add_child(lb)


func on_setting(key: String) -> void:
	if key == "snd":
		snd_on = not snd_on
	elif key == "mus":
		mus_on = not mus_on
		update_music()
	elif key == "vib":
		vib_on = not vib_on
		vibrate(40)
	elif key == "fps":
		show_fps = not show_fps
		fps_label.visible = show_fps
	elif key == "lang":
		lang = "bn" if lang == "en" else "en"
		reopen = "settings"
		save_game()
		get_tree().reload_current_scene()
		return
	save_game()
	refresh_settings()


func show_missions() -> void:
	ensure_day()
	show_simple(missions_box, "missions", true)
	refresh_missions()


func refresh_missions() -> void:
	ensure_day()
	for c in missions_list.get_children():
		missions_list.remove_child(c)
		c.queue_free()
	var ms: Array = dstate["m"]
	for i in ms.size():
		missions_list.add_child(make_mission_row(i))


func make_mission_row(i: int) -> Control:
	var ms: Array = dstate["m"]
	var m: Dictionary = ms[i]
	var mt: Dictionary = MISSION_TYPES[int(m["i"])]
	var target := int(m["target"])
	var got := mini(int(m["got"]), target)
	var pc := PanelContainer.new()
	pc.custom_minimum_size = Vector2(940, 110)
	pc.add_theme_stylebox_override("panel", row_style())
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	pc.add_child(hb)
	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 6)
	hb.add_child(vb)
	var lb := make_label(28, Color.WHITE)
	lb.text = T(String(mt["d"])) % target
	vb.add_child(lb)
	var bar := ProgressBar.new()
	bar.min_value = 0.0
	bar.max_value = float(target)
	bar.value = float(got)
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0, 18)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_theme_stylebox_override("background", bar_style(Color(0.1, 0.05, 0.3, 0.55)))
	bar.add_theme_stylebox_override("fill", bar_style(Color("ffe27a")))
	vb.add_child(bar)
	var info := make_label(22, Color("c9b8ff"))
	info.text = "%d / %d" % [got, target]
	vb.add_child(info)
	var btn: Button
	if bool(m["claimed"]):
		btn = make_button(T("CLAIMED"), Vector2(230, 70), 24, Color(0.34, 0.28, 0.5))
		btn.disabled = true
	elif got >= target:
		btn = make_button(T("CLAIM") + "  +%d" % MISSION_REWARD, Vector2(230, 70), 26, Color("3fc98a"))
		btn.pressed.connect(on_claim_mission.bind(i))
	else:
		btn = make_button("+%d" % MISSION_REWARD, Vector2(230, 70), 26, Color(0.34, 0.28, 0.5))
		btn.disabled = true
	hb.add_child(btn)
	return pc


func on_claim_mission(i: int) -> void:
	var ms: Array = dstate["m"]
	var m: Dictionary = ms[i]
	if bool(m["claimed"]) or int(m["got"]) < int(m["target"]):
		return
	m["claimed"] = true
	bank += MISSION_REWARD
	play_sfx("claim")
	gain_xp(20)
	save_game()
	refresh_bank()
	refresh_missions()


func show_daily() -> void:
	ensure_day()
	show_simple(daily_box, "daily", true)
	refresh_daily()


func refresh_daily() -> void:
	ensure_day()
	var done := bool(dstate["chal"])
	var zn: String = ZONES[daily_zone()]["name"]
	daily_zone_label.text = T("Zone  %s") % T(zn)
	daily_info.text = T("Reward  %d coins") % daily_reward()
	daily_streak.text = T("Streak  %d days") % (int(dstate.get("streak", 0)) if String(dstate.get("last", "")) == today_str() or String(dstate.get("last", "")) == yesterday_str() else 0)
	daily_btn.text = T("COMPLETED") if done else T("START")
	daily_btn.disabled = done


func start_daily() -> void:
	ensure_day()
	if bool(dstate["chal"]):
		return
	mode = Mode.ADVENTURE
	daily_run = true
	level = daily_level()
	apply_zone(daily_zone())
	go(show_ready)


func show_spin() -> void:
	ensure_day()
	show_simple(spin_box, "spin", true)
	update_spin_ui()


func update_spin_ui() -> void:
	var free := not bool(dstate["spun"])
	spin_btn.text = T("FREE SPIN") if free else T("SPIN  -%d") % SPIN_COST
	spin_btn.disabled = spinning
	if not spinning and spin_label.text == "":
		spin_label.text = T("Spin the wheel!")


func draw_wheel() -> void:
	var c := Vector2(165, 165)
	var n := SPIN_PRIZES.size()
	var font := wheel.get_theme_default_font()
	for i in n:
		var pts := PackedVector2Array([c])
		for k in range(0, 9):
			var phi := (float(i) - 0.5 + float(k) / 8.0) * TAU / float(n) - PI / 2.0
			pts.append(c + Vector2(cos(phi), sin(phi)) * 160.0)
		wheel.draw_colored_polygon(pts, hc(SPIN_COLORS[i]))
	for i in n:
		var th := float(i) * TAU / float(n) - PI / 2.0
		wheel.draw_set_transform(c, th, Vector2.ONE)
		wheel.draw_string(font, Vector2(66, 11), "%d" % int(SPIN_PRIZES[i]), HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Color.WHITE)
	wheel.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	wheel.draw_arc(c, 160.0, 0.0, TAU, 64, Color("e9d2ff"), 6.0)
	wheel.draw_circle(c, 26.0, Color("2a1670"))


func pick_spin() -> int:
	var total := 0
	for w in SPIN_WEIGHTS:
		total += int(w)
	var r := randi() % total
	for i in SPIN_WEIGHTS.size():
		r -= int(SPIN_WEIGHTS[i])
		if r < 0:
			return i
	return 0


func on_spin() -> void:
	if spinning:
		return
	ensure_day()
	if not bool(dstate["spun"]):
		dstate["spun"] = true
	else:
		if bank < SPIN_COST:
			toast("Not enough coins")
			play_sfx("deny")
			return
		bank -= SPIN_COST
	spinning = true
	spin_label.text = ""
	refresh_bank()
	play_sfx("spin")
	var idx := pick_spin()
	spin_idx = idx
	var n := SPIN_PRIZES.size()
	var target := TAU * 5.0 - float(idx) * TAU / float(n) + randf_range(-0.6, 0.6) * PI / float(n)
	wheel.rotation = 0.0
	update_spin_ui()
	var tw := create_tween()
	tw.tween_property(wheel, "rotation", target, 4.0).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	tw.tween_callback(finish_spin)


func finish_spin() -> void:
	var prize := int(SPIN_PRIZES[spin_idx])
	bank += prize
	stat_add("spins", 1)
	gain_xp(15)
	spinning = false
	spin_label.text = T("You won %d coins!") % prize
	play_sfx("claim")
	vibrate(60)
	save_game()
	refresh_bank()
	update_spin_ui()


func show_awards() -> void:
	show_simple(awards_box, "awards", true)
	awards_page = 0
	refresh_awards()


func awards_pages() -> int:
	return ceili(float(ACHS.size()) / 6.0)


func on_awards_page(d: int) -> void:
	awards_page = clampi(awards_page + d, 0, awards_pages() - 1)
	refresh_awards()


func refresh_awards() -> void:
	for c in awards_grid.get_children():
		awards_grid.remove_child(c)
		c.queue_free()
	var first := awards_page * 6
	for i in 6:
		var idx := first + i
		if idx >= ACHS.size():
			break
		awards_grid.add_child(make_ach_card(idx))
	awards_page_label.text = "%d / %d" % [awards_page + 1, awards_pages()]


func make_ach_card(i: int) -> Button:
	var a: Dictionary = ACHS[i]
	var val := stat_value(String(a["s"]))
	var target := int(a["t"])
	var done := val >= target
	var claimed := ach_claimed.has(String(a["id"]))
	var status := "%d / %d" % [mini(val, target), target]
	var col := Color("5a3cb0")
	if claimed:
		status = T("CLAIMED")
		col = Color("3fc98a")
	elif done:
		status = T("CLAIM") + "  +%d" % int(a["r"])
		col = Color("f2a93c")
	var txt := "%s\n%s\n%s" % [T(String(a["n"])), T(String(a["d"])), status]
	var btn := make_button(txt, Vector2(380, 150), 22, col)
	btn.pressed.connect(on_ach_card.bind(i))
	return btn


func on_ach_card(i: int) -> void:
	var a: Dictionary = ACHS[i]
	var id := String(a["id"])
	if ach_claimed.has(id) or stat_value(String(a["s"])) < int(a["t"]):
		return
	ach_claimed.append(id)
	bank += int(a["r"])
	play_sfx("claim")
	gain_xp(25)
	save_game()
	refresh_bank()
	refresh_awards()


func show_stats() -> void:
	show_simple(stats_box, "stats", false)
	var secs := int(float(stats.get("time", 0.0)))
	var tm := "%dh %02dm" % [floori(float(secs) / 3600.0), floori(float(secs % 3600) / 60.0)]
	var lines: Array = []
	lines.append(T("Player level  %d") % player_level())
	lines.append(T("XP  %d / %d") % [xp_into(), xp_need(player_level())])
	lines.append(T("Runs  %d") % int(stats.get("runs", 0)))
	lines.append(T("Total coins  %d") % int(stats.get("coins", 0)))
	lines.append(T("Total score  %d") % int(stats.get("score", 0)))
	lines.append(T("Best combo  x%d") % int(stats.get("combo", 0)))
	lines.append(T("Levels cleared  %d") % stat_value("cleared"))
	lines.append(T("Stars  %d / %d") % [total_stars(), ZONES.size() * LEVELS_PER_ZONE * 3])
	lines.append(T("Power-ups  %d") % int(stats.get("powers", 0)))
	lines.append(T("Daily challenges  %d") % int(stats.get("daily", 0)))
	lines.append(T("Play time  %s") % tm)
	stats_left.text = "\n".join(PackedStringArray(lines))
	var rl: Array = [T("Top scores")]
	if records.is_empty():
		rl.append(T("No records yet"))
	for i in records.size():
		var r: Dictionary = records[i]
		var zn: String = ZONES[int(r["z"])]["name"]
		rl.append("%d.  %d   %s" % [i + 1, int(r["s"]), T(zn)])
	stats_right.text = "\n".join(PackedStringArray(rl))


func add_record(sc: int) -> void:
	if sc <= 0:
		return
	records.append({"s": sc, "z": zone})
	records.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["s"]) > int(b["s"]))
	while records.size() > 8:
		records.pop_back()


func record_ghost(delta: float) -> void:
	rec_t += delta
	while rec_t >= 0.1:
		rec_t -= 0.1
		if rec_d.size() < 2400:
			rec_d.append(distance)
			rec_y.append(uy)


func update_ghost() -> void:
	if ghost_data.is_empty():
		ghost_sprite.visible = false
		return
	var gd: PackedFloat32Array = ghost_data["d"]
	var gy: PackedFloat32Array = ghost_data["y"]
	var f := run_clock / 0.1
	var i := int(f)
	if i + 1 >= gd.size():
		ghost_sprite.visible = false
		return
	var k := f - float(i)
	var d := lerpf(gd[i], gd[i + 1], k)
	var y := lerpf(gy[i], gy[i + 1], k)
	var x := UNI_X + (d - distance)
	ghost_sprite.visible = x > -150.0 and x < get_viewport_rect().size.x + 150.0
	ghost_sprite.position = Vector2(x, y)
	ghost_sprite.texture = ghost_tex_jump if y < FLOOR - 1.0 else ghost_tex_run


func end_run_stats() -> void:
	stat_add("score", score)
	stat_max("combo", best_combo)
	mission_event("score", score)
	mission_event("combo", best_combo, true)
	if mode == Mode.ENDLESS:
		gain_xp(floori(float(score) / 10.0) + coins)
	else:
		gain_xp(coins)
