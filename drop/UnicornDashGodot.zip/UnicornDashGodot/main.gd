extends Node2D

const VW := 1280.0
const VH := 576.0
const WIDE := 2800.0
const FLOOR := 474.0
const UNI_X := 250.0
const UNI_SCALE := 0.42
const FEET := 350.0
const GRAVITY := 2700.0
const JUMP_V := -820.0
const HOLD_G := 0.6
const MAX_JUMPS := 2
const START_SPEED := 430.0
const MAX_SPEED := 980.0
const TAIL_DX := -38.0
const TAIL_DY := -66.0
const TRAIL_LEN := 280.0
const HudScript := preload("res://hud.gd")


const OBS := {
	"rock": {"w": 70.0, "h": 52.0},
	"crystal": {"w": 48.0, "h": 86.0},
	"bush": {"w": 76.0, "h": 44.0}
}

enum State { READY, PLAYING, PAUSED, COUNT, DEAD }

var rainbow: Array = [
	Color("ff5f8d"), Color("ffb05f"), Color("ffe066"),
	Color("6fe3a5"), Color("5fb8ff"), Color("a56bff")
]
var state: int = State.READY
var speed := START_SPEED
var distance := 0.0
var score := 0
var coins := 0
var best := 0
var uy := FLOOR
var vy := 0.0
var jumps := 0
var held := false
var spawn_gap := 600.0
var run_time := 0.0
var shake := 0.0
var fps_timer := 0.0

var bg: Node2D
var world: Node2D
var uni: AnimatedSprite2D
var sparks: CPUParticles2D
var lines: Array[Line2D] = []
var trail: Array[Vector2] = []
var layers: Array = []
var clouds: Array = []
var obstacles: Array = []
var items: Array = []

var hud: HudScript
var next_mark := 500
var count_t := 0.0
var count_n := 0


func _ready() -> void:
	randomize()
	Engine.max_fps = 0
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
	get_tree().set_quit_on_go_back(false)
	load_best()
	build_background()
	build_world()
	hud = HudScript.new()
	add_child(hud)
	hud.pause_pressed.connect(pause_game)
	hud.resume_pressed.connect(resume_game)
	hud.retry_pressed.connect(on_retry)
	hud.home_pressed.connect(show_ready)
	show_ready()


func build_background() -> void:
	bg = Node2D.new()
	add_child(bg)

	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	g.colors = PackedColorArray([Color("6a46b8"), Color("d77fcf"), Color("ffc9b8")])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.width = 8
	gt.height = 256
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	var sky := Sprite2D.new()
	sky.texture = gt
	sky.centered = false
	sky.scale = Vector2(WIDE / 8.0, (VH + 400.0) / 256.0)
	bg.add_child(sky)

	var sun := Sprite2D.new()
	sun.texture = load("res://art/sun.png")
	sun.position = Vector2(980, 150)
	sun.scale = Vector2(1.1, 1.1)
	sun.modulate = Color(1, 1, 1, 0.85)
	bg.add_child(sun)

	make_layer("res://art/rainbow.png", FLOOR - 440.0 + 40.0, 0.03)

	for i in 5:
		var c := Sprite2D.new()
		c.texture = load("res://art/cloud%d.png" % (i % 3))
		c.position = Vector2(randf_range(0, VW + 300), randf_range(40, 230))
		var s := randf_range(0.6, 1.1)
		c.scale = Vector2(s, s)
		c.modulate = Color(1, 1, 1, randf_range(0.45, 0.8))
		bg.add_child(c)
		clouds.append({"node": c, "f": randf_range(0.03, 0.12)})

	make_layer("res://art/far.png", FLOOR - 330.0 + 40.0, 0.07)
	make_layer("res://art/mid.png", FLOOR - 250.0 + 30.0, 0.16)
	make_layer("res://art/near.png", FLOOR - 190.0 + 34.0, 0.42)
	make_layer("res://art/ground.png", FLOOR - 14.0, 1.0)


func make_layer(path: String, y: float, factor: float) -> void:
	var tex: Texture2D = load(path)
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	s.position = Vector2(0, y)
	s.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	s.region_enabled = true
	s.region_rect = Rect2(0, 0, WIDE, tex.get_height())
	bg.add_child(s)
	layers.append({"node": s, "f": factor, "w": float(tex.get_width()), "h": float(tex.get_height()), "off": 0.0})


func build_world() -> void:
	world = Node2D.new()
	add_child(world)

	for k in 6:
		var ln := Line2D.new()
		ln.width = 8.6
		ln.begin_cap_mode = Line2D.LINE_CAP_ROUND
		ln.end_cap_mode = Line2D.LINE_CAP_ROUND
		ln.joint_mode = Line2D.LINE_JOINT_ROUND
		ln.antialiased = true
		var gr := Gradient.new()
		var c: Color = rainbow[k]
		gr.offsets = PackedFloat32Array([0.0, 0.7, 1.0])
		gr.colors = PackedColorArray([Color(c.r, c.g, c.b, 0.0), Color(c.r, c.g, c.b, 0.85), c])
		ln.gradient = gr
		world.add_child(ln)
		lines.append(ln)

	sparks = CPUParticles2D.new()
	sparks.texture = load("res://art/spark.png")
	sparks.amount = 28
	sparks.lifetime = 0.7
	sparks.local_coords = false
	sparks.direction = Vector2(-1, 0)
	sparks.spread = 35.0
	sparks.gravity = Vector2.ZERO
	sparks.initial_velocity_min = 60.0
	sparks.initial_velocity_max = 160.0
	sparks.scale_amount_min = 0.15
	sparks.scale_amount_max = 0.4
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 1, 0.85, 1), Color(1, 0.7, 1, 0)])
	sparks.color_ramp = cg
	sparks.emitting = false
	world.add_child(sparks)

	uni = AnimatedSprite2D.new()
	uni.sprite_frames = build_frames()
	uni.centered = false
	uni.offset = Vector2(-192, -FEET)
	uni.scale = Vector2(UNI_SCALE, UNI_SCALE)
	uni.position = Vector2(UNI_X, uy)
	world.add_child(uni)
	uni.play("run")


func build_frames() -> SpriteFrames:
	var sheet: Texture2D = load("res://art/unicorn.png")
	var sf := SpriteFrames.new()
	sf.add_animation("run")
	sf.set_animation_speed("run", 12.0)
	sf.set_animation_loop("run", true)
	for i in 4:
		var a := AtlasTexture.new()
		a.atlas = sheet
		a.region = Rect2(i * 384, 0, 384, 384)
		sf.add_frame("run", a)
	sf.add_animation("jump")
	sf.set_animation_speed("jump", 1.0)
	sf.set_animation_loop("jump", false)
	var j := AtlasTexture.new()
	j.atlas = sheet
	j.region = Rect2(4 * 384, 0, 384, 384)
	sf.add_frame("jump", j)
	return sf


func reset_world() -> void:
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	trail.clear()
	speed = START_SPEED
	distance = 0.0
	score = 0
	coins = 0
	uy = FLOOR
	vy = 0.0
	jumps = 0
	spawn_gap = 700.0
	shake = 0.0
	next_mark = 500
	held = false
	world.position = Vector2.ZERO
	world.process_mode = Node.PROCESS_MODE_INHERIT
	sparks.emitting = false
	for ln in lines:
		ln.points = PackedVector2Array()
	uni.play("run")


func show_ready() -> void:
	reset_world()
	state = State.READY
	hud.show_ready(best)


func start_run() -> void:
	reset_world()
	state = State.PLAYING
	sparks.emitting = true
	hud.show_play()


func on_retry() -> void:
	start_run()


func pause_game() -> void:
	if state != State.PLAYING:
		return
	state = State.PAUSED
	held = false
	world.process_mode = Node.PROCESS_MODE_DISABLED
	hud.show_paused()


func resume_game() -> void:
	if state != State.PAUSED:
		return
	hud.hide_paused()
	state = State.COUNT
	count_t = 2.4
	count_n = 0


func update_count(delta: float) -> void:
	count_t -= delta
	var n := ceili(count_t / 0.8)
	if n != count_n and n > 0:
		count_n = n
		hud.show_count(n)
	if count_t <= 0.0:
		hud.hide_count()
		world.process_mode = Node.PROCESS_MODE_INHERIT
		state = State.PLAYING


func toggle_pause() -> void:
	if state == State.PLAYING:
		pause_game()
	elif state == State.PAUSED:
		resume_game()


func press() -> void:
	if state == State.READY:
		start_run()
		do_jump()
	elif state == State.PLAYING:
		do_jump()


func do_jump() -> void:
	if jumps >= MAX_JUMPS:
		return
	vy = JUMP_V if jumps == 0 else JUMP_V * 0.92
	jumps += 1
	pop(Vector2(UNI_X - 20.0, uy - 6.0), 8, 0.6)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		held = event.pressed
		if event.pressed:
			press()
	elif event is InputEventKey and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if event.pressed:
				toggle_pause()
		elif event.keycode == KEY_SPACE or event.keycode == KEY_UP:
			held = event.pressed
			if event.pressed:
				press()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		held = false
		pause_game()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		match state:
			State.PLAYING:
				pause_game()
			State.PAUSED:
				resume_game()
			State.DEAD:
				show_ready()
			State.READY:
				get_tree().quit()


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	fps_timer += delta
	if fps_timer >= 0.5:
		fps_timer = 0.0
		hud.set_fps("%d FPS" % Engine.get_frames_per_second())
	if state == State.PAUSED:
		return
	if state == State.COUNT:
		update_count(delta)
		return
	run_time += delta
	if state == State.PLAYING:
		update_play(delta)
	elif state == State.READY:
		scroll_layers(START_SPEED * 0.35 * delta)
	scroll_clouds(delta)
	update_visuals(delta)


func update_play(delta: float) -> void:
	speed = minf(MAX_SPEED, START_SPEED + distance * 0.02)
	var dx := speed * delta
	distance += dx
	var new_score := int(distance / 10.0)
	if new_score != score:
		score = new_score
		hud.set_score(score)
		if score >= next_mark:
			hud.toast("%d!" % next_mark)
			next_mark += 500
	var g := GRAVITY
	if held and vy < 0.0:
		g *= HOLD_G
	vy += g * delta
	uy += vy * delta
	if uy >= FLOOR:
		if vy > 300.0:
			pop(Vector2(UNI_X, FLOOR), 6, 0.5)
		uy = FLOOR
		vy = 0.0
		jumps = 0
	scroll_layers(dx)
	move_things(dx)
	spawn_gap -= dx
	if spawn_gap <= 0.0:
		spawn_pattern()
	check_hits()
	update_trail(dx)
	sparks.position = Vector2(UNI_X + TAIL_DX, uy + TAIL_DY)
	sparks.initial_velocity_min = speed * 0.6
	sparks.initial_velocity_max = speed * 1.0 + 60.0


func scroll_layers(dx: float) -> void:
	for l in layers:
		var off: float = fmod(l["off"] + dx * l["f"], l["w"])
		l["off"] = off
		var s: Sprite2D = l["node"]
		s.region_rect = Rect2(off, 0.0, WIDE, l["h"])


func scroll_clouds(delta: float) -> void:
	var base := speed if state == State.PLAYING else START_SPEED * 0.35
	for c in clouds:
		var n: Sprite2D = c["node"]
		n.position.x -= (base * c["f"] + 10.0) * delta
		if n.position.x < -380.0:
			n.position.x = get_viewport_rect().size.x + randf_range(40.0, 300.0)
			n.position.y = randf_range(40.0, 230.0)


func move_things(dx: float) -> void:
	for i in range(obstacles.size() - 1, -1, -1):
		var o: Dictionary = obstacles[i]
		var n: Sprite2D = o["node"]
		n.position.x -= dx
		if n.position.x < -200.0:
			n.queue_free()
			obstacles.remove_at(i)
	for i in range(items.size() - 1, -1, -1):
		var it: Dictionary = items[i]
		var n: Sprite2D = it["node"]
		n.position.x -= dx
		if n.position.x < -80.0:
			n.queue_free()
			items.remove_at(i)


func spawn_pattern() -> void:
	var x := get_viewport_rect().size.x + 140.0
	var r := randf()
	var extra := 0.0
	if r < 0.5:
		add_obstacle(pick_kind(), x)
		add_coin_arc(x, 5, 130.0)
	elif r < 0.78:
		add_obstacle(pick_kind(), x)
		add_obstacle(pick_kind(), x + 250.0)
		add_coin_arc(x + 125.0, 7, 170.0)
		extra = 250.0
	else:
		add_coin_line(x, 8, FLOOR - 70.0 - randf() * 90.0)
		extra = 0.0
	spawn_gap = speed * randf_range(0.95, 1.45) + 280.0 + extra


func pick_kind() -> String:
	var keys := OBS.keys()
	return keys[randi() % keys.size()]


func add_obstacle(kind: String, x: float) -> void:
	var s := Sprite2D.new()
	s.texture = load("res://art/%s.png" % kind)
	s.centered = false
	s.offset = Vector2(-128, -250)
	s.scale = Vector2(0.5, 0.5)
	s.position = Vector2(x, FLOOR + 2.0)
	world.add_child(s)
	world.move_child(s, uni.get_index())
	obstacles.append({"node": s, "w": OBS[kind]["w"], "h": OBS[kind]["h"]})


func add_coin(x: float, y: float) -> void:
	var s := Sprite2D.new()
	s.texture = load("res://art/coin.png")
	s.scale = Vector2(0.3, 0.3)
	s.position = Vector2(x, y)
	world.add_child(s)
	items.append({"node": s, "ph": randf() * 6.28, "y": y})


func add_coin_arc(cx: float, count: int, height: float) -> void:
	for i in count:
		var t := float(i) / float(count - 1)
		add_coin(cx - 120.0 + t * 240.0, FLOOR - 50.0 - sin(t * PI) * height)


func add_coin_line(x: float, count: int, y: float) -> void:
	for i in count:
		add_coin(x + i * 62.0, y)


func check_hits() -> void:
	var ur := Rect2(UNI_X - 34.0, uy - 82.0, 66.0, 76.0)
	for o in obstacles:
		var n: Sprite2D = o["node"]
		var w: float = o["w"]
		var h: float = o["h"]
		var orect := Rect2(n.position.x - w * 0.5, FLOOR - h, w, h)
		if ur.intersects(orect):
			die()
			return
	var center := Vector2(UNI_X, uy - 58.0)
	for i in range(items.size() - 1, -1, -1):
		var n: Sprite2D = items[i]["node"]
		if n.position.distance_to(center) < 52.0:
			pop(n.position, 10, 1.0)
			hud.fly_coin(n.position)
			n.queue_free()
			items.remove_at(i)
			coins += 1
			hud.set_coins(coins)


func die() -> void:
	state = State.DEAD
	shake = 18.0
	sparks.emitting = false
	var fresh := score > best
	if fresh:
		best = score
		save_best()
	hud.flash()
	hud.show_over(score, best, coins, fresh, 0.7)
	uni.play("jump")
	pop(Vector2(UNI_X, uy - 50.0), 18, 1.4)


func update_trail(dx: float) -> void:
	for i in trail.size():
		trail[i] = Vector2(trail[i].x - dx, trail[i].y)
	var anchor_x := UNI_X + TAIL_DX
	trail.append(Vector2(anchor_x, uy + TAIL_DY))
	while trail.size() > 0 and trail[0].x < anchor_x - TRAIL_LEN:
		trail.remove_at(0)
	var n := trail.size()
	for k in 6:
		var pts := PackedVector2Array()
		for i in n:
			var p := trail[i]
			var age := 1.0 - float(i) / float(maxi(n - 1, 1))
			var wave := sin(p.x * 0.028 + run_time * 9.0) * 7.0 * age
			pts.append(Vector2(p.x, p.y + (float(k) - 2.5) * 7.6 + wave))
		lines[k].points = pts


func update_visuals(delta: float) -> void:
	uni.position = Vector2(UNI_X, uy)
	if state == State.PLAYING:
		if uy < FLOOR - 1.0:
			if uni.animation != "jump":
				uni.play("jump")
		else:
			if uni.animation != "run" or not uni.is_playing():
				uni.play("run")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
	elif state == State.READY:
		if uni.animation != "run" or not uni.is_playing():
			uni.play("run")
		uni.speed_scale = 0.6
		if lines.size() > 0:
			for ln in lines:
				ln.points = PackedVector2Array()
	for it in items:
		var n: Sprite2D = it["node"]
		n.scale.x = 0.3 * absf(cos(run_time * 5.0 + it["ph"])) + 0.05
		n.position.y = float(it["y"]) + sin(run_time * 4.0 + it["ph"]) * 5.0
	if shake > 0.2:
		shake = lerpf(shake, 0.0, minf(1.0, delta * 9.0))
		world.position = Vector2(randf_range(-shake, shake), randf_range(-shake, shake))
	else:
		world.position = Vector2.ZERO


func pop(pos: Vector2, count: int, power: float) -> void:
	var p := CPUParticles2D.new()
	p.texture = load("res://art/spark.png")
	p.position = pos
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = count
	p.lifetime = 0.6
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 80.0 * power
	p.initial_velocity_max = 220.0 * power
	p.scale_amount_min = 0.2
	p.scale_amount_max = 0.5
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 0.95, 0.6, 1), Color(1, 0.6, 1, 0)])
	p.color_ramp = cg
	world.add_child(p)
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func load_best() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save.cfg") == OK:
		best = int(cf.get_value("run", "best", 0))


func save_best() -> void:
	var cf := ConfigFile.new()
	cf.set_value("run", "best", best)
	cf.save("user://save.cfg")
