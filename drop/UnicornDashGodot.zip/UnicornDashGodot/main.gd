extends Node2D

const VW := 1280.0
const VH := 576.0
const WIDE := 2800.0
const FLOOR := 474.0
const UNI_X := 250.0
const UNI_SCALE := 0.42
const FEET := 352.0
const UNI_ANCHOR := 230.0
const S := 1.68
const GRAVITY := 2700.0
const JUMP_V := -820.0
const HOLD_G := 0.6
const DUCK_FALL := 2.0
const MAX_JUMPS := 2
const START_SPEED := 430.0
const MAX_SPEED := 980.0
const TAIL_DX := -72.0
const TAIL_DY := -24.0
const TRAIL_LEN := 280.0
const FR := 384
const LEVELS_PER_ZONE := 10
const ZONE_NEED := 7
const PER_PAGE := 6
const ICE_BOOST := 1.3

const KINDS := {
	"crystal1": {"n": 1, "fps": 1.0, "sheet": "crystal1", "boxes": [[-9.0, 9.0, 0.0, 32.0]], "v": 1.0, "lift": 0.0},
	"crystal2": {"n": 1, "fps": 1.0, "sheet": "crystal2", "boxes": [[-26.0, 26.0, 0.0, 32.0]], "v": 1.0, "lift": 0.0},
	"spikes": {"n": 1, "fps": 1.0, "sheet": "spikes", "boxes": [[-34.0, 34.0, 0.0, 22.0]], "v": 1.0, "lift": 0.0},
	"boulder": {"n": 8, "fps": 10.0, "sheet": "boulder", "boxes": [[-15.0, 15.0, 0.0, 32.0]], "v": 1.4, "lift": 0.0},
	"wall": {"n": 1, "fps": 1.0, "sheet": "wall", "boxes": [[-9.0, 9.0, 0.0, 80.0]], "v": 1.0, "lift": 0.0},
	"pillar": {"n": 1, "fps": 1.0, "sheet": "pillar", "boxes": [[-28.0, -2.0, 0.0, 26.0], [-2.0, 24.0, 0.0, 54.0]], "v": 1.0, "lift": 0.0},
	"bird": {"n": 6, "fps": 14.0, "sheet": "bird", "boxes": [[-13.0, 13.0, 35.0, 53.0]], "v": 1.12, "lift": 0.0},
	"storm_low": {"n": 8, "fps": 11.0, "sheet": "storm_low", "boxes": [[-12.0, 12.0, 38.0, 58.0]], "v": 1.0, "lift": 0.0},
	"storm_high": {"n": 8, "fps": 11.0, "sheet": "storm_low", "boxes": [[-12.0, 12.0, 70.0, 90.0]], "v": 1.0, "lift": 32.0},
	"spin": {"n": 8, "fps": 11.0, "sheet": "spin", "boxes": [[-14.0, 14.0, 0.0, 31.0]], "v": 1.0, "lift": 0.0},
	"fire": {"n": 8, "fps": 11.0, "sheet": "fire", "boxes": [[-22.0, 22.0, 0.0, 30.0]], "v": 1.1, "lift": 0.0},
	"ice": {"n": 1, "fps": 1.0, "sheet": "ice", "boxes": [], "v": 1.0, "lift": 0.0},
	"pit": {"n": 1, "fps": 1.0, "sheet": "pit", "boxes": [], "v": 1.0, "lift": 0.0},
	"swing": {"n": 1, "fps": 1.0, "sheet": "swing", "boxes": [], "v": 1.0, "lift": 0.0},
	"laser": {"n": 2, "fps": 1.0, "sheet": "laser", "boxes": [[-5.0, 5.0, 0.0, 64.0]], "v": 1.0, "lift": 0.0},
	"wisp": {"n": 8, "fps": 12.0, "sheet": "wisp", "boxes": [], "v": 1.0, "lift": 0.0}
}

const ZONES: Array = [
	{"name": "Rainbow Meadow", "sky": ["6a46b8", "d77fcf", "ffc9b8"], "far": ["c8a0ee", "d7b7f5"], "near": ["8c64d2", "a888e6"], "gr": ["3f9a74", "86e29c"], "night": 0.0, "fx": "none", "zs": "", "raw": true},
	{"name": "Candy Clouds", "sky": ["ff9ed8", "ffd0ea", "fff1d6"], "far": ["e87fb8", "ffb3d9"], "near": ["d65f9e", "ff8fc4"], "gr": ["d4679f", "ffc2de"], "night": 0.0, "fx": "petal", "zs": ""},
	{"name": "Starlight Night", "sky": ["120c38", "3a2478", "7a4aa8"], "far": ["2a1f66", "4a3a96"], "near": ["1c1448", "34286e"], "gr": ["143a4a", "2a7a86"], "night": 1.0, "fx": "firefly", "zs": ""},
	{"name": "Frozen Peaks", "sky": ["12356b", "6fb4e0", "d6f0fa"], "far": ["6f9fd6", "bcdcf2"], "near": ["a8cbe8", "eaf6ff"], "gr": ["b8d8ec", "ffffff"], "night": 0.35, "fx": "snow", "zs": "ice"},
	{"name": "Sunset Dunes", "sky": ["ff7054", "ffa070", "ffd9a0"], "far": ["b45878", "e58a7a"], "near": ["8c3a66", "c46a70"], "gr": ["c8803c", "f0b868"], "night": 0.0, "fx": "dust", "zs": ""},
	{"name": "Ember Realm", "sky": ["280818", "8a2a1e", "e0642a"], "far": ["5a1c2c", "8c3040"], "near": ["3c1424", "662038"], "gr": ["3a1c1c", "ff7030"], "night": 0.5, "fx": "ember", "zs": "fire"},
	{"name": "Crystal Caves", "sky": ["1c0a40", "5a2e90", "a070d0"], "far": ["462a80", "7a52b8"], "near": ["30205f", "5c3d98"], "gr": ["3c2a70", "a070f0"], "night": 0.7, "fx": "sparkle", "zs": ""},
	{"name": "Enchanted Forest", "sky": ["0e3c40", "3a8a6a", "b8e8a0"], "far": ["1f6a52", "3f9a72"], "near": ["124c3c", "2a7a52"], "gr": ["1e5a38", "58c070"], "night": 0.25, "fx": "firefly", "zs": ""},
	{"name": "Cloud Kingdom", "sky": ["6aaaff", "b8d4ff", "fff0e0"], "far": ["a8c4f0", "e0ecff"], "near": ["d0dcf8", "ffffff"], "gr": ["dfe8fb", "ffffff"], "night": 0.0, "fx": "sparkle", "zs": ""},
	{"name": "Neon City", "sky": ["08022c", "601070", "c0309a"], "far": ["28105a", "5a2aa0"], "near": ["180a3c", "3a1c78"], "gr": ["140c38", "00e0ff"], "night": 0.9, "fx": "sparkle", "zs": ""},
	{"name": "Deep Ocean", "sky": ["021850", "0f6e9e", "3cb4c8"], "far": ["0a4682", "1c78b0"], "near": ["06306a", "14609a"], "gr": ["14606e", "30c0b8"], "night": 0.5, "fx": "bubble", "zs": "jelly"},
	{"name": "Autumn Hills", "sky": ["ff9a50", "ffc88a", "ffe8b8"], "far": ["c8643c", "e8905a"], "near": ["a04630", "d0703c"], "gr": ["8a5a2a", "e0a040"], "night": 0.0, "fx": "leaf", "zs": ""},
	{"name": "Desert Oasis", "sky": ["2a9cc8", "90d0d0", "fff0c0"], "far": ["d8b070", "f0d090"], "near": ["c09058", "e4b878"], "gr": ["d4a860", "58c090"], "night": 0.0, "fx": "dust", "zs": ""},
	{"name": "Haunted Mist", "sky": ["14122c", "505a78", "a0acc0"], "far": ["3c4468", "5a6690"], "near": ["283050", "44507a"], "gr": ["303846", "76a088"], "night": 0.6, "fx": "mist", "zs": "ghost"},
	{"name": "Space Rings", "sky": ["02020e", "30206a", "6a4aa8"], "far": ["463482", "7a62c8"], "near": ["2a1c62", "4a38a0"], "gr": ["262658", "a094ff"], "night": 1.0, "fx": "sparkle", "zs": ""},
	{"name": "Rainbow Waterfall", "sky": ["78c8ff", "d0e8ff", "ffe6fa"], "far": ["68b0e0", "a0dcf0"], "near": ["4c90d4", "80c8e8"], "gr": ["60d0b8", "ffaadc"], "night": 0.0, "fx": "bubble", "zs": ""},
	{"name": "Moon Garden", "sky": ["141448", "5a5aa8", "b0b0e8"], "far": ["4a4a94", "7878c0"], "near": ["36407a", "5c68a8"], "gr": ["3c6a80", "a0e8e8"], "night": 0.8, "fx": "firefly", "zs": ""},
	{"name": "Golden Temple", "sky": ["ffae50", "ffd890", "fff4cc"], "far": ["d0884a", "f0b868"], "near": ["a8643a", "d8943e"], "gr": ["c8963c", "ffd668"], "night": 0.0, "fx": "sparkle", "zs": ""}
]

const LUM := {
	"far": [0.58, 0.70],
	"mid": [0.625, 0.75],
	"near": [0.37, 0.49],
	"ground": [0.34, 0.76]
}

const FX := {
	"snow": {"pf": [0.6, -0.04], "ef": [0.75, 0.02], "dir": [0.0, 1.0], "spread": 25.0, "grav": [-40.0, 70.0], "v0": 20.0, "v1": 55.0, "s0": 0.1, "s1": 0.28, "life": 6.5, "n": 70, "col": "ffffff", "a": 0.9, "add": false},
	"petal": {"pf": [0.6, -0.04], "ef": [0.75, 0.02], "dir": [0.0, 1.0], "spread": 30.0, "grav": [-60.0, 50.0], "v0": 15.0, "v1": 45.0, "s0": 0.12, "s1": 0.3, "life": 7.0, "n": 26, "col": "ffb8dc", "a": 0.85, "add": false},
	"leaf": {"pf": [0.6, -0.04], "ef": [0.75, 0.02], "dir": [0.0, 1.0], "spread": 40.0, "grav": [-90.0, 60.0], "v0": 20.0, "v1": 60.0, "s0": 0.14, "s1": 0.3, "life": 6.0, "n": 22, "col": "e0782c", "a": 0.9, "add": false},
	"ember": {"pf": [0.5, 1.04], "ef": [0.6, 0.02], "dir": [0.0, -1.0], "spread": 30.0, "grav": [-60.0, -40.0], "v0": 40.0, "v1": 110.0, "s0": 0.1, "s1": 0.3, "life": 3.5, "n": 50, "col": "ff8a3c", "a": 1.0, "add": true},
	"bubble": {"pf": [0.5, 1.04], "ef": [0.6, 0.02], "dir": [0.0, -1.0], "spread": 20.0, "grav": [-20.0, -30.0], "v0": 20.0, "v1": 60.0, "s0": 0.12, "s1": 0.4, "life": 6.0, "n": 30, "col": "b8f0ff", "a": 0.55, "add": false},
	"firefly": {"pf": [0.5, 0.45], "ef": [0.6, 0.3], "dir": [0.0, -1.0], "spread": 180.0, "grav": [-10.0, 0.0], "v0": 6.0, "v1": 22.0, "s0": 0.1, "s1": 0.26, "life": 3.5, "n": 30, "col": "eaff7a", "a": 1.0, "add": true},
	"sparkle": {"pf": [0.5, 0.4], "ef": [0.6, 0.35], "dir": [0.0, -1.0], "spread": 180.0, "grav": [-20.0, 0.0], "v0": 5.0, "v1": 25.0, "s0": 0.1, "s1": 0.3, "life": 2.4, "n": 34, "col": "ffd6f6", "a": 1.0, "add": true},
	"dust": {"pf": [1.02, 0.6], "ef": [0.02, 0.3], "dir": [-1.0, 0.0], "spread": 8.0, "grav": [0.0, 0.0], "v0": 160.0, "v1": 320.0, "s0": 0.08, "s1": 0.22, "life": 4.0, "n": 26, "col": "ffe4b0", "a": 0.4, "add": false},
	"mist": {"pf": [1.05, 0.7], "ef": [0.03, 0.25], "dir": [-1.0, 0.0], "spread": 10.0, "grav": [0.0, 0.0], "v0": 30.0, "v1": 70.0, "s0": 1.0, "s1": 2.2, "life": 16.0, "n": 12, "col": "dfe8f5", "a": 0.12, "add": false}
}

const RHYTHMS: Array = [
	[1.0, 1.0, 1.2, 0.9],
	[1.1, 0.9, 1.1, 0.9, 1.3],
	[1.0, 1.3, 0.85, 1.15],
	[0.95, 1.2, 1.0, 1.2, 0.9],
	[1.25, 0.9, 0.9, 1.1]
]

const COMBOS: Array = [
	[["spikes", 0.0], ["storm_low", 1.0]],
	[["wall", 0.0], ["spikes", 1.1]],
	[["crystal2", 0.0], ["crystal2", 0.9], ["bird", 1.1]],
	[["pit", 0.0], ["crystal1", 1.05]],
	[["storm_high", 0.0], ["pit", 1.1]],
	[["spin", 0.0], ["spin", 0.9], ["storm_low", 1.1]],
	[["swing", 0.0], ["spikes", 1.15]],
	[["laser", 0.0], ["crystal1", 1.0]],
	[["boulder", 0.0], ["crystal2", 1.3]],
	[["fire", 0.0], ["bird", 1.0], ["crystal1", 1.1]],
	[["wisp", 0.0], ["spikes", 1.0]],
	[["pillar", 0.0], ["bird", 1.0]]
]

const LAYER_SHADER := """shader_type canvas_item;
uniform vec4 c_dark : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform vec4 c_light : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float l0 = 0.0;
uniform float l1 = 1.0;
void fragment() {
	vec4 t = texture(TEXTURE, UV);
	float l = dot(t.rgb, vec3(0.299, 0.587, 0.114));
	float k = clamp((l - l0) / max(l1 - l0, 0.001), 0.0, 1.0);
	COLOR = vec4(mix(c_dark.rgb, c_light.rgb, k), t.a);
}
"""

enum State { READY, PLAYING, DEAD, PAUSED, MENU, WIN }
enum Mode { ADVENTURE, ENDLESS }

var rainbow: Array = [
	Color("ff5f8d"), Color("ffb05f"), Color("ffe066"),
	Color("6fe3a5"), Color("5fb8ff"), Color("a56bff")
]
var state: int = State.MENU
var mode: int = Mode.ENDLESS
var screen := "home"
var zone := 0
var level := 0
var zone_mode: int = Mode.ADVENTURE
var cur_page := 0
var busy := false
var speed := START_SPEED
var distance := 0.0
var score := 0
var coins := 0
var uy := FLOOR
var vy := 0.0
var jumps := 0
var held := false
var ducking := false
var falling := false
var dk := 0.0
var duck_ids: Dictionary = {}
var jump_ids: Dictionary = {}
var spawn_gap := 600.0
var run_time := 0.0
var shake := 0.0
var fps_timer := 0.0
var combo := 0
var combo_t := 0.0
var best_combo := 0
var last_kind := ""
var last_kind2 := ""
var bank := 0
var prog: Array = []
var eb: Array = []
var lv: Dictionary = {}
var lv_ev: Array = []
var lv_len := 1.0
var lv_total := 0
var ev_i := 0
var storm_sheet := "storm_low"
var finish_node: Sprite2D = null
var banner_tw: Tween = null

var bg: Node2D
var world: Node2D
var uni: AnimatedSprite2D
var sparks: CPUParticles2D
var ambient: CPUParticles2D
var sky_g: Gradient
var sun_node: Sprite2D
var stars_node: Node2D
var layer_shader: Shader
var star_list: Array = []
var lines: Array[Line2D] = []
var trail: Array[Vector2] = []
var layers: Array = []
var clouds: Array = []
var obstacles: Array = []
var items: Array = []
var tex_cache: Dictionary = {}

var ui: CanvasLayer
var score_label: Label
var coin_label: Label
var fps_label: Label
var combo_label: Label
var pause_btn: Button
var progress_bar: ProgressBar
var pause_panel: PanelContainer
var ready_box: Control
var ready_title: Label
var ready_sub: Label
var ready_label: Label
var over_panel: PanelContainer
var over_title: Label
var over_score: Label
var over_best: Label
var over_nav: Button
var win_panel: PanelContainer
var win_title: Label
var win_stars: Array = []
var win_info: Label
var win_note: Label
var win_next: Button
var home_box: Control
var home_info: Label
var zone_box: Control
var zone_title: Label
var zone_grid: GridContainer
var page_label: Label
var prev_btn: Button
var next_btn: Button
var level_box: Control
var level_title: Label
var level_grid: GridContainer
var banner_box: Control
var banner_title: Label
var banner_sub: Label
var bank_row: HBoxContainer
var bank_label: Label
var fade: ColorRect


func _ready() -> void:
	randomize()
	Engine.max_fps = 0
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
	init_progress()
	load_save()
	build_background()
	build_world()
	build_ui()
	apply_zone(zone)
	show_menu()


func get_tex(path: String) -> Texture2D:
	if not tex_cache.has(path):
		tex_cache[path] = load(path)
	return tex_cache[path]


func hc(v: Variant) -> Color:
	return Color(String(v))


func build_background() -> void:
	bg = Node2D.new()
	add_child(bg)

	layer_shader = Shader.new()
	layer_shader.code = LAYER_SHADER

	sky_g = Gradient.new()
	sky_g.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	sky_g.colors = PackedColorArray([Color("6a46b8"), Color("d77fcf"), Color("ffc9b8")])
	var gt := GradientTexture2D.new()
	gt.gradient = sky_g
	gt.width = 8
	gt.height = 256
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	var sky := Sprite2D.new()
	sky.texture = gt
	sky.centered = false
	sky.scale = Vector2(WIDE / 8.0, (VH + 400.0) / 256.0)
	bg.add_child(sky)

	stars_node = Node2D.new()
	stars_node.visible = false
	bg.add_child(stars_node)
	for i in 46:
		var st := Sprite2D.new()
		st.texture = load("res://art/spark.png")
		st.position = Vector2(randf_range(0.0, WIDE), randf_range(10.0, 300.0))
		var ss := randf_range(0.08, 0.22)
		st.scale = Vector2(ss, ss)
		var base_a := randf_range(0.5, 1.0)
		st.modulate = Color(1, 1, 1, base_a)
		stars_node.add_child(st)
		star_list.append({"node": st, "ph": randf() * 6.28, "a": base_a})

	sun_node = Sprite2D.new()
	sun_node.texture = load("res://art/sun.png")
	sun_node.position = Vector2(980, 150)
	sun_node.scale = Vector2(1.1, 1.1)
	sun_node.modulate = Color(1, 1, 1, 0.85)
	bg.add_child(sun_node)

	make_layer("res://art/rainbow.png", FLOOR - 440.0 + 40.0, 0.03, "rainbow")

	for i in 5:
		var c := Sprite2D.new()
		c.texture = load("res://art/cloud%d.png" % (i % 3))
		c.position = Vector2(randf_range(0, VW + 300), randf_range(40, 230))
		var s := randf_range(0.6, 1.1)
		c.scale = Vector2(s, s)
		var ca := randf_range(0.45, 0.8)
		c.modulate = Color(1, 1, 1, ca)
		bg.add_child(c)
		clouds.append({"node": c, "f": randf_range(0.03, 0.12), "a": ca})

	make_layer("res://art/far.png", FLOOR - 330.0 + 40.0, 0.07, "far")
	make_layer("res://art/mid.png", FLOOR - 250.0 + 30.0, 0.16, "mid")
	make_layer("res://art/near.png", FLOOR - 190.0 + 34.0, 0.42, "near")
	make_layer("res://art/ground.png", FLOOR - 14.0, 1.0, "ground")


func make_layer(path: String, y: float, factor: float, key: String) -> void:
	var tex: Texture2D = load(path)
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	s.position = Vector2(0, y)
	s.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	s.region_enabled = true
	s.region_rect = Rect2(0, 0, WIDE, tex.get_height())
	bg.add_child(s)
	var mat: ShaderMaterial = null
	if key != "rainbow":
		mat = ShaderMaterial.new()
		mat.shader = layer_shader
	layers.append({"node": s, "f": factor, "w": float(tex.get_width()), "h": float(tex.get_height()), "off": 0.0, "key": key, "mat": mat})


func layer_palette(zd: Dictionary, key: String) -> Array:
	var far_c: Array = zd["far"]
	var near_c: Array = zd["near"]
	var gr_c: Array = zd["gr"]
	if key == "far":
		return [hc(far_c[0]), hc(far_c[1])]
	if key == "near":
		return [hc(near_c[0]), hc(near_c[1])]
	if key == "ground":
		return [hc(gr_c[0]), hc(gr_c[1])]
	return [hc(far_c[0]).lerp(hc(near_c[0]), 0.5), hc(far_c[1]).lerp(hc(near_c[1]), 0.5)]


func apply_zone(z: int) -> void:
	zone = z
	var zd: Dictionary = ZONES[z]
	var sky: Array = zd["sky"]
	sky_g.colors = PackedColorArray([hc(sky[0]), hc(sky[1]), hc(sky[2])])
	var night: float = zd["night"]
	var raw: bool = zd.get("raw", false)
	for l in layers:
		var key: String = l["key"]
		var s: Sprite2D = l["node"]
		if key == "rainbow":
			s.modulate = Color(1, 1, 1, clampf(1.0 - night, 0.0, 1.0))
			continue
		if raw:
			s.material = null
			continue
		var pal: Array = layer_palette(zd, key)
		var mat: ShaderMaterial = l["mat"]
		var lum: Array = LUM[key]
		mat.set_shader_parameter("c_dark", pal[0])
		mat.set_shader_parameter("c_light", pal[1])
		mat.set_shader_parameter("l0", float(lum[0]))
		mat.set_shader_parameter("l1", float(lum[1]))
		s.material = mat
	var tint := Color(1, 1, 1)
	if not raw:
		tint = hc(sky[2]).lightened(0.5)
	for c in clouds:
		var n: Sprite2D = c["node"]
		n.modulate = Color(tint.r, tint.g, tint.b, float(c["a"]) * (1.0 - 0.65 * night))
	if raw:
		sun_node.modulate = Color(1, 1, 1, 0.85)
	elif night >= 0.5:
		sun_node.modulate = Color(0.86, 0.9, 1.0, 0.9)
	else:
		sun_node.modulate = Color(1, 0.96, 0.85, 0.85)
	stars_node.visible = night >= 0.45
	stars_node.modulate.a = clampf((night - 0.3) / 0.5, 0.0, 1.0)
	var zs: String = zd["zs"]
	storm_sheet = "storm_low"
	if zs == "jelly":
		storm_sheet = "jelly"
	elif zs == "ghost":
		storm_sheet = "ghost"
	apply_fx(String(zd["fx"]))


func fade_ramp() -> Gradient:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.2, 0.75, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
	return g


func apply_fx(kind: String) -> void:
	ambient.emitting = false
	if not FX.has(kind):
		return
	var f: Dictionary = FX[kind]
	var vs := get_viewport_rect().size
	var pf: Array = f["pf"]
	var ef: Array = f["ef"]
	var dr: Array = f["dir"]
	var gv: Array = f["grav"]
	ambient.position = Vector2(vs.x * float(pf[0]), vs.y * float(pf[1]))
	ambient.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	ambient.emission_rect_extents = Vector2(vs.x * float(ef[0]), vs.y * float(ef[1]))
	ambient.direction = Vector2(float(dr[0]), float(dr[1]))
	ambient.spread = float(f["spread"])
	ambient.gravity = Vector2(float(gv[0]), float(gv[1]))
	ambient.initial_velocity_min = float(f["v0"])
	ambient.initial_velocity_max = float(f["v1"])
	ambient.scale_amount_min = float(f["s0"])
	ambient.scale_amount_max = float(f["s1"])
	ambient.lifetime = float(f["life"])
	ambient.amount = int(f["n"])
	ambient.preprocess = float(f["life"])
	var c := hc(f["col"])
	ambient.color = Color(c.r, c.g, c.b, float(f["a"]))
	ambient.color_ramp = fade_ramp()
	if bool(f["add"]):
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		ambient.material = m
	else:
		ambient.material = null
	ambient.restart()
	ambient.emitting = true


func build_world() -> void:
	world = Node2D.new()
	add_child(world)

	ambient = CPUParticles2D.new()
	ambient.texture = load("res://art/spark.png")
	ambient.local_coords = false
	ambient.emitting = false
	world.add_child(ambient)

	for k in 6:
		var ln := Line2D.new()
		ln.width = 8.6
		ln.begin_cap_mode = Line2D.LINE_CAP_ROUND
		ln.end_cap_mode = Line2D.LINE_CAP_ROUND
		ln.joint_mode = Line2D.LINE_JOINT_ROUND
		ln.antialiased = true
		var gr := Gradient.new()
		var c: Color = rainbow[k]
		gr.offsets = PackedFloat32Array([0.0, 0.7, 1.0])
		gr.colors = PackedColorArray([Color(c.r, c.g, c.b, 0.0), Color(c.r, c.g, c.b, 0.85), c])
		ln.gradient = gr
		world.add_child(ln)
		lines.append(ln)

	sparks = CPUParticles2D.new()
	sparks.texture = load("res://art/spark.png")
	sparks.amount = 28
	sparks.lifetime = 0.7
	sparks.local_coords = false
	sparks.direction = Vector2(-1, 0)
	sparks.spread = 35.0
	sparks.gravity = Vector2.ZERO
	sparks.initial_velocity_min = 60.0
	sparks.initial_velocity_max = 160.0
	sparks.scale_amount_min = 0.15
	sparks.scale_amount_max = 0.4
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 1, 0.85, 1), Color(1, 0.7, 1, 0)])
	sparks.color_ramp = cg
	sparks.emitting = false
	world.add_child(sparks)

	uni = AnimatedSprite2D.new()
	uni.sprite_frames = build_frames()
	uni.centered = false
	uni.offset = Vector2(-UNI_ANCHOR, -FEET)
	uni.scale = Vector2(UNI_SCALE, UNI_SCALE)
	uni.position = Vector2(UNI_X, uy)
	world.add_child(uni)
	uni.play("run")


func add_anim(sf: SpriteFrames, anim: String, sheet: Texture2D, first: int, count: int, fps: float, loop: bool) -> void:
	sf.add_animation(anim)
	sf.set_animation_speed(anim, fps)
	sf.set_animation_loop(anim, loop)
	for i in count:
		var a := AtlasTexture.new()
		a.atlas = sheet
		a.region = Rect2((first + i) * FR, 0, FR, FR)
		sf.add_frame(anim, a)


func build_frames() -> SpriteFrames:
	var sheet: Texture2D = load("res://art/unicorn2.png")
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	add_anim(sf, "run", sheet, 0, 8, 17.0, true)
	add_anim(sf, "jump", sheet, 8, 1, 1.0, false)
	add_anim(sf, "duck", sheet, 9, 4, 14.0, true)
	add_anim(sf, "dead", sheet, 13, 1, 1.0, false)
	return sf


func make_label(size: int, color: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color("2a1670"))
	l.add_theme_constant_override("outline_size", 10)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func make_button(text: String, size: Vector2, fsize: int, col: Color) -> Button:
	var btn := Button.new()
	btn.text = text
	btn.custom_minimum_size = size
	btn.add_theme_font_size_override("font_size", fsize)
	btn.add_theme_color_override("font_color", Color.WHITE)
	btn.add_theme_color_override("font_hover_color", Color.WHITE)
	btn.add_theme_color_override("font_pressed_color", Color.WHITE)
	btn.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.6))
	btn.add_theme_stylebox_override("normal", button_style(col))
	btn.add_theme_stylebox_override("hover", button_style(col.lightened(0.1)))
	btn.add_theme_stylebox_override("pressed", button_style(col.darkened(0.15)))
	btn.add_theme_stylebox_override("disabled", button_style(col))
	btn.add_theme_stylebox_override("focus", button_style(col))
	return btn


func make_panel() -> PanelContainer:
	var pc := PanelContainer.new()
	pc.set_anchors_preset(Control.PRESET_CENTER)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.grow_vertical = Control.GROW_DIRECTION_BOTH
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.17, 0.08, 0.4, 0.95)
	sb.set_corner_radius_all(30)
	sb.set_border_width_all(3)
	sb.border_color = Color("9a7bd9")
	sb.content_margin_left = 48
	sb.content_margin_right = 48
	sb.content_margin_top = 28
	sb.content_margin_bottom = 32
	pc.add_theme_stylebox_override("panel", sb)
	return pc


func button_style(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(24)
	s.set_border_width_all(3)
	s.border_color = Color("e9d2ff")
	return s


func bar_style(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(8)
	s.set_border_width_all(2)
	s.border_color = Color("e9d2ff")
	return s


func make_full_rect() -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func make_center_label(text: String, size: int, color: Color, top: float, parent: Control) -> Label:
	var l := make_label(size, color)
	l.text = text
	l.set_anchors_preset(Control.PRESET_CENTER_TOP)
	l.grow_horizontal = Control.GROW_DIRECTION_BOTH
	l.offset_top = top
	parent.add_child(l)
	return l


func make_star_row(size: float, parent: Control) -> Array:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(row)
	var out: Array = []
	for i in 3:
		var tr := TextureRect.new()
		tr.texture = get_tex("res://art/star_off.png")
		tr.custom_minimum_size = Vector2(size, size)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(tr)
		out.append(tr)
	return out


func build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)

	score_label = make_label(36, Color.WHITE)
	score_label.position = Vector2(36, 16)
	ui.add_child(score_label)

	coin_label = make_label(36, Color("ffe27a"))
	coin_label.anchor_left = 1.0
	coin_label.anchor_right = 1.0
	coin_label.offset_left = -420.0
	coin_label.offset_right = -120.0
	coin_label.offset_top = 16.0
	coin_label.offset_bottom = 70.0
	coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ui.add_child(coin_label)

	combo_label = make_label(34, Color("ffe27a"))
	combo_label.anchor_left = 0.5
	combo_label.anchor_right = 0.5
	combo_label.offset_left = -200.0
	combo_label.offset_right = 200.0
	combo_label.offset_top = 84.0
	combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_label.visible = false
	ui.add_child(combo_label)

	fps_label = make_label(16, Color("c9b8ff"))
	fps_label.anchor_left = 0.5
	fps_label.anchor_right = 0.5
	fps_label.offset_left = -80.0
	fps_label.offset_right = 80.0
	fps_label.offset_top = 8.0
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(fps_label)

	progress_bar = ProgressBar.new()
	progress_bar.min_value = 0.0
	progress_bar.max_value = 1.0
	progress_bar.show_percentage = false
	progress_bar.custom_minimum_size = Vector2(520, 16)
	progress_bar.anchor_left = 0.5
	progress_bar.anchor_right = 0.5
	progress_bar.offset_left = -260.0
	progress_bar.offset_right = 260.0
	progress_bar.offset_top = 46.0
	progress_bar.offset_bottom = 62.0
	progress_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	progress_bar.add_theme_stylebox_override("background", bar_style(Color(0.1, 0.05, 0.3, 0.55)))
	progress_bar.add_theme_stylebox_override("fill", bar_style(Color("ffe27a")))
	progress_bar.visible = false
	ui.add_child(progress_bar)

	pause_btn = make_button("II", Vector2(76, 76), 34, Color("5a3cb0"))
	pause_btn.anchor_left = 1.0
	pause_btn.anchor_right = 1.0
	pause_btn.offset_left = -104.0
	pause_btn.offset_right = -28.0
	pause_btn.offset_top = 14.0
	pause_btn.offset_bottom = 90.0
	pause_btn.pressed.connect(pause_game)
	ui.add_child(pause_btn)

	banner_box = make_full_rect()
	ui.add_child(banner_box)
	banner_title = make_center_label("", 68, Color.WHITE, 120.0, banner_box)
	banner_sub = make_center_label("", 32, Color("ffe27a"), 205.0, banner_box)
	banner_box.modulate.a = 0.0

	ready_box = make_full_rect()
	ui.add_child(ready_box)
	ready_title = make_center_label("", 78, Color.WHITE, 56.0, ready_box)
	ready_sub = make_center_label("", 36, Color("c9b8ff"), 152.0, ready_box)
	ready_label = make_center_label("TAP TO RUN", 40, Color("ffe27a"), 212.0, ready_box)
	make_center_label("Right side: tap to jump, hold higher, tap again for double jump  -  Left side: hold to duck", 22, Color("e6dcff"), 276.0, ready_box)
	var rb := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	rb.position = Vector2(24, 16)
	rb.pressed.connect(go_back)
	ready_box.add_child(rb)

	over_panel = make_panel()
	ui.add_child(over_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	over_panel.add_child(box)

	over_title = make_label(54, Color("ff8fc7"))
	over_title.text = "GAME OVER"
	over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_title)

	over_score = make_label(32, Color.WHITE)
	over_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_score)

	over_best = make_label(26, Color("ffe27a"))
	over_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_best)

	var btn := make_button("RETRY", Vector2(280, 68), 32, Color("b45cff"))
	btn.pressed.connect(on_retry)
	box.add_child(btn)
	over_nav = make_button("LEVELS", Vector2(280, 60), 28, Color("3fc98a"))
	over_nav.pressed.connect(to_select)
	box.add_child(over_nav)
	var mbtn := make_button("MENU", Vector2(280, 60), 28, Color("4a86e8"))
	mbtn.pressed.connect(to_menu)
	box.add_child(mbtn)

	pause_panel = make_panel()
	ui.add_child(pause_panel)
	var pbox := VBoxContainer.new()
	pbox.add_theme_constant_override("separation", 14)
	pause_panel.add_child(pbox)
	var pt := make_label(54, Color.WHITE)
	pt.text = "PAUSED"
	pt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pbox.add_child(pt)
	var b1 := make_button("RESUME", Vector2(280, 64), 30, Color("3fc98a"))
	b1.pressed.connect(resume_game)
	pbox.add_child(b1)
	var b2 := make_button("RESTART", Vector2(280, 64), 30, Color("b45cff"))
	b2.pressed.connect(on_retry)
	pbox.add_child(b2)
	var b3 := make_button("MENU", Vector2(280, 64), 30, Color("4a86e8"))
	b3.pressed.connect(to_menu)
	pbox.add_child(b3)

	win_panel = make_panel()
	ui.add_child(win_panel)
	var wbox := VBoxContainer.new()
	wbox.add_theme_constant_override("separation", 10)
	win_panel.add_child(wbox)
	win_title = make_label(50, Color("7fe8b0"))
	win_title.text = "LEVEL COMPLETE"
	win_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	wbox.add_child(win_title)
	win_stars = make_star_row(84.0, wbox)
	win_info = make_label(28, Color.WHITE)
	win_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	wbox.add_child(win_info)
	win_note = make_label(26, Color("ffe27a"))
	win_note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	wbox.add_child(win_note)
	win_next = make_button("NEXT", Vector2(300, 66), 32, Color("3fc98a"))
	win_next.pressed.connect(on_next)
	wbox.add_child(win_next)
	var wr := make_button("RETRY", Vector2(300, 58), 28, Color("b45cff"))
	wr.pressed.connect(on_retry)
	wbox.add_child(wr)
	var wl := make_button("LEVELS", Vector2(300, 58), 28, Color("4a86e8"))
	wl.pressed.connect(to_select)
	wbox.add_child(wl)

	build_home()
	build_zone_screen()
	build_level_screen()

	bank_row = HBoxContainer.new()
	bank_row.add_theme_constant_override("separation", 8)
	bank_row.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	bank_row.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	bank_row.offset_top = 18.0
	bank_row.offset_right = -28.0
	bank_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ci := TextureRect.new()
	ci.texture = get_tex("res://art/coin.png")
	ci.custom_minimum_size = Vector2(46, 46)
	ci.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ci.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ci.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bank_row.add_child(ci)
	bank_label = make_label(36, Color("ffe27a"))
	bank_row.add_child(bank_label)
	ui.add_child(bank_row)

	fade = ColorRect.new()
	fade.color = Color(0.07, 0.04, 0.2, 0.0)
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(fade)


func build_home() -> void:
	home_box = make_full_rect()
	ui.add_child(home_box)
	make_center_label("UNICORN DASH", 88, Color.WHITE, 46.0, home_box)
	home_info = make_center_label("", 28, Color("e6dcff"), 150.0, home_box)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_top", 210)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	home_box.add_child(margin)
	var cc := CenterContainer.new()
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(cc)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 22)
	cc.add_child(col)
	var adv := make_button("ADVENTURE", Vector2(440, 96), 44, Color("ff5fa8"))
	adv.pressed.connect(on_home_adventure)
	col.add_child(adv)
	var endl := make_button("ENDLESS", Vector2(440, 82), 38, Color("4a86e8"))
	endl.pressed.connect(on_home_endless)
	col.add_child(endl)


func build_zone_screen() -> void:
	zone_box = make_full_rect()
	ui.add_child(zone_box)
	zone_title = make_center_label("", 48, Color.WHITE, 12.0, zone_box)
	var back := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	back.position = Vector2(24, 14)
	back.pressed.connect(go_back)
	zone_box.add_child(back)

	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	zone_box.add_child(cc)
	zone_grid = GridContainer.new()
	zone_grid.columns = 3
	zone_grid.add_theme_constant_override("h_separation", 18)
	zone_grid.add_theme_constant_override("v_separation", 18)
	cc.add_child(zone_grid)

	var nav := HBoxContainer.new()
	nav.add_theme_constant_override("separation", 24)
	nav.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	nav.grow_horizontal = Control.GROW_DIRECTION_BOTH
	nav.grow_vertical = Control.GROW_DIRECTION_BEGIN
	nav.offset_bottom = -16.0
	nav.mouse_filter = Control.MOUSE_FILTER_IGNORE
	zone_box.add_child(nav)
	prev_btn = make_button("<", Vector2(96, 64), 36, Color("5a3cb0"))
	prev_btn.pressed.connect(on_page.bind(-1))
	nav.add_child(prev_btn)
	page_label = make_label(32, Color.WHITE)
	nav.add_child(page_label)
	next_btn = make_button(">", Vector2(96, 64), 36, Color("5a3cb0"))
	next_btn.pressed.connect(on_page.bind(1))
	nav.add_child(next_btn)


func build_level_screen() -> void:
	level_box = make_full_rect()
	ui.add_child(level_box)
	level_title = make_center_label("", 48, Color.WHITE, 12.0, level_box)
	var back := make_button("BACK", Vector2(150, 64), 28, Color("4a86e8"))
	back.position = Vector2(24, 14)
	back.pressed.connect(go_back)
	level_box.add_child(back)

	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	level_box.add_child(cc)
	level_grid = GridContainer.new()
	level_grid.columns = 5
	level_grid.add_theme_constant_override("h_separation", 14)
	level_grid.add_theme_constant_override("v_separation", 14)
	cc.add_child(level_grid)


func hide_screens() -> void:
	home_box.visible = false
	zone_box.visible = false
	level_box.visible = false
	ready_box.visible = false
	over_panel.visible = false
	pause_panel.visible = false
	win_panel.visible = false
	pause_btn.visible = false
	progress_bar.visible = false
	bank_row.visible = false


func refresh_bank() -> void:
	bank_label.text = "%d" % bank


func page_count() -> int:
	return ceili(float(ZONES.size()) / float(PER_PAGE))


func show_menu() -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = "home"
	home_info.text = "Stars  %d / %d" % [total_stars(), ZONES.size() * LEVELS_PER_ZONE * 3]
	refresh_bank()
	bank_row.visible = true
	home_box.visible = true
	update_hud()


func show_zones(m: int) -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = "zones"
	zone_mode = m
	zone_title.text = "ADVENTURE" if m == Mode.ADVENTURE else "ENDLESS"
	cur_page = floori(float(zone) / float(PER_PAGE))
	refresh_zones()
	refresh_bank()
	bank_row.visible = true
	zone_box.visible = true
	update_hud()


func show_levels(z: int) -> void:
	reset_run_state()
	hide_screens()
	state = State.MENU
	screen = "levels"
	apply_zone(z)
	var nm: String = ZONES[z]["name"]
	level_title.text = nm
	refresh_levels(z)
	refresh_bank()
	bank_row.visible = true
	level_box.visible = true
	update_hud()


func refresh_zones() -> void:
	for c in zone_grid.get_children():
		zone_grid.remove_child(c)
		c.queue_free()
	var first := cur_page * PER_PAGE
	for i in PER_PAGE:
		var z := first + i
		if z >= ZONES.size():
			break
		zone_grid.add_child(make_zone_card(z))
	page_label.text = "%d / %d" % [cur_page + 1, page_count()]
	prev_btn.disabled = cur_page <= 0
	next_btn.disabled = cur_page >= page_count() - 1


func make_zone_card(z: int) -> Button:
	var zd: Dictionary = ZONES[z]
	var sky: Array = zd["sky"]
	var nm: String = zd["name"]
	var is_open := zone_open(z)
	var txt := ""
	if not is_open:
		var prev_nm: String = ZONES[z - 1]["name"]
		txt = "LOCKED\nClear %d levels in\n%s" % [ZONE_NEED, prev_nm]
	elif zone_mode == Mode.ADVENTURE:
		txt = "%s\n%d / %d cleared   %d stars" % [nm, cleared(z), LEVELS_PER_ZONE, zone_stars(z)]
	else:
		txt = "%s\nBest  %d" % [nm, int(eb[z])]
	var base := hc(sky[1]).darkened(0.4)
	if not is_open:
		base = Color(0.28, 0.24, 0.4)
	var btn := make_button(txt, Vector2(380, 150), 26, base)
	btn.disabled = not is_open
	if not is_open:
		btn.icon = get_tex("res://art/lock.png")
		btn.add_theme_constant_override("icon_max_width", 48)
	btn.pressed.connect(on_zone_card.bind(z))
	return btn


func refresh_levels(z: int) -> void:
	for c in level_grid.get_children():
		level_grid.remove_child(c)
		c.queue_free()
	for l in LEVELS_PER_ZONE:
		level_grid.add_child(make_level_tile(z, l))


func make_level_tile(z: int, l: int) -> Button:
	var boss := l == LEVELS_PER_ZONE - 1
	var is_open := level_open(z, l)
	var base := Color("b45cff")
	if boss:
		base = Color("ff5f8d")
	if not is_open:
		base = Color(0.28, 0.24, 0.4)
	var btn := make_button("", Vector2(188, 168), 40, base)
	btn.disabled = not is_open
	var num := make_label(60, Color.WHITE)
	num.text = "%d" % (l + 1)
	num.set_anchors_preset(Control.PRESET_CENTER_TOP)
	num.grow_horizontal = Control.GROW_DIRECTION_BOTH
	num.offset_top = 26.0 if boss else 14.0
	btn.add_child(num)
	if boss:
		var bl := make_label(22, Color("ffe27a"))
		bl.text = "BOSS"
		bl.set_anchors_preset(Control.PRESET_CENTER_TOP)
		bl.grow_horizontal = Control.GROW_DIRECTION_BOTH
		bl.offset_top = 6.0
		btn.add_child(bl)
	if is_open:
		var got := stars_of(z, l)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 4)
		row.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
		row.grow_horizontal = Control.GROW_DIRECTION_BOTH
		row.grow_vertical = Control.GROW_DIRECTION_BEGIN
		row.offset_bottom = -12.0
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.add_child(row)
		for i in 3:
			var tr := TextureRect.new()
			tr.texture = get_tex("res://art/star_on.png" if i < got else "res://art/star_off.png")
			tr.custom_minimum_size = Vector2(44, 44)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
			row.add_child(tr)
	else:
		var lk := TextureRect.new()
		lk.texture = get_tex("res://art/lock.png")
		lk.set_anchors_preset(Control.PRESET_CENTER)
		lk.grow_horizontal = Control.GROW_DIRECTION_BOTH
		lk.grow_vertical = Control.GROW_DIRECTION_BOTH
		lk.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.add_child(lk)
	btn.pressed.connect(on_level_tile.bind(z, l))
	return btn


func on_home_adventure() -> void:
	go(show_zones.bind(Mode.ADVENTURE))


func on_home_endless() -> void:
	go(show_zones.bind(Mode.ENDLESS))


func on_page(d: int) -> void:
	cur_page = clampi(cur_page + d, 0, page_count() - 1)
	refresh_zones()


func on_zone_card(z: int) -> void:
	if zone_mode == Mode.ADVENTURE:
		go(show_levels.bind(z))
	else:
		go(start_endless.bind(z))


func on_level_tile(z: int, l: int) -> void:
	go(select_level.bind(z, l))


func start_endless(z: int) -> void:
	mode = Mode.ENDLESS
	apply_zone(z)
	show_ready()


func select_level(z: int, l: int) -> void:
	mode = Mode.ADVENTURE
	level = l
	apply_zone(z)
	show_ready()


func go(cb: Callable) -> void:
	if busy:
		return
	busy = true
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.14)
	tw.tween_callback(cb)
	tw.tween_property(fade, "color:a", 0.0, 0.2)
	tw.tween_callback(unbusy)


func unbusy() -> void:
	busy = false


func go_back() -> void:
	if busy:
		return
	if state == State.PLAYING:
		pause_game()
	elif state == State.PAUSED:
		resume_game()
	elif state == State.READY or state == State.DEAD or state == State.WIN:
		to_select()
	elif state == State.MENU:
		if screen == "levels":
			go(show_zones.bind(Mode.ADVENTURE))
		elif screen == "zones":
			go(show_menu)


func to_select() -> void:
	if mode == Mode.ADVENTURE:
		go(show_levels.bind(zone))
	else:
		go(show_zones.bind(Mode.ENDLESS))


func to_menu() -> void:
	go(show_menu)


func show_banner(title: String, sub: String) -> void:
	banner_title.text = title
	banner_sub.text = sub
	if banner_tw != null and banner_tw.is_valid():
		banner_tw.kill()
	banner_box.modulate.a = 1.0
	banner_tw = create_tween()
	banner_tw.tween_property(banner_box, "modulate:a", 0.0, 0.6).set_delay(1.5)


func level_title_text() -> String:
	if mode == Mode.ENDLESS:
		return "ENDLESS"
	if level == LEVELS_PER_ZONE - 1:
		return "FINAL CHALLENGE"
	return "LEVEL %d" % (level + 1)


func show_ready() -> void:
	reset_run_state()
	hide_screens()
	state = State.READY
	screen = "ready"
	var nm: String = ZONES[zone]["name"]
	ready_title.text = level_title_text()
	ready_sub.text = nm
	ready_box.visible = true
	update_hud()


func init_progress() -> void:
	prog.clear()
	eb.clear()
	for z in ZONES.size():
		var row: Array = []
		for l in LEVELS_PER_ZONE:
			row.append(0)
		prog.append(row)
		eb.append(0)


func stars_of(z: int, l: int) -> int:
	return int(prog[z][l])


func cleared(z: int) -> int:
	var n := 0
	for l in LEVELS_PER_ZONE:
		if stars_of(z, l) > 0:
			n += 1
	return n


func zone_stars(z: int) -> int:
	var n := 0
	for l in LEVELS_PER_ZONE:
		n += stars_of(z, l)
	return n


func total_stars() -> int:
	var n := 0
	for z in ZONES.size():
		n += zone_stars(z)
	return n


func zone_open(z: int) -> bool:
	return z == 0 or cleared(z - 1) >= ZONE_NEED


func level_open(z: int, l: int) -> bool:
	return zone_open(z) and (l == 0 or stars_of(z, l - 1) > 0)


func next_target() -> Vector2i:
	if level < LEVELS_PER_ZONE - 1:
		return Vector2i(zone, level + 1)
	if zone + 1 < ZONES.size() and zone_open(zone + 1):
		return Vector2i(zone + 1, 0)
	return Vector2i(-1, -1)


func reset_run_state() -> void:
	clear_run()
	if banner_tw != null and banner_tw.is_valid():
		banner_tw.kill()
	banner_box.modulate.a = 0.0
	sparks.emitting = false
	ducking = false
	held = false
	falling = false
	dk = 0.0
	duck_ids.clear()
	jump_ids.clear()
	jumps = 0
	uy = FLOOR
	vy = 0.0
	combo = 0
	shake = 0.0
	world.position = Vector2.ZERO


func clear_run() -> void:
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	trail.clear()
	if finish_node != null and is_instance_valid(finish_node):
		finish_node.queue_free()
	finish_node = null


func start_run() -> void:
	clear_run()
	distance = 0.0
	score = 0
	coins = 0
	combo = 0
	combo_t = 0.0
	best_combo = 0
	uy = FLOOR
	vy = 0.0
	jumps = 0
	dk = 0.0
	falling = false
	last_kind = ""
	last_kind2 = ""
	spawn_gap = 700.0
	shake = 0.0
	ev_i = 0
	world.position = Vector2.ZERO
	if mode == Mode.ADVENTURE:
		lv = build_level(zone, level)
		lv_ev = lv["ev"]
		lv_len = float(lv["len"])
		lv_total = int(lv["coins"])
		speed = float(lv["sp"])
	else:
		lv_ev = []
		lv_len = 1.0
		lv_total = 0
		speed = START_SPEED
	hide_screens()
	state = State.PLAYING
	screen = "play"
	pause_btn.visible = true
	progress_bar.visible = mode == Mode.ADVENTURE
	progress_bar.value = 0.0
	sparks.emitting = true
	var nm: String = ZONES[zone]["name"]
	if mode == Mode.ADVENTURE:
		show_banner(level_title_text(), nm)
	else:
		show_banner(nm, "ENDLESS")
	update_hud()


func on_retry() -> void:
	start_run()


func on_next() -> void:
	var t := next_target()
	if t.x < 0:
		return
	mode = Mode.ADVENTURE
	level = t.y
	apply_zone(t.x)
	start_run()


func pause_game() -> void:
	if state != State.PLAYING:
		return
	state = State.PAUSED
	pause_panel.visible = true
	sparks.emitting = false
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()


func resume_game() -> void:
	if state != State.PAUSED:
		return
	state = State.PLAYING
	pause_panel.visible = false
	sparks.emitting = true


func press() -> void:
	if state == State.READY:
		start_run()
		do_jump()
	elif state == State.PLAYING:
		do_jump()


func do_jump() -> void:
	if jumps >= MAX_JUMPS:
		return
	vy = JUMP_V if jumps == 0 else JUMP_V * 0.92
	jumps += 1
	pop(Vector2(UNI_X - 20.0, uy - 6.0), 8, 0.6)


func touch_down(index: int, pos: Vector2) -> void:
	if state != State.READY and state != State.PLAYING:
		return
	var w := get_viewport_rect().size.x
	if state == State.PLAYING and pos.x < w * 0.3:
		duck_ids[index] = true
		ducking = true
	else:
		jump_ids[index] = true
		held = true
		press()


func touch_up(index: int) -> void:
	if duck_ids.has(index):
		duck_ids.erase(index)
		ducking = not duck_ids.is_empty()
	if jump_ids.has(index):
		jump_ids.erase(index)
		held = not jump_ids.is_empty()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_down(event.index, event.position)
		else:
			touch_up(event.index)
	elif event is InputEventKey and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_UP or event.keycode == KEY_W:
			held = event.pressed
			if event.pressed:
				press()
		elif event.keycode == KEY_DOWN or event.keycode == KEY_S:
			ducking = event.pressed
		elif event.pressed and (event.keycode == KEY_P or event.keycode == KEY_ESCAPE):
			if state == State.PLAYING:
				pause_game()
			elif state == State.PAUSED:
				resume_game()
			elif event.keycode == KEY_ESCAPE:
				go_back()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		held = false
		ducking = false
		duck_ids.clear()
		jump_ids.clear()
		pause_game()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		go_back()


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	if state != State.PAUSED:
		run_time += delta
	if state == State.PLAYING:
		update_play(delta)
	elif state == State.READY or state == State.MENU:
		scroll_layers(START_SPEED * 0.35 * delta)
	elif state == State.DEAD:
		update_dead(delta)
	elif state == State.WIN:
		update_win(delta)
	if state != State.PAUSED:
		scroll_clouds(delta)
	update_visuals(delta)
	update_stars()
	fps_timer += delta
	if fps_timer >= 0.5:
		fps_timer = 0.0
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()


func on_ice() -> bool:
	if uy < FLOOR - 4.0:
		return false
	for o in obstacles:
		if o["kind"] == "ice":
			var n: Node2D = o["node"]
			if absf(n.position.x - UNI_X) < 80.0:
				return true
	return false


func update_play(delta: float) -> void:
	if mode == Mode.ENDLESS:
		speed = minf(MAX_SPEED, START_SPEED + distance * 0.02)
	var boost := ICE_BOOST if on_ice() else 1.0
	var dx := speed * delta * boost
	distance += dx
	var new_score := int(distance / 10.0)
	if new_score != score:
		score = new_score
		update_hud()
	dk = move_toward(dk, 1.0 if ducking else 0.0, delta * 9.0)
	var g := GRAVITY
	if held and vy < 0.0:
		g *= HOLD_G
	elif ducking and uy < FLOOR - 1.0:
		g *= DUCK_FALL
	vy += g * delta
	uy += vy * delta
	if uy >= FLOOR:
		if vy > 300.0:
			pop(Vector2(UNI_X, FLOOR), 6, 0.5)
		uy = FLOOR
		vy = 0.0
		jumps = 0
	scroll_layers(dx)
	move_things(delta, dx)
	if mode == Mode.ENDLESS:
		spawn_gap -= dx
		if spawn_gap <= 0.0:
			spawn_pattern()
	else:
		spawn_events()
	check_hits()
	if state != State.PLAYING:
		return
	if mode == Mode.ADVENTURE:
		progress_bar.value = clampf(distance / lv_len, 0.0, 1.0)
		if finish_node != null and finish_node.position.x <= UNI_X:
			win()
			return
	update_trail(dx)
	combo_t -= delta
	if combo_t <= 0.0 and combo > 0:
		combo = 0
		update_hud()
	sparks.position = Vector2(UNI_X + TAIL_DX, uy + TAIL_DY)
	sparks.initial_velocity_min = speed * 0.6
	sparks.initial_velocity_max = speed * 1.0 + 60.0


func update_dead(delta: float) -> void:
	if falling:
		vy += GRAVITY * delta * 0.9
		uy += vy * delta


func update_win(delta: float) -> void:
	var dx := speed * 0.6 * delta
	scroll_layers(dx)
	if uy < FLOOR or vy != 0.0:
		vy += GRAVITY * delta
		uy += vy * delta
		if uy >= FLOOR:
			uy = FLOOR
			vy = 0.0
			jumps = 0
	update_trail(dx)
	sparks.position = Vector2(UNI_X + TAIL_DX, uy + TAIL_DY)


func scroll_layers(dx: float) -> void:
	for l in layers:
		var off: float = fmod(l["off"] + dx * l["f"], l["w"])
		l["off"] = off
		var s: Sprite2D = l["node"]
		s.region_rect = Rect2(off, 0.0, WIDE, l["h"])


func scroll_clouds(delta: float) -> void:
	var base := speed if state == State.PLAYING else START_SPEED * 0.35
	for c in clouds:
		var n: Sprite2D = c["node"]
		n.position.x -= (base * c["f"] + 10.0) * delta
		if n.position.x < -380.0:
			n.position.x = get_viewport_rect().size.x + randf_range(40.0, 300.0)
			n.position.y = randf_range(40.0, 230.0)


func update_stars() -> void:
	if not stars_node.visible:
		return
	for i in 14:
		var d: Dictionary = star_list[i]
		var n: Sprite2D = d["node"]
		n.modulate.a = float(d["a"]) * (0.55 + 0.45 * sin(run_time * 2.4 + float(d["ph"])))


func move_things(_delta: float, dx: float) -> void:
	for i in range(obstacles.size() - 1, -1, -1):
		var o: Dictionary = obstacles[i]
		var n: Node2D = o["node"]
		n.position.x -= dx * float(o["v"])
		if n.position.x < -260.0:
			n.queue_free()
			obstacles.remove_at(i)
	for i in range(items.size() - 1, -1, -1):
		var it: Dictionary = items[i]
		var n: Sprite2D = it["node"]
		n.position.x -= dx * float(it["v"])
		if n.position.x < -80.0:
			n.queue_free()
			items.remove_at(i)
	if finish_node != null:
		finish_node.position.x -= dx


func kind_weights() -> Dictionary:
	var sc := float(score)
	var d := minf(sc / 2500.0, 1.0)
	var w := {"crystal1": 0.35, "crystal2": 0.25}
	if sc > 15.0:
		w["spikes"] = 0.5
	if sc > 60.0:
		w["fire"] = 0.12
	if sc > 80.0:
		w["storm_low"] = 0.3 + 0.1 * d
		w["storm_high"] = 0.2 + 0.12 * d
	if sc > 100.0:
		w["boulder"] = 0.35
	if sc > 120.0:
		w["pit"] = 0.25
	if sc > 200.0:
		w["spin"] = 0.15
	if sc > 260.0:
		w["bird"] = 0.15
		w["wall"] = 0.33
	if sc > 300.0:
		w["swing"] = 0.16
	if sc > 350.0:
		w["pillar"] = 0.12
	if sc > 380.0:
		w["laser"] = 0.14
	if sc > 450.0:
		w["wisp"] = 0.14
	var zs: String = ZONES[zone]["zs"]
	if zs == "ice" and sc > 30.0:
		w["ice"] = 0.3
	if last_kind != "" and w.has(last_kind):
		w[last_kind] *= 0.15
	if last_kind2 != "" and w.has(last_kind2):
		w[last_kind2] *= 0.55
	return w


func pick_kind() -> String:
	var w := kind_weights()
	var total := 0.0
	for k in w:
		total += float(w[k])
	var r := randf() * total
	for k in w:
		r -= float(w[k])
		if r <= 0.0:
			last_kind2 = last_kind
			last_kind = k
			return k
	return "crystal1"


func spawn_pattern() -> void:
	var x := get_viewport_rect().size.x + 140.0
	var r := randf()
	var extra := 0.0
	if r < 0.55:
		var k := pick_kind()
		add_obstacle(k, x, k == "pit" and randf() < 0.3)
		coins_for(k, x)
	elif r < 0.82 and score > 40:
		var k1 := pick_kind()
		var k2 := pick_kind()
		var off := 330.0
		if k1 == "pit" or k1 == "swing":
			off = 470.0
		add_obstacle(k1, x)
		add_obstacle(k2, x + off)
		coins_for(k1, x)
		coins_for(k2, x + off)
		extra = off
	else:
		add_coin_line(x, 8, FLOOR - 70.0 - randf() * 90.0)
	spawn_gap = speed * randf_range(0.95, 1.4) + 300.0 + extra


func coin_count(kind: String) -> int:
	match kind:
		"boulder":
			return 0
		"bird", "storm_low", "storm_high", "wisp":
			return 3
		"ice":
			return 4
	return 5


func coins_for(kind: String, x: float) -> void:
	var v: float = KINDS[kind]["v"]
	match kind:
		"boulder":
			pass
		"wall", "pillar":
			add_coin_arc(x, 5, 230.0, v)
		"bird", "storm_low", "storm_high", "wisp":
			add_coin_line(x - 60.0, 3, FLOOR - 40.0, v)
		"ice":
			add_coin_line(x - 90.0, 4, FLOOR - 45.0, v)
		"laser":
			add_coin_arc(x, 5, 200.0, v)
		_:
			add_coin_arc(x, 5, 150.0, v)


func level_weights(z: int, l: int, d: float) -> Dictionary:
	var gi := z * LEVELS_PER_ZONE + l
	var zs: String = ZONES[z]["zs"]
	var w := {"crystal1": 0.7, "crystal2": 0.5}
	if gi >= 1:
		w["spikes"] = 0.4 + 0.3 * d
	if gi >= 4:
		w["storm_low"] = 0.3 + 0.3 * d
	if gi >= 6:
		w["boulder"] = 0.25 + 0.2 * d
	if gi >= 8:
		w["storm_high"] = 0.25 + 0.25 * d
	if gi >= 10:
		w["pit"] = 0.25 + 0.3 * d
	if gi >= 12:
		w["spin"] = 0.2 + 0.2 * d
	if gi >= 14:
		w["wall"] = 0.2 + 0.2 * d
	if gi >= 16:
		w["swing"] = 0.2 + 0.25 * d
	if gi >= 20:
		w["laser"] = 0.2 + 0.25 * d
	if gi >= 22:
		w["bird"] = 0.2 + 0.2 * d
	if gi >= 24:
		w["wisp"] = 0.2 + 0.2 * d
	if gi >= 28:
		w["pillar"] = 0.2 + 0.2 * d
	if zs == "ice" and l >= 1:
		w["ice"] = 0.35
	if zs == "fire" and l >= 1:
		w["fire"] = 0.4
	return w


func pick_weighted(w: Dictionary, total: float, rng: RandomNumberGenerator) -> String:
	var r := rng.randf() * total
	for k in w:
		r -= float(w[k])
		if r <= 0.0:
			return String(k)
	return "crystal1"


func push_ev(ev: Array, st: Dictionary, kind: String, rng: RandomNumberGenerator) -> void:
	var wide := false
	var half := 0.0
	if kind == "pit":
		wide = rng.randf() < 0.3
		half = 80.0 if wide else 50.0
	st["at"] = float(st["at"]) + half
	ev.append({"at": float(st["at"]), "kind": kind, "wide": wide})
	st["coins"] = int(st["coins"]) + coin_count(kind)
	st["at"] = float(st["at"]) + half


func build_level(z: int, l: int) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = z * 1009 + l * 131 + 17
	var boss := l == LEVELS_PER_ZONE - 1
	var gi := z * LEVELS_PER_ZONE + l
	var d := clampf(0.05 + float(gi) / float(ZONES.size() * LEVELS_PER_ZONE) * 0.95 + (0.12 if boss else 0.0), 0.0, 1.0)
	var sp := minf(390.0 + float(z) * 9.0 + float(l) * 13.0 + (30.0 if boss else 0.0), 780.0)
	var secs := 30.0 + float(l) * 3.0 + (6.0 if boss else 0.0)
	var length := roundf(sp * secs)
	var w := level_weights(z, l, d)
	var total_w := 0.0
	for key in w:
		total_w += float(w[key])
	var rh: Array = RHYTHMS[rng.randi() % RHYTHMS.size()]
	var combos: Array = []
	if boss or l >= 5:
		for c in COMBOS:
			var ok := true
			for part in c:
				if not w.has(part[0]):
					ok = false
			if ok:
				combos.append(c)
	var ev: Array = []
	var st := {"at": 1500.0, "coins": 0}
	var idx := 0
	var last_k := ""
	var end_at := length - sp * 1.6
	while float(st["at"]) < end_at:
		if combos.size() > 0 and float(st["at"]) + sp * 3.4 < end_at and rng.randf() < (0.38 if boss else 0.14):
			var cb: Array = combos[rng.randi() % combos.size()]
			for part in cb:
				st["at"] = float(st["at"]) + sp * float(part[1])
				push_ev(ev, st, String(part[0]), rng)
			last_k = ""
		else:
			var kind := pick_weighted(w, total_w, rng)
			var tries := 0
			while tries < 3 and kind == last_k:
				kind = pick_weighted(w, total_w, rng)
				tries += 1
			last_k = kind
			push_ev(ev, st, kind, rng)
		var gap := sp * (1.0 - 0.25 * d) * float(rh[idx % rh.size()]) + rng.randf() * sp * 0.45 + 180.0
		if gap > 640.0 and rng.randf() < 0.2:
			ev.append({"at": float(st["at"]) + gap * 0.3, "kind": "coinline", "y": FLOOR - 70.0 - rng.randf() * 90.0})
			st["coins"] = int(st["coins"]) + 8
		st["at"] = float(st["at"]) + gap
		idx += 1
	ev.append({"at": length, "kind": "finish"})
	return {"sp": sp, "len": length, "ev": ev, "coins": int(st["coins"]), "boss": boss, "d": d}


func spawn_events() -> void:
	var limit := get_viewport_rect().size.x + 140.0
	while ev_i < lv_ev.size():
		var e: Dictionary = lv_ev[ev_i]
		var x := UNI_X + float(e["at"]) - distance
		if x > limit:
			break
		spawn_event(e, x)
		ev_i += 1


func spawn_event(e: Dictionary, x: float) -> void:
	var k: String = e["kind"]
	if k == "finish":
		add_finish(x)
	elif k == "coinline":
		add_coin_line(x, 8, float(e["y"]))
	else:
		add_obstacle(k, x, bool(e["wide"]))
		coins_for(k, x)


func win() -> void:
	state = State.WIN
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()
	pause_btn.visible = false
	progress_bar.visible = false
	combo_label.visible = false
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	if finish_node != null:
		finish_node.queue_free()
		finish_node = null
	var pct := 1.0
	if lv_total > 0:
		pct = float(coins) / float(lv_total)
	var got := 1
	if pct >= 0.6:
		got = 2
	if pct >= 0.9:
		got = 3
	var before := cleared(zone)
	if got > stars_of(zone, level):
		prog[zone][level] = got
	bank += coins
	save_game()
	var note := ""
	if before < ZONE_NEED and cleared(zone) >= ZONE_NEED and zone + 1 < ZONES.size():
		var nz: String = ZONES[zone + 1]["name"]
		note = "ZONE UNLOCKED  -  %s" % nz
	win_title.text = "LEVEL COMPLETE" if level < LEVELS_PER_ZONE - 1 else "ZONE BOSS DEFEATED"
	win_info.text = "Coins  %d / %d    (%d%%)" % [coins, lv_total, int(pct * 100.0)]
	win_note.text = note
	win_note.visible = note != ""
	win_next.visible = next_target().x >= 0
	for i in 3:
		var tr: TextureRect = win_stars[i]
		tr.texture = get_tex("res://art/star_on.png" if i < got else "res://art/star_off.png")
		tr.modulate.a = 0.0
		var tw := create_tween()
		tw.tween_property(tr, "modulate:a", 1.0, 0.25).set_delay(0.5 + 0.25 * float(i))
	pop(Vector2(UNI_X + 40.0, uy - 60.0), 24, 1.6)
	win_panel.visible = false
	get_tree().create_timer(0.9).timeout.connect(reveal_win)


func reveal_win() -> void:
	if state == State.WIN:
		win_panel.visible = true


func die(pit: bool = false) -> void:
	state = State.DEAD
	falling = pit
	shake = 8.0 if pit else 18.0
	sparks.emitting = false
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()
	pause_btn.visible = false
	progress_bar.visible = false
	combo_label.visible = false
	bank += coins
	if mode == Mode.ENDLESS:
		if score > int(eb[zone]):
			eb[zone] = score
		over_title.text = "GAME OVER"
		over_score.text = "Score  %d" % score
		over_best.text = "Best  %d     Coins  %d     Combo  x%d" % [int(eb[zone]), coins, best_combo]
		over_nav.text = "ZONES"
	else:
		var pct := int(clampf(distance / lv_len, 0.0, 1.0) * 100.0)
		over_title.text = "LEVEL FAILED"
		over_score.text = "Progress  %d%%" % pct
		over_best.text = "Coins  %d / %d" % [coins, lv_total]
		over_nav.text = "LEVELS"
	save_game()
	over_panel.visible = true
	if not pit:
		pop(Vector2(UNI_X, uy - 50.0), 18, 1.4)


func add_obstacle(kind: String, x: float, wide: bool = false) -> void:
	if kind == "swing":
		add_swing(x)
		return
	var info: Dictionary = KINDS[kind]
	var sheet: String = info["sheet"]
	if kind.begins_with("storm"):
		sheet = storm_sheet
	var s := Sprite2D.new()
	var tex: Texture2D = get_tex("res://art/obs_%s.png" % sheet)
	s.texture = tex
	s.hframes = maxi(1, int(tex.get_width() / FR))
	s.frame = 0
	s.centered = false
	s.offset = Vector2(-192, -FEET)
	var sx := UNI_SCALE
	var half := 0.0
	if kind == "pit":
		half = 80.0 if wide else 50.0
		sx = UNI_SCALE * (1.6 if wide else 1.0)
	s.scale = Vector2(sx, UNI_SCALE)
	s.position = Vector2(x, FLOOR - float(info["lift"]) * S)
	world.add_child(s)
	world.move_child(s, uni.get_index())
	obstacles.append({"node": s, "kind": kind, "v": info["v"], "n": info["n"], "fps": info["fps"], "ph": randf() * 4.0, "nm": false, "passed": false, "half": half})


func add_swing(x: float) -> void:
	var tex: Texture2D = get_tex("res://art/obs_swing.png")
	var root := Node2D.new()
	root.position = Vector2(x, FLOOR - 250.0)
	var chain := Line2D.new()
	chain.width = 5.0
	chain.default_color = Color("d9c8f5")
	chain.add_point(Vector2.ZERO)
	chain.add_point(Vector2(0.0, 200.0))
	root.add_child(chain)
	var mount := Sprite2D.new()
	mount.texture = tex
	mount.hframes = 2
	mount.frame = 1
	mount.scale = Vector2(UNI_SCALE, UNI_SCALE)
	mount.position = Vector2(0.0, -20.0 * UNI_SCALE)
	root.add_child(mount)
	var ball := Sprite2D.new()
	ball.texture = tex
	ball.hframes = 2
	ball.frame = 0
	ball.scale = Vector2(UNI_SCALE, UNI_SCALE)
	ball.position = Vector2(0.0, 200.0)
	root.add_child(ball)
	world.add_child(root)
	world.move_child(root, uni.get_index())
	obstacles.append({"node": root, "kind": "swing", "v": 1.0, "n": 1, "fps": 1.0, "ph": randf() * 6.28, "nm": false, "passed": false, "half": 0.0, "ball": ball, "chain": chain, "len": 200.0, "amp": 0.95, "freq": 2.3 + randf() * 0.4})


func add_finish(x: float) -> void:
	var s := Sprite2D.new()
	s.texture = get_tex("res://art/finish.png")
	s.centered = false
	s.offset = Vector2(-192, -FEET)
	s.scale = Vector2(UNI_SCALE, UNI_SCALE)
	s.position = Vector2(x, FLOOR)
	world.add_child(s)
	world.move_child(s, uni.get_index())
	finish_node = s


func add_coin(x: float, y: float, v: float = 1.0) -> void:
	var s := Sprite2D.new()
	s.texture = get_tex("res://art/coin.png")
	s.scale = Vector2(0.3, 0.3)
	s.position = Vector2(x, y)
	world.add_child(s)
	items.append({"node": s, "ph": randf() * 6.28, "y": y, "v": v})


func add_coin_arc(cx: float, count: int, height: float, v: float = 1.0) -> void:
	for i in count:
		var t := float(i) / float(count - 1)
		add_coin(cx - 120.0 + t * 240.0, FLOOR - 50.0 - sin(t * PI) * height, v)


func add_coin_line(x: float, count: int, y: float, v: float = 1.0) -> void:
	for i in count:
		add_coin(x + i * 62.0, y, v)


func player_rect() -> Rect2:
	var top := uy - lerpf(42.0, 22.0, dk) * S
	var bottom := uy - 7.0 * S
	return Rect2(UNI_X - 11.0 * S, top, 22.0 * S, bottom - top)


func wisp_center(o: Dictionary) -> float:
	return 38.0 + sin(run_time * 3.2 + float(o["ph"]) * 2.0) * 20.0


func laser_on(o: Dictionary) -> bool:
	return fmod(run_time * 0.5 + float(o["ph"]), 1.0) < 0.5


func swing_ball(o: Dictionary) -> Vector2:
	var n: Node2D = o["node"]
	var a := float(o["amp"]) * sin(run_time * float(o["freq"]) + float(o["ph"]))
	return n.position + Vector2(sin(a), cos(a)) * float(o["len"])


func circle_hits_rect(c: Vector2, r: float, rc: Rect2) -> bool:
	var px := clampf(c.x, rc.position.x, rc.end.x)
	var py := clampf(c.y, rc.position.y, rc.end.y)
	return c.distance_to(Vector2(px, py)) < r


func obstacle_boxes(o: Dictionary) -> Array:
	var k: String = o["kind"]
	if k == "wisp":
		var c := wisp_center(o)
		return [[-9.0, 9.0, c - 9.0, c + 9.0]]
	if k == "laser" and not laser_on(o):
		return []
	return KINDS[k]["boxes"]


func check_hits() -> void:
	var ur := player_rect()
	for o in obstacles:
		var n: Node2D = o["node"]
		var k: String = o["kind"]
		var hit := false
		var near := false
		if k == "swing":
			hit = circle_hits_rect(swing_ball(o), 26.0, ur)
		elif k == "pit":
			if uy >= FLOOR - 3.0 and absf(n.position.x - UNI_X) < float(o["half"]) - 12.0:
				die(true)
				return
		else:
			for b in obstacle_boxes(o):
				var orect := Rect2(n.position.x + float(b[0]) * S, FLOOR - float(b[3]) * S, (float(b[1]) - float(b[0])) * S, (float(b[3]) - float(b[2])) * S)
				if ur.intersects(orect):
					hit = true
				else:
					var gx := maxf(orect.position.x - ur.end.x, ur.position.x - orect.end.x)
					var gy := maxf(orect.position.y - ur.end.y, ur.position.y - orect.end.y)
					if gx < 0.0 and gy >= 0.0 and gy < 14.0:
						near = true
		if hit:
			die()
			return
		if near:
			o["nm"] = true
		if not o["passed"] and n.position.x < UNI_X - 60.0:
			o["passed"] = true
			if o["nm"]:
				add_combo(2)
				pop(Vector2(UNI_X + 30.0, uy - 70.0), 6, 0.5)
	var center := Vector2(UNI_X, uy - 58.0 + dk * 20.0)
	for i in range(items.size() - 1, -1, -1):
		var n: Sprite2D = items[i]["node"]
		if n.position.distance_to(center) < 56.0:
			pop(n.position, 10, 1.0)
			n.queue_free()
			items.remove_at(i)
			coins += 1
			add_combo(1)
			update_hud()


func add_combo(n: int) -> void:
	combo += n
	combo_t = 1.6
	best_combo = maxi(best_combo, combo)
	if combo >= 4 and mode == Mode.ENDLESS:
		distance += 3.0 * float(n) * 10.0
	update_hud()


func update_trail(dx: float) -> void:
	for i in trail.size():
		trail[i] = Vector2(trail[i].x - dx, trail[i].y)
	var anchor_x := UNI_X + TAIL_DX
	trail.append(Vector2(anchor_x, uy + TAIL_DY + dk * 14.0))
	while trail.size() > 0 and trail[0].x < anchor_x - TRAIL_LEN:
		trail.remove_at(0)
	var n := trail.size()
	for k in 6:
		var pts := PackedVector2Array()
		for i in n:
			var p := trail[i]
			var age := 1.0 - float(i) / float(maxi(n - 1, 1))
			var wave := sin(p.x * 0.028 + run_time * 9.0) * 7.0 * age
			pts.append(Vector2(p.x, p.y + (float(k) - 2.5) * 6.4 + wave))
		lines[k].points = pts


func update_swing(o: Dictionary) -> void:
	var root: Node2D = o["node"]
	var local := swing_ball(o) - root.position
	var ball: Sprite2D = o["ball"]
	var chain: Line2D = o["chain"]
	ball.position = local
	ball.rotation = local.x * 0.02
	chain.set_point_position(1, local)


func update_visuals(delta: float) -> void:
	uni.position = Vector2(UNI_X, uy)
	if state == State.PLAYING or state == State.WIN:
		if uy < FLOOR - 1.0:
			if uni.animation != "jump":
				uni.play("jump")
		elif dk > 0.5 and state == State.PLAYING:
			if uni.animation != "duck" or not uni.is_playing():
				uni.play("duck")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
		else:
			if uni.animation != "run" or not uni.is_playing():
				uni.play("run")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
	elif state == State.DEAD:
		if uni.animation != "dead":
			uni.play("dead")
	elif state == State.READY or state == State.MENU:
		if uni.animation != "run" or not uni.is_playing():
			uni.play("run")
		uni.speed_scale = 0.6
		if lines.size() > 0:
			for ln in lines:
				ln.points = PackedVector2Array()
	if state == State.PAUSED:
		uni.pause()
	if state != State.PAUSED:
		for o in obstacles:
			var n: Node2D = o["node"]
			var k: String = o["kind"]
			if k == "swing":
				update_swing(o)
				continue
			var sp := n as Sprite2D
			if k == "laser":
				sp.frame = 1 if laser_on(o) else 0
				continue
			if k == "wisp":
				sp.frame = int((run_time + float(o["ph"])) * float(o["fps"])) % int(o["n"])
				sp.position.y = FLOOR - (wisp_center(o) - 40.0) * S
				continue
			if int(o["n"]) > 1:
				sp.frame = int((run_time + float(o["ph"])) * float(o["fps"])) % int(o["n"])
			var bob := 0.0
			if k == "bird" or k == "storm_low" or k == "storm_high":
				bob = sin(run_time * 3.2 + float(o["ph"]) * 2.0) * 4.0
			sp.position.y = FLOOR - float(KINDS[k]["lift"]) * S + bob
		for it in items:
			var n: Sprite2D = it["node"]
			n.scale.x = 0.3 * absf(cos(run_time * 5.0 + it["ph"])) + 0.05
			n.position.y = float(it["y"]) + sin(run_time * 4.0 + it["ph"]) * 5.0
	if shake > 0.2:
		shake = lerpf(shake, 0.0, minf(1.0, delta * 9.0))
		world.position = Vector2(randf_range(-shake, shake), randf_range(-shake, shake))
	else:
		world.position = Vector2.ZERO
	if state == State.READY:
		ready_label.modulate.a = 0.55 + 0.45 * absf(sin(run_time * 3.0))


func update_hud() -> void:
	score_label.text = "%d" % score
	coin_label.text = "%d" % coins
	var playing := state == State.PLAYING or state == State.PAUSED or state == State.DEAD or state == State.WIN
	score_label.visible = playing
	coin_label.visible = playing
	combo_label.visible = playing and combo >= 2
	combo_label.text = "COMBO x%d" % combo


func pop(pos: Vector2, count: int, power: float) -> void:
	var p := CPUParticles2D.new()
	p.texture = get_tex("res://art/spark.png")
	p.position = pos
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = count
	p.lifetime = 0.6
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 80.0 * power
	p.initial_velocity_max = 220.0 * power
	p.scale_amount_min = 0.2
	p.scale_amount_max = 0.5
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 0.95, 0.6, 1), Color(1, 0.6, 1, 0)])
	p.color_ramp = cg
	world.add_child(p)
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func load_save() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save.cfg") != OK:
		return
	bank = int(cf.get_value("wallet", "bank", 0))
	var flat: Array = cf.get_value("adv", "stars", [])
	if flat.size() == ZONES.size() * LEVELS_PER_ZONE:
		for z in ZONES.size():
			for l in LEVELS_PER_ZONE:
				prog[z][l] = clampi(int(flat[z * LEVELS_PER_ZONE + l]), 0, 3)
	var ebs: Array = cf.get_value("end", "best", [])
	for z in mini(ebs.size(), ZONES.size()):
		eb[z] = int(ebs[z])
	if ebs.is_empty():
		eb[0] = int(cf.get_value("run", "best", 0))
	zone = clampi(int(cf.get_value("run", "zone", 0)), 0, ZONES.size() - 1)
	if not zone_open(zone):
		zone = 0


func save_game() -> void:
	var cf := ConfigFile.new()
	var flat: Array = []
	for z in ZONES.size():
		for l in LEVELS_PER_ZONE:
			flat.append(stars_of(z, l))
	cf.set_value("adv", "stars", flat)
	cf.set_value("end", "best", eb)
	cf.set_value("wallet", "bank", bank)
	cf.set_value("run", "zone", zone)
	cf.save("user://save.cfg")
