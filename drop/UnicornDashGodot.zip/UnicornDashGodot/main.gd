extends Node2D

const VW := 1280.0
const VH := 576.0
const WIDE := 2800.0
const FLOOR := 474.0
const UNI_X := 250.0
const UNI_SCALE := 0.42
const FEET := 352.0
const UNI_ANCHOR := 230.0
const S := 1.68
const GRAVITY := 2700.0
const JUMP_V := -820.0
const HOLD_G := 0.6
const DUCK_FALL := 2.0
const MAX_JUMPS := 2
const START_SPEED := 430.0
const MAX_SPEED := 980.0
const TAIL_DX := -72.0
const TAIL_DY := -24.0
const TRAIL_LEN := 280.0
const FR := 384

const KINDS := {
	"crystal1": {"n": 1, "fps": 1.0, "sheet": "crystal1", "boxes": [[-9.0, 9.0, 0.0, 32.0]], "v": 1.0, "lift": 0.0},
	"crystal2": {"n": 1, "fps": 1.0, "sheet": "crystal2", "boxes": [[-26.0, 26.0, 0.0, 32.0]], "v": 1.0, "lift": 0.0},
	"spikes": {"n": 1, "fps": 1.0, "sheet": "spikes", "boxes": [[-34.0, 34.0, 0.0, 22.0]], "v": 1.0, "lift": 0.0},
	"boulder": {"n": 8, "fps": 10.0, "sheet": "boulder", "boxes": [[-15.0, 15.0, 0.0, 32.0]], "v": 1.4, "lift": 0.0},
	"wall": {"n": 1, "fps": 1.0, "sheet": "wall", "boxes": [[-9.0, 9.0, 0.0, 80.0]], "v": 1.0, "lift": 0.0},
	"pillar": {"n": 1, "fps": 1.0, "sheet": "pillar", "boxes": [[-28.0, -2.0, 0.0, 26.0], [-2.0, 24.0, 0.0, 54.0]], "v": 1.0, "lift": 0.0},
	"bird": {"n": 6, "fps": 14.0, "sheet": "bird", "boxes": [[-13.0, 13.0, 35.0, 53.0]], "v": 1.12, "lift": 0.0},
	"storm_low": {"n": 8, "fps": 11.0, "sheet": "storm_low", "boxes": [[-12.0, 12.0, 38.0, 58.0]], "v": 1.0, "lift": 0.0},
	"storm_high": {"n": 8, "fps": 11.0, "sheet": "storm_low", "boxes": [[-12.0, 12.0, 70.0, 90.0]], "v": 1.0, "lift": 32.0},
	"spin": {"n": 8, "fps": 11.0, "sheet": "spin", "boxes": [[-14.0, 14.0, 0.0, 31.0]], "v": 1.0, "lift": 0.0},
	"fire": {"n": 8, "fps": 11.0, "sheet": "fire", "boxes": [[-22.0, 22.0, 0.0, 30.0]], "v": 1.1, "lift": 0.0}
}

enum State { READY, PLAYING, DEAD, PAUSED }

var rainbow: Array = [
	Color("ff5f8d"), Color("ffb05f"), Color("ffe066"),
	Color("6fe3a5"), Color("5fb8ff"), Color("a56bff")
]
var state: int = State.READY
var speed := START_SPEED
var distance := 0.0
var score := 0
var coins := 0
var best := 0
var uy := FLOOR
var vy := 0.0
var jumps := 0
var held := false
var ducking := false
var dk := 0.0
var duck_ids: Dictionary = {}
var jump_ids: Dictionary = {}
var spawn_gap := 600.0
var run_time := 0.0
var shake := 0.0
var fps_timer := 0.0
var combo := 0
var combo_t := 0.0
var best_combo := 0
var last_kind := ""
var last_kind2 := ""

var bg: Node2D
var world: Node2D
var uni: AnimatedSprite2D
var sparks: CPUParticles2D
var lines: Array[Line2D] = []
var trail: Array[Vector2] = []
var layers: Array = []
var clouds: Array = []
var obstacles: Array = []
var items: Array = []
var tex_cache: Dictionary = {}

var ui: CanvasLayer
var score_label: Label
var coin_label: Label
var fps_label: Label
var combo_label: Label
var pause_btn: Button
var pause_panel: PanelContainer
var ready_box: Control
var ready_label: Label
var over_panel: PanelContainer
var over_score: Label
var over_best: Label


func _ready() -> void:
	randomize()
	Engine.max_fps = 0
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
	load_best()
	build_background()
	build_world()
	build_ui()
	show_ready()


func get_tex(path: String) -> Texture2D:
	if not tex_cache.has(path):
		tex_cache[path] = load(path)
	return tex_cache[path]


func build_background() -> void:
	bg = Node2D.new()
	add_child(bg)

	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	g.colors = PackedColorArray([Color("6a46b8"), Color("d77fcf"), Color("ffc9b8")])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.width = 8
	gt.height = 256
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	var sky := Sprite2D.new()
	sky.texture = gt
	sky.centered = false
	sky.scale = Vector2(WIDE / 8.0, (VH + 400.0) / 256.0)
	bg.add_child(sky)

	var sun := Sprite2D.new()
	sun.texture = load("res://art/sun.png")
	sun.position = Vector2(980, 150)
	sun.scale = Vector2(1.1, 1.1)
	sun.modulate = Color(1, 1, 1, 0.85)
	bg.add_child(sun)

	make_layer("res://art/rainbow.png", FLOOR - 440.0 + 40.0, 0.03)

	for i in 5:
		var c := Sprite2D.new()
		c.texture = load("res://art/cloud%d.png" % (i % 3))
		c.position = Vector2(randf_range(0, VW + 300), randf_range(40, 230))
		var s := randf_range(0.6, 1.1)
		c.scale = Vector2(s, s)
		c.modulate = Color(1, 1, 1, randf_range(0.45, 0.8))
		bg.add_child(c)
		clouds.append({"node": c, "f": randf_range(0.03, 0.12)})

	make_layer("res://art/far.png", FLOOR - 330.0 + 40.0, 0.07)
	make_layer("res://art/mid.png", FLOOR - 250.0 + 30.0, 0.16)
	make_layer("res://art/near.png", FLOOR - 190.0 + 34.0, 0.42)
	make_layer("res://art/ground.png", FLOOR - 14.0, 1.0)


func make_layer(path: String, y: float, factor: float) -> void:
	var tex: Texture2D = load(path)
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	s.position = Vector2(0, y)
	s.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	s.region_enabled = true
	s.region_rect = Rect2(0, 0, WIDE, tex.get_height())
	bg.add_child(s)
	layers.append({"node": s, "f": factor, "w": float(tex.get_width()), "h": float(tex.get_height()), "off": 0.0})


func build_world() -> void:
	world = Node2D.new()
	add_child(world)

	for k in 6:
		var ln := Line2D.new()
		ln.width = 8.6
		ln.begin_cap_mode = Line2D.LINE_CAP_ROUND
		ln.end_cap_mode = Line2D.LINE_CAP_ROUND
		ln.joint_mode = Line2D.LINE_JOINT_ROUND
		ln.antialiased = true
		var gr := Gradient.new()
		var c: Color = rainbow[k]
		gr.offsets = PackedFloat32Array([0.0, 0.7, 1.0])
		gr.colors = PackedColorArray([Color(c.r, c.g, c.b, 0.0), Color(c.r, c.g, c.b, 0.85), c])
		ln.gradient = gr
		world.add_child(ln)
		lines.append(ln)

	sparks = CPUParticles2D.new()
	sparks.texture = load("res://art/spark.png")
	sparks.amount = 28
	sparks.lifetime = 0.7
	sparks.local_coords = false
	sparks.direction = Vector2(-1, 0)
	sparks.spread = 35.0
	sparks.gravity = Vector2.ZERO
	sparks.initial_velocity_min = 60.0
	sparks.initial_velocity_max = 160.0
	sparks.scale_amount_min = 0.15
	sparks.scale_amount_max = 0.4
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 1, 0.85, 1), Color(1, 0.7, 1, 0)])
	sparks.color_ramp = cg
	sparks.emitting = false
	world.add_child(sparks)

	uni = AnimatedSprite2D.new()
	uni.sprite_frames = build_frames()
	uni.centered = false
	uni.offset = Vector2(-UNI_ANCHOR, -FEET)
	uni.scale = Vector2(UNI_SCALE, UNI_SCALE)
	uni.position = Vector2(UNI_X, uy)
	world.add_child(uni)
	uni.play("run")


func add_anim(sf: SpriteFrames, anim: String, sheet: Texture2D, first: int, count: int, fps: float, loop: bool) -> void:
	sf.add_animation(anim)
	sf.set_animation_speed(anim, fps)
	sf.set_animation_loop(anim, loop)
	for i in count:
		var a := AtlasTexture.new()
		a.atlas = sheet
		a.region = Rect2((first + i) * FR, 0, FR, FR)
		sf.add_frame(anim, a)


func build_frames() -> SpriteFrames:
	var sheet: Texture2D = load("res://art/unicorn2.png")
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	add_anim(sf, "run", sheet, 0, 8, 17.0, true)
	add_anim(sf, "jump", sheet, 8, 1, 1.0, false)
	add_anim(sf, "duck", sheet, 9, 4, 14.0, true)
	add_anim(sf, "dead", sheet, 13, 1, 1.0, false)
	return sf


func make_label(size: int, color: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color("2a1670"))
	l.add_theme_constant_override("outline_size", 10)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func make_button(text: String, size: Vector2, fsize: int, col: Color) -> Button:
	var btn := Button.new()
	btn.text = text
	btn.custom_minimum_size = size
	btn.add_theme_font_size_override("font_size", fsize)
	btn.add_theme_color_override("font_color", Color.WHITE)
	btn.add_theme_color_override("font_hover_color", Color.WHITE)
	btn.add_theme_color_override("font_pressed_color", Color.WHITE)
	btn.add_theme_stylebox_override("normal", button_style(col))
	btn.add_theme_stylebox_override("hover", button_style(col.lightened(0.1)))
	btn.add_theme_stylebox_override("pressed", button_style(col.darkened(0.15)))
	btn.add_theme_stylebox_override("focus", button_style(col))
	return btn


func make_panel() -> PanelContainer:
	var pc := PanelContainer.new()
	pc.set_anchors_preset(Control.PRESET_CENTER)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.grow_vertical = Control.GROW_DIRECTION_BOTH
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.17, 0.08, 0.4, 0.95)
	sb.set_corner_radius_all(30)
	sb.set_border_width_all(3)
	sb.border_color = Color("9a7bd9")
	sb.content_margin_left = 48
	sb.content_margin_right = 48
	sb.content_margin_top = 28
	sb.content_margin_bottom = 32
	pc.add_theme_stylebox_override("panel", sb)
	return pc


func build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)

	score_label = make_label(36, Color.WHITE)
	score_label.position = Vector2(36, 16)
	ui.add_child(score_label)

	coin_label = make_label(36, Color("ffe27a"))
	coin_label.anchor_left = 1.0
	coin_label.anchor_right = 1.0
	coin_label.offset_left = -420.0
	coin_label.offset_right = -120.0
	coin_label.offset_top = 16.0
	coin_label.offset_bottom = 70.0
	coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ui.add_child(coin_label)

	combo_label = make_label(34, Color("ffe27a"))
	combo_label.anchor_left = 0.5
	combo_label.anchor_right = 0.5
	combo_label.offset_left = -200.0
	combo_label.offset_right = 200.0
	combo_label.offset_top = 70.0
	combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_label.visible = false
	ui.add_child(combo_label)

	fps_label = make_label(16, Color("c9b8ff"))
	fps_label.anchor_left = 0.5
	fps_label.anchor_right = 0.5
	fps_label.offset_left = -80.0
	fps_label.offset_right = 80.0
	fps_label.offset_top = 8.0
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(fps_label)

	pause_btn = make_button("II", Vector2(76, 76), 34, Color("5a3cb0"))
	pause_btn.anchor_left = 1.0
	pause_btn.anchor_right = 1.0
	pause_btn.offset_left = -104.0
	pause_btn.offset_right = -28.0
	pause_btn.offset_top = 14.0
	pause_btn.offset_bottom = 90.0
	pause_btn.pressed.connect(pause_game)
	ui.add_child(pause_btn)

	ready_box = Control.new()
	ready_box.set_anchors_preset(Control.PRESET_FULL_RECT)
	ready_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(ready_box)

	var title := make_label(78, Color("ffffff"))
	title.text = "UNICORN DASH"
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	title.grow_horizontal = Control.GROW_DIRECTION_BOTH
	title.offset_top = 70.0
	ready_box.add_child(title)

	ready_label = make_label(40, Color("ffe27a"))
	ready_label.text = "TAP TO RUN"
	ready_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	ready_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	ready_label.offset_top = 170.0
	ready_box.add_child(ready_label)

	var hint := make_label(22, Color("e6dcff"))
	hint.text = "Right side: tap to jump, hold higher, tap again for double jump  -  Left side: hold to duck"
	hint.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hint.grow_horizontal = Control.GROW_DIRECTION_BOTH
	hint.offset_top = 230.0
	ready_box.add_child(hint)

	over_panel = make_panel()
	ui.add_child(over_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	over_panel.add_child(box)

	var ot := make_label(54, Color("ff8fc7"))
	ot.text = "GAME OVER"
	ot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(ot)

	over_score = make_label(32, Color.WHITE)
	over_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_score)

	over_best = make_label(26, Color("ffe27a"))
	over_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_best)

	var btn := make_button("RETRY", Vector2(280, 68), 32, Color("b45cff"))
	btn.pressed.connect(on_retry)
	box.add_child(btn)
	var mbtn := make_button("MENU", Vector2(280, 60), 28, Color("4a86e8"))
	mbtn.pressed.connect(to_menu)
	box.add_child(mbtn)

	pause_panel = make_panel()
	ui.add_child(pause_panel)
	var pbox := VBoxContainer.new()
	pbox.add_theme_constant_override("separation", 14)
	pause_panel.add_child(pbox)
	var pt := make_label(54, Color.WHITE)
	pt.text = "PAUSED"
	pt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pbox.add_child(pt)
	var b1 := make_button("RESUME", Vector2(280, 64), 30, Color("3fc98a"))
	b1.pressed.connect(resume_game)
	pbox.add_child(b1)
	var b2 := make_button("RESTART", Vector2(280, 64), 30, Color("b45cff"))
	b2.pressed.connect(on_retry)
	pbox.add_child(b2)
	var b3 := make_button("MENU", Vector2(280, 64), 30, Color("4a86e8"))
	b3.pressed.connect(to_menu)
	pbox.add_child(b3)


func button_style(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(24)
	s.set_border_width_all(3)
	s.border_color = Color("e9d2ff")
	return s


func show_ready() -> void:
	state = State.READY
	ready_box.visible = true
	over_panel.visible = false
	pause_panel.visible = false
	pause_btn.visible = false
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	trail.clear()
	ducking = false
	dk = 0.0
	duck_ids.clear()
	jump_ids.clear()
	uy = FLOOR
	vy = 0.0
	combo = 0
	update_hud()


func to_menu() -> void:
	show_ready()


func clear_run() -> void:
	for o in obstacles:
		o["node"].queue_free()
	for it in items:
		it["node"].queue_free()
	obstacles.clear()
	items.clear()
	trail.clear()


func start_run() -> void:
	clear_run()
	speed = START_SPEED
	distance = 0.0
	score = 0
	coins = 0
	combo = 0
	combo_t = 0.0
	best_combo = 0
	uy = FLOOR
	vy = 0.0
	jumps = 0
	dk = 0.0
	last_kind = ""
	last_kind2 = ""
	spawn_gap = 700.0
	shake = 0.0
	world.position = Vector2.ZERO
	state = State.PLAYING
	ready_box.visible = false
	over_panel.visible = false
	pause_panel.visible = false
	pause_btn.visible = true
	sparks.emitting = true
	update_hud()


func on_retry() -> void:
	start_run()


func pause_game() -> void:
	if state != State.PLAYING:
		return
	state = State.PAUSED
	pause_panel.visible = true
	sparks.emitting = false
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()


func resume_game() -> void:
	if state != State.PAUSED:
		return
	state = State.PLAYING
	pause_panel.visible = false
	sparks.emitting = true


func press() -> void:
	if state == State.READY:
		start_run()
		do_jump()
	elif state == State.PLAYING:
		do_jump()


func do_jump() -> void:
	if jumps >= MAX_JUMPS:
		return
	vy = JUMP_V if jumps == 0 else JUMP_V * 0.92
	jumps += 1
	pop(Vector2(UNI_X - 20.0, uy - 6.0), 8, 0.6)


func touch_down(index: int, pos: Vector2) -> void:
	if state == State.PAUSED or state == State.DEAD:
		return
	var w := get_viewport_rect().size.x
	if state == State.PLAYING and pos.x < w * 0.3:
		duck_ids[index] = true
		ducking = true
	else:
		jump_ids[index] = true
		held = true
		press()


func touch_up(index: int) -> void:
	if duck_ids.has(index):
		duck_ids.erase(index)
		ducking = not duck_ids.is_empty()
	if jump_ids.has(index):
		jump_ids.erase(index)
		held = not jump_ids.is_empty()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_down(event.index, event.position)
		else:
			touch_up(event.index)
	elif event is InputEventKey and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_UP or event.keycode == KEY_W:
			held = event.pressed
			if event.pressed:
				press()
		elif event.keycode == KEY_DOWN or event.keycode == KEY_S:
			ducking = event.pressed
		elif event.pressed and (event.keycode == KEY_P or event.keycode == KEY_ESCAPE):
			if state == State.PLAYING:
				pause_game()
			elif state == State.PAUSED:
				resume_game()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		held = false
		ducking = false
		duck_ids.clear()
		jump_ids.clear()
		pause_game()


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	run_time += delta
	if state == State.PLAYING:
		update_play(delta)
	elif state == State.READY:
		scroll_layers(START_SPEED * 0.35 * delta)
	if state != State.PAUSED:
		scroll_clouds(delta)
	update_visuals(delta)
	fps_timer += delta
	if fps_timer >= 0.5:
		fps_timer = 0.0
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()


func update_play(delta: float) -> void:
	speed = minf(MAX_SPEED, START_SPEED + distance * 0.02)
	var dx := speed * delta
	distance += dx
	var new_score := int(distance / 10.0)
	if new_score != score:
		score = new_score
		update_hud()
	dk = move_toward(dk, 1.0 if ducking else 0.0, delta * 9.0)
	var g := GRAVITY
	if held and vy < 0.0:
		g *= HOLD_G
	elif ducking and uy < FLOOR - 1.0:
		g *= DUCK_FALL
	vy += g * delta
	uy += vy * delta
	if uy >= FLOOR:
		if vy > 300.0:
			pop(Vector2(UNI_X, FLOOR), 6, 0.5)
		uy = FLOOR
		vy = 0.0
		jumps = 0
	scroll_layers(dx)
	move_things(delta, dx)
	spawn_gap -= dx
	if spawn_gap <= 0.0:
		spawn_pattern()
	check_hits()
	update_trail(dx)
	combo_t -= delta
	if combo_t <= 0.0 and combo > 0:
		combo = 0
		update_hud()
	sparks.position = Vector2(UNI_X + TAIL_DX, uy + TAIL_DY)
	sparks.initial_velocity_min = speed * 0.6
	sparks.initial_velocity_max = speed * 1.0 + 60.0


func scroll_layers(dx: float) -> void:
	for l in layers:
		var off: float = fmod(l["off"] + dx * l["f"], l["w"])
		l["off"] = off
		var s: Sprite2D = l["node"]
		s.region_rect = Rect2(off, 0.0, WIDE, l["h"])


func scroll_clouds(delta: float) -> void:
	var base := speed if state == State.PLAYING else START_SPEED * 0.35
	for c in clouds:
		var n: Sprite2D = c["node"]
		n.position.x -= (base * c["f"] + 10.0) * delta
		if n.position.x < -380.0:
			n.position.x = get_viewport_rect().size.x + randf_range(40.0, 300.0)
			n.position.y = randf_range(40.0, 230.0)


func move_things(_delta: float, dx: float) -> void:
	for i in range(obstacles.size() - 1, -1, -1):
		var o: Dictionary = obstacles[i]
		var n: Sprite2D = o["node"]
		n.position.x -= dx * float(o["v"])
		if n.position.x < -240.0:
			n.queue_free()
			obstacles.remove_at(i)
	for i in range(items.size() - 1, -1, -1):
		var it: Dictionary = items[i]
		var n: Sprite2D = it["node"]
		n.position.x -= dx * float(it["v"])
		if n.position.x < -80.0:
			n.queue_free()
			items.remove_at(i)


func kind_weights() -> Dictionary:
	var sc := float(score)
	var d := minf(sc / 2500.0, 1.0)
	var w := {"crystal1": 0.35, "crystal2": 0.25}
	if sc > 15.0:
		w["spikes"] = 0.5
	if sc > 60.0:
		w["fire"] = 0.12
	if sc > 80.0:
		w["storm_low"] = 0.3 + 0.1 * d
		w["storm_high"] = 0.2 + 0.12 * d
	if sc > 100.0:
		w["boulder"] = 0.35
	if sc > 200.0:
		w["spin"] = 0.15
	if sc > 260.0:
		w["bird"] = 0.15
		w["wall"] = 0.33
	if sc > 350.0:
		w["pillar"] = 0.12
	if last_kind != "" and w.has(last_kind):
		w[last_kind] *= 0.15
	if last_kind2 != "" and w.has(last_kind2):
		w[last_kind2] *= 0.55
	return w


func pick_kind() -> String:
	var w := kind_weights()
	var total := 0.0
	for k in w:
		total += float(w[k])
	var r := randf() * total
	for k in w:
		r -= float(w[k])
		if r <= 0.0:
			last_kind2 = last_kind
			last_kind = k
			return k
	return "crystal1"


func spawn_pattern() -> void:
	var x := get_viewport_rect().size.x + 140.0
	var r := randf()
	var extra := 0.0
	if r < 0.55:
		var k := pick_kind()
		add_obstacle(k, x)
		coins_for(k, x)
	elif r < 0.82 and score > 40:
		var k1 := pick_kind()
		var k2 := pick_kind()
		add_obstacle(k1, x)
		add_obstacle(k2, x + 330.0)
		coins_for(k1, x)
		coins_for(k2, x + 330.0)
		extra = 330.0
	else:
		add_coin_line(x, 8, FLOOR - 70.0 - randf() * 90.0)
	spawn_gap = speed * randf_range(0.95, 1.4) + 300.0 + extra


func coins_for(kind: String, x: float) -> void:
	var v: float = KINDS[kind]["v"]
	match kind:
		"boulder":
			pass
		"wall", "pillar":
			add_coin_arc(x, 5, 230.0, v)
		"bird", "storm_low", "storm_high":
			add_coin_line(x - 60.0, 3, FLOOR - 40.0, v)
		_:
			add_coin_arc(x, 5, 150.0, v)


func add_obstacle(kind: String, x: float) -> void:
	var info: Dictionary = KINDS[kind]
	var s := Sprite2D.new()
	var tex: Texture2D = get_tex("res://art/obs_%s.png" % info["sheet"])
	s.texture = tex
	s.hframes = int(tex.get_width() / FR)
	s.frame = 0
	s.centered = false
	s.offset = Vector2(-192, -FEET)
	s.scale = Vector2(UNI_SCALE, UNI_SCALE)
	s.position = Vector2(x, FLOOR - float(info["lift"]) * S)
	world.add_child(s)
	world.move_child(s, uni.get_index())
	obstacles.append({"node": s, "kind": kind, "v": info["v"], "n": info["n"], "fps": info["fps"], "ph": randf() * 4.0, "nm": false, "passed": false})


func add_coin(x: float, y: float, v: float = 1.0) -> void:
	var s := Sprite2D.new()
	s.texture = get_tex("res://art/coin.png")
	s.scale = Vector2(0.3, 0.3)
	s.position = Vector2(x, y)
	world.add_child(s)
	items.append({"node": s, "ph": randf() * 6.28, "y": y, "v": v})


func add_coin_arc(cx: float, count: int, height: float, v: float = 1.0) -> void:
	for i in count:
		var t := float(i) / float(count - 1)
		add_coin(cx - 120.0 + t * 240.0, FLOOR - 50.0 - sin(t * PI) * height, v)


func add_coin_line(x: float, count: int, y: float, v: float = 1.0) -> void:
	for i in count:
		add_coin(x + i * 62.0, y, v)


func player_rect() -> Rect2:
	var top := uy - lerpf(42.0, 22.0, dk) * S
	var bottom := uy - 7.0 * S
	return Rect2(UNI_X - 11.0 * S, top, 22.0 * S, bottom - top)


func check_hits() -> void:
	var ur := player_rect()
	for o in obstacles:
		var n: Sprite2D = o["node"]
		var hit := false
		var near := false
		for b in KINDS[o["kind"]]["boxes"]:
			var orect := Rect2(n.position.x + float(b[0]) * S, FLOOR - float(b[3]) * S, (float(b[1]) - float(b[0])) * S, (float(b[3]) - float(b[2])) * S)
			if ur.intersects(orect):
				hit = true
			else:
				var gx := maxf(orect.position.x - ur.end.x, ur.position.x - orect.end.x)
				var gy := maxf(orect.position.y - ur.end.y, ur.position.y - orect.end.y)
				if gx < 0.0 and gy >= 0.0 and gy < 14.0:
					near = true
		if hit:
			die()
			return
		if near:
			o["nm"] = true
		if not o["passed"] and n.position.x < UNI_X - 60.0:
			o["passed"] = true
			if o["nm"]:
				add_combo(2)
				pop(Vector2(UNI_X + 30.0, uy - 70.0), 6, 0.5)
	var center := Vector2(UNI_X, uy - 58.0 + dk * 20.0)
	for i in range(items.size() - 1, -1, -1):
		var n: Sprite2D = items[i]["node"]
		if n.position.distance_to(center) < 56.0:
			pop(n.position, 10, 1.0)
			n.queue_free()
			items.remove_at(i)
			coins += 1
			add_combo(1)
			update_hud()


func add_combo(n: int) -> void:
	combo += n
	combo_t = 1.6
	best_combo = maxi(best_combo, combo)
	if combo >= 4:
		distance += 3.0 * float(n) * 10.0
	update_hud()


func die() -> void:
	state = State.DEAD
	shake = 18.0
	sparks.emitting = false
	held = false
	ducking = false
	duck_ids.clear()
	jump_ids.clear()
	pause_btn.visible = false
	combo_label.visible = false
	if score > best:
		best = score
		save_best()
	over_score.text = "Score  %d" % score
	over_best.text = "Best  %d     Coins  %d     Combo  x%d" % [best, coins, best_combo]
	over_panel.visible = true
	pop(Vector2(UNI_X, uy - 50.0), 18, 1.4)


func update_trail(dx: float) -> void:
	for i in trail.size():
		trail[i] = Vector2(trail[i].x - dx, trail[i].y)
	var anchor_x := UNI_X + TAIL_DX
	trail.append(Vector2(anchor_x, uy + TAIL_DY + dk * 14.0))
	while trail.size() > 0 and trail[0].x < anchor_x - TRAIL_LEN:
		trail.remove_at(0)
	var n := trail.size()
	for k in 6:
		var pts := PackedVector2Array()
		for i in n:
			var p := trail[i]
			var age := 1.0 - float(i) / float(maxi(n - 1, 1))
			var wave := sin(p.x * 0.028 + run_time * 9.0) * 7.0 * age
			pts.append(Vector2(p.x, p.y + (float(k) - 2.5) * 6.4 + wave))
		lines[k].points = pts


func update_visuals(delta: float) -> void:
	uni.position = Vector2(UNI_X, uy)
	if state == State.PLAYING:
		if uy < FLOOR - 1.0:
			if uni.animation != "jump":
				uni.play("jump")
		elif dk > 0.5:
			if uni.animation != "duck" or not uni.is_playing():
				uni.play("duck")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
		else:
			if uni.animation != "run" or not uni.is_playing():
				uni.play("run")
			uni.speed_scale = clampf(speed / START_SPEED, 0.9, 2.3)
	elif state == State.DEAD:
		if uni.animation != "dead":
			uni.play("dead")
	elif state == State.READY:
		if uni.animation != "run" or not uni.is_playing():
			uni.play("run")
		uni.speed_scale = 0.6
		if lines.size() > 0:
			for ln in lines:
				ln.points = PackedVector2Array()
	if state == State.PAUSED:
		uni.pause()
	if state != State.PAUSED:
		for o in obstacles:
			var n: Sprite2D = o["node"]
			if int(o["n"]) > 1:
				n.frame = int((run_time + float(o["ph"])) * float(o["fps"])) % int(o["n"])
			var bob := 0.0
			var k: String = o["kind"]
			if k == "bird" or k == "storm_low" or k == "storm_high":
				bob = sin(run_time * 3.2 + float(o["ph"]) * 2.0) * 4.0
			n.position.y = FLOOR - float(KINDS[k]["lift"]) * S + bob
		for it in items:
			var n: Sprite2D = it["node"]
			n.scale.x = 0.3 * absf(cos(run_time * 5.0 + it["ph"])) + 0.05
			n.position.y = float(it["y"]) + sin(run_time * 4.0 + it["ph"]) * 5.0
	if shake > 0.2:
		shake = lerpf(shake, 0.0, minf(1.0, delta * 9.0))
		world.position = Vector2(randf_range(-shake, shake), randf_range(-shake, shake))
	else:
		world.position = Vector2.ZERO
	if state == State.READY:
		ready_label.modulate.a = 0.55 + 0.45 * absf(sin(run_time * 3.0))


func update_hud() -> void:
	score_label.text = "%d" % score
	coin_label.text = "%d" % coins
	var playing := state != State.READY
	score_label.visible = playing
	coin_label.visible = playing
	combo_label.visible = playing and combo >= 2
	combo_label.text = "COMBO x%d" % combo


func pop(pos: Vector2, count: int, power: float) -> void:
	var p := CPUParticles2D.new()
	p.texture = get_tex("res://art/spark.png")
	p.position = pos
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = count
	p.lifetime = 0.6
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 80.0 * power
	p.initial_velocity_max = 220.0 * power
	p.scale_amount_min = 0.2
	p.scale_amount_max = 0.5
	var cg := Gradient.new()
	cg.colors = PackedColorArray([Color(1, 0.95, 0.6, 1), Color(1, 0.6, 1, 0)])
	p.color_ramp = cg
	world.add_child(p)
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func load_best() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save.cfg") == OK:
		best = int(cf.get_value("run", "best", 0))


func save_best() -> void:
	var cf := ConfigFile.new()
	cf.set_value("run", "best", best)
	cf.save("user://save.cfg")
