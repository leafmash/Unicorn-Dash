extends Control

signal action(key: String)
signal built(list: Array)

const Cp := preload("res://cp_kit.gd")
const U := 1.6

var m
var buttons: Array = []
var scrim: TextureRect
var scrim_grad: Gradient
var scrim_tw: Tween = null
var layer: Control
var ready_root: Control = null
var toast_box: Control
var toast_tw: Tween = null
var current := ""
var revive_t := 0.0
var revive_ring: Control = null
var revive_frac := 1.0


func setup(main: Node) -> void:
	m = main
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	scrim_grad = Gradient.new()
	scrim_grad.colors = PackedColorArray([Color("140a3399"), Color("1a0e3db3")])
	var gt := GradientTexture2D.new()
	gt.gradient = scrim_grad
	gt.fill_from = Vector2(0.0, 0.0)
	gt.fill_to = Vector2(0.0, 1.0)
	gt.width = 8
	gt.height = 128
	scrim = TextureRect.new()
	scrim.texture = gt
	scrim.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	scrim.stretch_mode = TextureRect.STRETCH_SCALE
	scrim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scrim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scrim.modulate.a = 0.0
	scrim.visible = false
	add_child(scrim)
	layer = Control.new()
	layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(layer)
	toast_box = Control.new()
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.modulate.a = 0.0
	add_child(toast_box)


func d(v: float) -> float:
	return v * U


func emit_action(key: String) -> void:
	action.emit(key)


func _process(delta: float) -> void:
	if current == "revive":
		revive_t -= delta
		revive_frac = clampf(revive_t / 5.0, 0.0, 1.0)
		if revive_ring != null:
			revive_ring.queue_redraw()
		if revive_t <= 0.0:
			current = ""
			emit_action("skip")


func set_scrim(tone: int, dim: float) -> void:
	if tone == 2:
		scrim_grad.colors = PackedColorArray([Color("0e0626e6"), Color("1a0e3df2")])
	elif tone == 3:
		scrim_grad.colors = PackedColorArray([Color("140a33cc"), Color("1a0e3de6")])
	else:
		scrim_grad.colors = PackedColorArray([Color("140a3399"), Color("1a0e3db3")])
	scrim.visible = true
	if scrim_tw != null and scrim_tw.is_valid():
		scrim_tw.kill()
	scrim_tw = scrim.create_tween()
	scrim_tw.tween_property(scrim, "modulate:a", dim, 0.3)


func clear_layer() -> void:
	for c in layer.get_children():
		layer.remove_child(c)
		c.queue_free()
	buttons.clear()
	revive_ring = null


func hide_all() -> void:
	current = ""
	clear_layer()
	if scrim_tw != null and scrim_tw.is_valid():
		scrim_tw.kill()
	scrim.modulate.a = 0.0
	scrim.visible = false
	hide_ready()


func open_dialog(root: Control, kind: String, tone: int, dim: float) -> void:
	hide_ready()
	var keep: Array = buttons.duplicate()
	clear_layer()
	buttons.append_array(keep)
	current = kind
	layer.add_child(root)
	root.position = ((size - root.size) * 0.5).round()
	set_scrim(tone, dim)
	Cp.pop_in(root)
	built.emit(buttons)


func shell(w_dp: float, h_dp: float) -> Control:
	var w := minf(d(w_dp), size.x - d(24.0))
	return Cp.glass(Vector2(w, d(h_dp)), 28.0)


func add_title(root: Control, text: String, sp: float, y_dp: float) -> float:
	var s := sp
	while s > 14.0 and Cp.text_w(text, s) > root.size.x - d(36.0):
		s -= 1.0
	var t := Cp.grad_title(text, s)
	t.position = Vector2((root.size.x - t.size.x) * 0.5, d(y_dp))
	root.add_child(t)
	return t.size.y


func add_text(root: Control, text: String, sp: float, col: Color, y: float, shadow: bool = true) -> Label:
	var l := Cp.label(text, sp, col, shadow)
	Cp.place(l, d(12.0), y, root.size.x - d(24.0), d(sp * 1.35), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(l, root.size.x - d(24.0))
	l.custom_minimum_size.x = 0.0
	root.add_child(l)
	return l


func add_btn(root: Control, text: String, x: float, y: float, w: float, h_dp: float, kind: String, sp: float, key: String, o: Dictionary = {}) -> Button:
	var b := Cp.g_button(text, w, h_dp, kind, sp, o)
	b.position = Vector2(x, y)
	b.pressed.connect(emit_action.bind(key))
	root.add_child(b)
	buttons.append(b)
	return b


func add_stat(root: Control, head: String, value: String, col: Color, x: float, y: float, w: float, h: float) -> void:
	var bg := Cp.shape(Vector2(w, h), d(14.0), {"top": Color(1.0, 1.0, 1.0, 0.09)})
	bg.position = Vector2(x, y)
	root.add_child(bg)
	var hl := Cp.label(head, 9.5, Color("bfb2ec"), false)
	Cp.place(hl, 0.0, d(6.0), w, d(14.0), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(hl, w - d(8.0))
	hl.custom_minimum_size.x = 0.0
	bg.add_child(hl)
	var vl := Cp.label(value, 17.0, col)
	Cp.place(vl, 0.0, d(20.0), w, d(26.0), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(vl, w - d(8.0))
	vl.custom_minimum_size.x = 0.0
	bg.add_child(vl)


func add_xp_row(root: Control, x: float, y: float, w: float, text: String, frac: float) -> void:
	var l := Cp.label(text, 10.5, Cp.LILAC, false)
	Cp.place(l, x, y, w, d(14.0))
	root.add_child(l)
	var b := Cp.bar(Vector2(w, d(6.0)), Color("ffe27a"), Color("ffb000"))
	b.position = Vector2(x, y + d(18.0))
	root.add_child(b)
	var tw := b.create_tween()
	tw.tween_interval(0.45)
	tw.tween_callback(fill_bar.bind(b, frac))


func fill_bar(b: Control, frac: float) -> void:
	if is_instance_valid(b):
		Cp.bar_set(b, frac, true)


func set_count(v: float, l: Label, suffix: String) -> void:
	l.text = "%d%s" % [int(v), suffix]


func add_count(root: Control, target: int, suffix: String, sp: float, y: float) -> void:
	var l := Cp.label("0" + suffix, sp, Color.WHITE)
	Cp.place(l, 0.0, y, root.size.x, d(sp * 1.3), HORIZONTAL_ALIGNMENT_CENTER)
	l.custom_minimum_size.x = 0.0
	root.add_child(l)
	var tw := l.create_tween()
	tw.tween_interval(0.15)
	tw.tween_method(set_count.bind(l, suffix), 0.0, float(target), 1.0).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


func hs(i: float) -> float:
	return fposmod(sin(i * 12.9898) * 43758.5453, 1.0)


func draw_confetti(c: Control) -> void:
	var p: float = c.get_meta("p")
	if p >= 1.0:
		return
	var w := c.size.x
	var h := c.size.y
	var cx := w * 0.5
	var cy := h * 0.42
	for i in 46:
		var fi := float(i)
		var a := hs(fi) * TAU
		var sp := 0.35 + hs(fi + 90.0) * 0.9
		var vx := cos(a) * sp * w * 0.5
		var vy := sin(a) * sp * h * 0.5 - h * 0.25
		var px := cx + vx * p
		var py := cy + vy * p + h * 0.9 * p * p
		var col := Color.from_hsv(hs(fi + 33.0), 0.62, 1.0)
		col.a = clampf(1.0 - p, 0.0, 1.0)
		c.draw_circle(Vector2(px, py), (3.0 + hs(fi + 7.0) * 4.0) * U, col)


func set_confetti(v: float, c: Control) -> void:
	if not is_instance_valid(c):
		return
	c.set_meta("p", v)
	c.queue_redraw()


func add_confetti() -> void:
	var c := Control.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.set_meta("p", 0.0)
	c.draw.connect(draw_confetti.bind(c))
	layer.add_child(c)
	var tw := c.create_tween()
	tw.tween_method(set_confetti.bind(c), 0.0, 1.0, 2.6).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_callback(c.queue_free)


func set_star(t: float, star: Control, glow: Control) -> void:
	if not is_instance_valid(star):
		return
	var v := Cp.spring(t, 0.34, 260.0)
	star.scale = Vector2(v, v)
	star.rotation = deg_to_rad((1.0 - v) * -50.0)
	star.modulate.a = clampf(v, 0.0, 1.0)
	glow.modulate.a = clampf(v, 0.0, 1.0) * 0.7


func make_star(index: int, on: bool, label: String) -> Control:
	var sw := d(70.0)
	var root := Control.new()
	root.size = Vector2(sw, d(76.0))
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var base := Cp.icon("star_off", 48.0)
	base.position = Vector2((sw - base.size.x) * 0.5, d(5.0))
	root.add_child(base)
	if on:
		var glow := Cp.pulse_glow(Cp.GOLD, 34.0)
		glow.position = Vector2((sw - glow.size.x) * 0.5, d(29.0) - glow.size.y * 0.5)
		glow.modulate.a = 0.0
		root.add_child(glow)
		var star := Cp.icon("star_on", 52.0)
		star.position = Vector2((sw - star.size.x) * 0.5, d(3.0))
		star.pivot_offset = star.size * 0.5
		star.scale = Vector2.ZERO
		star.modulate.a = 0.0
		root.add_child(star)
		var tw := root.create_tween()
		tw.tween_interval(0.45 + float(index) * 0.42)
		tw.tween_callback(m.play_sfx.bind("star"))
		tw.tween_method(set_star.bind(star, glow), 0.0, 1.2, 1.2)
	var lb := Cp.label(label, 10.5, Cp.MINT if on else Cp.DIM, false)
	Cp.place(lb, 0.0, d(58.0), sw, d(16.0), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(lb, sw)
	lb.custom_minimum_size.x = 0.0
	root.add_child(lb)
	return root


func track_colors(on: bool) -> Array:
	if on:
		return [Color("ff8fdc"), Color("b45cff"), Color("8b45ee")]
	return [Color(1.0, 1.0, 1.0, 0.25), Color(1.0, 1.0, 1.0, 0.22), Color(1.0, 1.0, 1.0, 0.19)]


func paint_track(track: Control, on: bool) -> void:
	var cols := track_colors(on)
	var mat: ShaderMaterial = track.material
	mat.set_shader_parameter("c_top", cols[0])
	mat.set_shader_parameter("c_mid", cols[1])
	mat.set_shader_parameter("c_bot", cols[2])


func set_knob(t: float, knob: Control, from_x: float, to_x: float) -> void:
	if not is_instance_valid(knob):
		return
	knob.position.x = from_x + (to_x - from_x) * clampf(Cp.spring(t, 0.6, 500.0), 0.0, 1.2)


func on_toggle(key: String, track: Control, knob: Control, btn: Button) -> void:
	var on := not bool(btn.get_meta("on"))
	btn.set_meta("on", on)
	paint_track(track, on)
	var off_x := d(3.0)
	var on_x := d(3.0) + d(20.0)
	var tw := knob.create_tween()
	tw.tween_method(set_knob.bind(knob, on_x if not on else off_x, on_x if on else off_x), 0.0, 0.6, 0.6)
	emit_action(key)


func add_toggle(root: Control, text: String, on: bool, x: float, y: float, w: float, key: String) -> void:
	var h := d(42.0)
	var row := Cp.shape(Vector2(w, h), d(14.0), {"top": Color(1.0, 1.0, 1.0, 0.08)})
	row.position = Vector2(x, y)
	root.add_child(row)
	var l := Cp.label(text, 14.0, Color.WHITE)
	Cp.place(l, d(14.0), 0.0, w - d(86.0), h)
	Cp.fit(l, w - d(86.0))
	l.custom_minimum_size.x = 0.0
	row.add_child(l)
	var sw_w := d(46.0)
	var sw_h := d(26.0)
	var cols := track_colors(on)
	var track := Cp.shape(Vector2(sw_w, sw_h), sw_h * 0.5, {"top": cols[0], "mid": cols[1], "bot": cols[2]})
	track.position = Vector2(w - d(14.0) - sw_w, (h - sw_h) * 0.5)
	row.add_child(track)
	var knob := Cp.shape(Vector2(d(20.0), d(20.0)), d(10.0), {"top": Color.WHITE})
	knob.position = Vector2(d(3.0) + (d(20.0) if on else 0.0), d(3.0))
	track.add_child(knob)
	var btn := Cp.flat_button(Vector2(w, h))
	btn.set_meta("punch_node", row)
	btn.set_meta("on", on)
	btn.pressed.connect(on_toggle.bind(key, track, knob, btn))
	row.add_child(btn)
	buttons.append(btn)


func show_pause() -> void:
	var root := shell(320.0, 290.0)
	var pad := d(22.0)
	var iw := root.size.x - pad * 2.0
	var y := d(16.0)
	y += add_title(root, m.T("PAUSED"), 30.0, 16.0) + d(10.0)
	add_btn(root, m.T("RESUME"), pad, y, iw, 48.0, "primary", 16.0, "resume", {"lead": "play", "lead_dp": 18.0})
	y += d(48.0) + d(10.0)
	var hw := (iw - d(10.0)) * 0.5
	add_btn(root, m.T("RESTART"), pad, y, hw, 38.0, "soft", 13.0, "restart")
	add_btn(root, m.T("MENU"), pad + hw + d(10.0), y, hw, 38.0, "soft", 13.0, "menu")
	y += d(38.0) + d(10.0)
	add_toggle(root, m.T("Music"), m.mus_on, pad, y, iw, "tmusic")
	y += d(42.0) + d(10.0)
	add_toggle(root, m.T("Sound effects"), m.snd_on, pad, y, iw, "tsfx")
	open_dialog(root, "pause", 1, 1.0)


func show_over(o: Dictionary) -> void:
	var root := shell(460.0, 300.0)
	var pad := d(20.0)
	var iw := root.size.x - pad * 2.0
	var level_mode: bool = bool(o.get("level_mode", false))
	var new_best: bool = bool(o.get("new_best", false))
	var title: String = m.T("LEVEL FAILED") if level_mode else (m.T("NEW BEST!") if new_best else m.T("GAME OVER"))
	var y := d(14.0)
	y += add_title(root, title, 28.0, 14.0) + d(4.0)
	if level_mode:
		add_count(root, int(o.get("pct", 0)), "%", 46.0, y)
	else:
		add_count(root, int(o.get("score", 0)), "", 46.0, y)
	y += d(60.0)
	add_text(root, String(o.get("sub", "")), 12.0, Cp.LILAC, y, false)
	y += d(22.0)
	var gap := d(8.0)
	var sw := (iw - gap * 2.0) / 3.0
	var stats: Array = o.get("stats", [])
	for i in stats.size():
		var st: Array = stats[i]
		add_stat(root, String(st[0]), String(st[1]), st[2], pad + float(i) * (sw + gap), y, sw, d(50.0))
	y += d(50.0) + d(8.0)
	add_xp_row(root, pad, y, iw, String(o.get("xp_text", "")), float(o.get("xp_frac", 0.0)))
	y += d(26.0) + d(10.0)
	var hw := (iw - d(10.0)) * 0.5
	add_btn(root, m.T("RETRY"), pad, y, hw, 44.0, "primary", 16.0, "restart", {"lead": "loop", "lead_dp": 18.0})
	add_btn(root, String(o.get("nav_text", m.T("MENU"))), pad + hw + d(10.0), y, hw, 44.0, "soft", 16.0, String(o.get("nav_key", "menu")))
	open_dialog(root, "over", 1, 0.9)
	if new_best and not level_mode:
		add_confetti()


func show_complete(o: Dictionary) -> void:
	var root := shell(480.0, 322.0)
	var pad := d(20.0)
	var iw := root.size.x - pad * 2.0
	var y := d(14.0)
	y += add_title(root, String(o.get("title", m.T("LEVEL COMPLETE"))), 26.0, 14.0) + d(6.0)
	var stars: Array = o.get("stars", [true, false, false])
	var labels: Array = [m.T("Finish"), m.T("%d%% pickups") % 60, m.T("%d%% pickups") % 90]
	var gap := d(14.0)
	var sw := d(70.0)
	var total := sw * 3.0 + gap * 2.0
	var sx := (root.size.x - total) * 0.5
	for i in 3:
		var sc := make_star(i, bool(stars[i]), String(labels[i]))
		sc.position = Vector2(sx + float(i) * (sw + gap), y)
		root.add_child(sc)
	y += d(78.0) + d(4.0)
	var g2 := d(8.0)
	var sw2 := (iw - g2 * 2.0) / 3.0
	var stats: Array = o.get("stats", [])
	for i in stats.size():
		var st: Array = stats[i]
		add_stat(root, String(st[0]), String(st[1]), st[2], pad + float(i) * (sw2 + g2), y, sw2, d(50.0))
	y += d(50.0) + d(8.0)
	add_xp_row(root, pad, y, iw, String(o.get("xp_text", "")), float(o.get("xp_frac", 0.0)))
	y += d(26.0)
	var note := String(o.get("note", ""))
	if note != "":
		add_text(root, note, 11.5, Cp.SUN, y, false)
	y += d(20.0)
	var daily: bool = bool(o.get("daily", false))
	var has_next: bool = bool(o.get("has_next", false))
	if daily:
		var hw := (iw - d(10.0)) * 0.5
		add_btn(root, m.T("RETRY"), pad, y, hw, 44.0, "soft", 16.0, "restart")
		add_btn(root, m.T("MENU"), pad + hw + d(10.0), y, hw, 44.0, "primary", 16.0, "menu")
	elif has_next:
		var unit := (iw - d(20.0)) / 3.2
		add_btn(root, m.T("RETRY"), pad, y, unit, 42.0, "soft", 14.0, "restart")
		add_btn(root, m.T("NEXT"), pad + unit + d(10.0), y, unit * 1.2, 44.0, "primary", 16.0, "next", {"lead": "play", "lead_dp": 16.0})
		add_btn(root, m.T("LEVELS"), pad + unit * 2.2 + d(20.0), y, unit, 42.0, "soft", 14.0, "lvls")
	else:
		var hw2 := (iw - d(10.0)) * 0.5
		add_btn(root, m.T("RETRY"), pad, y, hw2, 44.0, "soft", 16.0, "restart")
		add_btn(root, m.T("LEVELS"), pad + hw2 + d(10.0), y, hw2, 44.0, "primary", 16.0, "lvls")
	open_dialog(root, "complete", 3, 0.88)
	add_confetti()


func show_unlock(z: int) -> void:
	var zd: Dictionary = m.ZONES[z]
	var root := shell(340.0, 250.0)
	var y := d(16.0)
	y += add_title(root, m.T("ZONE UNLOCKED"), 26.0, 16.0) + d(10.0)
	var pw := d(150.0)
	var ph := d(84.0)
	var holder := Control.new()
	holder.size = Vector2(pw, ph)
	holder.position = Vector2((root.size.x - pw) * 0.5, y)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(holder)
	var sky_c: Color = m.hc(zd["sky"][1])
	var glow := Cp.pulse_glow(sky_c, 90.0)
	glow.position = Vector2((pw - glow.size.x) * 0.5, (ph - glow.size.y) * 0.5)
	holder.add_child(glow)
	var art := Control.new()
	art.size = Vector2(pw, ph)
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var amat := ShaderMaterial.new()
	amat.shader = m.cp_zones.round_shader()
	amat.set_shader_parameter("size", art.size)
	amat.set_shader_parameter("radius", d(16.0))
	art.material = amat
	art.draw.connect(m.cp_zones.draw_preview.bind(art, zd))
	holder.add_child(art)
	var rim_c := Color(1.0, 1.0, 1.0, 0.85)
	var rim := Cp.shape(Vector2(pw, ph), d(16.0), {"top": Color(1.0, 1.0, 1.0, 0.0), "rim_t": rim_c, "rim_b": rim_c, "rim_w": d(2.0)})
	holder.add_child(rim)
	y += ph + d(10.0)
	add_text(root, m.T(String(zd["name"])), 20.0, Color.WHITE, y)
	y += d(32.0)
	var bw := d(180.0)
	add_btn(root, m.T("CONTINUE"), (root.size.x - bw) * 0.5, y, bw, 44.0, "gold", 16.0, "cont")
	open_dialog(root, "unlock", 3, 1.0)
	add_confetti()


func draw_revive() -> void:
	var c := revive_ring.size * 0.5
	var r := revive_ring.size.x * 0.5 - d(3.0)
	revive_ring.draw_arc(c, r, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, 0.16), d(6.0), true)
	if revive_frac > 0.005:
		revive_ring.draw_arc(c, r, -PI * 0.5, -PI * 0.5 + TAU * revive_frac, 48, Cp.HEART, d(6.0), true)


func set_pulse(t: float, n: Control) -> void:
	if not is_instance_valid(n):
		return
	var s := 0.94 + 0.14 * Cp.reverse_wave(t, 0.55)
	n.scale = Vector2(s, s)


func show_revive(o: Dictionary) -> void:
	var root := shell(330.0, 300.0)
	var pad := d(22.0)
	var iw := root.size.x - pad * 2.0
	var y := d(14.0)
	y += add_title(root, m.T("REVIVE?"), 28.0, 14.0) + d(6.0)
	var rs := d(92.0)
	revive_ring = Control.new()
	revive_ring.size = Vector2(rs, rs)
	revive_ring.pivot_offset = Vector2(rs, rs) * 0.5
	revive_ring.position = Vector2((root.size.x - rs) * 0.5, y)
	revive_ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	revive_ring.draw.connect(draw_revive)
	root.add_child(revive_ring)
	var hi := Cp.icon("heart", 54.0)
	hi.position = (Vector2(rs, rs) - hi.size) * 0.5
	revive_ring.add_child(hi)
	var ptw := revive_ring.create_tween().set_loops()
	ptw.tween_method(set_pulse.bind(revive_ring), 0.0, 1.1, 1.1)
	y += rs + d(10.0)
	var info: String = m.T("Hearts %d   Cost %d") % [int(o.get("hearts", 0)), int(o.get("cost", 0))]
	add_text(root, info, 12.5, Color("ffd0e0"), y, false)
	y += d(24.0)
	add_btn(root, m.T("REVIVE"), pad, y, iw, 46.0, "gold", 16.0, "revive", {"heart": true})
	y += d(46.0) + d(8.0)
	var nw := d(150.0)
	add_btn(root, m.T("NO THANKS"), (root.size.x - nw) * 0.5, y, nw, 34.0, "soft", 13.0, "skip")
	revive_t = 5.0
	revive_frac = 1.0
	open_dialog(root, "revive", 1, 0.7)
	current = "revive"


func show_ready(title: String, sub: String) -> void:
	hide_ready()
	ready_root = Control.new()
	ready_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ready_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ready_root)
	move_child(ready_root, 0)
	var bk := Cp.round_btn(40.0, "back", 20.0)
	bk.position = Vector2(d(14.0), d(10.0))
	bk.pressed.connect(emit_action.bind("back"))
	ready_root.add_child(bk)
	var bl: Array = [bk]
	var sp := 40.0
	while sp > 18.0 and Cp.text_w(title, sp) > size.x - d(40.0):
		sp -= 1.0
	var tt := Cp.grad_title(title, sp)
	tt.position = Vector2((size.x - tt.size.x) * 0.5, d(52.0))
	ready_root.add_child(tt)
	Cp.pop_in(tt)
	var sl := Cp.label(sub, 14.0, Color("c9b8ff"))
	Cp.place(sl, 0.0, d(52.0) + tt.size.y + d(2.0), size.x, d(22.0), HORIZONTAL_ALIGNMENT_CENTER)
	ready_root.add_child(sl)
	var txt: String = m.T("TAP TO RUN")
	var gw := Cp.text_w(txt, 20.0) + d(44.0)
	var g := Cp.glass(Vector2(gw, d(44.0)), 22.0)
	g.position = Vector2((size.x - gw) * 0.5, d(52.0) + tt.size.y + d(40.0))
	g.pivot_offset = g.size * 0.5
	ready_root.add_child(g)
	var gl := Cp.label(txt, 20.0, Cp.SUN)
	Cp.place(gl, 0.0, 0.0, gw, d(44.0), HORIZONTAL_ALIGNMENT_CENTER)
	g.add_child(gl)
	var rtw := g.create_tween().set_loops()
	rtw.tween_method(set_pulse.bind(g), 0.0, 1.1, 1.1)
	var h1 := make_hint(m.T("HOLD TO DUCK"))
	h1.position = Vector2(d(14.0), size.y - d(6.0) - h1.size.y)
	ready_root.add_child(h1)
	var h2 := make_hint(m.T("TAP TO JUMP"))
	h2.position = Vector2(size.x - d(14.0) - h2.size.x, size.y - d(6.0) - h2.size.y)
	ready_root.add_child(h2)
	built.emit(bl)
	ready_root.modulate.a = 0.0
	var ftw := ready_root.create_tween()
	ftw.tween_property(ready_root, "modulate:a", 1.0, 0.22)


func make_hint(text: String) -> Control:
	var w := Cp.text_w(text, 12.0) + d(28.0)
	var g := Cp.glass(Vector2(w, d(30.0)), 14.0)
	var l := Cp.label(text, 12.0, Color.WHITE)
	Cp.place(l, 0.0, 0.0, w, d(30.0), HORIZONTAL_ALIGNMENT_CENTER)
	g.add_child(l)
	return g


func hide_ready() -> void:
	if ready_root != null and is_instance_valid(ready_root):
		remove_child(ready_root)
		ready_root.queue_free()
	ready_root = null


func show_toast(text: String, top_px: float) -> void:
	if toast_tw != null and toast_tw.is_valid():
		toast_tw.kill()
	for c in toast_box.get_children():
		toast_box.remove_child(c)
		c.queue_free()
	var w := minf(Cp.text_w(text, 14.0) + d(36.0), size.x - d(24.0))
	var g := Cp.glass(Vector2(w, d(34.0)), 18.0)
	toast_box.add_child(g)
	var l := Cp.label(text, 14.0, Color.WHITE)
	Cp.place(l, d(8.0), 0.0, w - d(16.0), d(34.0), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(l, w - d(16.0))
	l.custom_minimum_size.x = 0.0
	g.add_child(l)
	toast_box.position = Vector2((size.x - w) * 0.5, top_px - d(12.0))
	toast_box.modulate.a = 0.0
	toast_tw = toast_box.create_tween()
	toast_tw.set_parallel(true)
	toast_tw.tween_property(toast_box, "modulate:a", 1.0, 0.18)
	toast_tw.tween_property(toast_box, "position:y", top_px, 0.25).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	toast_tw.chain().tween_interval(1.3)
	toast_tw.chain().tween_property(toast_box, "modulate:a", 0.0, 0.35)
