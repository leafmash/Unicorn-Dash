extends Control

signal finished

const Cp := preload("res://cp_kit.gd")
const BANDS: Array = ["ff6b9d", "ffb86b", "ffe27a", "7dffd4", "6bc4ff", "9a5cff"]
const SKY: Array = ["140a33", "3b1f7a", "b0509f"]
const LOAD_TIME := 1.7
const HOLD_TIME := 2.1
const FADE_TIME := 0.45

var clock := 0.0
var prog := 0.0
var stars: Array = []
var bar: Control
var built_w := 0.0
var built_h := 0.0
var title_text := ""
var load_text := ""
var tip_text := ""


func setup(t_title: String, t_loading: String, t_tip: String) -> void:
	title_text = t_title
	load_text = t_loading
	tip_text = t_tip
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	for i in 54:
		stars.append([rng.randf(), rng.randf() * 0.75, 0.8 + rng.randf() * 1.8, rng.randf()])
	resized.connect(build)


func build() -> void:
	if size.x < 100.0:
		return
	if is_equal_approx(size.x, built_w) and is_equal_approx(size.y, built_h):
		return
	built_w = size.x
	built_h = size.y
	for c in get_children():
		remove_child(c)
		c.queue_free()
	var w := size.x
	var h := size.y
	var sp := 38.0
	while Cp.text_w(title_text, sp) > w - Cp.dp(40.0) and sp > 19.0:
		sp *= 0.92
	var title := Cp.grad_title(title_text, sp)
	title.position = Vector2((w - title.size.x) * 0.5, h * 0.53 - Cp.dp(4.0))
	add_child(title)
	var by := title.position.y + title.size.y * 0.8 + Cp.dp(10.0)
	bar = Cp.bar(Vector2(Cp.dp(240.0), Cp.dp(8.0)))
	bar.position = Vector2((w - bar.size.x) * 0.5, by)
	add_child(bar)
	Cp.bar_set(bar, prog, false)
	var sub := Cp.label(load_text, 11.0, Cp.LILAC, false)
	Cp.place(sub, 0.0, by + Cp.dp(14.0), w, Cp.dp(18.0), HORIZONTAL_ALIGNMENT_CENTER)
	add_child(sub)
	var tip := Cp.label(tip_text, 10.5, Cp.DIM, false)
	Cp.place(tip, 0.0, by + Cp.dp(34.0), w, Cp.dp(18.0), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(tip, w - Cp.dp(40.0))
	add_child(tip)


func _process(delta: float) -> void:
	clock += delta
	prog = Cp.fast_out_slow_in(clampf(clock / LOAD_TIME, 0.0, 1.0))
	if bar != null:
		Cp.bar_set(bar, prog, false)
	if clock > HOLD_TIME:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		var k := (clock - HOLD_TIME) / FADE_TIME
		modulate.a = clampf(1.0 - k, 0.0, 1.0)
		if k >= 1.0:
			finished.emit()
			set_process(false)
			queue_free()
			return
	queue_redraw()


func _draw() -> void:
	var w := size.x
	var h := size.y
	var c0 := Color(String(SKY[0]))
	var c1 := Color(String(SKY[1]))
	var c2 := Color(String(SKY[2]))
	draw_polygon(
		PackedVector2Array([Vector2(0.0, 0.0), Vector2(w, 0.0), Vector2(w, h * 0.5), Vector2(0.0, h * 0.5)]),
		PackedColorArray([c0, c0, c1, c1])
	)
	draw_polygon(
		PackedVector2Array([Vector2(0.0, h * 0.5), Vector2(w, h * 0.5), Vector2(w, h), Vector2(0.0, h)]),
		PackedColorArray([c1, c1, c2, c2])
	)
	var tw := fmod(clock / 1.8, 1.0)
	for s in stars:
		var a := 0.2 + 0.8 * absf(sin((tw + float(s[3])) * TAU))
		draw_circle(Vector2(float(s[0]) * w, float(s[1]) * h), float(s[2]) * Cp.U, Color(1.0, 1.0, 1.0, a))
	var center := Vector2(w * 0.5, h * 0.5)
	var r0 := minf(w * 0.3, h * 0.42)
	var sweep := PI * minf(1.0, prog * 1.2)
	if sweep <= 0.001:
		return
	var sw := Cp.dp(8.0)
	for i in BANDS.size():
		var r := r0 - i * Cp.dp(9.0)
		if r <= 0.0:
			continue
		var col := Color(String(BANDS[i]))
		draw_arc(center, r, PI, PI + sweep, 72, col, sw, true)
		draw_circle(center + Vector2(cos(PI), sin(PI)) * r, sw * 0.5, col)
		draw_circle(center + Vector2(cos(PI + sweep), sin(PI + sweep)) * r, sw * 0.5, col)
