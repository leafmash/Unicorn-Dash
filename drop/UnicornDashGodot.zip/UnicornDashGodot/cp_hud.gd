extends Control

signal action(key: String)
signal built(list: Array)

const Cp := preload("res://cp_kit.gd")
const U := 1.6
const POWER_KEYS := ["shield", "magnet", "x2", "slow"]

var m
var buttons: Array = []
var built_w := 0.0
var built_h := 0.0
var data: Dictionary = {}

var score_label: Label
var sub_label: Label
var coin_pill: Control
var coin_label: Label
var heart_pill: Control
var heart_label: Label
var prog_group: Control
var prog_bar: Control
var prog_star: Control
var pause_btn: Button
var dist_label: Label
var ring_nodes: Dictionary = {}
var combo_node: Control
var combo_label: Label
var combo_val := 0
var combo_frac := 0.0
var combo_tw: Tween = null
var banner_box: Control
var banner_tw: Tween = null
var hint_l: Control
var hint_r: Control
var hint_t := 0.0
var star_lit := false
var last_coin_text := ""
var last_heart_text := ""


func setup(main: Node) -> void:
	m = main
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(on_resized)


func d(v: float) -> float:
	return v * U


func emit_action(key: String) -> void:
	action.emit(key)


func on_resized() -> void:
	if size.x < 200.0:
		return
	if is_equal_approx(size.x, built_w) and is_equal_approx(size.y, built_h):
		return
	built_w = size.x
	built_h = size.y
	build()
	apply(data)
	built.emit(buttons)


func _process(delta: float) -> void:
	if hint_t > 0.0:
		hint_t = maxf(0.0, hint_t - delta)
		var a := clampf(hint_t / 1.0, 0.0, 1.0) * 0.85
		set_hint_alpha(a)


func set_hint_alpha(a: float) -> void:
	if hint_l == null:
		return
	hint_l.modulate.a = a
	hint_r.modulate.a = a
	hint_l.visible = a > 0.01
	hint_r.visible = a > 0.01


func show_hint(secs: float) -> void:
	hint_t = secs + 1.0
	set_hint_alpha(0.85)


func build() -> void:
	for c in get_children():
		remove_child(c)
		c.queue_free()
	buttons.clear()
	ring_nodes.clear()
	var mx := d(14.0)
	var my := d(10.0)

	score_label = Cp.label("0", 34.0, Color.WHITE)
	Cp.place(score_label, mx, my - d(2.0), d(260.0), d(40.0))
	add_child(score_label)

	sub_label = Cp.label("", 12.0, Color("e9dcff"), false)
	Cp.place(sub_label, mx, my + d(38.0), d(260.0), d(16.0))
	add_child(sub_label)

	coin_pill = Cp.pill(26.0)
	coin_pill.position = Vector2(mx, my + d(58.0))
	add_child(coin_pill)
	Cp.pill_add(coin_pill, Cp.icon("coin", 16.0))
	Cp.pill_add(coin_pill, Cp.gap(d(6.0)))
	coin_label = Cp.label("0", 13.0, Cp.SUN)
	Cp.set_text(coin_label, "0")
	Cp.pill_add(coin_pill, coin_label)
	Cp.pill_update(coin_pill)

	heart_pill = Cp.pill(26.0)
	heart_pill.position = Vector2(0.0, my)
	add_child(heart_pill)
	Cp.pill_add(heart_pill, Cp.icon("heart", 16.0))
	Cp.pill_add(heart_pill, Cp.gap(d(6.0)))
	heart_label = Cp.label("x1", 13.0, Color("ffd0e0"))
	Cp.set_text(heart_label, "x1")
	Cp.pill_add(heart_pill, heart_label)
	Cp.pill_update(heart_pill)
	heart_pill.position.x = (size.x - heart_pill.size.x) * 0.5

	var pw := d(176.0)
	prog_group = Control.new()
	prog_group.size = Vector2(pw, d(18.0))
	prog_group.position = Vector2((size.x - pw) * 0.5, my + d(34.0))
	prog_group.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(prog_group)
	prog_bar = Cp.bar(Vector2(d(150.0), d(8.0)), Color("ffe27a"), Color("ffb000"))
	prog_bar.position = Vector2(0.0, d(5.0))
	prog_group.add_child(prog_bar)
	prog_star = Cp.icon("star_off", 18.0)
	prog_star.position = Vector2(d(158.0), 0.0)
	prog_group.add_child(prog_star)
	star_lit = false

	pause_btn = Cp.round_btn(40.0, "pause", 20.0)
	pause_btn.position = Vector2(size.x - mx - d(40.0), my)
	pause_btn.pressed.connect(emit_action.bind("pause"))
	add_child(pause_btn)
	buttons.append(pause_btn)

	dist_label = Cp.label("", 12.0, Color("e9dcff"), false)
	Cp.place(dist_label, size.x - mx - d(140.0), my + d(46.0), d(140.0), d(16.0), HORIZONTAL_ALIGNMENT_RIGHT)
	add_child(dist_label)

	for i in POWER_KEYS.size():
		var rn := make_ring(String(POWER_KEYS[i]))
		rn.position = Vector2(mx + float(i) * d(40.0), my + d(92.0))
		rn.visible = false
		add_child(rn)
		ring_nodes[String(POWER_KEYS[i])] = rn

	var cs := d(56.0)
	combo_node = Control.new()
	combo_node.size = Vector2(cs, cs)
	combo_node.pivot_offset = Vector2(cs, cs) * 0.5
	combo_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	combo_node.visible = false
	combo_node.draw.connect(draw_combo)
	add_child(combo_node)
	combo_label = Cp.label("x2", 19.0, Color("ffe27a"))
	Cp.place(combo_label, 0.0, 0.0, cs, cs, HORIZONTAL_ALIGNMENT_CENTER)
	combo_node.add_child(combo_label)

	banner_box = Control.new()
	banner_box.size = Vector2(size.x, d(70.0))
	banner_box.position = Vector2(0.0, my + d(58.0))
	banner_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner_box.modulate.a = 0.0
	add_child(banner_box)

	hint_l = make_hint(m.T("HOLD TO DUCK"))
	hint_l.position = Vector2(mx, size.y - d(6.0) - hint_l.size.y)
	add_child(hint_l)
	hint_r = make_hint(m.T("TAP TO JUMP"))
	hint_r.position = Vector2(size.x - mx - hint_r.size.x, size.y - d(6.0) - hint_r.size.y)
	add_child(hint_r)
	set_hint_alpha(clampf(hint_t, 0.0, 1.0) * 0.85)


func make_hint(text: String) -> Control:
	var w := Cp.text_w(text, 12.0) + d(28.0)
	var g := Cp.glass(Vector2(w, d(30.0)), 14.0)
	var l := Cp.label(text, 12.0, Color.WHITE)
	Cp.place(l, 0.0, 0.0, w, d(30.0), HORIZONTAL_ALIGNMENT_CENTER)
	g.add_child(l)
	return g


func ring_color(key: String) -> Color:
	if key == "shield":
		return Cp.CYAN
	if key == "magnet":
		return Cp.PINK
	if key == "x2":
		return Cp.SUN
	return Color("8fb8ff")


func glyph_of(key: String) -> String:
	if key == "shield":
		return "aura"
	if key == "magnet":
		return "candy"
	if key == "x2":
		return "blast"
	return "freeze"


func make_ring(key: String) -> Control:
	var sz := d(34.0)
	var r := Control.new()
	r.size = Vector2(sz, sz)
	r.custom_minimum_size = Vector2(sz, sz)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.set_meta("key", key)
	r.set_meta("frac", 1.0)
	r.draw.connect(draw_ring.bind(r))
	return r


func draw_ring(r: Control) -> void:
	var key: String = r.get_meta("key")
	var frac: float = r.get_meta("frac")
	var col := ring_color(key)
	var c := r.size * 0.5
	r.draw_circle(c, r.size.x * 0.5, Color(0.118, 0.063, 0.314, 0.7))
	var rad := r.size.x * 0.5 - d(3.5)
	var sw := d(3.0)
	r.draw_arc(c, rad, 0.0, TAU, 32, Color(1.0, 1.0, 1.0, 0.16), sw, true)
	if frac > 0.005:
		r.draw_arc(c, rad, -PI * 0.5, -PI * 0.5 + TAU * clampf(frac, 0.0, 1.0), 32, col, sw, true)
	draw_glyph(r, glyph_of(key), col, c, d(8.5))


func draw_glyph(ci: CanvasItem, kind: String, col: Color, c: Vector2, h: float) -> void:
	var sw := h * 0.38
	if kind == "aura":
		ci.draw_arc(c, h * 0.95, 0.0, TAU, 24, col, sw, true)
		ci.draw_circle(c, h * 0.34, col)
	elif kind == "candy":
		ci.draw_circle(c, h * 0.62, col)
		ci.draw_line(c + Vector2(-h * 1.1, 0.0), c + Vector2(-h * 0.7, 0.0), col, sw, true)
		ci.draw_line(c + Vector2(h * 0.7, 0.0), c + Vector2(h * 1.1, 0.0), col, sw, true)
	elif kind == "blast":
		ci.draw_circle(c, h * 0.42, col)
		for i in 8:
			var a := float(i) * PI * 0.25
			var dir := Vector2(cos(a), sin(a))
			ci.draw_line(c + dir * h * 0.74, c + dir * h * 1.2, col, sw * 0.8, true)
	else:
		for i in 3:
			var a2 := float(i) * PI / 3.0
			var dir2 := Vector2(cos(a2), sin(a2))
			ci.draw_line(c + dir2 * h * 1.05, c - dir2 * h * 1.05, col, sw * 0.8, true)


func draw_combo() -> void:
	var c := combo_node.size * 0.5
	var r := combo_node.size.x * 0.5 - d(2.0)
	combo_node.draw_arc(c, r, 0.0, TAU, 40, Color(1.0, 1.0, 1.0, 0.2), d(3.0), true)
	if combo_frac > 0.01:
		combo_node.draw_arc(c, r, -PI * 0.5, -PI * 0.5 + TAU * clampf(combo_frac, 0.0, 1.0), 40, Color(1.0, 0.886, 0.478, 0.9), d(3.0), true)


func pop_combo() -> void:
	if combo_tw != null and combo_tw.is_valid():
		combo_tw.kill()
	combo_tw = combo_node.create_tween()
	combo_tw.tween_method(set_combo_scale, 0.0, 0.8, 0.8)


func set_combo_scale(t: float) -> void:
	var s := 1.0 + 0.4 * (1.0 - Cp.spring(t, 0.4, 500.0))
	combo_node.scale = Vector2(s, s)


func apply(snap: Dictionary) -> void:
	data = snap
	if score_label == null:
		return
	var show_hud: bool = bool(snap.get("show", false))
	score_label.visible = show_hud
	sub_label.visible = show_hud
	coin_pill.visible = show_hud
	heart_pill.visible = show_hud
	pause_btn.visible = show_hud and bool(snap.get("pause", false))
	dist_label.visible = show_hud
	var level_mode: bool = bool(snap.get("level_mode", false))
	prog_group.visible = show_hud and level_mode
	if not show_hud:
		combo_node.visible = false
		for k in ring_nodes:
			var hidden: Control = ring_nodes[k]
			hidden.visible = false
		set_hint_alpha(0.0)
		return
	score_label.text = "%d" % int(snap.get("score", 0))
	sub_label.text = String(snap.get("sub", ""))
	var ct := "%d" % int(snap.get("coins", 0))
	if ct != last_coin_text:
		last_coin_text = ct
		Cp.set_text(coin_label, ct)
		Cp.pill_update(coin_pill)
	var ht := "x%d" % int(snap.get("lives", 1))
	if ht != last_heart_text:
		last_heart_text = ht
		Cp.set_text(heart_label, ht)
		Cp.pill_update(heart_pill)
		heart_pill.position.x = (size.x - heart_pill.size.x) * 0.5
	if level_mode:
		var f := clampf(float(snap.get("progress", 0.0)), 0.0, 1.0)
		Cp.bar_set(prog_bar, f, false)
		var lit := f >= 1.0
		if lit != star_lit:
			star_lit = lit
			Cp.set_icon(prog_star, "star_on" if lit else "star_off")
	dist_label.text = m.T("%d m") % int(snap.get("dist", 0))
	var combo := int(snap.get("combo", 0))
	if combo > 1:
		combo_frac = float(snap.get("combo_f", 0.0))
		var cp: Vector2 = snap.get("combo_pos", Vector2(300.0, 200.0))
		combo_node.position = cp - combo_node.size * 0.5
		combo_node.visible = true
		if combo != combo_val:
			combo_label.text = "x%d" % combo
			combo_label.add_theme_font_size_override("font_size", roundi(minf(17.0 + float(combo), 26.0) * U))
			pop_combo()
		combo_node.queue_redraw()
	else:
		combo_node.visible = false
	combo_val = combo
	var powers: Array = snap.get("powers", [])
	var slot := 0
	for k in ring_nodes:
		var rn: Control = ring_nodes[k]
		rn.visible = false
	for p in powers:
		var key := String(p[0])
		if not ring_nodes.has(key):
			continue
		var node: Control = ring_nodes[key]
		node.set_meta("frac", float(p[1]))
		node.position.x = d(14.0) + float(slot) * d(40.0)
		node.visible = true
		node.queue_redraw()
		slot += 1


func show_banner(title: String, sub: String) -> void:
	if banner_box == null:
		return
	for c in banner_box.get_children():
		banner_box.remove_child(c)
		c.queue_free()
	var sl := Cp.label(sub, 12.0, Cp.SUN)
	Cp.place(sl, 0.0, 0.0, size.x, d(18.0), HORIZONTAL_ALIGNMENT_CENTER)
	banner_box.add_child(sl)
	var sp := 30.0
	while sp > 16.0 and Cp.text_w(title, sp) > size.x - d(40.0):
		sp -= 1.0
	var tt := Cp.grad_title(title, sp)
	tt.position = Vector2((size.x - tt.size.x) * 0.5, d(18.0))
	banner_box.add_child(tt)
	if banner_tw != null and banner_tw.is_valid():
		banner_tw.kill()
	var base_y := d(10.0) + d(58.0)
	banner_box.modulate.a = 0.0
	banner_box.position.y = base_y + d(14.0)
	banner_tw = banner_box.create_tween()
	banner_tw.set_parallel(true)
	banner_tw.tween_property(banner_box, "modulate:a", 1.0, 0.25)
	banner_tw.tween_property(banner_box, "position:y", base_y, 0.3).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	banner_tw.chain().tween_interval(1.4)
	banner_tw.chain().tween_property(banner_box, "modulate:a", 0.0, 0.5)


func clear_banner() -> void:
	if banner_tw != null and banner_tw.is_valid():
		banner_tw.kill()
	if banner_box != null:
		banner_box.modulate.a = 0.0
	hint_t = 0.0
	set_hint_alpha(0.0)
