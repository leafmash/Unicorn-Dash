extends RefCounted


static func hs(n: float) -> float:
	var v := sin(n * 127.1 + 311.7) * 43758.5453
	return v - floor(v)


static func smooth(v: float) -> float:
	return v * v * (3.0 - 2.0 * v)


static func ease_out(v: float) -> float:
	return 1.0 - pow(1.0 - v, 3.0)


static func damp(a: float, b: float, r: float, dt: float) -> float:
	return a + (b - a) * (1.0 - exp(-r * dt))


static func hx(v: int) -> Color:
	return Color(float((v >> 16) & 255) / 255.0, float((v >> 8) & 255) / 255.0, float(v & 255) / 255.0, 1.0)


static func rgba(r: int, g: int, b: int, a: float) -> Color:
	return Color(float(r) / 255.0, float(g) / 255.0, float(b) / 255.0, clampf(a, 0.0, 1.0))


static func with_alpha(c: Color, a: float) -> Color:
	return Color(c.r, c.g, c.b, clampf(a, 0.0, 1.0))


static func _hue_to_rgb(p: float, q: float, t_in: float) -> float:
	var t := t_in
	if t < 0.0:
		t += 1.0
	if t > 1.0:
		t -= 1.0
	if t < 1.0 / 6.0:
		return p + (q - p) * 6.0 * t
	if t < 0.5:
		return q
	if t < 2.0 / 3.0:
		return p + (q - p) * (2.0 / 3.0 - t) * 6.0
	return p


static func hsl(h_in: float, s_in: float, l_in: float, a: float = 1.0) -> Color:
	var h := fposmod(h_in, 360.0) / 360.0
	var s := clampf(s_in / 100.0, 0.0, 1.0)
	var l := clampf(l_in / 100.0, 0.0, 1.0)
	var r: float
	var g: float
	var b: float
	if s == 0.0:
		r = l
		g = l
		b = l
	else:
		var q := l * (1.0 + s) if l < 0.5 else l + s - l * s
		var p := 2.0 * l - q
		r = _hue_to_rgb(p, q, h + 1.0 / 3.0)
		g = _hue_to_rgb(p, q, h)
		b = _hue_to_rgb(p, q, h - 1.0 / 3.0)
	return Color(r, g, b, clampf(a, 0.0, 1.0))


class Rng:
	var s: int = 1

	func _init(seed_value: int) -> void:
		s = (seed_value * 9301 + 49297) % 2147483647
		if s == 0:
			s = 1

	func next() -> float:
		s = (s * 48271) % 2147483647
		return float(s) / 2147483647.0
