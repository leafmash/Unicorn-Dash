extends Node2D

var x
var build: Callable
var snap: Array = []
var idx: int = -99999
var ver: int = -1
var used: bool = false
var dyn: bool = false


func _draw() -> void:
	if not build.is_valid():
		return
	x.sub_begin(self, snap)
	build.call(self)
	x.sub_end()
