extends RefCounted

const Util = preload("res://scripts/util.gd")
const Data = preload("res://scripts/data.gd")

var x
var g
var label_stroke: Color = Color(40.0 / 255.0, 20.0 / 255.0, 80.0 / 255.0, 0.45)


func _init(ctx, game) -> void:
	x = ctx
	g = game


func label(text: String, size: float, px: float, py: float, col: Color, align: int = 1) -> void:
	x.text(text, px, py, size, col, align, label_stroke, maxf(2.0, size * 0.16))


func title(text: String, size: float, px: float, py: float) -> void:
	var w: float = x.measure(text, size)
	x.halo(px, py, w * 0.5, 300.0, 100.0, 70.0, 0.16)
	var cx := px - w * 0.5
	for i in text.length():
		var ch := text.substr(i, 1)
		var cw: float = x.measure(ch, size)
		label(ch, size, cx + cw * 0.5, py, Util.hsl(fposmod(44.0 * i + g.clock * 40.0, 360.0), 95.0, 68.0), 1)
		cx += cw


func sparkle(px: float, py: float, s: float, ph: float) -> void:
	var clock: float = g.clock
	var k := 0.5 + 0.5 * sin(clock * 3.0 + ph)
	var r := s * (0.4 + 0.6 * k)
	x.save()
	x.translate(px, py)
	x.rotate(clock * 0.4 + ph)
	x.set_fill(Util.rgba(255, 255, 255, 0.4 + 0.6 * k))
	x.begin_path()
	x.move_to(0.0, -r)
	x.quad_to(r * 0.12, -r * 0.12, r, 0.0)
	x.quad_to(r * 0.12, r * 0.12, 0.0, r)
	x.quad_to(-r * 0.12, r * 0.12, -r, 0.0)
	x.quad_to(-r * 0.12, -r * 0.12, 0.0, -r)
	x.fill()
	x.restore()
	x.halo(px, py, r * 2.2, 50.0, 100.0, 80.0, 0.3 * k)


func pill(x0: float, y0: float, w: float, h: float, r: float) -> void:
	x.begin_path()
	x.round_rect(x0, y0, w, h, r)


func glass(x0: float, y0: float, w: float, h: float, r: float, a: float = 1.0) -> void:
	pill(x0, y0, w, h, r)
	x.set_fill_g(x.lin(0.0, y0, 0.0, y0 + h, Util.rgba(96, 66, 176, 0.8 * a), Util.rgba(38, 22, 92, 0.84 * a)))
	x.fill()
	x.set_stroke_g(x.lin(0.0, y0, 0.0, y0 + h, Util.rgba(255, 255, 255, 0.42), Util.rgba(255, 255, 255, 0.08)))
	x.lw = 1.4
	x.stroke()


func panel(cx: float, cy: float, w: float, h: float) -> void:
	for i in 7:
		var gg: float = 3.0 + i * 4.0
		x.set_fill(Util.rgba(8, 0, 36, 0.07))
		pill(cx - w / 2.0 - gg, cy - h / 2.0 - gg + 8.0, w + gg * 2.0, h + gg * 2.0, 24.0 + gg)
		x.fill()
	glass(cx - w / 2.0, cy - h / 2.0, w, h, 24.0, 1.0)


func heart(px: float, py: float, sz: float, col: Color) -> void:
	x.begin_path()
	x.move_to(px, py + sz * 0.9)
	x.bezier_to(px - sz * 1.5, py - sz * 0.1, px - sz * 0.8, py - sz * 1.2, px, py - sz * 0.4)
	x.bezier_to(px + sz * 0.8, py - sz * 1.2, px + sz * 1.5, py - sz * 0.1, px, py + sz * 0.9)
	x.close_path()
	x.set_fill(col)
	x.fill()


func coin_icon(px: float, py: float, r: float) -> void:
	x.halo(px, py, r * 2.2, 45.0, 100.0, 60.0, 0.5)
	x.set_fill(Util.hx(0xffd23f))
	x.set_stroke(Util.hx(0xffb000))
	x.lw = 1.6
	x.begin_path()
	x.arc(px, py, r, 0.0, 7.0)
	x.fill()
	x.stroke()
	x.set_fill(Util.rgba(255, 255, 255, 0.7))
	x.begin_path()
	x.ellipse(px - r * 0.3, py - r * 0.3, r * 0.25, r * 0.4, 0.0, 0.0, 7.0)
	x.fill()


func button(id: String, cx: float, cy: float, w: float, h: float, text: String, hue: float = 300.0, size: float = 18.0) -> void:
	var pressed: bool = g.down_id == id
	var s := 0.94 if pressed else 1.0
	x.save()
	x.translate(cx, cy)
	x.scale(s, s)
	for i in 4:
		var gg: float = 1.0 + i * 2.0
		x.set_fill(Util.rgba(8, 0, 36, 0.1))
		pill(-w / 2.0 - gg, -h / 2.0 - gg + 4.0, w + gg * 2.0, h + gg * 2.0, h / 2.0 + gg)
		x.fill()
	pill(-w / 2.0, -h / 2.0, w, h, h / 2.0)
	x.set_fill_g(x.lin(0.0, -h / 2.0, 0.0, h / 2.0, Util.hsl(hue + 20.0, 100.0, 72.0), Util.hsl(hue - 20.0, 90.0, 56.0)))
	x.fill()
	x.set_stroke(Util.rgba(255, 255, 255, 0.85))
	x.lw = 2.0
	x.stroke()
	pill(-w / 2.0 + 6.0, -h / 2.0 + 3.0, w - 12.0, h * 0.4, h * 0.2)
	x.set_fill(Util.rgba(255, 255, 255, 0.22))
	x.fill()
	label(text, size, 0.0, 1.0, Color(1, 1, 1, 1))
	x.restore()
	g.btns.append([Rect2(cx - w / 2.0 - 4.0, cy - h / 2.0 - 4.0, w + 8.0, h + 8.0), id])


func round_button(id: String, cx: float, cy: float, r: float, kind: String) -> void:
	var pressed: bool = g.down_id == id
	x.save()
	x.translate(cx, cy)
	var s := 0.9 if pressed else 1.0
	x.scale(s, s)
	x.set_fill(Util.rgba(30, 16, 80, 0.8))
	x.set_stroke(Util.rgba(255, 255, 255, 0.4))
	x.lw = 1.4
	x.begin_path()
	x.arc(0.0, 0.0, r, 0.0, 7.0)
	x.fill()
	x.stroke()
	x.set_fill(Color(1, 1, 1, 1))
	if kind == "pause":
		x.fill_rect(-r * 0.34, -r * 0.4, r * 0.22, r * 0.8)
		x.fill_rect(r * 0.12, -r * 0.4, r * 0.22, r * 0.8)
	x.restore()
	g.btns.append([Rect2(cx - r - 8.0, cy - r - 8.0, r * 2.0 + 16.0, r * 2.0 + 16.0), id])


func vignette() -> void:
	var r: float = Vector2(g.L, 360.0).length() * 0.55
	var cols := [Util.rgba(10, 4, 40, 0.0), Util.rgba(10, 4, 40, 0.0), Util.rgba(10, 4, 40, 0.32)]
	x.set_fill_g(x.rad_n(g.L / 2.0, 180.0, r, cols, [0.0, 120.0 / r, 1.0]))
	x.fill_rect(0.0, -g.ty - 10.0, g.L, 380.0 + g.ty * 2.0)


func top_y() -> float:
	return -g.ty


func draw_hud() -> void:
	var top := top_y() + 12.0
	var ml: float = g.ML
	var mr: float = g.MR
	glass(ml, top, 112.0, 34.0, 17.0)
	label(str(int(round(g.shown))), 22.0, ml + 14.0, top + 17.5, Color(1, 1, 1, 1), 0)
	label("BEST " + str(g.best), 9.0, ml + 100.0, top + 17.5, Util.hx(0xd9c8ff), 2)
	var cw := 76.0
	glass(g.L - mr - 40.0 - cw - 10.0, top, cw, 34.0, 17.0)
	coin_icon(g.L - mr - 40.0 - cw + 6.0, top + 17.0, 8.0)
	label(str(g.coins), 18.0, g.L - mr - 40.0 - 22.0, top + 17.5, Util.hx(0xffe27a), 2)
	g.ui.round_button("pause", g.L - mr - 14.0, top + 17.0, 15.0, "pause")
	if g.combo >= 2 and g.combo_t > 0.0:
		var a := minf(1.0, g.combo_t)
		x.save()
		x.alpha = a
		label("COMBO x" + str(g.combo), 14.0, g.L - mr - 40.0 - cw * 0.5 - 10.0, top + 50.0, Util.hx(0xffe27a), 1)
		x.restore()
	if g.hint > 0.0:
		x.save()
		x.alpha = minf(1.0, g.hint)
		var ty0: float = 360.0 + g.ty - 26.0
		label("Right side: tap to jump, hold to jump higher, tap again in the air for a double jump", 11.0, g.L / 2.0, ty0 - 16.0, Util.hx(0xf1e8ff))
		label("Left side: hold to duck", 11.0, g.L / 2.0, ty0, Util.hx(0xf1e8ff))
		x.restore()
	if g.banner_life > 0.0:
		var k: float = g.banner_life / g.banner_max
		var a2 := minf(1.0, minf(k * 4.0, (1.0 - k) * 6.0 + 0.0 + 1.0))
		x.save()
		x.alpha = clampf(a2, 0.0, 1.0) * clampf(k * 5.0, 0.0, 1.0)
		var by := top + 78.0 + (1.0 - Util.ease_out(minf(1.0, (1.0 - k) * 6.0))) * -10.0
		label(g.banner_text, 26.0, g.L / 2.0, by, Color(1, 1, 1, 1))
		label(g.banner_sub, 13.0, g.L / 2.0, by + 24.0, Util.hx(0xffe27a))
		x.restore()
	if g.toast_life > 0.0:
		x.save()
		x.alpha = clampf(g.toast_life * 3.0, 0.0, 1.0)
		label(g.toast_text, 16.0, g.L / 2.0, top + 150.0, Util.hx(0xffe27a))
		x.restore()


func draw_menu() -> void:
	var top := top_y() + 12.0
	glass(g.ML, top, 96.0, 34.0, 17.0)
	coin_icon(g.ML + 17.0, top + 17.0, 8.0)
	label(str(g.bank), 16.0, g.ML + 88.0, top + 17.5, Util.hx(0xffe27a), 2)
	glass(g.L - g.MR - 112.0, top, 112.0, 34.0, 17.0)
	label("BEST " + str(g.best), 14.0, g.L - g.MR - 56.0, top + 17.5, Color(1, 1, 1, 1), 1)
	title("UNICORN DASH", 40.0, g.L / 2.0, top + 44.0)
	label(g.zone.name, 12.0, g.L / 2.0, top + 72.0, Util.hx(0xf1e8ff))
	var pulse := 1.0 + 0.03 * sin(g.clock * 4.0)
	x.save()
	x.translate(g.L / 2.0, 330.0)
	x.scale(pulse, pulse)
	x.translate(-g.L / 2.0, -330.0)
	button("play", g.L / 2.0, 330.0, 190.0, 46.0, "PLAY", 320.0, 22.0)
	x.restore()


func draw_pause() -> void:
	x.set_fill(Util.rgba(10, 4, 40, 0.5))
	x.fill_rect(0.0, -g.ty - 10.0, g.L, 380.0 + g.ty * 2.0)
	panel(g.L / 2.0, 180.0, 240.0, 230.0)
	label("PAUSED", 26.0, g.L / 2.0, 118.0, Color(1, 1, 1, 1))
	button("resume", g.L / 2.0, 164.0, 170.0, 38.0, "RESUME", 150.0, 17.0)
	button("restart", g.L / 2.0, 210.0, 170.0, 38.0, "RESTART", 300.0, 17.0)
	button("menu", g.L / 2.0, 256.0, 170.0, 38.0, "MENU", 220.0, 17.0)


func draw_over() -> void:
	var since: float = g.now_ms() - g.st_at
	var k := clampf(since / 350.0, 0.0, 1.0)
	x.save()
	x.alpha = k
	x.set_fill(Util.rgba(10, 4, 40, 0.42))
	x.fill_rect(0.0, -g.ty - 10.0, g.L, 380.0 + g.ty * 2.0)
	var cy := 180.0 + (1.0 - Util.ease_out(k)) * 20.0
	panel(g.L / 2.0, cy, 290.0, 250.0)
	var tt := "NEW BEST!" if g.new_best else "GAME OVER"
	title(tt, 28.0, g.L / 2.0, cy - 92.0)
	label(str(int(floor(g.score))), 44.0, g.L / 2.0, cy - 46.0, Color(1, 1, 1, 1))
	label("SCORE", 10.0, g.L / 2.0, cy - 16.0, Util.hx(0xd9c8ff))
	coin_icon(g.L / 2.0 - 100.0, cy + 6.0, 7.0)
	label(str(g.coins), 15.0, g.L / 2.0 - 88.0, cy + 6.5, Util.hx(0xffe27a), 0)
	label("BEST " + str(g.best), 14.0, g.L / 2.0 + 100.0, cy + 6.5, Color(1, 1, 1, 1), 2)
	if g.run_combo >= 2:
		label("Best combo x" + str(g.run_combo), 11.0, g.L / 2.0, cy + 28.0, Util.hx(0xffe27a))
	button("restart", g.L / 2.0 - 64.0, cy + 76.0, 112.0, 40.0, "RETRY", 320.0, 17.0)
	button("menu", g.L / 2.0 + 64.0, cy + 76.0, 112.0, 40.0, "MENU", 220.0, 17.0)
	x.restore()


func draw_ui() -> void:
	match g.st:
		0:
			draw_menu()
		1:
			draw_hud()
		3:
			draw_hud()
			draw_pause()
		2:
			draw_hud()
			if g.now_ms() >= g.st_at:
				draw_over()
