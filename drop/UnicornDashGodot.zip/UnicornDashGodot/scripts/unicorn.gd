extends RefCounted

const Util = preload("res://scripts/util.gd")
const Data = preload("res://scripts/data.gd")


class UniQ:
	var x: float = 0.0
	var y: float = 0.0
	var ang: float = 0.0
	var sq: float = 1.0
	var dk: float = 0.0
	var air: bool = false
	var stand: bool = false
	var tt: float = 0.0
	var rt: float = NAN
	var sit: float = 0.0
	var rear: float = 0.0
	var happy: bool = false
	var dead: bool = false
	var sc: float = 1.0
	var hn: int = 0
	var fx: float = 1.0
	var nod: float = 0.0
	var ghost: bool = false
	var gait: int = 0
	var stride: float = 0.0
	var wph: float = 0.0

	func clear() -> void:
		gait = 0
		stride = 0.0
		wph = 0.0
		x = 0.0
		y = 0.0
		ang = 0.0
		sq = 1.0
		dk = 0.0
		air = false
		stand = false
		tt = 0.0
		rt = NAN
		sit = 0.0
		rear = 0.0
		happy = false
		dead = false
		sc = 1.0
		hn = 0
		fx = 1.0
		nod = 0.0
		ghost = false


var x
var foot_col: Color = Color(0.4784, 0.3843, 0.6588)
var eye_col: Color = Color(0.2314, 0.1647, 0.3529)


func _init(ctx) -> void:
	x = ctx


func mane(si: int, b: int) -> float:
	return Data.SK[si].h0 + Data.SK[si].st * b


func trail_color(ti: int, b: int, tt: float, skin: int, a: float) -> Color:
	var c: Dictionary = Data.TR[ti]
	if c.c.is_empty() and not c.cycle:
		return Util.hsl(mane(skin, b), 95.0, 62.0, a)
	if c.cycle:
		return Util.hsl(fposmod(140.0 + 80.0 * (1.0 + sin(tt * 1.6 + b * 0.9)), 360.0), 90.0, 66.0, a)
	var v: Array = c.c[b]
	return Util.hsl(v[0], v[1], v[2], a)


func ribbon(x0: float, x1: float, yc: float, ti: int, tt: float, skin: int) -> void:
	x.cap_round = true
	for b in 6:
		x.set_stroke_g(x.lin(x0, 0.0, x1, 0.0, trail_color(ti, b, tt, skin, 0.0), trail_color(ti, b, tt, skin, 0.9)))
		x.lw = 3.4
		x.begin_path()
		for i in range(15):
			var px: float = lerpf(x0, x1, i / 14.0)
			var py: float = yc + (b - 2.5) * 3.6 + sin(tt * 4.0 + i * 0.6 + b * 0.4) * 2.2
			if i > 0:
				x.line_to(px, py)
			else:
				x.move_to(px, py)
		x.stroke()


func heart_path(px: float, py: float, sz: float) -> void:
	x.begin_path()
	x.move_to(px, py + sz * 0.9)
	x.bezier_to(px - sz * 1.5, py - sz * 0.1, px - sz * 0.8, py - sz * 1.2, px, py - sz * 0.4)
	x.bezier_to(px + sz * 0.8, py - sz * 1.2, px + sz * 1.5, py - sz * 0.1, px, py + sz * 0.9)
	x.close_path()


func horn_shape(hi: int, tt: float, gh: float) -> void:
	var hh: Dictionary = Data.HR[hi] if hi >= 0 and hi < Data.HR.size() else Data.HR[0]
	var hue: float = gh if hh.type == "gold" else hh.hue
	var a := Vector2(28.2, -48.4)
	var b := Vector2(37.4, -70.2)
	var c := Vector2(33.6, -46.6)
	x.begin_path()
	x.move_to(a.x, a.y)
	x.line_to(b.x, b.y)
	x.line_to(c.x, c.y)
	if hh.type == "candy":
		x.set_fill(Color(1, 1, 1, 1))
		x.fill()
		if not x.ink:
			x.set_fill(Util.rgba(232, 40, 84, 0.95))
			for i in 5:
				var s0: float = 0.08 + i * 0.18
				var s1: float = s0 + 0.09
				if s1 > 1.0:
					continue
				x.begin_path()
				var l0 := a.lerp(b, s0)
				var l1 := a.lerp(b, s1)
				var r0 := c.lerp(b, s0)
				var r1 := c.lerp(b, s1)
				x.move_to(l0.x, l0.y)
				x.line_to(l1.x, l1.y)
				x.line_to(r1.x, r1.y)
				x.line_to(r0.x, r0.y)
				x.close_path()
				x.fill()
	else:
		var c0: Color
		var c1: Color
		match hh.type:
			"crystal":
				c0 = Util.hx(0x7fe3ff)
				c1 = Util.hx(0xeafcff)
			"flame":
				var f := 0.5 + 0.5 * sin(tt * 14.0)
				c0 = Util.hsl(8.0 + 8.0 * f, 100.0, 52.0)
				c1 = Util.hsl(44.0 + 10.0 * f, 100.0, 72.0)
			"heart":
				c0 = Util.hx(0xff4f86)
				c1 = Util.hx(0xffc2d6)
			"rainbow":
				hue = fposmod(tt * 120.0, 360.0)
				c0 = Util.hsl(hue, 100.0, 64.0)
				c1 = Util.hsl(fposmod(hue + 70.0, 360.0), 100.0, 80.0)
			_:
				c0 = Util.hx(0xffe27a)
				c1 = Util.hx(0xfff9d6)
		x.set_fill_g(x.lin(30.9, -47.5, 37.4, -70.2, c0, c1))
		x.fill()
		if hh.type == "crystal":
			x.set_stroke(Util.rgba(255, 255, 255, 0.9))
			x.lw = 0.8
			x.begin_path()
			x.move_to(33.0, -50.0)
			x.line_to(36.3, -66.0)
			x.move_to(30.5, -50.0)
			x.line_to(35.3, -60.0)
			x.stroke()
		if hh.type == "heart":
			heart_path(37.6, -74.0, 3.4)
			x.set_fill(Util.hx(0xfff0f5))
			x.fill()
		if hh.type == "star":
			x.set_fill(Util.hx(0xfffbd0))
			x.begin_path()
			for i in 10:
				var r: float = 1.8 if i % 2 == 1 else 4.0
				var an: float = -PI / 2.0 + i * PI / 5.0
				x.line_to(37.6 + cos(an) * r, -73.0 + sin(an) * r)
			x.close_path()
			x.fill()
	x.halo(37.4, -70.2, 20.0 if hh.type == "flame" else 16.0, hue, 100.0, 70.0, 0.7)


func leg(lx: float, ph: float, col: Color, air: bool) -> void:
	var fx2: float
	var fy: float
	if air:
		fx2 = lx + (12.0 if lx > 0.0 else -10.0)
		fy = -12.0 if lx > 0.0 else -9.0
	else:
		fx2 = lx + sin(ph) * 9.0
		fy = -3.0 - maxf(0.0, cos(ph)) * 8.0
	x.set_stroke(col)
	x.lw = 5.0
	x.cap_round = true
	x.begin_path()
	x.move_to(lx, -20.0)
	x.quad_to(lx + (fx2 - lx) * 0.3 + 3.0, -11.0, fx2, fy)
	x.stroke()
	x.set_fill(foot_col)
	x.begin_path()
	x.arc(fx2, fy, 2.6, 0.0, 7.0)
	x.fill()


func band(si: int, b: int, mw: float) -> void:
	x.set_stroke(Util.hsl(mane(si, b), 95.0, 62.0))
	x.lw = mw
	x.cap_round = true


func straight_leg(lx: float, col: Color) -> void:
	x.set_stroke(col)
	x.lw = 5.0
	x.cap_round = true
	x.begin_path()
	x.move_to(lx, -20.0)
	x.line_to(lx + 1.0, -4.0)
	x.stroke()
	x.set_fill(foot_col)
	x.begin_path()
	x.arc(lx + 1.0, -3.0, 2.6, 0.0, 7.0)
	x.fill()


func hind_leg(lx: float, col: Color) -> void:
	x.set_fill(col)
	x.begin_path()
	x.ellipse(lx + 4.0, -12.0, 11.0, 6.5, -0.15, 0.0, 7.0)
	x.fill()
	x.set_fill(foot_col)
	x.begin_path()
	x.arc(lx + 14.0, -5.0, 2.6, 0.0, 7.0)
	x.fill()


func paw_leg(lx: float, col: Color, tt: float, ph: float) -> void:
	var k := sin(tt * 12.0 + ph) * 3.0
	x.set_stroke(col)
	x.lw = 5.0
	x.cap_round = true
	x.join_round = true
	x.begin_path()
	x.move_to(lx, -20.0)
	x.line_to(lx + 10.0, -24.0 + k)
	x.line_to(lx + 15.0, -13.0 + k)
	x.stroke()
	x.set_fill(foot_col)
	x.begin_path()
	x.arc(lx + 15.0, -12.0 + k, 2.6, 0.0, 7.0)
	x.fill()


func walk_leg(lx: float, ph: float, col: Color, stride: float) -> void:
	var lift := maxf(0.0, cos(ph))
	var fx2 := lx + sin(ph) * stride
	var fy := -3.0 - lift * (stride * 0.8 + 1.0)
	var bend := 3.2 if lx > 0.0 else -3.2
	var kx := (lx + fx2) * 0.5 + bend * (0.55 + lift)
	var ky := (-20.0 + fy) * 0.5 - lift * 2.6
	x.set_stroke(col)
	x.lw = 5.0
	x.cap_round = true
	x.join_round = true
	x.begin_path()
	x.move_to(lx, -20.0)
	x.quad_to(kx, ky, fx2, fy)
	x.stroke()
	x.set_fill(foot_col)
	x.begin_path()
	x.arc(fx2, fy, 2.7, 0.0, 7.0)
	x.fill()


func limb(lx: float, ph: float, col: Color, air: bool, sit: float, q: UniQ) -> void:
	if not air and q.gait > 0 and q.stride > 0.3 and q.rear <= 0.02 and sit <= 0.5:
		walk_leg(lx, ph, col, q.stride)
	elif not air and q.rear > 0.02:
		if lx > 0.0:
			paw_leg(lx, col, q.tt, ph)
		else:
			x.save()
			x.translate(-12.0, -20.0)
			x.rotate(q.rear * 0.9)
			x.translate(12.0, 20.0)
			straight_leg(lx, col)
			x.restore()
	elif not air and q.stand:
		straight_leg(lx, col)
	elif sit > 0.5:
		if lx > 0.0:
			straight_leg(lx, col)
		else:
			hind_leg(lx, col)
	else:
		leg(lx, ph, col, air)


func draw(q: UniQ, si: int) -> void:
	if not q.ghost and x.alpha > 0.99:
		x.ink_begin()
		draw_body(q, si)
		x.ink_end()
	draw_body(q, si)


func draw_body(q: UniQ, si: int) -> void:
	var s: Dictionary = Data.SK[si]
	var body_c := Util.hx(s.body)
	var leg_c := Util.hx(s.leg)
	var back_c := Util.hx(s.back)
	var tt := q.tt
	var gt := q.gait
	var run: float = q.wph if gt > 0 else (tt if is_nan(q.rt) else q.rt) * 17.0
	var p_nh := run
	var p_nf: float = run + 0.1 if gt == 0 else (run + PI if gt == 2 else run + 0.5 * PI)
	var p_fh: float = run + 3.0 if gt == 0 else run + PI
	var p_ff: float = run + 3.1 if gt == 0 else (run if gt == 2 else run + 1.5 * PI)
	var sc := q.sc
	var sit := q.sit
	x.save()
	x.translate(q.x, q.y)
	x.rotate(q.ang)
	var fl: float = 0.04 if absf(q.fx) < 0.04 else q.fx
	x.scale(sc / q.sq * fl, sc * (1.0 - 0.36 * q.dk) * q.sq)
	if sit > 0.0:
		x.translate(0.0, sit * 6.0)
		x.rotate(-sit * 0.3)
	if q.rear > 0.0:
		x.translate(-12.0, -20.0)
		x.rotate(-q.rear * 0.9)
		x.translate(12.0, 20.0)
	x.halo(2.0, -28.0, 46.0, 300.0, 100.0, 70.0, 0.14)

	for b in 6:
		band(si, b, 3.2)
		var w := sin(tt * 9.0 + b * 0.6) * 4.0
		x.begin_path()
		x.move_to(-18.0, -30.0 + b * 1.4)
		x.quad_to(-32.0, -26.0 + w, -44.0 + w, -10.0 + b * 2.2 + w * 0.5)
		x.stroke()

	limb(-12.0, p_fh, back_c, q.air, sit, q)
	limb(12.0, p_ff, back_c, q.air, sit, q)

	x.set_fill(body_c)
	x.begin_path()
	x.ellipse(0.0, -27.0, 20.0, 11.0, 0.0, 0.0, 7.0)
	x.fill()
	x.set_fill(Util.rgba(180, 150, 230, 0.35))
	x.begin_path()
	x.ellipse(0.0, -22.0, 17.0, 6.0, 0.0, 0.0, 7.0)
	x.fill()

	limb(-12.0, p_nh, leg_c, q.air, sit, q)
	limb(12.0, p_nf, leg_c, q.air, sit, q)

	x.save()
	if q.nod != 0.0:
		x.translate(14.0, -34.0)
		x.rotate(q.nod)
		x.translate(-14.0, 34.0)
	horn_shape(q.hn, tt, s.horn)
	x.set_stroke(body_c)
	x.lw = 10.0
	x.cap_round = true
	x.begin_path()
	x.move_to(13.0, -31.0)
	x.line_to(22.0, -44.0)
	x.stroke()
	x.set_fill(body_c)
	x.begin_path()
	x.ellipse(27.0, -47.0, 8.5, 5.8, 0.4, 0.0, 7.0)
	x.fill()
	x.begin_path()
	x.move_to(23.0, -51.0)
	x.line_to(25.0, -59.0)
	x.line_to(29.0, -52.0)
	x.fill()

	for b in 6:
		band(si, b, 3.0)
		var w2 := sin(tt * 10.0 + b * 0.7) * 3.0
		x.begin_path()
		x.move_to(20.0, -50.0 + b * 0.8)
		x.quad_to(8.0, -58.0 + w2, -4.0 + w2, -40.0 + b * 1.8)
		x.stroke()

	x.set_fill(Util.rgba(255, 120, 170, 0.35))
	x.begin_path()
	x.ellipse(25.5, -45.5, 2.6, 1.8, 0.0, 0.0, 7.0)
	x.fill()
	if q.dead:
		x.set_stroke(eye_col)
		x.lw = 1.2
		x.begin_path()
		x.move_to(28.0, -50.0)
		x.line_to(31.0, -47.0)
		x.move_to(31.0, -50.0)
		x.line_to(28.0, -47.0)
		x.stroke()
	elif q.happy:
		x.set_stroke(eye_col)
		x.lw = 1.5
		x.cap_round = true
		x.begin_path()
		x.arc(29.5, -47.8, 2.2, PI, 0.0)
		x.stroke()
	elif fposmod(tt * 0.9 + si * 0.37, 3.4) < 0.12:
		x.set_stroke(eye_col)
		x.lw = 1.2
		x.begin_path()
		x.move_to(28.0, -48.5)
		x.line_to(31.0, -48.5)
		x.stroke()
	else:
		x.set_fill(eye_col)
		x.begin_path()
		x.arc(29.5, -48.5, 1.5, 0.0, 7.0)
		x.fill()
	x.restore()
	x.restore()
