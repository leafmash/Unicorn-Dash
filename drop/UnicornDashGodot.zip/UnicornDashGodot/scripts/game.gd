extends Node2D

const Util = preload("res://scripts/util.gd")
const Data = preload("res://scripts/data.gd")
const Ent = preload("res://scripts/entities.gd")
const Ctx = preload("res://scripts/ctx.gd")
const Uni = preload("res://scripts/unicorn.gd")
const Obstacles = preload("res://scripts/obstacles.gd")
const Scene = preload("res://scripts/scene.gd")
const Ui = preload("res://scripts/ui.gd")
const OT = Data.OT

const G := 290.0
const STEP := 1.0 / 120.0
const RISE_HELD := 1500.0
const RISE_FREE := 2900.0
const FALL := 2800.0

const ST_MENU := 0
const ST_PLAY := 1
const ST_DEAD := 2
const ST_PAUSE := 3

var x
var uni
var obd
var scn
var ui

var W: float = 1280.0
var H: float = 576.0
var u: float = 1.6
var L: float = 520.0
var ty: float = 0.0
var ML: float = 22.0
var MR: float = 22.0

var st: int = ST_MENU
var st_at: float = 0.0
var acc: float = 0.0
var alpha_i: float = 1.0
var end_at: float = 0.0
var clock: float = 0.0
var fade: float = 1.0
var fade_dir: int = -1
var fade_cb: Callable = Callable()

var zone_i: int = 0
var zone: Dictionary = Data.ZN[0]

var p = Ent.Player.new()
var obs: Array = []
var items: Array = []
var parts: Array = []
var part_pool: Array = []
var pops: Array = []
var trail: Array = []
var amb: Array = []
var tq: Array = []

var toast_text: String = ""
var toast_life: float = 0.0
var banner_text: String = ""
var banner_sub: String = ""
var banner_life: float = 0.0
var banner_max: float = 2.8

var score: float = 0.0
var shown: float = 0.0
var coins: int = 0
var speed: float = 320.0
var gap: float = 520.0
var dist: float = 0.0
var t: float = 0.0
var shake: float = 0.0
var flash: float = 0.0
var combo: int = 0
var combo_t: float = 0.0
var grace: float = 0.0
var buffer: float = 0.0
var run_dist: float = 0.0
var run_dodge: int = 0
var run_combo: int = 0
var run_near: int = 0
var boost: float = 1.0
var dust_t: float = 0.0
var hint: float = 0.0
var new_best: bool = false
var punch: float = 0.0
var frame: int = 0
var mile: int = 0
var trail_t: float = 0.0
var last_t: int = -1
var last_t2: int = -1
var cam_lift: float = 0.0
var got: int = 0

var best: int = 0
var bank: int = 0
var runs: int = 0
var skin: int = 0
var trail_sel: int = 0
var horn_sel: int = 0
var opt_vib: bool = true

var key_jump: bool = false
var key_duck: bool = false
var ptr_duck: int = 0
var ptr_jumps: int = 0
var ptr_ids: Dictionary = {}

var q = Uni.UniQ.new()
var lob_fx: float = 1.0
var lob_tg: float = 1.0
var lob_g: float = 0.0
var lob_gt: float = 0.0
var lob_next: float = 2.5
var lob_hop: float = 0.0
var lob_gh: float = 0.0
var lob_px: float = 0.0
var lob_ptx: float = 0.0
var lob_wk: float = 0.0
var lob_wph: float = 0.0
var lob_wnext: float = 1.5

var btns: Array = []
var down_id: String = ""
var bs: Dictionary = {}
var shot_mode: bool = false

var LP: Array = []


func _ready() -> void:
	randomize()
	x = Ctx.new()
	uni = Uni.new(x)
	obd = Obstacles.new(x, self)
	scn = Scene.new(x, self)
	ui = Ui.new(x, self)
	for i in 15:
		if i == 0:
			LP.append([38.0, -70.0])
		elif i == 1:
			LP.append([35.0, -45.0])
		elif i == 2:
			LP.append([27.0, -52.0])
		elif i == 3:
			LP.append([-44.0, -10.0])
		elif i == 4:
			LP.append([-32.0, -26.0])
		elif i == 5:
			LP.append([13.0, 0.0])
		elif i == 6:
			LP.append([-12.0, 0.0])
		else:
			var k := float(i - 7)
			LP.append([20.0 * cos(k * PI / 4.0), -27.0 + 11.0 * sin(k * PI / 4.0)])
	load_save()
	get_viewport().size_changed.connect(fit_screen)
	fit_screen()
	set_zone(0)
	reset_run()
	st = ST_MENU
	fade = 1.0
	fade_dir = -1


func fit_screen() -> void:
	var s := get_viewport_rect().size
	W = s.x
	H = s.y
	u = minf(H / 360.0, W / 520.0)
	L = W / u
	ty = (H / u - 360.0) / 2.0
	ML = 22.0
	MR = 22.0
	p.x = maxf(90.0, L * 0.17)


func load_save() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://save.cfg") == OK:
		best = int(cf.get_value("run", "best", 0))
		bank = int(cf.get_value("run", "bank", 0))
		runs = int(cf.get_value("run", "runs", 0))
		skin = clampi(int(cf.get_value("look", "skin", 0)), 0, Data.SK.size() - 1)
		trail_sel = clampi(int(cf.get_value("look", "trail", 0)), 0, Data.TR.size() - 1)
		horn_sel = clampi(int(cf.get_value("look", "horn", 0)), 0, Data.HR.size() - 1)


func save_game() -> void:
	var cf := ConfigFile.new()
	cf.set_value("run", "best", best)
	cf.set_value("run", "bank", bank)
	cf.set_value("run", "runs", runs)
	cf.set_value("look", "skin", skin)
	cf.set_value("look", "trail", trail_sel)
	cf.set_value("look", "horn", horn_sel)
	cf.save("user://save.cfg")


func now_ms() -> float:
	return float(Time.get_ticks_msec())


func rnd() -> float:
	return randf()


func buzz(ms: int) -> void:
	if opt_vib and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)


func snd(_name: String, _v: float = 0.0) -> void:
	pass


func say(s: String) -> void:
	tq.append(s)


func set_zone(i: int) -> void:
	zone_i = i
	zone = Data.ZN[i]
	scn.amb_init()


func go(n: int, delay: float = 0.0) -> void:
	st = n
	st_at = now_ms() + delay


func cover(cb: Callable) -> void:
	if fade_dir > 0:
		return
	fade_dir = 1
	fade_cb = cb


func reset_run() -> void:
	p = Ent.Player.new()
	p.x = maxf(90.0, L * 0.17)
	obs.clear()
	items.clear()
	for pt in parts:
		part_pool.append(pt)
	parts.clear()
	trail.clear()
	pops.clear()
	tq.clear()
	toast_text = ""
	toast_life = 0.0
	banner_text = ""
	banner_sub = ""
	banner_life = 0.0
	score = 0.0
	shown = 0.0
	coins = 0
	combo = 0
	combo_t = 0.0
	grace = 0.0
	buffer = 0.0
	run_dist = 0.0
	run_dodge = 0
	run_combo = 0
	run_near = 0
	dust_t = 0.0
	got = 0
	mile = 0
	last_t = -1
	last_t2 = -1
	speed = 320.0
	boost = 1.0
	gap = 520.0
	dist = 0.0
	t = 0.0
	shake = 0.0
	flash = 0.0
	acc = 0.0
	new_best = false
	hint = 5.0 if runs < 3 else 0.0


func begin_run() -> void:
	set_zone(zone_i)
	reset_run()
	banner_text = zone.name
	banner_sub = "ENDLESS"
	banner_life = 2.8
	banner_max = 2.8
	save_game()
	go(ST_PLAY)


func start_run() -> void:
	cover(begin_run)


func to_menu() -> void:
	cover(func():
		reset_run()
		go(ST_MENU)
	)


func pause_game() -> void:
	clear_pointers()
	if st == ST_PLAY:
		go(ST_PAUSE)


func clear_pointers() -> void:
	ptr_ids.clear()
	ptr_jumps = 0
	ptr_duck = 0
	key_jump = false
	key_duck = false


func act(id: String) -> void:
	match id:
		"play":
			start_run()
		"pause":
			pause_game()
		"resume":
			if st == ST_PAUSE:
				go(ST_PLAY)
		"restart":
			start_run()
		"menu":
			to_menu()


func jump() -> bool:
	if p.dead:
		return false
	if not p.air:
		p.vy = -700.0
		p.air = true
		p.jumps = 1
		p.sq = 1.18
		snd("jump")
		buzz(8)
		for i in 4:
			spark(p.x - 10.0 + i * 5.0, G - 2.0, -40.0 - rnd() * 60.0, -20.0 - rnd() * 30.0, 0.4, 3.0 + rnd() * 3.0, 40.0, 30.0, 88.0, 0.6, 0.2)
		return true
	if p.jumps < 2:
		p.vy = -620.0
		p.jumps = maxi(2, p.jumps + 1)
		p.sq = 1.14
		burst(p.x - 8.0, p.y - 10.0, 12, 300.0, 130.0)
		snd("djump")
		return true
	return false


func press() -> void:
	if st == ST_PLAY and not jump():
		buffer = 0.12


func spark(px: float, py: float, vx: float, vy: float, life: float, size: float, h: float, sat: float, lum: float, a: float, gr: float) -> void:
	var pt
	if part_pool.size() > 0:
		pt = part_pool.pop_back()
	else:
		pt = Ent.Part.new()
	pt.x = px
	pt.y = py
	pt.vx = vx
	pt.vy = vy
	pt.life = life
	pt.maxl = life
	pt.s = size
	pt.h = h
	pt.sat = sat
	pt.lum = lum
	pt.a = a
	pt.gr = gr
	parts.append(pt)


func burst(px: float, py: float, n: int, hue: float, power: float = 170.0) -> void:
	for i in n:
		var a := rnd() * 6.283
		var s := rnd() * power
		spark(px, py, cos(a) * s, sin(a) * s - 70.0, 0.5 + rnd() * 0.4, 4.0 + rnd() * 6.0, hue, 0.0 if hue == 0.0 else 100.0, 100.0 if hue == 0.0 else 70.0, 1.0, 1.0)


func step_parts(dt: float) -> void:
	var w := 0
	for i in parts.size():
		var pt = parts[i]
		pt.vy += 600.0 * dt * pt.gr
		pt.x += pt.vx * dt
		pt.y += pt.vy * dt
		pt.life -= dt
		if pt.life > 0.0:
			parts[w] = pt
			w += 1
		else:
			part_pool.append(pt)
	parts.resize(w)


func trail_fx() -> void:
	var f: String = Data.TR[trail_sel].fx
	if f == "dust":
		return
	var px: float = p.x - 16.0
	var py: float = p.y - 20.0 + (rnd() - 0.5) * 10.0
	match f:
		"star":
			spark(px, py, -40.0 - rnd() * 30.0, (rnd() - 0.5) * 40.0, 0.7, 4.0 + rnd() * 3.0, 48.0, 100.0, 78.0, 0.9, 0.0)
		"heart":
			spark(px, py, -30.0 - rnd() * 30.0, -20.0 - rnd() * 20.0, 0.8, 4.0 + rnd() * 3.0, 335.0, 100.0, 80.0, 0.9, -0.1)
		"snow":
			spark(px, py, -30.0 - rnd() * 30.0, (rnd() - 0.5) * 20.0, 1.0, 3.0 + rnd() * 3.0, 200.0, 40.0, 96.0, 0.85, 0.15)
		"ember":
			spark(px, py, -30.0 - rnd() * 30.0, -10.0 - rnd() * 20.0, 0.7, 3.0 + rnd() * 3.0, 20.0, 100.0, 60.0, 0.9, -0.35)
		"spark":
			spark(px, py, -50.0 - rnd() * 30.0, (rnd() - 0.5) * 60.0, 0.5, 3.0 + rnd() * 3.0, 180.0 if rnd() < 0.5 else 300.0, 100.0, 68.0, 0.9, 0.0)
		_:
			spark(px, py, -40.0 - rnd() * 30.0, (rnd() - 0.5) * 30.0, 0.8, 4.0 + rnd() * 3.0, 45.0, 100.0, 72.0, 0.9, 0.05)


func near_miss() -> void:
	run_near += 1
	score += 15.0
	punch = maxf(punch, 0.7)
	pops.append(Ent.Pop.new("Close call! +15", p.x + 14.0, p.y - 74.0, 1.1))
	snd("near")


func place_obs(at: float, type: int, w: int, seed_v: float, dx: float) -> void:
	var ox := L + 50.0 + dx
	var v := 1.0
	if type == OT.BIRD:
		v = 1.12
	elif type == OT.FIRE:
		v = 1.1
	elif type == OT.BOULDER:
		v = 1.4
	var o = Ent.Obs.new(ox, type, w, seed_v, v)
	if type == OT.PIT:
		o.pw = 100.0 + 60.0 * (w - 1)
	obs.append(o)
	match type:
		OT.CRYSTAL, OT.SPIN, OT.FIRE, OT.SPIKES:
			for i in 5:
				items.append(Ent.Item.new("coin", ox - 60.0 + i * 30.0, G - 38.0 - 90.0 * sin(PI * i / 4.0), float(i), v, false))
		OT.PIT:
			for i in 5:
				items.append(Ent.Item.new("coin", ox - o.pw / 2.0 + i * o.pw / 4.0, G - 40.0 - 80.0 * sin(PI * i / 4.0), float(i), v, false))
		OT.PILLAR, OT.WALL:
			for i in 5:
				items.append(Ent.Item.new("coin", ox - 60.0 + i * 30.0, G - 70.0 - 80.0 * sin(PI * i / 4.0), float(i), v, false))
		OT.ICE:
			for i in 5:
				items.append(Ent.Item.new("coin", ox - 60.0 + i * 30.0, G - 16.0, float(i), v, false))
		OT.BOULDER:
			pass
		_:
			for i in 3:
				items.append(Ent.Item.new("coin", ox - 30.0 + i * 30.0, G - 16.0, float(i), v, false))


func spawn() -> void:
	var d := minf(score / 2500.0, 1.0)
	var zs: String = zone.zs
	var w: Array = []
	w.resize(15)
	w.fill(0.0)
	w[OT.CRYSTAL] = 0.55
	w[OT.SPIKES] = 0.5 if score > 15.0 else 0.0
	w[OT.BOULDER] = 0.35 if score > 100.0 else 0.0
	w[OT.STORM_LOW] = 0.3 + 0.1 * d if score > 80.0 else 0.0
	w[OT.STORM_HIGH] = 0.2 + 0.12 * d if score > 80.0 else 0.0
	w[OT.SWING] = 0.38 if score > 180.0 else 0.0
	w[OT.LASER] = 0.38 if score > 220.0 else 0.0
	w[OT.WISP] = 0.14 if score > 300.0 else 0.0
	w[OT.PIT] = 0.18 if score > 120.0 else 0.0
	w[OT.SPIN] = 0.15 if score > 200.0 else 0.0
	w[OT.BIRD] = 0.15 if score > 260.0 else 0.0
	w[OT.WALL] = 0.33 if score > 260.0 else 0.0
	w[OT.PILLAR] = 0.12 if score > 350.0 else 0.0
	w[OT.ICE] = 0.2 if zs == "ice" and score > 60.0 else 0.0
	w[OT.FIRE] = 0.3 if zs == "fire" and score > 60.0 else 0.0
	for k in 15:
		if k == last_t:
			w[k] *= 0.15
		elif k == last_t2:
			w[k] *= 0.55
	if score > 250.0 and rnd() < 0.12 + 0.16 * d:
		var pool: Array = []
		var all: Array = []
		all.append_array(Data.COMBOS)
		all.append_array(Data.ECOMBOS)
		for c in all:
			var ok := true
			for e in c:
				if not (w[e[0]] > 0.0 or e[0] == last_t):
					ok = false
			if ok:
				pool.append(c)
		if pool.size() > 0:
			var c2: Array = pool[int(floor(rnd() * pool.size()))]
			var dx := 0.0
			for i in c2.size():
				var e2: Array = c2[i]
				if i > 0:
					dx += speed * e2[1]
				place_obs(0.0, e2[0], e2[2], rnd() * 99.0, dx)
			last_t2 = c2[c2.size() - 2][0] if c2.size() > 1 else last_t
			last_t = c2[c2.size() - 1][0]
			gap = dx + speed * (1.0 - 0.25 * d) + rnd() * speed * 0.6
			return
	var total := 0.0
	for v in w:
		total += v
	var qv := rnd() * total
	var type: int = OT.CRYSTAL
	for k in 15:
		qv -= w[k]
		if qv <= 0.0:
			type = k
			break
	last_t2 = last_t
	last_t = type
	var wd := 1
	if (type == OT.CRYSTAL and rnd() < 0.3 + 0.3 * d) or (type == OT.PIT and rnd() < 0.3 + 0.3 * d):
		wd = 2
	place_obs(0.0, type, wd, rnd() * 99.0, 0.0)
	gap = speed * (0.92 - 0.28 * d) + rnd() * speed * 0.6
	if type == OT.PIT:
		gap += 160.0 if wd == 2 else 100.0


func collect(it) -> void:
	if it.k == "coin":
		var prev := combo
		combo = mini(combo + 1, 5) if combo_t > 0.0 else 1
		combo_t = 1.6
		run_combo = maxi(run_combo, combo)
		if (combo == 3 or combo == 5) and prev != combo:
			pops.append(Ent.Pop.new("x" + str(combo), p.x + 24.0, p.y - 60.0, 0.9))
			punch = maxf(punch, 0.6)
		if not it.bonus:
			got += 1
		coins += 1
		score += 5.0 * combo
		burst(it.x, it.y, 7, 45.0, 120.0)
		snd("coin", float(combo))


func low_y(th: float) -> float:
	var c := cos(th)
	var sn := sin(th)
	var m := 0.0
	for pt in LP:
		m = maxf(m, pt[0] * sn + pt[1] * c)
	return m


func crash(o) -> void:
	die(o)


func die(o) -> void:
	var ty2: int = o.type if o != null else -1
	var k := "impact"
	if ty2 == OT.PIT:
		k = "pit"
	elif ty2 == OT.STORM_LOW or ty2 == OT.STORM_HIGH or ty2 == OT.WISP:
		k = "zap"
	elif ty2 == OT.BIRD:
		k = "bird"
	elif ty2 == OT.FIRE:
		k = "fire"
	go(ST_DEAD, 1150.0 if k == "zap" else 800.0)
	end_at = now_ms()
	p.dead = true
	punch = 1.2
	p.kind = k
	p.hy = p.y
	p.hold = 0.0
	p.rest = false
	p.landed = false
	p.bounces = 0
	p.end_ang = -2.6
	p.spin = -7.0
	p.vx = -90.0
	p.vy = -380.0
	p.fall = false
	p.jx = 0.0
	shake = 12.0
	flash = 1.0
	burst(p.x, p.y - 22.0, 22, 330.0, 260.0)
	if k == "pit" and o != null:
		p.fall = true
		p.has_pit = true
		p.pit0 = o.x - o.pw / 2.0
		p.pit1 = o.x + o.pw / 2.0
		p.vy = 40.0
		p.vx = 0.0
		p.spin = -1.8
		shake = 5.0
		flash = 0.5
		for i in 12:
			spark(p.x + (rnd() - 0.5) * 30.0, G - 2.0, (rnd() - 0.5) * 150.0, -30.0 - rnd() * 70.0, 0.5, 4.0 + rnd() * 5.0, 36.0, 28.0, 80.0, 0.7, 0.3)
		snd("fall")
	elif k == "zap":
		p.hold = 0.38
		p.vy = -40.0
		p.vx = -30.0
		p.spin = -3.2
		shake = 7.0
		burst(p.x, p.y - 24.0, 26, 55.0, 280.0)
		snd("zap")
	elif k == "bird":
		p.vx = -170.0
		p.vy = -260.0
		p.spin = -12.0
		for i in 16:
			spark(p.x, p.y - 30.0, (rnd() - 0.5) * 220.0, -rnd() * 170.0, 0.9, 3.0 + rnd() * 4.0, 260.0, 30.0, 30.0, 0.9, 0.6)
		snd("break")
	elif k == "fire":
		p.vx = -70.0
		p.vy = -300.0
		p.spin = -5.0
		burst(p.x, p.y - 20.0, 22, 22.0, 260.0)
	elif o != null:
		if ty2 == OT.CRYSTAL:
			o.dead = true
			burst(o.x, G - 18.0, 18, fposmod(zone.hue + 40.0, 360.0), 260.0)
			snd("break")
		elif ty2 == OT.SPIN:
			burst(o.x, G - 16.0, 16, 50.0, 260.0)
		elif ty2 == OT.PILLAR:
			p.vx = -150.0
			p.vy = -230.0
			for i in 14:
				spark(o.x, G - 30.0, (rnd() - 0.5) * 200.0, -rnd() * 150.0, 0.7, 4.0 + rnd() * 5.0, 30.0, 20.0, 70.0, 0.7, 0.5)
	snd("die")
	buzz(120)
	bank += coins
	var sc := int(floor(score))
	new_best = sc > best
	if new_best:
		best = sc
	runs += 1
	save_game()


func dead_step(dt: float) -> void:
	var k := lerpf(0.25, 1.0, Util.ease_out(clampf((now_ms() - end_at) / 700.0, 0.0, 1.0)))
	var d := dt * k
	p.py = p.y
	if p.fall:
		p.vy += 1900.0 * d
		p.y += p.vy * d
		p.x = Util.damp(p.x, clampf(p.x, p.pit0 + 20.0, p.pit1 - 20.0), 9.0, d)
		p.ang += p.spin * d
		if p.y > G + 140.0:
			p.y = G + 140.0
			p.vy = 0.0
		p.air = true
		return
	if p.rest:
		p.x += p.vx * d
		p.vx = Util.damp(p.vx, 0.0, 6.0, d)
		p.ang = Util.damp(p.ang, p.end_ang, 7.0, d)
		p.y = G - low_y(p.ang)
		p.air = false
		return
	if p.hold > 0.0:
		p.hold -= d
		p.y = p.hy - 4.0 + sin(clock * 60.0) * 2.4
		p.jx = sin(clock * 90.0) * 2.5
		p.ang = sin(clock * 55.0) * 0.14
		p.vy = -40.0
		if p.hold <= 0.0:
			p.jx = 0.0
			p.ang = 0.0
			p.vy = 0.0
		p.air = true
		return
	p.vy += 2200.0 * d
	p.y += p.vy * d
	p.x += p.vx * d
	p.vx = Util.damp(p.vx, 0.0, 3.0, d)
	p.ang += p.spin * d
	var gy := G - low_y(p.ang)
	if p.y >= gy:
		p.y = gy
		land_fx(clampf(p.vy / 1100.0, 0.0, 1.0))
		if p.vy > 260.0 and p.bounces < 1:
			p.bounces += 1
			p.vy *= -0.3
			p.spin *= 0.5
		else:
			p.vy = 0.0
			p.rest = true
			p.landed = true
			p.ang = p.end_ang + round((p.ang - p.end_ang) / 6.2832) * 6.2832
	p.air = not p.rest


func land_fx(imp: float) -> void:
	var cnt := 8 + int(round(10.0 * imp))
	for i in cnt:
		spark(p.x + (rnd() - 0.5) * 34.0, G - 2.0, (rnd() - 0.5) * (120.0 + 200.0 * imp), -20.0 - rnd() * (50.0 + 90.0 * imp), 0.55, 4.0 + rnd() * (4.0 + 4.0 * imp), 36.0, 28.0, 80.0, 0.65, 0.25)
	shake = maxf(shake, 3.0 + 7.0 * imp)
	snd("land", imp)


func effects(dt: float) -> void:
	shown += (score - shown) * (1.0 - exp(-dt * 12.0))
	shake *= exp(-dt * 9.0)
	punch *= exp(-dt * 9.0)
	flash = maxf(0.0, flash - dt * 2.0)
	toast_life = maxf(0.0, toast_life - dt)
	if toast_life <= 0.0 and tq.size() > 0:
		toast_text = tq.pop_front()
		toast_life = 1.8
	banner_life = maxf(0.0, banner_life - dt)
	var w := 0
	for i in pops.size():
		var pp = pops[i]
		pp.life -= dt
		pp.y -= 34.0 * dt
		if pp.life > 0.0:
			pops[w] = pp
			w += 1
	pops.resize(w)
	if st == ST_DEAD and p.dead and not p.fall and now_ms() - end_at < 2600.0:
		if (p.kind == "fire" or p.kind == "zap") and rnd() < dt * 22.0:
			spark(p.x + (rnd() - 0.5) * 24.0, p.y - 14.0 - rnd() * 14.0, (rnd() - 0.5) * 16.0, -26.0 - rnd() * 24.0, 1.1, 6.0 + rnd() * 4.0, 0.0, 0.0, 50.0 + rnd() * 18.0, 0.42, -0.25)
		if p.kind == "fire" and rnd() < dt * 30.0:
			spark(p.x + (rnd() - 0.5) * 26.0, p.y - 10.0 - rnd() * 16.0, (rnd() - 0.5) * 30.0, -40.0 - rnd() * 40.0, 0.8, 3.0 + rnd() * 2.0, 24.0, 100.0, 60.0, 0.9, -0.35)
	step_parts(dt)


func near_on_ice() -> bool:
	if p.air:
		return false
	for o in obs:
		if o.type == OT.ICE and absf(o.x - p.x) < 66.0:
			return true
	return false


func update(dt: float) -> void:
	t += dt
	frame += 1
	var on_ice := near_on_ice()
	var bt := 1.28 if on_ice else 1.0
	boost = Util.damp(boost, bt, 3.2, dt)
	speed = (320.0 + 360.0 * (1.0 - exp(-score / 3000.0)) + 140.0 * (1.0 - exp(-maxf(0.0, score - 1500.0) / 8000.0))) * boost
	dist += speed * dt
	run_dist += speed * dt
	score += speed * dt * 0.05
	hint = maxf(0.0, hint - dt)
	p.duck = key_duck or ptr_duck > 0
	p.dk = Util.damp(p.dk, 1.0 if p.duck else 0.0, 24.0, dt)
	var held := key_jump or ptr_jumps > 0
	p.py = p.y
	var gr := FALL
	if p.vy < 0.0:
		gr = RISE_HELD if held else RISE_FREE
	elif p.duck and p.air:
		gr = FALL * 2.0
	p.vy += gr * dt
	p.y += p.vy * dt
	if p.y >= G:
		if p.air:
			var imp := clampf(p.vy / 1100.0, 0.0, 1.0)
			p.sq = 0.9 - 0.12 * imp
			for i in 6:
				spark(p.x + (rnd() - 0.5) * 18.0, G - 2.0, (rnd() - 0.5) * 160.0, -20.0 - rnd() * 50.0, 0.45, 3.0 + rnd() * 3.0, 40.0, 30.0, 88.0, 0.6, 0.25)
			snd("land", imp)
		p.y = G
		p.vy = 0.0
		p.air = false
		p.jumps = 0
		if buffer > 0.0:
			jump()
	buffer = maxf(0.0, buffer - dt)
	p.rt += dt
	p.sq = Util.damp(p.sq, 1.0, 14.0, dt)
	p.ang = Util.damp(p.ang, clampf(p.vy * 0.0004, -0.28, 0.28), 12.0, dt)
	dust_t -= dt
	if not p.air and dust_t <= 0.0:
		dust_t = 0.075
		spark(p.x - 14.0, G - 2.0, -speed * 0.18 - rnd() * 30.0, -16.0 - rnd() * 24.0, 0.42, 3.0 + rnd() * 3.0, 40.0, 30.0, 88.0, 0.5, 0.2)
	trail_t -= dt
	if trail_t <= 0.0:
		trail_t = 0.05
		trail_fx()
	if frame % 2 == 0:
		trail.append(Ent.TrailPt.new(p.y - lerpf(28.0, 16.0, p.dk), t))
	while trail.size() > 0 and t - trail[0].t > 0.4:
		trail.pop_front()
	gap -= speed * dt
	if gap <= 0.0:
		spawn()
	for o in obs:
		o.x -= speed * dt * o.v
	for o in obs:
		if not o.passed and o.x < p.x - 30.0:
			o.passed = true
			run_dodge += 1
			if o.nm and not o.dead:
				near_miss()
	var keep: Array = []
	for o in obs:
		if o.x > -60.0 and not o.dead:
			keep.append(o)
	obs = keep
	var cx: float = p.x
	var cy: float = p.y - 22.0
	for it in items:
		it.x -= speed * dt * it.v
		if Vector2(cx - it.x, cy - it.y).length() < 28.0:
			collect(it)
			it.gone = true
	var keep_i: Array = []
	for it in items:
		if not it.gone and it.x > -30.0:
			keep_i.append(it)
	items = keep_i
	var me := [p.x - 11.0, p.y - lerpf(42.0, 22.0, p.dk), p.x + 11.0, p.y - 7.0]
	for o in obs:
		if o.dead or o.type == OT.ICE:
			continue
		if o.type == OT.PIT:
			if not p.air and grace <= 0.0 and p.x + 8.0 > o.x - o.pw / 2.0 and p.x - 8.0 < o.x + o.pw / 2.0:
				crash(o)
				return
			continue
		var bxs: Array = obd.boxes(o)
		var hit := false
		for b in bxs:
			if me[0] < b[2] and me[2] > b[0] and me[1] < b[3] and me[3] > b[1]:
				hit = true
		if not hit:
			if not o.nm:
				for b in bxs:
					var dx := maxf(b[0] - me[2], me[0] - b[2])
					var dy := maxf(b[1] - me[3], me[1] - b[3])
					if dx < 0.0 and dy >= 0.0 and dy < 8.0:
						o.nm = true
			continue
		if grace > 0.0:
			continue
		crash(o)
		return
	combo_t -= dt
	if combo_t <= 0.0:
		combo = 0
	grace = maxf(0.0, grace - dt)
	var m := int(floor(score / 250.0))
	if m > mile:
		mile = m
		var msgs := ["", "Nice run", "Rainbow speed", "Unstoppable", "Legend"]
		say(msgs[mini(m, 4)])
		snd("milestone")


func lobby_tick(dt: float) -> void:
	var dx := lob_ptx - lob_px
	var moving := absf(dx) > 1.5
	if moving:
		var dir := 1.0 if dx > 0.0 else -1.0
		lob_tg = dir
		if absf(lob_fx - dir) < 0.4 and lob_hop <= 0.0:
			var sp := 56.0 * clampf(absf(dx) / 18.0, 0.3, 1.0)
			lob_px += dir * minf(absf(dx), sp * dt)
			lob_wph += sp * 0.0997 * dt
			lob_wk = Util.damp(lob_wk, 1.0, 7.0, dt)
		else:
			lob_wk = Util.damp(lob_wk, 0.0, 9.0, dt)
	else:
		lob_wk = Util.damp(lob_wk, 0.0, 6.0, dt)
		lob_wnext -= dt
		if lob_wnext <= 0.0:
			var tgt := (rnd() * 2.0 - 1.0) * 72.0
			if absf(tgt - lob_px) < 34.0:
				tgt = -50.0 - rnd() * 20.0 if lob_px > 0.0 else 50.0 + rnd() * 20.0
			lob_ptx = tgt
			lob_wnext = 2.2 + rnd() * 3.2
	lob_next -= dt
	if lob_next <= 0.0:
		var r := rnd()
		if r < 0.38:
			if not moving:
				lob_tg = -lob_tg
			lob_next = 4.5 + rnd() * 3.0
		else:
			lob_gt = 1.0 if rnd() < 0.5 else -1.0
			lob_gh = 0.9
			lob_next = 2.4 + rnd() * 2.6
	if lob_gh > 0.0:
		lob_gh -= dt
		if lob_gh <= 0.0:
			lob_gt = 0.0
	lob_fx = Util.damp(lob_fx, lob_tg, 4.2, dt)
	lob_g = Util.damp(lob_g, lob_gt, 5.0, dt)
	if lob_hop > 0.0:
		lob_hop = maxf(0.0, lob_hop - dt)


func step(dt_in: float) -> void:
	var dt := minf(dt_in, 0.05)
	clock += dt
	if fade_dir > 0:
		fade = minf(1.0, fade + dt * 5.0)
		if fade >= 1.0:
			fade_dir = -1
			var f := fade_cb
			fade_cb = Callable()
			if f.is_valid():
				f.call()
	elif fade > 0.0:
		fade = maxf(0.0, fade - dt * 3.2)
	var ts2 := 1.0
	if st == ST_PLAY:
		acc += dt
		var n := 0
		while acc >= STEP - 0.0000001 and n < 10 and st == ST_PLAY:
			update(STEP)
			acc -= STEP
			n += 1
		if n == 10 or acc < 0.0:
			acc = 0.0
		alpha_i = minf(1.0, acc / STEP)
	else:
		acc = 0.0
		alpha_i = 1.0
		if st == ST_MENU:
			t += dt
			dist += 12.0 * dt
			lob_tick(dt)
		if st == ST_DEAD:
			ts2 = lerpf(0.25, 1.0, Util.ease_out(clampf((now_ms() - end_at) / 700.0, 0.0, 1.0)))
			dead_step(dt)
	cam_lift = Util.damp(cam_lift, clampf(G - p.y, 0.0, 220.0) * 0.04 if (st == ST_PLAY or st == ST_DEAD) else 0.0, 7.0, dt)
	if st != ST_PAUSE:
		effects(dt * ts2)
		scn.amb_step(dt)


func lob_tick(dt: float) -> void:
	lobby_tick(dt)


func _process(delta: float) -> void:
	if shot_mode:
		return
	step(delta)
	queue_redraw()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		pause_game()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		back_pressed()


func back_pressed() -> void:
	match st:
		ST_PLAY:
			pause_game()
		ST_PAUSE:
			act("resume")
		ST_DEAD:
			act("menu")
		ST_MENU:
			get_tree().quit()


func hit_button(sp: Vector2) -> String:
	var lp := Vector2(sp.x / u, (sp.y - ty * u) / u)
	for i in range(btns.size() - 1, -1, -1):
		var b: Array = btns[i]
		if (b[0] as Rect2).has_point(lp):
			return b[1]
	return ""


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var id := hit_button(event.position) if event.pressed else ""
		if event.pressed:
			if id != "":
				down_id = id
				act(id)
				return
			if st == ST_PLAY:
				var px: float = event.position.x / u
				if px < L * 0.3:
					ptr_duck += 1
					ptr_ids[event.index] = "d"
				else:
					ptr_ids[event.index] = "j"
					ptr_jumps += 1
					press()
		else:
			down_id = ""
			if ptr_ids.has(event.index):
				var s: String = ptr_ids[event.index]
				ptr_ids.erase(event.index)
				if s == "d":
					ptr_duck = maxi(0, ptr_duck - 1)
				else:
					ptr_jumps = maxi(0, ptr_jumps - 1)
	elif event is InputEventKey:
		var k: InputEventKey = event
		if k.echo:
			return
		if k.keycode == KEY_SPACE or k.keycode == KEY_UP or k.keycode == KEY_W:
			key_jump = k.pressed
			if k.pressed:
				if st == ST_PLAY:
					press()
				elif st == ST_MENU:
					act("play")
				elif st == ST_DEAD and now_ms() > st_at:
					act("restart")
		elif k.keycode == KEY_DOWN or k.keycode == KEY_S:
			key_duck = k.pressed
		elif k.pressed and (k.keycode == KEY_P or k.keycode == KEY_ESCAPE):
			back_pressed()
		elif k.pressed and k.keycode == KEY_ENTER:
			if st == ST_MENU:
				act("play")


func label(text: String, size: float, px: float, py: float, col: Color, align: int = 1) -> void:
	ui.label(text, size, px, py, col, align)


func sparkle(px: float, py: float, s: float, ph: float) -> void:
	ui.sparkle(px, py, s, ph)


func draw_parts() -> void:
	for pt in parts:
		var l: float = pt.life / pt.maxl
		x.halo(pt.x, pt.y, pt.s * 2.2, pt.h, pt.sat, pt.lum, minf(1.0, l * 1.2) * pt.a)


func lobby_actors() -> void:
	var cx: float = L / 2.0
	var fy := 282.0
	scn.lobby_scene(cx)
	scn.dream_ambient()
	var ux := cx + lob_px
	var wk := lob_wk
	var hp := sin(PI * (1.0 - lob_hop / 0.75)) if lob_hop > 0.0 else 0.0
	var br := sin(clock * 1.9)
	var bob := absf(sin(lob_wph)) * 1.6 * wk
	x.set_fill(Util.rgba(0, 0, 0, 0.3))
	x.begin_path()
	x.ellipse(ux, fy + 4.0, 64.0 * (1.0 - hp * 0.3), 9.0 * (1.0 - hp * 0.3), 0.0, 0.0, 7.0)
	x.fill()
	q.clear()
	q.x = ux
	q.y = fy - hp * 46.0 - bob
	q.ang = sin(clock * 0.7) * 0.012
	var hop_sq := 0.0
	if lob_hop > 0.0:
		hop_sq = -0.06 if (hp < 0.12 or lob_hop < 0.1) else 0.04
	q.sq = 1.0 + br * 0.011 + hop_sq
	q.dk = 0.0
	q.air = hp > 0.15
	q.stand = wk < 0.05
	q.gait = 1 if wk > 0.02 else 0
	q.stride = 7.0 * wk
	q.wph = lob_wph
	q.tt = clock * 0.55
	q.happy = lob_hop > 0.0
	q.dead = false
	q.sc = 2.25
	q.hn = horn_sel
	q.fx = lob_fx
	q.nod = lob_g * 0.2 + sin(clock * 0.8) * 0.03
	uni.draw(q, skin)
	draw_parts()


func play_actors(rs: float) -> void:
	var py: float = p.y + (p.py - p.y) * (1.0 - alpha_i)
	var lift := minf(1.0, maxf(0.0, 1.0 - (G - py) / 260.0))
	x.set_fill(Util.rgba(0, 0, 0, 0.22))
	x.begin_path()
	var pf: bool = p.dead and p.fall
	x.ellipse(p.x, G + 4.0, 0.0 if pf else 24.0 * lift, 0.0 if pf else 4.5 * lift, 0.0, 0.0, 7.0)
	x.fill()
	if trail.size() > 2:
		x.cap_round = true
		x.join_round = true
		var tx0: float = p.x - 14.0 - (t - trail[0].t) * speed * 0.45
		var lw := 4.2
		for b in 6:
			x.set_stroke_g(x.lin(tx0, 0.0, p.x - 14.0, 0.0, uni.trail_color(trail_sel, b, t, skin, 0.0), uni.trail_color(trail_sel, b, t, skin, 0.75)))
			x.lw = lw
			x.begin_path()
			for j in trail.size():
				var tp = trail[j]
				var age: float = t - tp.t
				var ptx: float = p.x - 14.0 - age * speed * 0.45
				var pty: float = tp.y + (b - 2.5) * lw + sin(age * 20.0 + b) * 1.3
				if j == 0:
					x.move_to(ptx, pty)
				else:
					x.line_to(ptx, pty)
			x.line_to(p.x - 14.0, py - lerpf(28.0, 16.0, p.dk) + (b - 2.5) * lw)
			x.stroke()
	for it in items:
		var ix: float = it.x + rs
		obd.coin(it, ix)
	for o in obs:
		if o.dead:
			continue
		obd.draw_obs(o, o.x + rs)
	x.save()
	if p.dead and p.fall and p.has_pit:
		x.alpha = clampf(1.0 - (py - G) / 120.0, 0.0, 1.0)
	else:
		x.alpha = 0.45 if (grace > 0.0 and int(floor(t * 16.0)) % 2 != 0) else 1.0
	q.clear()
	q.x = p.x + p.jx
	q.y = py + (0.0 if (p.air or p.dead or p.vic != 0) else sin(t * 34.0) * 0.8)
	q.ang = p.ang
	q.sq = p.sq
	q.dk = p.dk
	q.air = p.air
	q.tt = t
	q.rt = p.rt
	q.sit = 0.0 if p.vic != 0 else p.dk
	q.rear = p.rear
	q.stand = p.stand != 0
	q.happy = p.happy
	q.dead = p.dead
	q.sc = 1.0
	q.hn = horn_sel
	uni.draw(q, skin)
	x.restore()
	if p.dead and p.fall and p.has_pit:
		x.set_fill_g(x.lin(0.0, G, 0.0, 360.0 + ty, Util.hx(zone.soil), Util.hx(zone.edge)))
		x.fill_rect(-20.0, G, p.pit0 + 20.0, 80.0 + ty + 10.0)
		x.fill_rect(p.pit1, G, L - p.pit1 + 20.0, 80.0 + ty + 10.0)
		x.set_fill(Util.hx(zone.edge))
		x.fill_rect(-20.0, G, p.pit0 + 20.0, 6.0)
		x.fill_rect(p.pit1, G, L - p.pit1 + 20.0, 6.0)
	if p.dead and p.kind == "zap" and p.hold > 0.0:
		x.halo(p.x, p.y - 26.0, 70.0, 55.0, 100.0, 75.0, 0.8)
		x.set_stroke(Util.hx(0xfff6a8))
		x.lw = 2.0
		x.join_round = true
		for b in 3:
			var bx0: float = p.x + (rnd() - 0.5) * 20.0
			var by0: float = p.y - 6.0 - rnd() * 10.0
			x.begin_path()
			x.move_to(bx0, by0)
			for i in 5:
				bx0 += (rnd() - 0.5) * 26.0
				by0 -= 8.0 + rnd() * 8.0
				x.line_to(bx0, by0)
			x.stroke()
	draw_parts()
	for pp in pops:
		x.save()
		x.alpha = minf(1.0, pp.life * 2.5)
		label(pp.t, 13.0, pp.x, pp.y, Util.hx(0xffe27a))
		x.restore()


func actors(rs: float) -> void:
	if st == ST_MENU:
		lobby_actors()
		return
	play_actors(rs)


func _draw() -> void:
	if x == null:
		return
	var sp := 1.0 + punch * 0.03
	var base := Transform2D(0.0, Vector2(u * sp, u * sp), 0.0, Vector2(W * 0.5 * (1.0 - sp), H * 0.5 * (1.0 - sp) + sp * (ty + cam_lift) * u))
	x.begin(self, base)
	btns.clear()
	var t_saved := t
	if st == ST_PLAY:
		t -= STEP * (1.0 - alpha_i)
	var rs := speed * STEP * (1.0 - alpha_i) if st == ST_PLAY else 0.0
	x.save()
	if shake > 0.3:
		x.translate(sin(clock * 71.0) * shake * 0.5, cos(clock * 59.0) * shake * 0.5)
	scn.draw_scene(dist - rs)
	actors(rs)
	if st != ST_MENU:
		scn.amb_draw()
	x.restore()
	ui.vignette()
	if flash > 0.0:
		x.set_fill(Util.rgba(255, 60, 100, flash * 0.3))
		x.fill_rect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
	t = t_saved
	ui.draw_ui()
	if fade > 0.0:
		x.set_fill(Util.rgba(20, 8, 60, fade))
		x.fill_rect(0.0, -ty - 10.0, L, 380.0 + ty * 2.0)
