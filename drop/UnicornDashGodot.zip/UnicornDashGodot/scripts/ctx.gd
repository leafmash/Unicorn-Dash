extends RefCounted

const Util = preload("res://scripts/util.gd")

const INK_OUT := 3.2
const INK_COLOR := Color(0.1412, 0.0627, 0.3294, 0.95)

var c: CanvasItem
var font: Font
var tf: Transform2D = Transform2D.IDENTITY
var tf_dirty: bool = true
var stack: Array = []
var alpha: float = 1.0
var fill_c: Color = Color.BLACK
var stroke_c: Color = Color.BLACK
var fill_g = null
var stroke_g = null
var lw: float = 1.0
var cap_round: bool = false
var join_round: bool = false
var ink: bool = false
var dash_on: bool = false
var dash_a: float = 0.0
var dash_b: float = 0.0
var dash_off: float = 0.0
var subs: Array = []
var closed: Array = []
var cur: PackedVector2Array = PackedVector2Array()
var has_pt: bool = false
var halo_tex: ImageTexture
var rad_cache: Dictionary = {}


func _init() -> void:
	font = ThemeDB.fallback_font
	halo_tex = _make_radial([Color(1, 1, 1, 1.0), Color(1, 1, 1, 0.4), Color(1, 1, 1, 0.0)], [0.0, 0.35, 1.0], 64)


func _make_radial(cols: Array, pos: Array, size: int) -> ImageTexture:
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var half := float(size) * 0.5
	for yy in size:
		for xx in size:
			var d := Vector2(float(xx) + 0.5 - half, float(yy) + 0.5 - half).length() / half
			img.set_pixel(xx, yy, _stops_color(cols, pos, d))
	return ImageTexture.create_from_image(img)


func _stops_color(cols: Array, pos: Array, t: float) -> Color:
	var n := cols.size()
	if t <= pos[0]:
		return cols[0]
	if t >= pos[n - 1]:
		return cols[n - 1]
	for i in range(n - 1):
		if t <= pos[i + 1]:
			var k: float = (t - pos[i]) / maxf(pos[i + 1] - pos[i], 0.000001)
			return (cols[i] as Color).lerp(cols[i + 1], k)
	return cols[n - 1]


func begin(canvas: CanvasItem, base: Transform2D) -> void:
	c = canvas
	tf = base
	tf_dirty = true
	stack.clear()
	alpha = 1.0
	fill_c = Color.BLACK
	stroke_c = Color.BLACK
	fill_g = null
	stroke_g = null
	lw = 1.0
	cap_round = false
	join_round = false
	ink = false
	dash_on = false
	dash_off = 0.0
	begin_path()


func _flush() -> void:
	if tf_dirty:
		c.draw_set_transform_matrix(tf)
		tf_dirty = false


func save() -> void:
	stack.append([tf, alpha, fill_c, stroke_c, fill_g, stroke_g, lw, cap_round, join_round, dash_on, dash_a, dash_b, dash_off, ink])


func restore() -> void:
	if stack.is_empty():
		return
	var s: Array = stack.pop_back()
	tf = s[0]
	alpha = s[1]
	fill_c = s[2]
	stroke_c = s[3]
	fill_g = s[4]
	stroke_g = s[5]
	lw = s[6]
	cap_round = s[7]
	join_round = s[8]
	dash_on = s[9]
	dash_a = s[10]
	dash_b = s[11]
	dash_off = s[12]
	ink = s[13]
	tf_dirty = true


func translate(px: float, py: float) -> void:
	tf = tf.translated_local(Vector2(px, py))
	tf_dirty = true


func scale(sx: float, sy: float) -> void:
	tf = tf.scaled_local(Vector2(sx, sy))
	tf_dirty = true


func rotate(a: float) -> void:
	tf = tf.rotated_local(a)
	tf_dirty = true


func set_fill(col: Color) -> void:
	if ink:
		return
	fill_c = col
	fill_g = null


func set_fill_g(g) -> void:
	if ink:
		return
	fill_g = g


func set_stroke(col: Color) -> void:
	if ink:
		return
	stroke_c = col
	stroke_g = null


func set_stroke_g(g) -> void:
	if ink:
		return
	stroke_g = g


func set_dash(a: float, b: float) -> void:
	dash_a = a
	dash_b = b
	dash_on = true


func clear_dash() -> void:
	dash_on = false


func lin(x0: float, y0: float, x1: float, y1: float, c0: Color, c1: Color) -> Dictionary:
	return {"t": 0, "p0": Vector2(x0, y0), "p1": Vector2(x1, y1), "cols": [c0, c1], "pos": [0.0, 1.0]}


func lin_n(x0: float, y0: float, x1: float, y1: float, cols: Array, pos: Array) -> Dictionary:
	return {"t": 0, "p0": Vector2(x0, y0), "p1": Vector2(x1, y1), "cols": cols, "pos": pos}


func rad(cx: float, cy: float, r: float, c0: Color, c1: Color) -> Dictionary:
	return {"t": 1, "c": Vector2(cx, cy), "r": r, "cols": [c0, c1], "pos": [0.0, 1.0]}


func rad_n(cx: float, cy: float, r: float, cols: Array, pos: Array) -> Dictionary:
	return {"t": 1, "c": Vector2(cx, cy), "r": r, "cols": cols, "pos": pos}


func begin_path() -> void:
	subs.clear()
	closed.clear()
	cur = PackedVector2Array()
	has_pt = false


func _commit() -> void:
	if cur.size() > 0:
		subs.append(cur)
		closed.append(false)
	cur = PackedVector2Array()


func move_to(px: float, py: float) -> void:
	_commit()
	cur.append(Vector2(px, py))
	has_pt = true


func line_to(px: float, py: float) -> void:
	if not has_pt:
		move_to(px, py)
		return
	cur.append(Vector2(px, py))


func quad_to(cx: float, cy: float, px: float, py: float) -> void:
	if not has_pt:
		move_to(cx, cy)
	if cur.size() == 0:
		cur.append(Vector2(cx, cy))
	var p0: Vector2 = cur[cur.size() - 1]
	var p1 := Vector2(cx, cy)
	var p2 := Vector2(px, py)
	var ln := (p1 - p0).length() + (p2 - p1).length()
	var n := clampi(int(ln * tf.x.length() * 0.22), 4, 18)
	for i in range(1, n + 1):
		var t := float(i) / float(n)
		var a := p0.lerp(p1, t)
		var b := p1.lerp(p2, t)
		cur.append(a.lerp(b, t))


func bezier_to(c1x: float, c1y: float, c2x: float, c2y: float, px: float, py: float) -> void:
	if not has_pt:
		move_to(c1x, c1y)
	if cur.size() == 0:
		cur.append(Vector2(c1x, c1y))
	var p0: Vector2 = cur[cur.size() - 1]
	var p1 := Vector2(c1x, c1y)
	var p2 := Vector2(c2x, c2y)
	var p3 := Vector2(px, py)
	var ln := (p1 - p0).length() + (p2 - p1).length() + (p3 - p2).length()
	var n := clampi(int(ln * tf.x.length() * 0.22), 5, 22)
	for i in range(1, n + 1):
		var t := float(i) / float(n)
		cur.append(p0.bezier_interpolate(p1, p2, p3, t))


func close_path() -> void:
	if cur.size() == 0:
		return
	var first: Vector2 = cur[0]
	subs.append(cur)
	closed.append(true)
	cur = PackedVector2Array([first])
	has_pt = true


func rect(px: float, py: float, w: float, h: float) -> void:
	_commit()
	subs.append(PackedVector2Array([Vector2(px, py), Vector2(px + w, py), Vector2(px + w, py + h), Vector2(px, py + h)]))
	closed.append(true)
	cur = PackedVector2Array([Vector2(px, py)])
	has_pt = true


func round_rect(px: float, py: float, w: float, h: float, r_in: float) -> void:
	var r := maxf(0.0, minf(r_in, minf(w, h) * 0.5))
	_commit()
	var pts := PackedVector2Array()
	var seg := clampi(int(r * tf.x.length() * 0.4) + 3, 3, 12)
	var corners := [Vector2(px + w - r, py + r), Vector2(px + w - r, py + h - r), Vector2(px + r, py + h - r), Vector2(px + r, py + r)]
	for k in 4:
		var cc: Vector2 = corners[k]
		for i in range(seg + 1):
			var a := (float(k) + float(i) / float(seg)) * PI * 0.5 - PI * 0.5
			pts.append(cc + Vector2(cos(a), sin(a)) * r)
	subs.append(pts)
	closed.append(true)
	cur = PackedVector2Array([pts[0]])
	has_pt = true


func arc(cx: float, cy: float, r: float, a0: float, a1: float) -> void:
	if r <= 0.0:
		return
	ellipse(cx, cy, r, r, 0.0, a0, a1)


func ellipse(cx: float, cy: float, rx: float, ry: float, rot: float, a0: float, a1: float) -> void:
	if rx <= 0.0 or ry <= 0.0:
		return
	var sweep := a1 - a0
	var full := sweep >= TAU - 0.000001
	if full:
		sweep = TAU
	else:
		if sweep < 0.0:
			sweep += TAU * ceil(-sweep / TAU)
		sweep = fmod(sweep, TAU)
	var n := int(clampf(maxf(rx, ry) * tf.x.length() * 0.45 + 8.0, 10.0, 56.0) * sweep / TAU)
	n = maxi(n, 3)
	var center := Vector2(cx, cy)
	var pts := PackedVector2Array()
	for i in range(n + 1):
		var a := a0 + sweep * float(i) / float(n)
		var p := Vector2(cos(a) * rx, sin(a) * ry)
		if rot != 0.0:
			p = p.rotated(rot)
		pts.append(center + p)
	if cur.size() > 0 and cur[cur.size() - 1].distance_squared_to(pts[0]) > 0.5:
		_commit()
	if cur.size() == 0:
		cur = pts
	else:
		cur.append_array(pts)
	has_pt = true


func circle(px: float, py: float, r: float) -> void:
	move_to(px + r, py)
	arc(px, py, r, 0.0, 7.0)


func oval(px: float, py: float, rx: float, ry: float) -> void:
	move_to(px + rx, py)
	ellipse(px, py, rx, ry, 0.0, 0.0, 7.0)


func _clean(pts: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	for p in pts:
		if out.size() == 0 or out[out.size() - 1].distance_squared_to(p) > 0.000001:
			out.append(p)
	if out.size() > 1 and out[0].distance_squared_to(out[out.size() - 1]) <= 0.000001:
		out.remove_at(out.size() - 1)
	return out


func _area(pts: PackedVector2Array) -> float:
	var a := 0.0
	var n := pts.size()
	for i in n:
		var p: Vector2 = pts[i]
		var q: Vector2 = pts[(i + 1) % n]
		a += p.x * q.y - q.x * p.y
	return a * 0.5


func _col_a(col: Color) -> Color:
	return Color(col.r, col.g, col.b, col.a * alpha)


func _fill_poly(pts0: PackedVector2Array) -> void:
	var pts := _clean(pts0)
	if pts.size() < 3:
		return
	if absf(_area(pts)) < 0.001:
		return
	if fill_g == null:
		c.draw_colored_polygon(pts, _col_a(fill_c))
		return
	var g: Dictionary = fill_g
	if g.t == 0:
		_fill_lin(pts, g)
	else:
		_fill_rad(pts, g)


func _fill_lin(pts: PackedVector2Array, g: Dictionary) -> void:
	var p0: Vector2 = g.p0
	var d: Vector2 = (g.p1 as Vector2) - p0
	var len2 := d.length_squared()
	var cols: Array = g.cols
	var pos: Array = g.pos
	if len2 < 0.000001:
		c.draw_colored_polygon(pts, _col_a(cols[0]))
		return
	var tmin := 1.0e9
	var tmax := -1.0e9
	for p in pts:
		var t := (p - p0).dot(d) / len2
		tmin = minf(tmin, t)
		tmax = maxf(tmax, t)
	var cuts: Array = []
	for q in pos:
		if q > tmin + 0.0001 and q < tmax - 0.0001:
			cuts.append(q)
	if tmin < pos[0] - 0.0001 and not cuts.has(pos[0]) and tmax > pos[0] + 0.0001:
		cuts.append(pos[0])
	if tmax > pos[pos.size() - 1] + 0.0001 and not cuts.has(pos[pos.size() - 1]) and tmin < pos[pos.size() - 1] - 0.0001:
		cuts.append(pos[pos.size() - 1])
	cuts.sort()
	if cuts.is_empty():
		_draw_grad_poly(pts, p0, d, len2, cols, pos)
		return
	var bounds: Array = [-1000.0]
	bounds.append_array(cuts)
	bounds.append(1000.0)
	var perp := d.orthogonal() * 1000.0
	for i in range(bounds.size() - 1):
		var ta: float = bounds[i]
		var tb: float = bounds[i + 1]
		var band := PackedVector2Array([p0 + d * ta + perp, p0 + d * tb + perp, p0 + d * tb - perp, p0 + d * ta - perp])
		var res: Array = Geometry2D.intersect_polygons(pts, band)
		for poly in res:
			var cp := _clean(poly)
			if cp.size() >= 3 and absf(_area(cp)) > 0.001:
				_draw_grad_poly(cp, p0, d, len2, cols, pos)


func _draw_grad_poly(pts: PackedVector2Array, p0: Vector2, d: Vector2, len2: float, cols: Array, pos: Array) -> void:
	var colors := PackedColorArray()
	for p in pts:
		var t := (p - p0).dot(d) / len2
		colors.append(_col_a(_stops_color(cols, pos, t)))
	c.draw_polygon(pts, colors)


func _rad_tex(g: Dictionary) -> ImageTexture:
	var key := ""
	for cc in g.cols:
		key += (cc as Color).to_html(true) + ","
	for q in g.pos:
		key += str(snappedf(q, 0.001)) + ","
	if rad_cache.has(key):
		return rad_cache[key]
	if rad_cache.size() > 120:
		rad_cache.clear()
	var tex := _make_radial(g.cols, g.pos, 48)
	rad_cache[key] = tex
	return tex


func _fill_rad(pts: PackedVector2Array, g: Dictionary) -> void:
	var tex := _rad_tex(g)
	var uvs := PackedVector2Array()
	var colors := PackedColorArray()
	var cc: Vector2 = g.c
	var r: float = g.r
	for p in pts:
		uvs.append(Vector2(0.5, 0.5) + (p - cc) / (2.0 * r))
		colors.append(Color(1, 1, 1, alpha))
	c.draw_polygon(pts, colors, uvs, tex)


func fill() -> void:
	_flush()
	for i in subs.size():
		_fill_poly(subs[i])
	_fill_poly(cur)
	if ink:
		_stroke_all(INK_OUT, true)


func fill_rect(px: float, py: float, w: float, h: float) -> void:
	_flush()
	_fill_poly(PackedVector2Array([Vector2(px, py), Vector2(px + w, py), Vector2(px + w, py + h), Vector2(px, py + h)]))


func stroke() -> void:
	_flush()
	_stroke_all(lw + (INK_OUT if ink else 0.0), false)


func stroke_rect(px: float, py: float, w: float, h: float) -> void:
	_flush()
	var pts := PackedVector2Array([Vector2(px, py), Vector2(px + w, py), Vector2(px + w, py + h), Vector2(px, py + h)])
	_stroke_poly(pts, true, lw + (INK_OUT if ink else 0.0))


func _stroke_all(w: float, force_close: bool) -> void:
	for i in subs.size():
		_stroke_poly(subs[i], closed[i] or force_close, w)
	_stroke_poly(cur, force_close, w)


func _grad_color_at(p: Vector2) -> Color:
	var g: Dictionary = stroke_g
	if g.t == 1:
		var d: float = (p - (g.c as Vector2)).length() / float(g.r)
		return _col_a(_stops_color(g.cols, g.pos, d))
	var p0: Vector2 = g.p0
	var dv: Vector2 = (g.p1 as Vector2) - p0
	var l2 := dv.length_squared()
	var t := 0.0 if l2 < 0.000001 else (p - p0).dot(dv) / l2
	return _col_a(_stops_color(g.cols, g.pos, t))


func _stroke_poly(pts0: PackedVector2Array, is_closed: bool, w: float) -> void:
	var pts := _clean(pts0)
	if pts.size() < 2 or w <= 0.0:
		return
	if not is_closed and pts0.size() > 3 and pts0[0].distance_squared_to(pts0[pts0.size() - 1]) <= 0.000001:
		is_closed = true
	if is_closed:
		pts.append(pts[0])
	if dash_on and not ink:
		for seg in _dash(pts):
			_stroke_line(seg, false, w)
		return
	_stroke_line(pts, is_closed, w)


func _stroke_line(pts: PackedVector2Array, is_closed: bool, w: float) -> void:
	if pts.size() < 2:
		return
	var col := _col_a(stroke_c)
	if stroke_g != null:
		var colors := PackedColorArray()
		for p in pts:
			colors.append(_grad_color_at(p))
		c.draw_polyline_colors(pts, colors, w, true)
		if cap_round and w >= 2.0 and not is_closed:
			c.draw_circle(pts[0], w * 0.5, colors[0])
			c.draw_circle(pts[pts.size() - 1], w * 0.5, colors[colors.size() - 1])
		return
	c.draw_polyline(pts, col, w, true)
	if w >= 2.0 and not is_closed:
		if cap_round:
			c.draw_circle(pts[0], w * 0.5, col)
			c.draw_circle(pts[pts.size() - 1], w * 0.5, col)
		if join_round and pts.size() <= 8 and w >= 3.0:
			for i in range(1, pts.size() - 1):
				c.draw_circle(pts[i], w * 0.5, col)


func _dash(pts: PackedVector2Array) -> Array:
	var segs: Array = []
	var period := dash_a + dash_b
	if period <= 0.001:
		return [pts]
	var pos := fposmod(dash_off, period)
	var on := true
	var left := dash_a
	if pos >= dash_a:
		on = false
		left = period - pos
	else:
		left = dash_a - pos
	var cur_seg := PackedVector2Array()
	if on:
		cur_seg.append(pts[0])
	for i in range(pts.size() - 1):
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		var seg_len := a.distance_to(b)
		var done := 0.0
		while seg_len - done > left:
			done += left
			var p := a.lerp(b, done / seg_len)
			if on:
				cur_seg.append(p)
				segs.append(cur_seg)
				cur_seg = PackedVector2Array()
				left = dash_b
			else:
				cur_seg = PackedVector2Array([p])
				left = dash_a
			on = not on
		left -= seg_len - done
		if on:
			cur_seg.append(b)
	if on and cur_seg.size() > 1:
		segs.append(cur_seg)
	return segs


func halo(px: float, py: float, r: float, h: float, s: float, l: float, a: float) -> void:
	if a <= 0.0 or r <= 0.0 or ink:
		return
	_flush()
	c.draw_texture_rect(halo_tex, Rect2(px - r, py - r, r * 2.0, r * 2.0), false, Util.hsl(h, s, l, minf(1.0, a) * alpha))


func halo_c(px: float, py: float, r: float, col: Color, a: float) -> void:
	if a <= 0.0 or r <= 0.0 or ink:
		return
	_flush()
	c.draw_texture_rect(halo_tex, Rect2(px - r, py - r, r * 2.0, r * 2.0), false, Color(col.r, col.g, col.b, minf(1.0, a) * alpha))


func ink_begin() -> void:
	save()
	fill_c = INK_COLOR
	stroke_c = INK_COLOR
	fill_g = null
	stroke_g = null
	join_round = true
	cap_round = true
	lw = 1.0
	ink = true


func ink_end() -> void:
	ink = false
	restore()


func measure(s: String, size: float) -> float:
	var sc := tf.x.length()
	var fs := maxi(int(round(size * sc)), 4)
	return font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x / sc


func text(s: String, px: float, py: float, size: float, col: Color, align: int = 1, outline: Color = Color(0, 0, 0, 0), outline_w: float = 0.0) -> void:
	var sc := tf.x.length()
	var fs := maxi(int(round(size * sc)), 4)
	var pos: Vector2 = tf * Vector2(px, py)
	c.draw_set_transform_matrix(Transform2D.IDENTITY)
	tf_dirty = true
	var wdt := font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var ox := 0.0
	if align == 1:
		ox = -wdt * 0.5
	elif align == 2:
		ox = -wdt
	var by := pos.y + (font.get_ascent(fs) - font.get_descent(fs)) * 0.5
	var p2 := Vector2(pos.x + ox, by)
	if outline.a > 0.0 and outline_w > 0.0:
		c.draw_string_outline(font, p2, s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, maxi(1, int(ceil(outline_w * sc * 0.5))), _col_a(outline))
	c.draw_string(font, p2, s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, _col_a(col))
