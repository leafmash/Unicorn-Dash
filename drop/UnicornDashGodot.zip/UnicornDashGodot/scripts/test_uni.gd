extends Node2D
const Ctx = preload("res://scripts/ctx.gd")
const Uni = preload("res://scripts/unicorn.gd")
const Util = preload("res://scripts/util.gd")
var x
var u
var n := 0
var tt := 0.0
func _ready():
	x = Ctx.new()
	u = Uni.new(x)
func _process(d):
	tt += d
	queue_redraw()
	n += 1
	if n == 6:
		get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT"))
		get_tree().quit()
func _draw():
	draw_rect(Rect2(0,0,2000,1000), Color("c9b8ff"))
	x.begin(self, Transform2D.IDENTITY)
	var q = u.UniQ.new()
	for i in 6:
		q.clear()
		q.x = 130.0 + i * 190.0
		q.y = 250.0
		q.sc = 2.4
		q.tt = 1.0
		q.air = false
		q.gait = 1
		q.stride = 7.0
		q.wph = i * 0.9
		q.hn = i % 7
		u.draw(q, i)
	for i in 4:
		q.clear()
		q.x = 130.0 + i * 190.0
		q.y = 520.0
		q.sc = 2.4
		q.tt = 1.0 + i * 0.3
		q.air = i == 1
		q.dk = 1.0 if i == 2 else 0.0
		q.hn = 0
		q.happy = i == 3
		u.draw(q, 6 + i)
	u.ribbon(100.0, 400.0, 350.0, 1, tt, 0)
