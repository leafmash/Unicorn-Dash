extends RefCounted

const Util = preload("res://scripts/util.gd")
const Data = preload("res://scripts/data.gd")
const OT = Data.OT
const G := 290.0

var x
var g


func _init(ctx, game) -> void:
	x = ctx
	g = game


func zhue() -> float:
	return g.zone.hue


func shard(px: float, h: float, w: float, hue: float) -> void:
	x.set_fill_g(x.lin(0.0, -h, 0.0, 0.0, Util.hsl(hue, 100.0, 86.0), Util.hsl(hue, 80.0, 46.0)))
	x.begin_path()
	x.move_to(px - w, 0.0)
	x.line_to(px - w * 0.55, -h * 0.72)
	x.line_to(px, -h)
	x.line_to(px + w * 0.55, -h * 0.72)
	x.line_to(px + w, 0.0)
	x.close_path()
	x.fill()
	x.set_stroke(Util.hsl(hue, 100.0, 92.0, 0.9))
	x.lw = 1.4
	x.stroke()
	x.begin_path()
	x.move_to(px - w * 0.2, -h * 0.2)
	x.line_to(px - w * 0.1, -h * 0.8)
	x.set_stroke(Util.rgba(255, 255, 255, 0.6))
	x.stroke()


func crystal(o, ox: float) -> void:
	var hue := fposmod(zhue() + 40.0, 360.0)
	x.halo(ox, G - 18.0, 58.0 if o.w == 2 else 36.0, hue, 100.0, 65.0, 0.55 + 0.15 * sin(g.t * 3.0 + o.seed_v))
	x.save()
	x.translate(ox, G)
	if o.w == 2:
		shard(-16.0, 30.0, 9.0, hue)
		shard(14.0, 36.0, 11.0, hue)
		shard(0.0, 22.0, 8.0, hue + 20.0)
	else:
		shard(0.0, 36.0, 11.0, hue)
		shard(-9.0, 20.0, 6.0, hue + 20.0)
	x.restore()


func storm(o, ox: float, cy: float) -> void:
	if g.zone.zs == "ghost":
		ghost(o, ox, cy)
		return
	x.halo(ox, cy, 36.0, 270.0, 80.0, 55.0, 0.45)
	x.set_fill(Util.hx(0x3a2c66))
	x.begin_path()
	x.arc(ox - 10.0, cy + 2.0, 10.0, 0.0, 7.0)
	x.move_to(ox + 20.0, cy)
	x.arc(ox + 10.0, cy, 10.0, 0.0, 7.0)
	x.move_to(ox + 12.0, cy - 6.0)
	x.arc(ox, cy - 6.0, 13.0, 0.0, 7.0)
	x.fill()
	x.set_fill(Util.rgba(190, 170, 255, 0.35))
	x.begin_path()
	x.arc(ox - 3.0, cy - 10.0, 7.0, 0.0, 7.0)
	x.fill()
	if sin(g.t * 9.0 + o.seed_v) > 0.55:
		x.set_stroke(Util.hx(0xfff3a0))
		x.lw = 2.4
		x.join_round = true
		x.begin_path()
		x.move_to(ox + 2.0, cy + 8.0)
		x.line_to(ox - 4.0, cy + 18.0)
		x.line_to(ox + 3.0, cy + 18.0)
		x.line_to(ox - 3.0, cy + 30.0)
		x.stroke()
		x.halo(ox, cy + 18.0, 22.0, 52.0, 100.0, 70.0, 0.6)


func wisp_y(o) -> float:
	return G - 62.0 + sin(g.t * 3.2 + o.seed_v) * 34.0


func wisp(o, ox: float) -> void:
	var cy := wisp_y(o)
	if g.zone.zs == "jelly":
		jelly(o, ox, cy)
		return
	for i in range(4, 0, -1):
		var wy: float = G - 62.0 + sin((g.t - i * 0.05) * 3.2 + o.seed_v) * 34.0
		x.halo(ox + i * 10.0, wy, 14.0 - i * 2.0, 160.0, 100.0, 70.0, 0.45)
	x.halo(ox, cy, 40.0, 160.0, 100.0, 60.0, 0.75)
	x.set_fill(Util.hx(0xeafffa))
	x.begin_path()
	x.arc(ox, cy, 8.0, 0.0, 7.0)
	x.fill()


func portal_fx(ox: float) -> void:
	var cy := G - 52.0
	x.halo(ox, cy, 96.0, 300.0, 100.0, 70.0, 0.6)
	for i in 5:
		x.set_stroke(Util.hsl(fposmod(i * 60.0 + g.clock * 120.0, 360.0), 100.0, 72.0, 0.9))
		x.lw = 4.0
		x.begin_path()
		x.ellipse(ox, cy, 12.0 + i * 2.5 + sin(g.clock * 6.0 + i) * 1.5, 60.0 - i * 5.0, 0.0, 0.0, 7.0)
		x.stroke()
	x.halo(ox, cy, 44.0, 50.0, 100.0, 85.0, 0.5)
	g.sparkle(ox - 24.0, cy - 40.0 + sin(g.clock * 2.0) * 6.0, 7.0, 1.0)
	g.sparkle(ox + 22.0, cy + 10.0 + sin(g.clock * 2.0 + 2.0) * 6.0, 6.0, 3.0)
	g.label("FINISH", 12.0, ox, cy - 78.0, Util.hx(0xffe27a))


func jelly(o, ox: float, cy: float) -> void:
	x.halo(ox, cy, 44.0, 310.0, 80.0, 70.0, 0.6)
	var pul := sin(g.t * 5.0 + o.seed_v) * 2.0
	x.set_fill(Util.rgba(255, 150, 220, 0.88))
	x.begin_path()
	x.arc(ox, cy - 2.0, 12.0 + pul * 0.5, PI, 0.0)
	x.line_to(ox + 12.0, cy + 2.0)
	x.quad_to(ox, cy + 6.0 + pul, ox - 12.0, cy + 2.0)
	x.close_path()
	x.fill()
	x.set_stroke(Util.rgba(255, 190, 235, 0.85))
	x.lw = 2.0
	x.cap_round = true
	for i in range(-2, 3):
		x.begin_path()
		x.move_to(ox + i * 5.0, cy + 3.0)
		x.quad_to(ox + i * 5.0 + sin(g.t * 4.0 + i) * 4.0, cy + 12.0, ox + i * 5.0 + sin(g.t * 4.0 + i + 1.0) * 3.0, cy + 21.0)
		x.stroke()
	x.set_fill(Util.rgba(255, 255, 255, 0.6))
	x.begin_path()
	x.arc(ox - 4.0, cy - 8.0, 3.0, 0.0, 7.0)
	x.fill()


func ghost(o, ox: float, cy: float) -> void:
	var a := 0.6 + 0.3 * sin(g.t * 3.0 + o.seed_v)
	x.halo(ox, cy, 40.0, 200.0, 40.0, 85.0, 0.45)
	x.set_fill(Util.rgba(235, 240, 255, a))
	x.begin_path()
	x.arc(ox, cy - 2.0, 12.0, PI, 0.0)
	x.line_to(ox + 12.0, cy + 12.0)
	x.line_to(ox + 6.0, cy + 7.0)
	x.line_to(ox, cy + 12.0)
	x.line_to(ox - 6.0, cy + 7.0)
	x.line_to(ox - 12.0, cy + 12.0)
	x.close_path()
	x.fill()
	x.set_fill(Util.hx(0x2a2050))
	x.begin_path()
	x.arc(ox - 4.0, cy - 3.0, 2.0, 0.0, 7.0)
	x.move_to(ox + 6.0, cy - 3.0)
	x.arc(ox + 4.0, cy - 3.0, 2.0, 0.0, 7.0)
	x.fill()


func pit(o, ox: float) -> void:
	var w: float = o.pw
	var x0 := ox - w / 2.0
	x.set_fill_g(x.lin(0.0, G, 0.0, G + 90.0, Util.hx(0x060218), Util.hx(0x140834)))
	x.fill_rect(x0, G - 1.0, w, 82.0 + g.ty + 12.0)
	x.halo(ox, G + 46.0, w * 0.6, zhue(), 100.0, 55.0, 0.3)
	x.set_fill(Util.hx(g.zone.edge))
	x.begin_path()
	x.move_to(x0 - 5.0, G)
	x.line_to(x0 + 6.0, G)
	x.line_to(x0 + 1.0, G + 12.0)
	x.line_to(x0 - 5.0, G + 8.0)
	x.close_path()
	x.move_to(x0 + w + 5.0, G)
	x.line_to(x0 + w - 6.0, G)
	x.line_to(x0 + w - 1.0, G + 12.0)
	x.line_to(x0 + w + 5.0, G + 8.0)
	x.close_path()
	x.fill()
	x.set_fill(Util.rgba(255, 255, 255, 0.12))
	for i in 4:
		x.fill_rect(x0 + 8.0 + i * (w - 16.0) / 4.0, G + 18.0 + (i % 2) * 14.0, 3.0, 12.0)


func spin(o, ox: float) -> void:
	var cy := G - 16.0
	var hue := fposmod(zhue() + 180.0, 360.0)
	x.halo(ox, cy, 34.0, hue, 100.0, 62.0, 0.5)
	x.save()
	x.translate(ox, cy)
	x.rotate(g.t * 7.0 + o.seed_v)
	x.set_fill(Util.hx(0xd9d2ff))
	x.set_stroke(Util.hsl(hue, 90.0, 60.0))
	x.lw = 1.5
	x.join_round = true
	x.begin_path()
	for i in 16:
		var r2: float = 10.0 if i % 2 == 1 else 18.0
		var a: float = i * PI / 8.0
		x.line_to(cos(a) * r2, sin(a) * r2)
	x.close_path()
	x.fill()
	x.stroke()
	x.set_fill(Util.hsl(hue, 80.0, 45.0))
	x.begin_path()
	x.arc(0.0, 0.0, 6.0, 0.0, 7.0)
	x.fill()
	x.restore()


func spikes(o, ox: float) -> void:
	var hue := fposmod(zhue() + 40.0, 360.0)
	x.halo(ox, G - 10.0, 40.0, hue, 80.0, 60.0, 0.3)
	x.set_fill(Util.hsl(hue, 25.0, 82.0))
	x.set_stroke(Util.hsl(hue, 40.0, 40.0))
	x.lw = 1.4
	x.join_round = true
	for i in 4:
		var sx: float = ox - 27.0 + i * 18.0
		x.begin_path()
		x.move_to(sx - 9.0, G)
		x.line_to(sx, G - 24.0)
		x.line_to(sx + 9.0, G)
		x.close_path()
		x.fill()
		x.stroke()


func boulder(o, ox: float) -> void:
	var hue := fposmod(zhue() + 30.0, 360.0)
	x.halo(ox, G - 17.0, 36.0, hue, 50.0, 50.0, 0.25)
	x.save()
	x.translate(ox, G - 17.0)
	x.rotate(-g.t * 8.0 - o.seed_v)
	var c0 := Util.hsl(hue, 25.0, 66.0)
	var c1 := Util.hsl(hue, 30.0, 30.0)
	x.set_fill_g(x.rad_n(-5.0, -6.0, 20.0, [c0, c0, c1], [0.0, 0.15, 1.0]))
	x.begin_path()
	x.arc(0.0, 0.0, 17.0, 0.0, 7.0)
	x.fill()
	x.set_stroke(Util.rgba(20, 10, 50, 0.5))
	x.lw = 1.6
	x.begin_path()
	x.move_to(-10.0, -4.0)
	x.line_to(-2.0, 2.0)
	x.line_to(4.0, -8.0)
	x.move_to(2.0, 2.0)
	x.line_to(9.0, 9.0)
	x.stroke()
	x.restore()


func wall(o, ox: float) -> void:
	var hue := fposmod(zhue() + 20.0, 360.0)
	x.halo(ox, G - 40.0, 44.0, hue, 60.0, 55.0, 0.25)
	x.set_fill_g(x.lin(ox - 9.0, 0.0, ox + 9.0, 0.0, Util.hsl(hue, 30.0, 62.0), Util.hsl(hue, 30.0, 38.0)))
	x.fill_rect(ox - 9.0, G - 80.0, 18.0, 80.0)
	x.set_stroke(Util.rgba(20, 10, 50, 0.45))
	x.lw = 1.2
	for i in range(1, 6):
		x.begin_path()
		x.move_to(ox - 9.0, G - i * 13.3)
		x.line_to(ox + 9.0, G - i * 13.3)
		x.stroke()
	x.set_fill(Util.hsl(hue, 40.0, 72.0))
	x.fill_rect(ox - 12.0, G - 80.0, 24.0, 6.0)


func swing_x(o) -> float:
	var a := 0.85 * sin(g.t * 2.3 + o.seed_v)
	return o.x + 105.0 * sin(a)


func swing_y(o) -> float:
	var a := 0.85 * sin(g.t * 2.3 + o.seed_v)
	return G - 140.0 + 105.0 * cos(a)


func swing(o, ox: float) -> void:
	var bxx: float = ox + (swing_x(o) - o.x)
	var byy: float = swing_y(o)
	var hue := fposmod(zhue() + 200.0, 360.0)
	x.halo(bxx, byy, 30.0, hue, 100.0, 60.0, 0.45)
	x.set_stroke(Util.rgba(210, 200, 255, 0.8))
	x.lw = 2.0
	x.begin_path()
	x.move_to(ox, G - 140.0)
	x.line_to(bxx, byy)
	x.stroke()
	x.set_fill(Util.hx(0xd9d2ff))
	x.begin_path()
	x.arc(ox, G - 140.0, 6.0, 0.0, 7.0)
	x.fill()
	x.set_fill(Util.hx(0x2f2557))
	x.set_stroke(Util.hsl(hue, 90.0, 62.0))
	x.lw = 2.0
	x.begin_path()
	x.arc(bxx, byy, 12.0, 0.0, 7.0)
	x.fill()
	x.stroke()
	x.set_fill(Util.hsl(hue, 90.0, 70.0))
	x.begin_path()
	x.arc(bxx - 3.0, byy - 3.0, 3.0, 0.0, 7.0)
	x.fill()


func laser_on(o) -> bool:
	return fposmod(g.t * 0.5 + o.seed_v, 1.0) < 0.5


func laser(o, ox: float) -> void:
	var ph := fposmod(g.t * 0.5 + o.seed_v, 1.0)
	var on := ph < 0.5
	var warn := ph > 0.82
	x.halo(ox, G - 32.0, 50.0, 330.0, 100.0, 60.0, 0.35 if on else 0.08)
	x.set_fill(Util.hx(0x3a2c66))
	x.fill_rect(ox - 40.0, G - 44.0, 8.0, 44.0)
	x.fill_rect(ox + 32.0, G - 44.0, 8.0, 44.0)
	x.set_fill(Util.hx(0xff5a8c) if on else Util.hx(0x8a7ac8))
	x.fill_rect(ox - 40.0, G - 46.0, 8.0, 5.0)
	x.fill_rect(ox + 32.0, G - 46.0, 8.0, 5.0)
	if on:
		x.set_fill(Util.rgba(255, 90, 140, 0.35))
		x.fill_rect(ox - 32.0, G - 40.0, 64.0, 16.0)
		x.set_fill(Util.hx(0xffd0e0))
		x.fill_rect(ox - 32.0, G - 36.0, 64.0, 8.0)
	elif warn and sin(g.t * 40.0) > 0.0:
		x.set_fill(Util.rgba(255, 90, 140, 0.4))
		x.fill_rect(ox - 32.0, G - 33.0, 64.0, 2.0)


func bird(o, ox: float) -> void:
	var cy := G - 44.0 + sin(g.t * 5.0 + o.seed_v) * 3.0
	var fl := sin(g.t * 22.0 + o.seed_v)
	x.halo(ox, cy, 28.0, zhue(), 80.0, 55.0, 0.3)
	x.set_fill(Util.hx(0x2f2557))
	x.begin_path()
	x.ellipse(ox, cy, 13.0, 8.0, 0.0, 0.0, 7.0)
	x.fill()
	x.begin_path()
	x.move_to(ox - 2.0, cy - 2.0)
	x.quad_to(ox + 4.0, cy - 8.0 - fl * 10.0, ox + 15.0, cy - 3.0 - fl * 12.0)
	x.line_to(ox + 4.0, cy + 2.0)
	x.close_path()
	x.fill()
	x.set_fill(Util.hx(0xffb347))
	x.begin_path()
	x.move_to(ox - 12.0, cy - 2.0)
	x.line_to(ox - 21.0, cy + 1.0)
	x.line_to(ox - 12.0, cy + 3.0)
	x.fill()
	x.set_fill(Color(1, 1, 1, 1))
	x.begin_path()
	x.arc(ox - 7.0, cy - 2.0, 2.2, 0.0, 7.0)
	x.fill()
	x.set_fill(Util.hx(0x2a2050))
	x.begin_path()
	x.arc(ox - 7.5, cy - 2.0, 1.0, 0.0, 7.0)
	x.fill()


func flames(o, ox: float) -> void:
	x.halo(ox, G - 14.0, 46.0, 20.0, 100.0, 55.0, 0.6)
	var cols := [Util.hx(0xfff3a0), Util.hx(0xff9a2a), Util.hx(0xe03a1a)]
	var pos := [0.0, 0.5, 1.0]
	for i in 5:
		var fx0: float = ox - 20.0 + i * 10.0
		var h: float = 22.0 + 10.0 * sin(g.t * 9.0 + i * 1.7 + o.seed_v) + (0.0 if i % 2 == 1 else 6.0)
		x.set_fill_g(x.lin_n(0.0, G - h, 0.0, G, cols, pos))
		x.begin_path()
		x.move_to(fx0 - 6.0, G)
		x.quad_to(fx0 - 5.0, G - h * 0.5, fx0, G - h)
		x.quad_to(fx0 + 5.0, G - h * 0.5, fx0 + 6.0, G)
		x.fill()


func pillar(o, ox: float) -> void:
	var hue := fposmod(zhue() + 40.0, 360.0)
	x.halo(ox, G - 28.0, 50.0, hue, 70.0, 60.0, 0.3)
	x.set_fill_g(x.lin(0.0, G - 54.0, 0.0, G, Util.hsl(hue, 45.0, 72.0), Util.hsl(hue, 45.0, 38.0)))
	x.set_stroke(Util.hsl(hue, 60.0, 90.0, 0.9))
	x.lw = 1.4
	x.join_round = true
	x.begin_path()
	x.move_to(ox - 28.0, G)
	x.line_to(ox - 28.0, G - 26.0)
	x.line_to(ox - 2.0, G - 26.0)
	x.line_to(ox - 2.0, G - 54.0)
	x.line_to(ox + 24.0, G - 54.0)
	x.line_to(ox + 24.0, G)
	x.close_path()
	x.fill()
	x.stroke()
	x.set_stroke(Util.rgba(255, 255, 255, 0.35))
	x.begin_path()
	x.move_to(ox - 22.0, G - 22.0)
	x.line_to(ox - 22.0, G - 6.0)
	x.move_to(ox + 4.0, G - 50.0)
	x.line_to(ox + 4.0, G - 8.0)
	x.stroke()


func ice(o, ox: float) -> void:
	x.set_fill_g(x.lin(0.0, G - 3.0, 0.0, G + 9.0, Util.rgba(240, 253, 255, 0.96), Util.rgba(150, 215, 245, 0.92)))
	x.begin_path()
	x.round_rect(ox - 66.0, G - 3.0, 132.0, 12.0, 6.0)
	x.fill()
	x.set_fill(Util.rgba(255, 255, 255, 0.75))
	x.fill_rect(ox - 48.0, G - 1.0, 22.0, 2.0)
	x.fill_rect(ox + 8.0, G + 2.0, 30.0, 2.0)
	x.halo(ox + sin(g.t * 2.0 + o.seed_v) * 40.0, G - 2.0, 12.0, 190.0, 100.0, 88.0, 0.5)


func coin(it, ix: float) -> void:
	var w := maxf(0.22, absf(cos(g.t * 6.0 + it.ph)))
	x.halo(ix, it.y, 18.0, 45.0, 100.0, 60.0, 0.55)
	x.set_fill(Util.hx(0xffd23f))
	x.set_stroke(Util.hx(0xffb000))
	x.lw = 2.0
	x.begin_path()
	x.ellipse(ix, it.y, 8.0 * w, 8.0, 0.0, 0.0, 7.0)
	x.fill()
	x.stroke()
	x.set_fill(Util.rgba(255, 255, 255, 0.7))
	x.begin_path()
	x.ellipse(ix - 2.0 * w, it.y - 2.5, 2.0 * w, 3.0, 0.0, 0.0, 7.0)
	x.fill()


func draw_obs(o, ox: float) -> void:
	match o.type:
		OT.CRYSTAL:
			crystal(o, ox)
		OT.WISP:
			wisp(o, ox)
		OT.PIT:
			pit(o, ox)
		OT.SPIN:
			spin(o, ox)
		OT.BIRD:
			bird(o, ox)
		OT.FIRE:
			flames(o, ox)
		OT.PILLAR:
			pillar(o, ox)
		OT.ICE:
			ice(o, ox)
		OT.SPIKES:
			spikes(o, ox)
		OT.BOULDER:
			boulder(o, ox)
		OT.WALL:
			wall(o, ox)
		OT.SWING:
			swing(o, ox)
		OT.LASER:
			laser(o, ox)
		_:
			storm(o, ox, (G - 48.0 if o.type == OT.STORM_LOW else G - 80.0) + sin(g.t * 3.0 + o.seed_v) * 3.0)


func boxes(o) -> Array:
	match o.type:
		OT.CRYSTAL:
			var hw: float = 26.0 if o.w == 2 else 9.0
			return [[o.x - hw, G - 32.0, o.x + hw, G]]
		OT.SPIN:
			return [[o.x - 14.0, G - 31.0, o.x + 14.0, G]]
		OT.FIRE:
			return [[o.x - 22.0, G - 30.0, o.x + 22.0, G]]
		OT.PILLAR:
			return [[o.x - 28.0, G - 26.0, o.x - 2.0, G], [o.x - 2.0, G - 54.0, o.x + 24.0, G]]
		OT.BIRD:
			return [[o.x - 13.0, G - 53.0, o.x + 13.0, G - 35.0]]
		OT.SPIKES:
			return [[o.x - 34.0, G - 22.0, o.x + 34.0, G]]
		OT.BOULDER:
			return [[o.x - 15.0, G - 32.0, o.x + 15.0, G]]
		OT.WALL:
			return [[o.x - 9.0, G - 80.0, o.x + 9.0, G]]
		OT.SWING:
			var bxx := swing_x(o)
			var byy := swing_y(o)
			return [[bxx - 11.0, byy - 11.0, bxx + 11.0, byy + 11.0]]
		OT.LASER:
			if not laser_on(o):
				return []
			return [[o.x - 36.0, G - 36.0, o.x + 36.0, G - 28.0]]
		_:
			var cy: float = wisp_y(o) if o.type == OT.WISP else (G - 48.0 if o.type == OT.STORM_LOW else G - 80.0)
			return [[o.x - 12.0, cy - 10.0, o.x + 12.0, cy + 10.0]]
