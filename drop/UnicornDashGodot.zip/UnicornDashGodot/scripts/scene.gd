extends RefCounted

const Util = preload("res://scripts/util.gd")
const Data = preload("res://scripts/data.gd")
const G := 290.0

var x
var g
var no_cloud := [false, false, false, false, false, true, true, false, false, true, true, false, false, false, true, false, false, false]


func _init(ctx, game) -> void:
	x = ctx
	g = game


func layer(off: float, cs: float, seed_v: int, fn: Callable) -> void:
	var a := int(floor(off / cs)) - 1
	var b := int(ceil((off + g.L) / cs)) + 1
	for i in range(a, b + 1):
		fn.call(i * cs + (Util.hs(float(i * 3 + seed_v)) - 0.5) * cs * 0.6 - off, Util.hs(float(i * 7 + seed_v)), Util.hs(float(i * 13 + seed_v + 9)))


func tri(px: float, y: float, h: float, w: float) -> void:
	x.move_to(px - w, y)
	x.line_to(px, y - h)
	x.line_to(px + w, y)


func dome(px: float, y: float, r: float, k: float) -> void:
	x.move_to(px - r, y)
	x.ellipse(px, y, r, r * k, 0.0, PI, PI * 2.0)


func disc(px: float, py: float, r: float) -> void:
	x.move_to(px + r, py)
	x.arc(px, py, r, 0.0, 7.0)


func wave(rd: float, y: float, a: float, b: float, k: float) -> void:
	x.begin_path()
	x.move_to(0.0, G)
	var i := 0.0
	while i <= g.L + 12.0:
		x.line_to(i, y - a * sin((i + rd) / b) - a * 0.5 * sin((i + rd) / (b * k)))
		i += 12.0
	x.line_to(g.L + 12.0, G)
	x.fill()


func z0f(rd: float) -> void:
	x.lw = 7.0
	layer(rd * 0.08, 400.0, 1, func(px, r1, _r2):
		for k in 6:
			x.set_stroke(Util.hsl(k * 55.0, 90.0, 68.0, 0.5))
			x.begin_path()
			x.arc(px, G + 20.0, 150.0 + 30.0 * r1 - k * 7.0, PI, PI * 2.0)
			x.stroke()
	)


func z0n(rd: float) -> void:
	x.set_fill(Util.hx(g.zone.near))
	wave(rd * 0.2, G - 34.0, 18.0, 70.0, 0.43)


func z0m(rd: float) -> void:
	x.set_fill(Util.hx(g.zone.edge))
	x.begin_path()
	layer(rd * 0.45, 80.0, 3, func(px, r1, r2):
		disc(px, G - 6.0, 12.0 + 8.0 * r1)
		disc(px + 14.0, G - 4.0, 9.0 + 6.0 * r2)
		disc(px - 12.0, G - 4.0, 8.0 + 5.0 * r2)
	)
	x.fill()


func z0g(rd: float) -> void:
	x.lw = 2.0
	layer(rd, 46.0, 21, func(px, r1, r2):
		x.set_stroke(Util.hx(g.zone.edge))
		x.begin_path()
		x.move_to(px, G + 3.0)
		x.line_to(px, G - 9.0 - r1 * 7.0)
		x.stroke()
		x.set_fill(Util.hsl(r2 * 360.0, 90.0, 70.0))
		x.begin_path()
		disc(px, G - 12.0 - r1 * 7.0, 3.4)
		x.fill()
	)


func backdrop_far(rd: float) -> void:
	z0f(rd)


func backdrop_near(rd: float) -> void:
	z0n(rd)


func backdrop_mid(rd: float) -> void:
	z0m(rd)


func backdrop_ground(rd: float) -> void:
	z0g(rd)


func ground_base() -> void:
	var z: Dictionary = g.zone
	x.set_fill_g(x.lin(0.0, G, 0.0, 360.0 + g.ty, Util.hx(z.soil), Util.hx(z.edge)))
	x.fill_rect(0.0, G, g.L, 80.0 + g.ty + 10.0)
	x.set_fill(Util.hx(z.edge))
	x.fill_rect(0.0, G, g.L, 6.0)


func backdrop(rd: float) -> void:
	var z: Dictionary = g.zone
	x.save()
	x.cap_round = false
	x.join_round = false
	x.alpha = 0.8
	backdrop_far(rd)
	x.alpha = 0.5
	backdrop_near(rd)
	x.alpha = 0.3
	backdrop_mid(rd)
	x.restore()
	x.save()
	x.set_fill_g(x.lin(0.0, G - 170.0, 0.0, G, Util.with_alpha(Util.hx(z.sky1), 0.0), Util.with_alpha(Util.hx(z.sky1), 0.5)))
	x.fill_rect(0.0, G - 170.0, g.L, 170.0)
	x.restore()
	ground_base()
	x.save()
	x.cap_round = false
	x.join_round = false
	x.alpha = 0.75
	backdrop_ground(rd)
	x.restore()


func draw_scene(rd: float) -> void:
	var z: Dictionary = g.zone
	var t: float = g.t
	x.set_fill_g(x.lin(0.0, 0.0, 0.0, G, Util.hx(z.sky0), Util.hx(z.sky1)))
	x.fill_rect(0.0, -g.ty - 10.0, g.L, 380.0 + g.ty * 2.0)
	if z.night > 0.1:
		x.set_fill(Color(1, 1, 1, 1))
		var a0: float = x.alpha
		for i in 60:
			x.alpha = a0 * z.night * (0.3 + 0.7 * absf(sin(t * 2.0 + i)))
			x.fill_rect(Util.hs(float(i)) * g.L, Util.hs(float(i + 99)) * 190.0, 1.6, 1.6)
		x.alpha = a0
	if z.night > 0.55:
		var cyc := t / 6.0
		var k := fposmod(cyc, 1.0)
		var id := int(floor(cyc))
		if k < 0.12:
			var f := k / 0.12
			var sx0: float = Util.hs(float(id)) * g.L * 0.8 + 40.0
			var sy0 := 20.0 + Util.hs(float(id + 5)) * 60.0
			var hx: float = sx0 + f * 150.0
			var hy := sy0 + f * 70.0
			x.set_stroke_g(x.lin(hx - 60.0, hy - 28.0, hx, hy, Util.rgba(255, 255, 255, 0.0), Util.rgba(255, 255, 255, 1.0 - f)))
			x.lw = 2.0
			x.cap_round = true
			x.begin_path()
			x.move_to(hx - 60.0, hy - 28.0)
			x.line_to(hx, hy)
			x.stroke()
	var sx: float = g.L * 0.76
	var sy: float = 88.0 + 30.0 * z.night + sin(t * 0.5) * 2.0
	var night_hue := 230.0 if z.night > 0.5 else 40.0
	x.halo(sx, sy, 170.0, night_hue, 100.0, 85.0 if z.night > 0.5 else 80.0, 0.55)
	x.halo(sx, sy, 80.0, night_hue, 100.0, 92.0, 0.45)
	x.set_fill(Util.hx(z.body))
	x.begin_path()
	x.arc(sx, sy, 32.0, 0.0, 7.0)
	x.fill()
	if z.night > 0.5:
		x.set_fill(Util.rgba(120, 120, 180, 0.14 * z.night))
		x.begin_path()
		x.arc(sx - 10.0, sy - 6.0, 6.0, 0.0, 7.0)
		x.move_to(sx + 8.0 + 4.5, sy + 9.0)
		x.arc(sx + 8.0, sy + 9.0, 4.5, 0.0, 7.0)
		x.move_to(sx + 12.0 + 3.0, sy - 10.0)
		x.arc(sx + 12.0, sy - 10.0, 3.0, 0.0, 7.0)
		x.fill()
	var zi: int = g.zone_i
	var ca: float = 0.0 if no_cloud[zi] else 0.75 - 0.5 * z.night
	if ca > 0.0:
		x.set_fill(Util.rgba(255, 255, 255, ca))
		x.begin_path()
		layer(rd * 0.05 + t * 10.0, 190.0, 5, func(px, r1, r2):
			var y: float = 36.0 + 100.0 * r1
			var s: float = 0.8 + r2 * 0.7
			x.move_to(px + 14.0 * s, y)
			x.arc(px, y, 14.0 * s, 0.0, 7.0)
			x.move_to(px + 48.0 * s, y - 4.0 * s)
			x.arc(px + 30.0 * s, y - 6.0 * s, 18.0 * s, 0.0, 7.0)
			x.move_to(px + 62.0 * s, y)
			x.arc(px + 48.0 * s, y, 14.0 * s, 0.0, 7.0)
		)
		x.fill()
	backdrop(rd)


func amb_init() -> void:
	g.amb.clear()
	for i in 38:
		g.amb.append(g.Ent.Amb.new(randf() * g.L, randf() * G, 0.35 + randf() * 0.65, randf() * 9.0))


func amb_step(dt: float) -> void:
	var m: int = g.zone.fx
	var run: float = g.speed if g.st == 1 else 130.0
	var clock: float = g.clock
	for a in g.amb:
		a.x -= run * 0.22 * a.z * dt
		match m:
			0:
				a.y -= 10.0 * a.z * dt
				a.x += sin(clock * 0.8 + a.ph) * 8.0 * dt
			1:
				a.y += 26.0 * a.z * dt
				a.x += sin(clock * 1.2 + a.ph) * 22.0 * dt
			2:
				a.y += sin(clock * 0.9 + a.ph) * 12.0 * dt
				a.x += cos(clock * 0.7 + a.ph) * 10.0 * dt
			3:
				a.y += 38.0 * a.z * dt
				a.x += sin(clock + a.ph) * 14.0 * dt - 18.0 * dt
			4:
				a.x -= run * 0.5 * a.z * dt
				a.y += sin(clock * 2.0 + a.ph) * 6.0 * dt
			6:
				a.y -= (14.0 + 16.0 * a.z) * dt
				a.x += sin(clock * 1.4 + a.ph) * 10.0 * dt
			7:
				a.y += 30.0 * a.z * dt
				a.x += sin(clock * 1.6 + a.ph) * 26.0 * dt - 16.0 * dt
			8:
				a.y += 230.0 * a.z * dt
			9:
				a.y += sin(clock * 0.5 + a.ph) * 5.0 * dt
				a.x += cos(clock * 0.4 + a.ph) * 6.0 * dt
			10:
				a.y += sin(clock * 0.7 + a.ph) * 6.0 * dt
			11, 12:
				a.y -= 12.0 * a.z * dt
				a.x += sin(clock + a.ph) * 10.0 * dt
			_:
				a.y -= 34.0 * a.z * dt
				a.x += sin(clock * 2.0 + a.ph) * 16.0 * dt
		if a.x < -20.0:
			a.x = g.L + 20.0
		if a.x > g.L + 40.0:
			a.x = -10.0
		if a.y > G - 4.0:
			a.y = -8.0
		if a.y < -10.0:
			a.y = G - 6.0


func amb_draw() -> void:
	var z: Dictionary = g.zone
	var m: int = z.fx
	var clock: float = g.clock
	for a in g.amb:
		var fl := 0.5 + 0.5 * sin(clock * 3.0 + a.ph * 5.0)
		match m:
			0:
				x.halo(a.x, a.y, 5.0 * a.z + 2.0, 48.0, 100.0, 78.0, 0.35 + 0.35 * fl)
			1:
				x.save()
				x.translate(a.x, a.y)
				x.rotate(clock * 1.5 + a.ph)
				x.set_fill(Util.rgba(255, 200, 225, 0.85))
				x.begin_path()
				x.ellipse(0.0, 0.0, 4.0 * a.z + 1.0, 2.0 * a.z + 0.8, 0.0, 0.0, 7.0)
				x.fill()
				x.restore()
			2:
				x.halo(a.x, a.y, 9.0 * a.z + 3.0, 62.0, 100.0, 70.0, 0.3 + 0.6 * fl)
			3:
				x.set_fill(Util.rgba(255, 255, 255, 0.5 + 0.4 * a.z))
				x.begin_path()
				x.arc(a.x, a.y, 1.2 + 1.6 * a.z, 0.0, 7.0)
				x.fill()
			4:
				x.halo(a.x, a.y, 8.0 * a.z + 2.0, 32.0, 70.0, 80.0, 0.18 * a.z)
			6:
				x.set_stroke(Util.rgba(210, 245, 255, 0.35 + 0.4 * a.z))
				x.lw = 1.1
				x.begin_path()
				x.arc(a.x, a.y, 2.0 + 4.0 * a.z, 0.0, 7.0)
				x.stroke()
				x.set_fill(Util.rgba(255, 255, 255, 0.6))
				x.fill_rect(a.x - 1.0, a.y - 2.2 * a.z - 1.0, 1.4, 1.4)
			7:
				x.save()
				x.translate(a.x, a.y)
				x.rotate(clock * 1.8 + a.ph)
				x.set_fill(Util.hsl(z.hue + fposmod(a.ph * 7.0, 36.0), 85.0, 55.0, 0.9))
				x.begin_path()
				x.ellipse(0.0, 0.0, 4.5 * a.z + 1.5, 2.4 * a.z + 0.8, 0.0, 0.0, 7.0)
				x.fill()
				x.restore()
			8:
				x.set_stroke(Util.hsl(z.hue + 160.0 if a.ph > 4.5 else z.hue, 100.0, 66.0, 0.35 + 0.4 * a.z))
				x.lw = 1.2
				x.begin_path()
				x.move_to(a.x, a.y)
				x.line_to(a.x - 1.5, a.y + 6.0 + 8.0 * a.z)
				x.stroke()
			9:
				x.halo(a.x, a.y * 0.6 + 90.0, 34.0 * a.z + 14.0, z.hue, 30.0, 78.0, 0.06 + 0.05 * fl)
			10:
				x.halo(a.x, a.y, 5.0 * a.z + 2.0, z.hue, 100.0, 86.0, 0.3 + 0.6 * fl)
			11:
				x.halo(a.x, a.y, 6.0 * a.z + 2.0, z.hue, 100.0, 72.0, 0.35 + 0.5 * fl)
			12:
				x.halo(a.x, a.y, 6.0 * a.z + 2.0, fposmod(clock * 60.0 + a.ph * 40.0, 360.0), 100.0, 72.0, 0.35 + 0.5 * fl)
			_:
				x.halo(a.x, a.y, 6.0 * a.z + 2.0, 22.0, 100.0, 60.0, 0.35 + 0.5 * fl)


func dream_ambient() -> void:
	var clock: float = g.clock
	for i in 16:
		var spd: float = 4.0 + (i % 4) * 2.5
		var px := fposmod(Util.hs(float(i)) * g.L + sin(clock * 0.2 + i) * 20.0 + clock * spd, g.L)
		var py: float = 30.0 + Util.hs(float(i + 40)) * 250.0 + sin(clock * 0.5 + i * 1.7) * 14.0
		var r: float = 6.0 + Util.hs(float(i + 80)) * 16.0
		var hue := fposmod(Util.hs(float(i + 120)) * 360.0 + clock * 10.0, 360.0)
		var a: float = 0.12 + 0.1 * sin(clock * 1.3 + i)
		x.halo(px, py, r * 2.0, hue, 90.0, 78.0, a)
	for i in 7:
		var k := fposmod(clock * 0.12 + i / 7.0, 1.0)
		var px2: float = g.L * (0.08 + 0.84 * Util.hs(float(i + 200))) + sin(clock * 0.9 + i * 2.0) * 26.0
		var py2: float = G + 6.0 - k * 300.0
		var a2 := sin(k * PI) * 0.7
		g.sparkle(px2, py2, 2.6 + (i % 3) * 1.1, i + clock)
		x.halo(px2, py2, 10.0, 300.0 - k * 120.0, 100.0, 80.0, a2 * 0.35)


func rainbow_arc(cx: float, cy: float) -> void:
	var clock: float = g.clock
	x.cap_round = false
	for b in 7:
		x.set_stroke(Util.hsl(b * 48.0 + fposmod(clock * 8.0, 360.0), 95.0, 68.0, 0.13 + 0.04 * sin(clock * 0.8 + b)))
		x.lw = 9.0
		x.begin_path()
		x.arc(cx, cy, 196.0 - b * 8.5, PI, 0.0)
		x.stroke()


func lobby_scene(cx: float) -> void:
	var clock: float = g.clock
	var fy := 282.0
	x.set_fill_g(x.lin(0.0, 40.0, 0.0, fy, Util.rgba(255, 255, 255, 0.0), Util.rgba(255, 210, 255, 0.2)))
	x.begin_path()
	x.move_to(cx - 34.0, 40.0)
	x.line_to(cx + 34.0, 40.0)
	x.line_to(cx + 128.0, fy)
	x.line_to(cx - 128.0, fy)
	x.close_path()
	x.fill()
	rainbow_arc(cx, fy - 10.0)
	x.save()
	x.translate(cx, 190.0)
	x.rotate(clock * 0.08)
	x.set_fill(Util.rgba(255, 255, 255, 0.055))
	for i in 12:
		x.rotate(PI / 6.0)
		x.begin_path()
		x.move_to(0.0, 0.0)
		x.line_to(-18.0, -230.0)
		x.line_to(18.0, -230.0)
		x.fill()
	x.restore()
	x.halo(cx, 190.0, 150.0, fposmod(clock * 12.0 + 280.0, 360.0), 100.0, 70.0, 0.3)
	var cols := [Util.rgba(255, 190, 255, 0.55), Util.rgba(255, 190, 255, 0.55), Util.rgba(150, 100, 255, 0.3), Util.rgba(100, 60, 220, 0.0)]
	x.set_fill_g(x.rad_n(cx, fy + 4.0, 140.0, cols, [0.0, 0.0714, 0.5857, 1.0]))
	x.begin_path()
	x.ellipse(cx, fy + 4.0, 140.0, 28.0, 0.0, 0.0, 7.0)
	x.fill()
	x.set_fill(Util.rgba(30, 14, 80, 0.55))
	x.begin_path()
	x.ellipse(cx, fy + 4.0, 104.0, 18.0, 0.0, 0.0, 7.0)
	x.fill()
	x.lw = 2.0
	x.set_stroke(Util.rgba(255, 255, 255, 0.7))
	x.begin_path()
	x.ellipse(cx, fy + 4.0, 104.0, 18.0, 0.0, 0.0, 7.0)
	x.stroke()
	var pr := fposmod(clock * 0.5, 1.0)
	x.set_stroke(Util.rgba(255, 200, 255, 0.6 * (1.0 - pr)))
	x.lw = 2.2
	x.begin_path()
	x.ellipse(cx, fy + 4.0, 104.0 + 40.0 * pr, 18.0 + 8.0 * pr, 0.0, 0.0, 7.0)
	x.stroke()
	x.set_dash(10.0, 9.0)
	x.dash_off = -clock * 14.0
	x.set_stroke(Util.rgba(150, 240, 255, 0.75))
	x.lw = 1.6
	x.begin_path()
	x.ellipse(cx, fy + 4.0, 122.0, 22.0, 0.0, 0.0, 7.0)
	x.stroke()
	x.clear_dash()
	for i in 9:
		var a := clock * 0.35 + i * 6.2832 / 9.0
		var rr := 118.0 + 14.0 * sin(clock + i)
		var px := cx + cos(a) * rr
		var py := 186.0 + sin(a) * 66.0 + sin(clock * 1.4 + i) * 8.0
		if sin(a) > -0.2 or i % 2 == 1:
			g.sparkle(px, py, 3.0 + (i % 3) * 1.6, float(i))
