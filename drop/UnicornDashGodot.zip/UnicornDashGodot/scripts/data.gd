extends RefCounted

enum OT { CRYSTAL, SPIN, FIRE, PIT, PILLAR, ICE, STORM_LOW, STORM_HIGH, WISP, BIRD, SPIKES, WALL, SWING, LASER, BOULDER }

const COIN_COUNT = [5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 5, 5, 3, 3, 0]

const ECOMBOS = [[[10, 0.0, 1], [6, 1.0, 1]], [[11, 0.0, 1], [10, 1.05, 1]], [[14, 0.0, 1], [0, 1.3, 1]], [[13, 0.0, 1], [0, 1.0, 1]], [[12, 0.0, 1], [10, 1.15, 1]], [[0, 0.0, 1], [0, 0.85, 1], [9, 1.1, 1]], [[10, 0.0, 1], [11, 0.95, 1], [13, 1.1, 1]]]

const COMBOS = [[[3, 0.0, 1], [0, 1.05, 1]], [[4, 0.0, 1], [9, 1.0, 1]], [[1, 0.0, 1], [1, 0.9, 1], [6, 1.1, 1]], [[2, 0.0, 1], [9, 1.0, 1], [0, 1.1, 1]], [[7, 0.0, 1], [3, 1.1, 2]], [[5, 0.0, 1], [4, 1.0, 1]], [[9, 0.0, 1], [3, 1.05, 1], [1, 1.0, 1]]]

const SK = [
	{"name": "Classic", "cost": 0, "zone": -1, "hc": 0, "body": 0xf6efff, "leg": 0xe6dafa, "back": 0xcdb8ee, "h0": 0.0, "st": 44.0, "horn": 48.0},
	{"name": "Sunny", "cost": 1200, "zone": -1, "hc": 0, "body": 0xfff0c4, "leg": 0xffe2a0, "back": 0xf3cd84, "h0": 0.0, "st": 11.0, "horn": 30.0},
	{"name": "Candy", "cost": 2500, "zone": -1, "hc": 0, "body": 0xffd6ec, "leg": 0xffc2e2, "back": 0xf0a8cf, "h0": 300.0, "st": 10.0, "horn": 330.0},
	{"name": "Frost", "cost": 4000, "zone": -1, "hc": 0, "body": 0xd8f4ff, "leg": 0xbfe8fa, "back": 0xa5d6ee, "h0": 170.0, "st": 16.0, "horn": 190.0},
	{"name": "Galaxy", "cost": 7500, "zone": -1, "hc": 0, "body": 0x6a58c8, "leg": 0x5a49b4, "back": 0x4a3a9c, "h0": 250.0, "st": 22.0, "horn": 280.0},
	{"name": "Aurora", "cost": 12000, "zone": -1, "hc": 0, "body": 0xc9ffe9, "leg": 0xa9f0d2, "back": 0x8addbd, "h0": 120.0, "st": 36.0, "horn": 150.0},
	{"name": "Ember", "cost": 0, "zone": 4, "hc": 0, "body": 0xffd9c2, "leg": 0xffc2a0, "back": 0xf0a47e, "h0": 0.0, "st": 12.0, "horn": 15.0},
	{"name": "Moonlit", "cost": 0, "zone": 16, "hc": 0, "body": 0xdfe6ff, "leg": 0xc9d4f8, "back": 0xaab8ec, "h0": 215.0, "st": 14.0, "horn": 230.0},
	{"name": "Rose", "cost": 0, "zone": -1, "hc": 10, "body": 0xffd1dc, "leg": 0xffb3c6, "back": 0xf08aa8, "h0": 345.0, "st": 12.0, "horn": 350.0},
	{"name": "Ruby", "cost": 0, "zone": -1, "hc": 25, "body": 0xff9bb0, "leg": 0xf27a96, "back": 0xd85a7c, "h0": 355.0, "st": 8.0, "horn": 350.0}
]

const TR = [
	{"name": "Rainbow", "cost": 0, "zone": -1, "hc": 0, "c": [], "cycle": false, "fx": "dust"},
	{"name": "Stardust", "cost": 1000, "zone": -1, "hc": 0, "c": [[48.0, 100.0, 70.0], [40.0, 100.0, 66.0], [54.0, 100.0, 78.0], [44.0, 100.0, 62.0], [50.0, 100.0, 74.0], [38.0, 100.0, 68.0]], "cycle": false, "fx": "star"},
	{"name": "Candy", "cost": 1800, "zone": -1, "hc": 0, "c": [[330.0, 95.0, 72.0], [0.0, 0.0, 98.0], [330.0, 95.0, 72.0], [0.0, 0.0, 98.0], [330.0, 95.0, 72.0], [0.0, 0.0, 98.0]], "cycle": false, "fx": "heart"},
	{"name": "Frost", "cost": 0, "zone": 3, "hc": 0, "c": [[190.0, 100.0, 85.0], [200.0, 90.0, 76.0], [210.0, 85.0, 68.0], [195.0, 100.0, 90.0], [205.0, 90.0, 72.0], [185.0, 100.0, 80.0]], "cycle": false, "fx": "snow"},
	{"name": "Flame", "cost": 0, "zone": 5, "hc": 0, "c": [[55.0, 100.0, 70.0], [40.0, 100.0, 60.0], [28.0, 100.0, 55.0], [16.0, 100.0, 52.0], [8.0, 100.0, 48.0], [0.0, 95.0, 42.0]], "cycle": false, "fx": "ember"},
	{"name": "Aurora", "cost": 3500, "zone": -1, "hc": 0, "c": [], "cycle": true, "fx": "star"},
	{"name": "Neon", "cost": 0, "zone": 9, "hc": 0, "c": [[300.0, 100.0, 65.0], [320.0, 100.0, 60.0], [180.0, 100.0, 60.0], [200.0, 100.0, 62.0], [280.0, 100.0, 66.0], [160.0, 100.0, 58.0]], "cycle": false, "fx": "spark"},
	{"name": "Golden", "cost": 0, "zone": 17, "hc": 0, "c": [[48.0, 100.0, 72.0], [45.0, 100.0, 64.0], [50.0, 100.0, 80.0], [42.0, 100.0, 58.0], [46.0, 100.0, 70.0], [52.0, 100.0, 76.0]], "cycle": false, "fx": "gold"},
	{"name": "Love", "cost": 0, "zone": -1, "hc": 6, "c": [[345.0, 100.0, 72.0], [330.0, 100.0, 76.0], [350.0, 95.0, 68.0], [340.0, 100.0, 80.0], [355.0, 90.0, 70.0], [325.0, 100.0, 74.0]], "cycle": false, "fx": "heart"}
]

const HR = [
	{"name": "Golden", "cost": 0, "zone": -1, "hc": 0, "type": "gold", "hue": 48.0},
	{"name": "Candy Cane", "cost": 1300, "zone": -1, "hc": 0, "type": "candy", "hue": 340.0},
	{"name": "Flame", "cost": 1900, "zone": -1, "hc": 0, "type": "flame", "hue": 20.0},
	{"name": "Rainbow", "cost": 2600, "zone": -1, "hc": 0, "type": "rainbow", "hue": 300.0},
	{"name": "Crystal", "cost": 0, "zone": 6, "hc": 0, "type": "crystal", "hue": 190.0},
	{"name": "Starlight", "cost": 0, "zone": 2, "hc": 0, "type": "star", "hue": 60.0},
	{"name": "Heartbeat", "cost": 0, "zone": -1, "hc": 8, "type": "heart", "hue": 340.0}
]

const PT = [
	{"name": "None", "cost": 0, "zone": -1, "kind": "", "desc": ""},
	{"name": "Fairy", "cost": 2500, "zone": -1, "kind": "fairy", "desc": "Power-ups last 50% longer"},
	{"name": "Kitten", "cost": 3800, "zone": -1, "kind": "cat", "desc": "More hearts, +5 coins every 10 coins"},
	{"name": "Dragon", "cost": 5500, "zone": -1, "kind": "dragon", "desc": "+20% score"},
	{"name": "Phoenix", "cost": 0, "zone": 5, "kind": "phoenix", "desc": "Free revive, clears the path"}
]

const SKL = [
	{"k": "dash", "name": "Rainbow Flash", "desc": "Brief invincible dash", "cost": 0, "zone": -1, "cd": 20.0, "dur": 0.5, "hue": 48.0},
	{"k": "candy", "name": "Candy Shower", "desc": "Short burst of coin rain", "cost": 1200, "zone": -1, "cd": 24.0, "dur": 0.0, "hue": 330.0},
	{"k": "aura", "name": "Aurora Shield", "desc": "Blocks one hit", "cost": 2000, "zone": -1, "cd": 30.0, "dur": 0.0, "hue": 150.0},
	{"k": "moon", "name": "Moon Leap", "desc": "Low gravity and extra jumps", "cost": 3500, "zone": -1, "cd": 32.0, "dur": 4.0, "hue": 225.0},
	{"k": "freeze", "name": "Time Freeze", "desc": "Slows the world down", "cost": 5500, "zone": -1, "cd": 38.0, "dur": 2.5, "hue": 195.0},
	{"k": "fire", "name": "Flame Breath", "desc": "Burns obstacles ahead", "cost": 8000, "zone": -1, "cd": 40.0, "dur": 1.2, "hue": 20.0},
	{"k": "blast", "name": "Sun Blast", "desc": "Destroys obstacles ahead", "cost": 11000, "zone": -1, "cd": 45.0, "dur": 0.0, "hue": 38.0},
	{"k": "warp", "name": "Star Warp", "desc": "Teleports you forward", "cost": 15000, "zone": -1, "cd": 50.0, "dur": 0.0, "hue": 270.0}
]

const MS = [
	{"t": "Collect 40 coins in one run", "k": "rcoins", "n": 40, "r": 40, "run": true},
	{"t": "Score 600 in one run", "k": "score", "n": 600, "r": 60, "run": true},
	{"t": "Dodge 40 obstacles today", "k": "dodge", "n": 40, "r": 40, "run": false},
	{"t": "Double jump 25 times today", "k": "dj", "n": 25, "r": 30, "run": false},
	{"t": "Collect 120 coins today", "k": "coins", "n": 120, "r": 50, "run": false},
	{"t": "Play 5 runs today", "k": "runs", "n": 5, "r": 30, "run": false},
	{"t": "Hit a x5 coin combo 3 times", "k": "c5", "n": 3, "r": 40, "run": false},
	{"t": "Grab 4 power-ups today", "k": "pw", "n": 4, "r": 35, "run": false}
]

const SPIN = [
	{"amount": 20, "weight": 18, "hearts": false},
	{"amount": 1, "weight": 14, "hearts": true},
	{"amount": 50, "weight": 12, "hearts": false},
	{"amount": 2, "weight": 7, "hearts": true},
	{"amount": 30, "weight": 16, "hearts": false},
	{"amount": 100, "weight": 7, "hearts": false},
	{"amount": 40, "weight": 12, "hearts": false},
	{"amount": 3, "weight": 2, "hearts": true},
	{"amount": 60, "weight": 9, "hearts": false},
	{"amount": 300, "weight": 1, "hearts": false}
]

const ZN = [
	{"name": "Rainbow Meadow", "sky0": 0xff96d2, "sky1": 0xffe8be, "far": 0xd6aaf7, "near": 0xaa8ceb, "soil": 0x78d6a0, "edge": 0x58be86, "body": 0xfff4c8, "night": 0.0, "hue": 320.0, "fx": 0, "key": 0, "pr": 0, "tm": 1.0, "zs": ""},
	{"name": "Candy Clouds", "sky0": 0xffc8eb, "sky1": 0xfff4d6, "far": 0xffa6d0, "near": 0xff86ba, "soil": 0xffb8d8, "edge": 0xec78aa, "body": 0xfffae6, "night": 0.0, "hue": 290.0, "fx": 1, "key": 2, "pr": 1, "tm": 1.05, "zs": ""},
	{"name": "Starlight Night", "sky0": 0x100c30, "sky1": 0x543080, "far": 0x342664, "near": 0x261c50, "soil": 0x285c68, "edge": 0x1a4252, "body": 0xe8ecff, "night": 1.0, "hue": 185.0, "fx": 2, "key": -3, "pr": 2, "tm": 1.12, "zs": ""},
	{"name": "Frozen Peaks", "sky0": 0x0a285a, "sky1": 0x96e0f4, "far": 0x6ea6de, "near": 0xbae0f6, "soil": 0xdef2fc, "edge": 0xffffff, "body": 0xffffff, "night": 0.45, "hue": 200.0, "fx": 3, "key": -5, "pr": 3, "tm": 1.0, "zs": "ice"},
	{"name": "Sunset Dunes", "sky0": 0xff7054, "sky1": 0xffd696, "far": 0xbc587a, "near": 0x8c3a66, "soil": 0xe2a05c, "edge": 0xc8783c, "body": 0xffecbe, "night": 0.0, "hue": 25.0, "fx": 4, "key": 5, "pr": 1, "tm": 0.95, "zs": ""},
	{"name": "Ember Realm", "sky0": 0x280a18, "sky1": 0xaa361e, "far": 0x601e28, "near": 0x401624, "soil": 0x4e2c2c, "edge": 0xff702c, "body": 0xffaa5a, "night": 0.6, "hue": 12.0, "fx": 5, "key": -1, "pr": 2, "tm": 0.9, "zs": "fire"},
	{"name": "Crystal Caves", "sky0": 0x1e0c3e, "sky1": 0x6e3ca0, "far": 0x462878, "near": 0x2e1c5c, "soil": 0x402c6e, "edge": 0x9664e6, "body": 0xdcbeff, "night": 0.7, "hue": 280.0, "fx": 10, "key": 3, "pr": 0, "tm": 1.08, "zs": ""},
	{"name": "Enchanted Forest", "sky0": 0x123c3c, "sky1": 0xaae696, "far": 0x286e56, "near": 0x1a5440, "soil": 0x388c54, "edge": 0x22683c, "body": 0xfffabe, "night": 0.25, "hue": 130.0, "fx": 0, "key": -2, "pr": 1, "tm": 1.04, "zs": ""},
	{"name": "Cloud Kingdom", "sky0": 0x6eaaff, "sky1": 0xfff5e6, "far": 0xc8dcff, "near": 0xecf0ff, "soil": 0xfafaff, "edge": 0xc8d7fa, "body": 0xfff4c8, "night": 0.0, "hue": 210.0, "fx": 10, "key": 7, "pr": 2, "tm": 0.96, "zs": ""},
	{"name": "Neon City", "sky0": 0x0a0428, "sky1": 0x781478, "far": 0x28145a, "near": 0x180c3c, "soil": 0x1a1438, "edge": 0x00e6ff, "body": 0xff5adc, "night": 0.9, "hue": 300.0, "fx": 8, "key": 4, "pr": 3, "tm": 0.88, "zs": ""},
	{"name": "Deep Ocean", "sky0": 0x021846, "sky1": 0x1478aa, "far": 0x0a4682, "near": 0x063064, "soil": 0x1e6e82, "edge": 0x14a0aa, "body": 0xaaf0ff, "night": 0.5, "hue": 190.0, "fx": 6, "key": -4, "pr": 0, "tm": 1.12, "zs": "jelly"},
	{"name": "Autumn Hills", "sky0": 0xffaa5a, "sky1": 0xffe6aa, "far": 0xdc7846, "near": 0xb45032, "soil": 0xaa6e3c, "edge": 0xd28c3c, "body": 0xffecb4, "night": 0.0, "hue": 25.0, "fx": 7, "key": 1, "pr": 1, "tm": 1.0, "zs": ""},
	{"name": "Desert Oasis", "sky0": 0x28a0c8, "sky1": 0xffecb4, "far": 0xe6be78, "near": 0xc8965a, "soil": 0xecc882, "edge": 0x3caa78, "body": 0xfffad2, "night": 0.0, "hue": 170.0, "fx": 4, "key": 6, "pr": 2, "tm": 0.94, "zs": ""},
	{"name": "Haunted Mist", "sky0": 0x18162c, "sky1": 0x6e788c, "far": 0x464c64, "near": 0x30344c, "soil": 0x363c46, "edge": 0x64826e, "body": 0xdce6f5, "night": 0.6, "hue": 270.0, "fx": 9, "key": -6, "pr": 3, "tm": 1.15, "zs": "ghost"},
	{"name": "Space Rings", "sky0": 0x020214, "sky1": 0x321e64, "far": 0x463282, "near": 0x2c1e5a, "soil": 0x28285a, "edge": 0xa08cff, "body": 0xffdca0, "night": 1.0, "hue": 230.0, "fx": 10, "key": 8, "pr": 0, "tm": 0.9, "zs": ""},
	{"name": "Rainbow Waterfall", "sky0": 0x78c8ff, "sky1": 0xffe6fa, "far": 0x78bee6, "near": 0x5aa0dc, "soil": 0x78dcc8, "edge": 0xffaadc, "body": 0xffffff, "night": 0.0, "hue": 180.0, "fx": 12, "key": 9, "pr": 1, "tm": 1.0, "zs": ""},
	{"name": "Moon Garden", "sky0": 0x141446, "sky1": 0x9696dc, "far": 0x505096, "near": 0x383c78, "soil": 0x466e82, "edge": 0xa0e6e6, "body": 0xf5f8ff, "night": 0.8, "hue": 200.0, "fx": 11, "key": -7, "pr": 2, "tm": 1.1, "zs": ""},
	{"name": "Golden Temple", "sky0": 0xffbe5a, "sky1": 0xfff4c8, "far": 0xdc9646, "near": 0xb46e32, "soil": 0xe0b45a, "edge": 0xffd764, "body": 0xfffcdc, "night": 0.0, "hue": 45.0, "fx": 11, "key": 10, "pr": 3, "tm": 0.92, "zs": ""}
]

const RHY = [[1.0, 1.0, 1.2, 0.9], [1.1, 0.9, 1.1, 0.9, 1.3], [1.0, 1.3, 0.85, 1.15], [0.95, 1.2, 1.0, 1.2, 0.9], [1.25, 0.9, 0.9, 1.1]]
