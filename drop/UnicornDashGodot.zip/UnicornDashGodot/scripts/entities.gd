extends RefCounted


class Obs:
	var x: float
	var type: int
	var w: int
	var seed_v: float
	var v: float
	var pw: float = 0.0
	var dead: bool = false
	var passed: bool = false
	var nm: bool = false

	func _init(px: float, ty: int, wd: int, sd: float, vv: float) -> void:
		x = px
		type = ty
		w = wd
		seed_v = sd
		v = vv


class Item:
	var k: String
	var x: float
	var y: float
	var ph: float
	var v: float
	var bonus: bool
	var gone: bool = false

	func _init(kk: String, px: float, py: float, p: float, vv: float, b: bool) -> void:
		k = kk
		x = px
		y = py
		ph = p
		v = vv
		bonus = b


class Part:
	var x: float = 0.0
	var y: float = 0.0
	var vx: float = 0.0
	var vy: float = 0.0
	var life: float = 0.0
	var maxl: float = 0.0
	var s: float = 0.0
	var h: float = 0.0
	var sat: float = 0.0
	var lum: float = 0.0
	var a: float = 0.0
	var gr: float = 0.0


class TrailPt:
	var y: float
	var t: float

	func _init(py: float, tt: float) -> void:
		y = py
		t = tt


class Amb:
	var x: float
	var y: float
	var z: float
	var ph: float

	func _init(px: float, py: float, pz: float, p: float) -> void:
		x = px
		y = py
		z = pz
		ph = p


class Pop:
	var t: String
	var x: float
	var y: float
	var life: float

	func _init(tx: String, px: float, py: float, l: float) -> void:
		t = tx
		x = px
		y = py
		life = l


class Player:
	var x: float = 90.0
	var y: float = 290.0
	var py: float = 290.0
	var vy: float = 0.0
	var vx: float = 0.0
	var air: bool = false
	var jumps: int = 0
	var duck: bool = false
	var dk: float = 0.0
	var sq: float = 1.0
	var ang: float = 0.0
	var dead: bool = false
	var fall: bool = false
	var rt: float = 0.0
	var vic: int = 0
	var vt: float = 0.0
	var vstart: float = 1.0
	var rear: float = 0.0
	var stand: int = 0
	var apex: bool = false
	var neigh: bool = false
	var happy: bool = false
	var hold: float = 0.0
	var kind: String = ""
	var pit0: float = 0.0
	var pit1: float = 0.0
	var has_pit: bool = false
	var rest: bool = false
	var landed: bool = false
	var bounces: int = 0
	var spin: float = 0.0
	var end_ang: float = -2.6
	var jx: float = 0.0
	var hy: float = 290.0
