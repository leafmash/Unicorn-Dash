extends Control

signal action(key: String)
signal built(list: Array)

const Cp := preload("res://cp_kit.gd")
const U := 1.6
const PAD_X := 14.0
const PAD_Y := 10.0

var m
var kind := ""
var buttons: Array = []
var items: Array = []
var built_w := 0.0
var built_h := 0.0
var wheel: Control = null
var spin_tw: Tween = null
var spin_target := 0.0
var spin_msg_label: Label = null
var spin_gold: Button = null
var spin_off: Button = null
var spin_pill: Control = null


func setup(main: Node, which: String) -> void:
	m = main
	kind = which
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(on_resized)
	visibility_changed.connect(on_visible)


func d(v: float) -> float:
	return v * U


func emit_action(key: String) -> void:
	action.emit(key)


func on_resized() -> void:
	if size.x < 200.0 or not is_visible_in_tree():
		return
	if is_equal_approx(size.x, built_w) and is_equal_approx(size.y, built_h):
		return
	refresh()


func on_visible() -> void:
	if not is_visible_in_tree():
		return
	refresh()


func reg(n: Control, index: int, dy: float = 22.0) -> void:
	items.append([n, n.position.y, index, dy])


func play_enter() -> void:
	for it in items:
		var n: Control = it[0]
		if is_instance_valid(n):
			Cp.enter(n, float(it[1]), int(it[2]), float(it[3]))


func refresh() -> void:
	if size.x < 200.0 or m == null:
		return
	built_w = size.x
	built_h = size.y
	for c in get_children():
		remove_child(c)
		c.queue_free()
	buttons.clear()
	items.clear()
	wheel = null
	spin_msg_label = null
	spin_gold = null
	spin_off = null
	spin_pill = null
	var bgc := Cp.shape(size, 0.0, {"top": Color(0.078, 0.039, 0.2, 0.7), "bot": Color(0.102, 0.055, 0.239, 0.8)})
	add_child(bgc)
	if kind == "settings":
		build_settings()
	elif kind == "missions":
		build_missions()
	elif kind == "daily":
		build_daily()
	elif kind == "spin":
		build_spin()
	elif kind == "awards":
		build_awards()
	elif kind == "stats":
		build_stats()
	else:
		build_board()
	play_enter()
	built.emit(buttons)


func coin_pill(text: String) -> Control:
	var pill := Cp.pill(30.0)
	Cp.pill_add(pill, Cp.icon("coin", 18.0))
	Cp.pill_add(pill, Cp.gap(d(5.0)))
	var l := Cp.label(text, 14.0, Cp.SUN)
	Cp.set_text(l, text)
	Cp.pill_add(pill, l)
	Cp.pill_update(pill)
	pill.set_meta("lbl", l)
	return pill


func text_pill(text: String) -> Control:
	var pill := Cp.pill(30.0)
	var l := Cp.label(text, 12.0, Cp.SUN)
	Cp.set_text(l, text)
	Cp.pill_add(pill, l)
	Cp.pill_update(pill)
	return pill


func build_back() -> void:
	var back := Cp.round_btn(40.0, "back", 22.0)
	back.position = Vector2(d(PAD_X), d(PAD_Y))
	back.pressed.connect(emit_action.bind("back"))
	add_child(back)
	buttons.append(back)
	reg(back, 0)


func build_header(title: String, sub: String, right: Control) -> void:
	build_back()
	var box := Control.new()
	box.size = Vector2(size.x - d(PAD_X * 2.0 + 40.0 + 40.0 + 120.0), d(40.0))
	box.position = Vector2((size.x - box.size.x) * 0.5, d(PAD_Y))
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(box)
	reg(box, 0)
	var sp := 26.0
	while Cp.text_w(title, sp) > box.size.x and sp > 13.0:
		sp *= 0.92
	var gt := Cp.grad_title(title, sp)
	var sub_h := d(15.0) if sub != "" else 0.0
	var total := gt.size.y * 0.85 + sub_h
	var top := (box.size.y - total) * 0.5
	gt.position = Vector2((box.size.x - gt.size.x) * 0.5, top)
	box.add_child(gt)
	if sub != "":
		var sl := Cp.label(sub, 11.5, Color("e9dcff"), false)
		Cp.place(sl, 0.0, top + gt.size.y * 0.85, box.size.x, sub_h, HORIZONTAL_ALIGNMENT_CENTER)
		Cp.fit(sl, box.size.x)
		sl.custom_minimum_size.x = 0.0
		box.add_child(sl)
	if right != null:
		right.position = Vector2(size.x - d(PAD_X) - right.size.x, d(PAD_Y) + (d(40.0) - right.size.y) * 0.5)
		add_child(right)
		reg(right, 0)


func body_top() -> float:
	return d(PAD_Y + 40.0 + 10.0)


func body_h() -> float:
	return size.y - body_top() - d(PAD_Y)


func title_of(key: String) -> String:
	return String(m.T(key)).to_upper()


func fit_label(l: Label, w: float) -> void:
	Cp.fit(l, w)
	l.custom_minimum_size.x = 0.0


func add_label(parent: Control, text: String, sp: float, col: Color, x: float, y: float, w: float, h: float, align: int = HORIZONTAL_ALIGNMENT_LEFT, shadow: bool = true) -> Label:
	var l := Cp.label(text, sp, col, shadow)
	Cp.place(l, x, y, w, h, align)
	fit_label(l, w)
	parent.add_child(l)
	return l


func add_btn(parent: Control, text: String, x: float, y: float, w: float, h_dp: float, bkind: String, sp: float, key: String, o: Dictionary = {}) -> Button:
	var b := Cp.g_button(text, w, h_dp, bkind, sp, o)
	b.position = Vector2(x, y)
	b.pressed.connect(emit_action.bind(key))
	parent.add_child(b)
	buttons.append(b)
	return b


func track_colors(on: bool) -> Array:
	if on:
		return [Color("ff8fdc"), Color("b45cff"), Color("8b45ee")]
	return [Color(1.0, 1.0, 1.0, 0.25), Color(1.0, 1.0, 1.0, 0.22), Color(1.0, 1.0, 1.0, 0.19)]


func paint_track(track: Control, on: bool) -> void:
	var cols := track_colors(on)
	var mat: ShaderMaterial = track.material
	mat.set_shader_parameter("c_top", cols[0])
	mat.set_shader_parameter("c_mid", cols[1])
	mat.set_shader_parameter("c_bot", cols[2])


func set_knob(t: float, knob: Control, from_x: float, to_x: float) -> void:
	if not is_instance_valid(knob):
		return
	knob.position.x = from_x + (to_x - from_x) * clampf(Cp.spring(t, 0.6, 500.0), 0.0, 1.2)


func on_toggle(key: String, track: Control, knob: Control, btn: Button) -> void:
	var on := not bool(btn.get_meta("on"))
	btn.set_meta("on", on)
	paint_track(track, on)
	var off_x := d(3.0)
	var on_x := d(3.0) + d(20.0)
	var tw := knob.create_tween()
	tw.tween_method(set_knob.bind(knob, off_x if on else on_x, on_x if on else off_x), 0.0, 0.6, 0.6)
	emit_action(key)


func add_toggle(parent: Control, text: String, on: bool, x: float, y: float, w: float, h: float, key: String) -> void:
	var row := Cp.shape(Vector2(w, h), d(14.0), {"top": Color(1.0, 1.0, 1.0, 0.08)})
	row.position = Vector2(x, y)
	parent.add_child(row)
	add_label(row, text, 14.0, Color.WHITE, d(14.0), 0.0, w - d(86.0), h)
	var sw_w := d(46.0)
	var sw_h := d(26.0)
	var cols := track_colors(on)
	var track := Cp.shape(Vector2(sw_w, sw_h), sw_h * 0.5, {"top": cols[0], "mid": cols[1], "bot": cols[2]})
	track.position = Vector2(w - d(14.0) - sw_w, (h - sw_h) * 0.5)
	row.add_child(track)
	var knob := Cp.shape(Vector2(d(20.0), d(20.0)), d(10.0), {"top": Color.WHITE})
	knob.position = Vector2(d(3.0) + (d(20.0) if on else 0.0), d(3.0))
	track.add_child(knob)
	var btn := Cp.flat_button(Vector2(w, h))
	btn.set_meta("punch_node", row)
	btn.set_meta("on", on)
	btn.pressed.connect(on_toggle.bind(key, track, knob, btn))
	row.add_child(btn)
	buttons.append(btn)


func build_settings() -> void:
	build_header(title_of("Settings"), "", Control.new())
	var top := body_top()
	var avail := body_h()
	var gap := d(12.0)
	var side_w := d(190.0)
	var left_w := size.x - d(PAD_X * 2.0) - side_w - gap
	var left := Cp.glass(Vector2(left_w, avail), 24.0)
	left.position = Vector2(d(PAD_X), top)
	add_child(left)
	reg(left, 1)
	var pad := d(12.0)
	var iw := left_w - pad * 2.0
	var rows: Array = [
		[m.T("Music"), m.mus_on, "mus"],
		[m.T("Sound effects"), m.snd_on, "snd"],
		[m.T("Vibration"), m.vib_on, "vib"],
		[m.T("FPS counter"), m.show_fps, "fps"]
	]
	var rh := minf(d(40.0), (avail - pad * 2.0 - d(7.0) * 4.0) / 5.0)
	var y := pad
	for r in rows:
		add_toggle(left, String(r[0]), bool(r[1]), pad, y, iw, rh, String(r[2]))
		y += rh + d(7.0)
	var lrow := Cp.shape(Vector2(iw, rh), d(14.0), {"top": Color(1.0, 1.0, 1.0, 0.08)})
	lrow.position = Vector2(pad, y)
	left.add_child(lrow)
	add_label(lrow, m.T("Language"), 14.0, Color.WHITE, d(14.0), 0.0, iw * 0.5, rh)
	var lname := "বাংলা" if m.lang == "bn" else "English"
	var cw := Cp.text_w(lname, 13.0) + d(28.0)
	var chip := Cp.shape(Vector2(cw, rh * 0.68), rh * 0.34, {"top": Color("ff8fdc"), "mid": Color("b45cff"), "bot": Color("8b45ee"), "gloss": 1.0})
	chip.position = Vector2(iw - d(14.0) - cw, rh * 0.16)
	lrow.add_child(chip)
	add_label(chip, lname, 13.0, Color.WHITE, 0.0, 0.0, cw, chip.size.y, HORIZONTAL_ALIGNMENT_CENTER)
	var lbtn := Cp.flat_button(Vector2(iw, rh))
	lbtn.set_meta("punch_node", lrow)
	lbtn.pressed.connect(emit_action.bind("lang"))
	lrow.add_child(lbtn)
	buttons.append(lbtn)
	var right := Cp.glass(Vector2(side_w, avail), 24.0)
	right.position = Vector2(size.x - d(PAD_X) - side_w, top)
	add_child(right)
	reg(right, 2)
	var bw := side_w - pad * 2.0
	var bh := minf(36.0, (avail / U - 24.0 - 6.0 * 4.0) / 5.0)
	var step := d(bh + 6.0)
	add_btn(right, m.T("STATS"), pad, pad, bw, bh, "soft", 13.0, "stats", {"lead": "board", "lead_dp": 16.0})
	add_btn(right, m.T("LEADERBOARD"), pad, pad + step, bw, bh, "soft", 11.5, "board", {"lead": "medal", "lead_dp": 16.0})
	add_btn(right, m.T("EXPORT SAVE"), pad, pad + step * 2.0, bw, bh, "soft", 11.5, "exp")
	add_btn(right, m.T("IMPORT SAVE"), pad, pad + step * 3.0, bw, bh, "soft", 11.5, "imp")
	add_btn(right, m.T("RESET PROGRESS"), pad, pad + step * 4.0, bw, bh, "soft", 11.0, "rst")


func build_missions() -> void:
	build_header(title_of("Daily Missions"), "", coin_pill("%d" % m.bank))
	var ms: Array = m.dstate["m"]
	var n := ms.size()
	var pad := d(14.0)
	var rh := d(64.0)
	var rg := d(8.0)
	var cw := minf(d(500.0), size.x - d(PAD_X * 2.0))
	var ch := pad * 2.0 + float(n) * rh + float(maxi(n - 1, 0)) * rg
	var card := Cp.glass(Vector2(cw, ch), 24.0)
	card.position = Vector2((size.x - cw) * 0.5, body_top() + maxf(0.0, (body_h() - ch) * 0.4))
	add_child(card)
	reg(card, 1)
	var iw := cw - pad * 2.0
	for i in n:
		var mi: Dictionary = ms[i]
		var mt: Dictionary = m.MISSIONS[int(mi["i"])]
		var target: int = m.mission_target(mi)
		var got := mini(int(mi["got"]), target)
		var claimed := bool(mi["claimed"])
		var can_claim := got >= target and not claimed
		var ry := pad + float(i) * (rh + rg)
		var row := Cp.shape(Vector2(iw, rh), d(16.0), {"top": Color(1.0, 1.0, 1.0, 0.07)})
		row.position = Vector2(pad, ry)
		card.add_child(row)
		var bw := d(118.0)
		var tw := iw - bw - d(36.0)
		var title_c := Cp.MINT if got >= target else Color("f4ecff")
		add_label(row, String(m.T(String(mt["d"]))) % int(mt["n"]), 13.0, title_c, d(14.0), d(8.0), tw, d(20.0))
		var bar := Cp.bar(Vector2(tw - d(50.0), d(6.0)), Color("ffe27a"), Color("ffb000"))
		bar.position = Vector2(d(14.0), d(38.0))
		row.add_child(bar)
		Cp.bar_set(bar, float(got) / float(maxi(target, 1)), false)
		add_label(row, "%d/%d" % [got, target], 10.0, Color("c9bdf0"), d(14.0) + tw - d(44.0), d(31.0), d(44.0), d(18.0), HORIZONTAL_ALIGNMENT_RIGHT, false)
		var bx := iw - d(12.0) - bw
		var by := (rh - d(40.0)) * 0.5
		if claimed:
			add_btn(row, m.T("CLAIMED"), bx, by, bw, 40.0, "off", 12.0, "mc%d" % i)
		elif can_claim:
			add_btn(row, "+%d" % int(mt["r"]), bx, by, bw, 40.0, "gold", 14.0, "mc%d" % i, {"coin": true})
		else:
			var dis := add_btn(row, "+%d" % int(mt["r"]), bx, by, bw, 40.0, "off", 14.0, "mc%d" % i, {"coin": true})
			dis.disabled = true


func build_daily() -> void:
	build_header(title_of("Daily Challenge"), "", coin_pill("%d" % m.bank))
	var done: bool = bool(m.dstate["chal"])
	var z: int = m.daily_zone()
	var zd: Dictionary = m.ZONES[z]
	var cw := minf(d(380.0), size.x - d(PAD_X * 2.0))
	var rule_txt: String = m.rule_label(String(m.daily_cfg()["rule"]))
	var ch := d(268.0) + (d(24.0) if rule_txt != "" else 0.0)
	var card := Cp.glass(Vector2(cw, ch), 26.0)
	card.position = Vector2((size.x - cw) * 0.5, body_top() + maxf(0.0, (body_h() - ch) * 0.4))
	add_child(card)
	reg(card, 1)
	var pw := d(150.0)
	var ph := d(84.0)
	var holder := Control.new()
	holder.size = Vector2(pw, ph)
	holder.position = Vector2((cw - pw) * 0.5, d(14.0))
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(holder)
	var art := Control.new()
	art.size = Vector2(pw, ph)
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var amat := ShaderMaterial.new()
	amat.shader = m.cp_zones.round_shader()
	amat.set_shader_parameter("size", art.size)
	amat.set_shader_parameter("radius", d(16.0))
	art.material = amat
	art.draw.connect(m.cp_zones.draw_preview.bind(art, zd))
	holder.add_child(art)
	var rim_c := Color(1.0, 1.0, 1.0, 0.85)
	holder.add_child(Cp.shape(Vector2(pw, ph), d(16.0), {"top": Color(1.0, 1.0, 1.0, 0.0), "rim_t": rim_c, "rim_b": rim_c, "rim_w": d(2.0)}))
	var y := d(14.0) + ph + d(8.0)
	add_label(card, m.T(String(zd["name"])), 18.0, Color.WHITE, d(12.0), y, cw - d(24.0), d(26.0), HORIZONTAL_ALIGNMENT_CENTER)
	y += d(28.0)
	if rule_txt != "":
		add_label(card, rule_txt, 13.0, Cp.SUN, d(12.0), y - d(4.0), cw - d(24.0), d(22.0), HORIZONTAL_ALIGNMENT_CENTER)
		y += d(22.0)
	var rw := "+%d" % m.daily_reward()
	var rl := Cp.label(rw, 22.0, Cp.SUN)
	var rwid := Cp.text_w(rw, 22.0)
	var ic := Cp.icon("coin", 24.0)
	var total := ic.size.x + d(8.0) + rwid
	ic.position = Vector2((cw - total) * 0.5, y + d(3.0))
	card.add_child(ic)
	Cp.place(rl, (cw - total) * 0.5 + ic.size.x + d(8.0), y, rwid + d(4.0), d(30.0))
	card.add_child(rl)
	y += d(32.0)
	var streak := 0
	var last := String(m.dstate.get("last", ""))
	if last == m.today_str() or last == m.yesterday_str():
		streak = int(m.dstate.get("streak", 0))
	add_label(card, String(m.T("Streak  %d days")) % streak, 12.5, Cp.ROSE, d(12.0), y, cw - d(24.0), d(20.0), HORIZONTAL_ALIGNMENT_CENTER)
	y += d(28.0)
	var bw := minf(d(220.0), cw - d(40.0))
	if done:
		add_btn(card, m.T("COMPLETED"), (cw - bw) * 0.5, y, bw, 46.0, "off", 16.0, "dstart")
	else:
		add_btn(card, m.T("START"), (cw - bw) * 0.5, y, bw, 46.0, "primary", 18.0, "dstart", {"lead": "play", "lead_dp": 18.0, "sheen": true})


func spin_colors(i: int) -> Color:
	var c: Color = m.hc(m.SPIN_COLORS[i])
	if i % 2 == 1:
		return c.lightened(0.08)
	return c


func draw_wheel() -> void:
	var n: int = m.SPIN_PRIZES.size()
	var c := wheel.size * 0.5
	var r := wheel.size.x * 0.5 - d(2.0)
	var seg := TAU / float(n)
	for i in n:
		var pts := PackedVector2Array([c])
		for k in range(0, 13):
			var phi := (float(i) - 0.5 + float(k) / 12.0) * seg - PI * 0.5
			pts.append(c + Vector2(cos(phi), sin(phi)) * r)
		wheel.draw_colored_polygon(pts, spin_colors(i))
		var a0 := (float(i) - 0.5) * seg - PI * 0.5
		wheel.draw_line(c, c + Vector2(cos(a0), sin(a0)) * r, Color(1.0, 1.0, 1.0, 0.7), d(1.5), true)
	for i in n:
		var th := float(i) * seg - PI * 0.5
		var txt := "%d" % int(m.SPIN_PRIZES[i])
		if bool(m.SPIN_HEARTS[i]):
			txt = "%d H" % int(m.SPIN_PRIZES[i])
		var fs := roundi(d(14.0))
		var tw := Cp.font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs).x
		wheel.draw_set_transform(c, th, Vector2.ONE)
		var px := r * 0.84 - tw
		wheel.draw_string_outline(Cp.font, Vector2(px, fs * 0.35), txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs, roundi(d(4.0)), Color(0.16, 0.08, 0.31, 0.7))
		wheel.draw_string(Cp.font, Vector2(px, fs * 0.35), txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs, Color.WHITE)
	wheel.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	wheel.draw_arc(c, r, 0.0, TAU, 72, Color(1.0, 1.0, 1.0, 0.85), d(4.0), true)


func draw_pointer(p: Control) -> void:
	var w := p.size.x
	var h := p.size.y
	var pts := PackedVector2Array([Vector2(1.0, 1.0), Vector2(w - 1.0, 1.0), Vector2(w * 0.5, h - 1.0)])
	p.draw_colored_polygon(pts, Cp.SUN)
	p.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[0]]), Color("b87400"), d(1.5), true)


func build_spin() -> void:
	build_back()
	var pill := coin_pill("%d" % m.bank)
	pill.position = Vector2(size.x - d(PAD_X) - pill.size.x, d(PAD_Y) + (d(40.0) - pill.size.y) * 0.5)
	add_child(pill)
	reg(pill, 0)
	spin_pill = pill
	var wd := minf(d(214.0), body_h() - d(20.0))
	var cx := size.x * 0.5
	var cy := size.y * 0.5 + d(8.0)
	var glow := Cp.pulse_glow(Cp.PURPLE, 130.0)
	glow.position = Vector2(cx - glow.size.x * 0.5, cy - glow.size.y * 0.5)
	add_child(glow)
	reg(glow, 0)
	wheel = Control.new()
	wheel.size = Vector2(wd, wd)
	wheel.position = Vector2(cx - wd * 0.5, cy - wd * 0.5)
	wheel.pivot_offset = Vector2(wd, wd) * 0.5
	wheel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wheel.draw.connect(draw_wheel)
	add_child(wheel)
	reg(wheel, 0)
	wheel.rotation = float(m.wheel_rot)
	var hub := Cp.shape(Vector2(d(34.0), d(34.0)), d(17.0), {"top": Color.WHITE, "bot": Color("e9dcff")})
	hub.position = Vector2(cx - d(17.0), cy - d(17.0))
	add_child(hub)
	var hc := Cp.icon("coin", 20.0)
	hc.position = (hub.size - hc.size) * 0.5
	hub.add_child(hc)
	var pointer := Control.new()
	pointer.size = Vector2(d(28.0), d(30.0))
	pointer.position = Vector2(cx - d(14.0), cy - wd * 0.5 - d(14.0))
	pointer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pointer.draw.connect(draw_pointer.bind(pointer))
	add_child(pointer)
	var rx := cx + wd * 0.5 + d(18.0)
	var rw := size.x - rx - d(PAD_X)
	var ry := cy - d(70.0)
	if rw > d(100.0):
		var tt := Cp.grad_title(String(m.T("DAILY SPIN")), 24.0)
		tt.position = Vector2(rx + (rw - tt.size.x) * 0.5, ry)
		add_child(tt)
		reg(tt, 1)
		spin_msg_label = Cp.label("", 12.5, Cp.SUN)
		Cp.place(spin_msg_label, rx, ry + tt.size.y + d(6.0), rw, d(44.0), HORIZONTAL_ALIGNMENT_CENTER)
		spin_msg_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		spin_msg_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
		add_child(spin_msg_label)
		var bw := minf(d(150.0), rw)
		var by := ry + tt.size.y + d(56.0)
		var free := not bool(m.dstate["spun"])
		var txt: String = m.T("FREE SPIN") if free else String(m.T("SPIN  -%d")) % m.SPIN_COST
		spin_gold = add_btn(self, txt, rx + (rw - bw) * 0.5, by, bw, 46.0, "gold", 16.0, "dospin")
		spin_off = add_btn(self, txt, rx + (rw - bw) * 0.5, by, bw, 46.0, "off", 16.0, "dospin")
		reg(spin_gold, 2)
		reg(spin_off, 2)
	spin_target = float(m.wheel_rot)
	if m.spinning:
		m.call_deferred("finish_spin")
	sync()


func sync() -> void:
	if kind != "spin" or spin_msg_label == null:
		return
	spin_msg_label.text = String(m.spin_msg)
	if spin_pill != null:
		var pl: Label = spin_pill.get_meta("lbl")
		Cp.set_text(pl, "%d" % m.bank)
		Cp.pill_update(spin_pill)
		spin_pill.position.x = size.x - d(PAD_X) - spin_pill.size.x
	var free := not bool(m.dstate["spun"])
	var txt: String = m.T("FREE SPIN") if free else String(m.T("SPIN  -%d")) % m.SPIN_COST
	for sb in [spin_gold, spin_off]:
		var sl: Label = sb.get_meta("label")
		Cp.set_text(sl, txt)
	var can: bool = not m.spinning
	spin_gold.visible = can
	spin_off.visible = not can
	spin_off.disabled = true


func start_spin(target: float) -> void:
	if wheel == null:
		return
	if spin_tw != null and spin_tw.is_valid():
		spin_tw.kill()
	spin_target = target
	wheel.rotation = 0.0
	m.wheel_rot = 0.0
	spin_tw = wheel.create_tween()
	spin_tw.tween_property(wheel, "rotation", target, 4.2).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	spin_tw.tween_callback(spin_done)


func spin_done() -> void:
	m.wheel_rot = spin_target
	m.finish_spin()


func build_awards() -> void:
	var achs: Array = m.ACHS
	var claimed_n: int = m.ach_claimed.size()
	build_header(title_of("Awards"), "", text_pill("%d/%d" % [claimed_n, achs.size()]))
	var pages: int = m.awards_pages()
	var page: int = clampi(m.awards_page, 0, pages - 1)
	var top := body_top()
	var pager_h := d(40.0)
	var avail := size.y - top - d(PAD_Y) - pager_h - d(6.0)
	var gap := d(8.0)
	var cw := (size.x - d(PAD_X * 2.0) - gap) * 0.5
	var ch := (avail - gap * 2.0) / 3.0
	for k in 6:
		var idx := page * 6 + k
		if idx >= achs.size():
			break
		var col := k % 2
		var rowi := floori(float(k) / 2.0)
		var card := make_ach(idx, Vector2(cw, ch))
		card.position = Vector2(d(PAD_X) + float(col) * (cw + gap), top + float(rowi) * (ch + gap))
		add_child(card)
		reg(card, 1 + rowi)
	var py := size.y - d(PAD_Y) - pager_h
	var lb := Cp.round_btn(34.0, "arrow_l", 18.0)
	var rb := Cp.round_btn(34.0, "arrow_r", 18.0)
	lb.position = Vector2(size.x * 0.5 - d(70.0) - lb.size.x * 0.5, py + (pager_h - lb.size.y) * 0.5)
	rb.position = Vector2(size.x * 0.5 + d(70.0) - rb.size.x * 0.5, py + (pager_h - rb.size.y) * 0.5)
	lb.pressed.connect(emit_action.bind("ap-1"))
	rb.pressed.connect(emit_action.bind("ap1"))
	add_child(lb)
	add_child(rb)
	buttons.append(lb)
	buttons.append(rb)
	add_label(self, "%d / %d" % [page + 1, pages], 14.0, Color.WHITE, size.x * 0.5 - d(50.0), py, d(100.0), pager_h, HORIZONTAL_ALIGNMENT_CENTER)


func make_ach(i: int, sz: Vector2) -> Control:
	var a: Dictionary = m.ACHS[i]
	var val: int = m.stat_value(String(a["s"]))
	var target := int(a["t"])
	var done := val >= target
	var claimed: bool = m.ach_claimed.has(String(a["id"]))
	var can_claim := done and not claimed
	var top_c := Color(1.0, 1.0, 1.0, 0.09)
	var rim := Color(1.0, 1.0, 1.0, 0.3)
	if can_claim:
		top_c = Color(1.0, 0.886, 0.478, 0.18)
		rim = Cp.SUN
	elif claimed:
		top_c = Color(0.49, 1.0, 0.83, 0.14)
		rim = Cp.MINT
	var root := Cp.shape(sz, d(16.0), {"top": top_c, "rim_t": rim, "rim_b": rim, "rim_w": d(1.3)})
	var px := d(12.0)
	var iw := sz.x - px * 2.0
	var name_c := Color("b8ffe6") if claimed else Color.WHITE
	add_label(root, m.T(String(a["n"])), 12.5, name_c, px, d(6.0), iw - d(52.0), d(20.0), HORIZONTAL_ALIGNMENT_LEFT)
	if claimed:
		var ck := Cp.icon("check", 14.0, Cp.MINT)
		ck.position = Vector2(sz.x - px - ck.size.x, d(9.0))
		root.add_child(ck)
	else:
		var rt := "%d" % int(a["r"])
		var rwid := Cp.text_w(rt, 11.0)
		var ic := Cp.icon("coin", 12.0)
		var rl := Cp.label(rt, 11.0, Cp.SUN)
		Cp.place(rl, sz.x - px - rwid - d(2.0), d(6.0), rwid + d(4.0), d(20.0))
		root.add_child(rl)
		ic.position = Vector2(sz.x - px - rwid - d(5.0) - ic.size.x, d(10.0))
		root.add_child(ic)
	add_label(root, m.T(String(a["d"])), 10.0, Cp.LILAC, px, d(25.0), iw, d(16.0), HORIZONTAL_ALIGNMENT_LEFT, false)
	var by := sz.y - d(8.0)
	if can_claim:
		var bh := minf(d(30.0), sz.y - d(46.0))
		add_btn(root, m.T("CLAIM"), px, sz.y - bh - d(7.0), iw, bh / U, "gold", 13.0, "ach%d" % i, {"coin": true})
	else:
		var bar_c0 := Cp.MINT if claimed else Cp.PINK
		var bar_c1 := Cp.MINT if claimed else Cp.PURPLE
		var bar := Cp.bar(Vector2(iw, d(5.0)), bar_c0, bar_c1)
		bar.position = Vector2(px, by - d(5.0))
		root.add_child(bar)
		Cp.bar_set(bar, float(mini(val, target)) / float(maxi(target, 1)), false)
		add_label(root, "%d / %d" % [mini(val, target), target], 9.5, Color("c9bdf0"), px, by - d(22.0), iw, d(14.0), HORIZONTAL_ALIGNMENT_RIGHT, false)
	return root


func split_stat(line: String) -> Array:
	var idx := line.rfind("  ")
	if idx < 0:
		return [line, ""]
	return [line.substr(0, idx), line.substr(idx + 2)]


func build_stats() -> void:
	build_header(title_of("Statistics"), "", Control.new())
	var secs := int(float(m.stats.get("time", 0.0)))
	var tm := "%dh %02dm" % [floori(float(secs) / 3600.0), floori(float(secs % 3600) / 60.0)]
	var lv: int = m.player_level()
	var lines: Array = [
		String(m.T("Player level  %d")) % lv,
		String(m.T("XP  %d / %d")) % [m.xp_into(), m.xp_need(lv)],
		String(m.T("Runs  %d")) % int(m.stats.get("runs", 0)),
		String(m.T("Total coins  %d")) % int(m.stats.get("coins", 0)),
		String(m.T("Total score  %d")) % int(m.stats.get("score", 0)),
		String(m.T("Best combo  x%d")) % int(m.stats.get("combo", 0)),
		String(m.T("Levels cleared  %d")) % m.stat_value("cleared"),
		String(m.T("Stars  %d / %d")) % [m.total_stars(), m.ZONES.size() * m.LEVELS_PER_ZONE * 3],
		String(m.T("Power-ups  %d")) % int(m.stats.get("powers", 0)),
		String(m.T("Daily challenges  %d")) % int(m.stats.get("daily", 0)),
		String(m.T("Play time  %s")) % tm,
		String(m.T("Near misses  %d")) % int(m.stats.get("near", 0)),
		String(m.T("Obstacles dodged  %d")) % int(m.stats.get("dodge", 0)),
		String(m.T("Distance  %d m")) % int(m.stats.get("dist", 0)),
		String(m.T("Best endless  %d")) % m.stat_value("best"),
		String(m.T("Spins  %d")) % int(m.stats.get("spins", 0))
	]
	lines.remove_at(1)
	var tones: Array = [Color.WHITE, Color.WHITE, Cp.SUN, Cp.SUN, Cp.ROSE, Cp.CYAN, Cp.SUN, Cp.MINT, Cp.PINK, Color.WHITE, Cp.ROSE, Cp.CYAN, Cp.MINT, Cp.SUN, Cp.PINK, Color.WHITE]
	var top := body_top()
	var avail := body_h()
	var cols := 4
	var rows := 4
	var gap := d(6.0)
	var cw := (size.x - d(PAD_X * 2.0) - gap * float(cols - 1)) / float(cols)
	var ch := minf((avail - gap * float(rows - 1)) / float(rows), d(96.0))
	var total_h := ch * float(rows) + gap * float(rows - 1)
	var y0 := top + (avail - total_h) * 0.35
	for i in lines.size():
		var parts := split_stat(String(lines[i]))
		var tile := Cp.shape(Vector2(cw, ch), d(16.0), {"top": Color(1.0, 1.0, 1.0, 0.09), "bot": Color(1.0, 1.0, 1.0, 0.05), "rim_t": Color(1.0, 1.0, 1.0, 0.25), "rim_b": Color(1.0, 1.0, 1.0, 0.1), "rim_w": d(1.2)})
		tile.position = Vector2(d(PAD_X) + float(i % cols) * (cw + gap), y0 + float(floori(float(i) / float(cols))) * (ch + gap))
		add_child(tile)
		reg(tile, floori(float(i) / 2.0))
		add_label(tile, String(parts[0]), 10.0, Color("bfb2ec"), d(6.0), ch * 0.1, cw - d(12.0), d(16.0), HORIZONTAL_ALIGNMENT_CENTER, false)
		add_label(tile, String(parts[1]), 17.0, tones[i], d(6.0), ch * 0.44, cw - d(12.0), d(30.0), HORIZONTAL_ALIGNMENT_CENTER)


func build_board() -> void:
	var zn: String = m.ZONES[m.board_zone]["name"]
	build_header(title_of("LEADERBOARD"), String(m.T("ENDLESS  -  TOP 10")), Control.new())
	var top := body_top()
	var foot := d(22.0)
	var nav_h := d(36.0)
	var avail := body_h() - foot - nav_h - d(6.0)
	var cw := minf(d(360.0), size.x - d(PAD_X * 2.0))
	var nav_y := top
	var lbtn := Cp.round_btn(32.0, "arrow_l", 16.0)
	var rbtn := Cp.round_btn(32.0, "arrow_r", 16.0)
	lbtn.position = Vector2((size.x - cw) * 0.5, nav_y + (nav_h - lbtn.size.y) * 0.5)
	rbtn.position = Vector2((size.x + cw) * 0.5 - rbtn.size.x, nav_y + (nav_h - rbtn.size.y) * 0.5)
	lbtn.pressed.connect(emit_action.bind("bz-1"))
	rbtn.pressed.connect(emit_action.bind("bz1"))
	add_child(lbtn)
	add_child(rbtn)
	buttons.append(lbtn)
	buttons.append(rbtn)
	add_label(self, m.T(zn), 15.0, Color.WHITE, (size.x - cw) * 0.5 + d(40.0), nav_y, cw - d(80.0), nav_h, HORIZONTAL_ALIGNMENT_CENTER)
	var card := Cp.glass(Vector2(cw, avail), 22.0)
	card.position = Vector2((size.x - cw) * 0.5, top + nav_h + d(6.0))
	add_child(card)
	reg(card, 1)
	var recs: Array = []
	if m.lb.has(str(m.board_zone)):
		recs = m.lb[str(m.board_zone)]
	if recs.is_empty():
		add_label(card, m.T("No runs yet"), 15.0, Cp.DIM, d(12.0), 0.0, cw - d(24.0), avail, HORIZONTAL_ALIGNMENT_CENTER)
	else:
		var rh := minf(d(34.0), (avail - d(16.0)) / 10.0)
		for i in recs.size():
			var r: Dictionary = recs[i]
			var col := Color.WHITE
			if i == 0:
				col = Color("ffd23f")
			elif i == 1:
				col = Color("e4e8f4")
			elif i == 2:
				col = Color("f0b27a")
			var ry := d(8.0) + float(i) * rh
			if i % 2 == 0:
				var band := Cp.shape(Vector2(cw - d(20.0), rh - d(2.0)), d(10.0), {"top": Color(1.0, 1.0, 1.0, 0.05)})
				band.position = Vector2(d(10.0), ry)
				card.add_child(band)
			add_label(card, "#%d" % (i + 1), 13.0, col, d(20.0), ry, d(44.0), rh)
			add_label(card, "%d" % int(r["s"]), 15.0, col, d(66.0), ry, cw * 0.5, rh)
	var ghost_txt: String = m.T("Ghost saved") if m.ghosts.has(str(m.board_zone)) else m.T("No ghost yet")
	add_label(self, ghost_txt, 10.5, Color("bfb2ec"), 0.0, size.y - d(PAD_Y) - foot, size.x, foot, HORIZONTAL_ALIGNMENT_CENTER, false)
