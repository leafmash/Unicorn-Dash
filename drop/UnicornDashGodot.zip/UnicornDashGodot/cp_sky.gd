extends Node2D

const Cp := preload("res://cp_kit.gd")
const U := 1.6

var m


func setup(main: Node) -> void:
	m = main


func halo(c: Vector2, r: float, col: Color) -> void:
	draw_texture_rect(Cp.halo_tex(), Rect2(c * U - Vector2(r, r) * U, Vector2(r, r) * 2.0 * U), false, col)


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	if m == null or m.zk.is_empty():
		return
	var z: Dictionary = m.zk[m.zone]
	var t: float = m.run_time
	var night: float = z["night"]
	var vs := get_viewport_rect().size
	var l := vs.x / U
	if night > 0.1:
		for i in 60:
			var a := night * (0.3 + 0.7 * absf(sin(t * 2.0 + float(i))))
			draw_rect(Rect2(m.hs(float(i)) * l * U, m.hs(float(i + 99)) * 190.0 * U, 1.6 * U, 1.6 * U), Color(1, 1, 1, a))
	if night > 0.55:
		var cyc := t / 6.0
		var k := fposmod(cyc, 1.0)
		var id := floorf(cyc)
		if k < 0.12:
			var f := k / 0.12
			var sx0: float = m.hs(id) * l * 0.8 + 40.0
			var sy0: float = 20.0 + m.hs(id + 5.0) * 60.0
			var hx := sx0 + f * 150.0
			var hy := sy0 + f * 70.0
			var pts := PackedVector2Array([Vector2(hx - 60.0, hy - 28.0) * U, Vector2(hx, hy) * U])
			var cols := PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1.0 - f)])
			draw_polyline_colors(pts, cols, 2.0 * U, true)
	var sx := l * 0.76
	var sy := 88.0 + 30.0 * night + sin(t * 0.5) * 2.0
	var c := Vector2(sx, sy) * U
	var moon := night > 0.5
	halo(Vector2(sx, sy), 170.0, m.hsl(230.0 if moon else 40.0, 100.0, 85.0 if moon else 80.0, 0.55))
	halo(Vector2(sx, sy), 80.0, m.hsl(230.0 if moon else 40.0, 100.0, 92.0, 0.45))
	var body: Color = z["body_c"]
	draw_circle(c, 32.0 * U, body)
	if moon:
		var cc := Color(120.0 / 255.0, 120.0 / 255.0, 180.0 / 255.0, 0.14 * night)
		draw_circle(c + Vector2(-10.0, -6.0) * U, 6.0 * U, cc)
		draw_circle(c + Vector2(8.0, 9.0) * U, 4.5 * U, cc)
		draw_circle(c + Vector2(12.0, -10.0) * U, 3.0 * U, cc)
