# Unicorn Dash Godot - Kotlin parity plan (5 phases)

Rules: Godot 4.3, sprite based, no comments in code, one zip per phase.
Reference: the Kotlin project (UnicornDash.zip). Everything must look, sound and animate like the Kotlin version.
To continue on another account: upload the latest phase zip (and UnicornDash.zip for reference) and say "Phase N শুরু করো, PHASES.md দেখো".

Phase 1 - Sound (DONE)
  tools/kotlin_synth.py is a line by line port of Synth.kt, SynthVoice.kt, Reverb.kt and the compressor.
  tools/bake_kotlin_audio.py ports Sfx.kt and MusicSeq.kt, then renders into audio/:
    47 sound effects (jump, djump, land_soft/hard, coin_1..5, shield, magnet, sx2, slow, life, break, die, fall, near, win, star, buy, deny, mission, ready, revive, click, tick, pop ...)
    music_menu.ogg and music_z0..z17.ogg (one seamless loop per zone, key / progression / tempo from the Kotlin ZN table)
  main.gd: new audio system (SFX player pools, Music bus with low-pass on pause and game over, music cross-fade between menu and zone tracks),
  new sound hooks: double jump, landing, coin combo pitch ladder, power-up per type, shield break, near miss, fall, die, revive, buy, deny, ready.
  Run  python3 tools/bake_kotlin_audio.py  to re-render (needs numpy and scipy).

Phase 2 - Design system and Home screen (DONE)
  New files: cp_kit.gd (Pal, shape shader for Glass / GButton / Pill / Bar, text fit, spring motion, press / enter / popIn), cp_loading.gd, cp_home.gd.
  tools/make_phase2_ui.py renders the 20 icon sprites into art/ui/cp_*.png. Home BOARD tile opens Stats until the Board screen arrives in Phase 5.
  Old art/ui kit and make_button stay for screens that Phase 3-5 will migrate.
  Rebuild art/ui from the Kotlin theme (CpTheme.kt): Pal colours, Glass panel, GButton primary / gold / danger gradients, Pill, RoundBtn, Bar.
  Icon sprites matching Kotlin vector icons: coin, heart, star, lock, gear, sound, pause, arrow, back, play, loop, bag, medal, board, spin, calendar, check.
  Text style (extra bold, soft shadow, auto shrink), motion helpers (pressable, enter, popIn, sheen, pulse glow).
  Loading screen (CpLoading.kt) and Home screen (CpHome.kt): profile capsule with XP bar, star chip, coin pill, missions card, daily card, best card, dock tiles, rainbow arc, mascot.

Phase 3 - Zones, levels, shop (DONE)
  CpZones.kt: zone cards with sky previews, page dots, level buttons with star pop, boss tiles, locked state.
  CpShop.kt: shop cards with live previews, tabs, buy / equip animation.

Phase 4 - In-game HUD and run panels (DONE)
  CpHud.kt: HUD pills, skill buttons, power-up rings, combo badge, countdown, toast layer.
  CpMenu.kt: pause, game over, level complete (count-up + star pop + confetti), unlock, revive, gift dialog.

Phase 5 - Extra screens and final polish (DONE)
  CpMisc.kt: settings toggles, stats, awards, board, spin wheel, missions.
  Bengali layout check, performance pass, README update.

Fix pass after Phase 2
  art/rainbow.png is rebuilt by tools/make_rainbow.py (2560x940, full arc, anti-aliased, shown at 0.5 scale).
  Unicorn is planted GROUND_SINK px into the grass and has a ground shadow during runs.
  cp_lobby.gd is the separate lobby scene ported from lobbyScene / dreamAmbient / lobbyTick (beam, rainbow arc, rays, pedestal, sparkles, wandering unicorn).
  The gameplay rainbow layer is hidden while the lobby is shown.
  Lobby polish: background layers no longer scroll on the home screen; lobby unicorn uses a distance driven walk cycle (frame follows the distance walked, frame 0 when stopped), turn-around squash, breathing, lean, hop squash and stretch, rare idle hops.
  Standing lobby unicorn: art/unicorn_stand.png (frame 0 with the eye removed) drawn through uni_stand.gdshader - head bend (nod and gaze), blink, eye look, tail wave. Values come from cp_lobby.gd (nod, blink_amount, tail_amp).

Phase 3 notes
  cp_zones.gd builds both the zone screen (3x2 cards with drawn sky previews, page dots, arrow buttons) and the level screen (5x2 buttons, star rows, boss tiles, pulsing next level, note pill).
  cp_shop.gd is the shop: 5 tabs, card row with live previews (unicorn skin shader, trail bands, horn, pet art, skill discs), selected card lift, buy / equip button, sparkle burst on purchase.
  The running unicorn on the left of the shop wears the selected skin / trail / horn / pet before you buy (pv_* preview vars in main.gd, cleared when the shop closes).
  The lobby unicorn now also wears the equipped skin (uni_stand.gdshader).
  Swipe paging is not done because taps fire on press; zones use arrow buttons.

Phase 4 notes
  cp_hud.gd: score + zone line, coin pill, heart pill, level progress bar with star, round pause button, distance, power-up rings with drawn glyphs,
  combo badge (follows the unicorn, spring pop, timer ring), banner (GradText), control hint pills. main.update_hud() builds one snapshot dictionary and calls hud.apply().
  cp_panels.gd: scrim + pop-in dialogs: pause (resume / restart / menu / music + sfx toggles), game over (count-up, 3 stat tiles, XP bar, confetti on new best),
  level complete (3 star pops with sfx, stat tiles, XP bar, confetti), revive (5 s heart ring, REVIVE / NO THANKS, auto skip), zone unlocked (sky preview, confetti),
  ready screen (title, zone, pulsing TAP TO RUN, hint pills, back button) and the glass toast layer.
  Flow change: after dying with revives left the REVIVE dialog comes first, game over follows on NO THANKS or after 5 s.
  Zone unlock dialog comes before the level complete dialog.
  The Kotlin hero skill button has no Godot counterpart (skills here are shop upgrades), so it is not ported. Daily gift dialog is not ported (no gift mechanic in Godot).

Phase 5 notes
  cp_misc.gd builds seven screens from the Kotlin CpMisc layouts, one instance per screen kind (settings, missions, daily, spin, awards, stats, board):
  settings (glass toggle list + language chip + STATS / LEADERBOARD side panel), missions (glass card, bars, claim buttons), daily challenge (zone preview card, reward, streak, START),
  spin (drawn wheel with pointer and hub, DAILY SPIN panel, gold / off button), awards (2 x 3 cards per page, claim buttons, pager arrows), stats (4 x 3 tiles),
  leaderboard (top 8 records with gold / silver / bronze, ghost status). Home BOARD tile now opens the leaderboard.
  Screens rebuild only when shown (visibility_changed) and on resize while visible. Toggles animate locally, so on_setting no longer rebuilds the screen.
  Export / Import / Reset progress from Kotlin settings are not ported (Godot has no such save tools).
  Bengali: every label goes through Cp.fit and shrinks to the available width; titles stay uppercase only for English.


Kotlin parity round 2 (found by diffing UnicornDash.zip against this project; phases 6-11)

Phase 6 - New power-ups (DONE)
  mini unicorn, rainbow dash (star), double score, coin rain, wings. art/pu_*.png, art/fx_wings.png from tools/make_phase6_art.py,
  .import files from tools/make_imports.py. HUD rings and glyphs for all 9 timed powers. Weighted pick_power(rng, lvl) like Kotlin pickPu.
  Dash: speed x1.4, invincible, smashes obstacles (+20 score), pulls coins, rainbow tint, 1 s grace after. Wings: flap on tap, low gravity, ceiling, 0.8 s grace after.
  Rain coins are bonus coins (not counted in level pickups). Score bonus is tracked in score_bonus (double score and smashes).

Phase 7 - Hero skills (DONE)
  Skill button on HUD with cooldown ring, 8 Kotlin skills (Rainbow Flash, Candy Shower, Aurora Shield, Moon Leap, Time Freeze, Flame Breath, Sun Blast, Star Warp), skills off in boss levels. Existing upgrades move to a 6th shop tab.

Phase 8 - Shop content and hearts currency (DONE)
  10 skins, 9 trails with particle FX, 7 horns, pets Fairy / Kitten / Dragon / Phoenix, hearts as second currency, zone-locked items, Kotlin prices.

Phase 9 - Progression parity (DONE)
  Daily gift dialog, daily challenge rules (no duck, no double jump, sprint) with 3 stars, 31 awards, 8 mission pool, 10-segment spin with hearts, per-zone top 10 leaderboard, 16 stat tiles, ghost for levels and daily, export / import / reset, near miss +15 score, endless bonus lives and milestone toasts.

Phase 10 - Zone visuals (DONE)
  Per-zone backdrops (far / near / mid / ground) for all 18 zones, rain weather, shooting stars, moon craters, vignette, death animations, victory animation, dash speed lines and camera punch.

Phase 11 - Audio and system polish (DONE)
  Hook unused sounds (gift, unlock, zone, milestone, rain, zap, wings, fan1-3, mini, skill, coin2), speed-reactive music, GET READY countdown, press back twice to exit, haptic patterns.

Phase 7 notes
  main.gd: HEROES table (id, name, desc, cost, cd, dur, hue) holds the 8 hero skills. The old SKILLS shop upgrades are now UPGRADES (up_lv, up_max, up_cost, upgrades dict); the save key stays "skills" so old saves load.
  Shop has 6 tabs: UNICORNS, TRAILS, HORNS, PETS, SKILLS (heroes, bought with coins, equip one, hero0 is free) and UPGRADES (old tab). Hero cards draw a glyph disc, the left side shows a floating glowing icon next to the unicorn, the note shows description and cooldown.
  Save: owned keys hero0..hero7, hero_sel.
  Run: use_skill() from the HUD button or the E key. Timed skills (dash, moon, freeze, fire) run sk_act then start sk_cd; instant skills (candy, aura, blast, warp) start sk_cd at once. Ready flash and the ready sound play when the cooldown ends. Cooldown is not reset on revive.
  dash = 0.5 s of the star power-up. candy = 3 s of coin rain. aura = shield that lasts until it is hit (shield pickups no longer shorten it). moon = half gravity, ceiling, up to 4 jumps. freeze = world speed eased to 0.3, blue tint, falling snow. fire = burns every obstacle except pits and ice within 200 px ahead, flame particles from the mouth. blast = destroys all obstacles within 420 px ahead, big ring. warp = collects coins in 280 px, shifts the world 280 px, clears obstacles around the unicorn, 1 s grace.
  Boss levels: the button is dim and a tap shows "Skills are off in final challenges". Endless and daily runs allow skills.
  cp_hud.gd: round skill button bottom right (pulse when ready, white arc while active, seconds left on cooldown, flash on ready), freeze tint layer. cp_kit.gd: draw_glyph moved here, hue_col added.

Phase 8 notes
  Catalog is the Kotlin Catalog.kt: 10 skins, 9 trails, 7 horns, pets None / Fairy / Kitten / Dragon / Phoenix, prices in coins or hearts (hc), zone locked items (Ember skin z4, Moonlit z16, Frost trail z3, Flame trail z5, Neon z9, Golden z17, Crystal horn z6, Starlight horn z2, Phoenix z5). They unlock when 7 levels of the zone are cleared (unlock_cosmetics at run end and on load).
  Skins: skin.gdshaderinc (shared by skin.gdshader and uni_stand.gdshader) remaps the sprite palette to body / leg / back colours and the mane bands to h0 + st * band hue, exactly like Unicorn.kt. Horn types recolour the sprite horn through hn_* uniforms (candy stripes, flame, rainbow, crystal, heart). A glow sprite sits at the horn tip, heart and star horns get a tip decoration.
  Trails: trail_color() gives per band colours (Rainbow follows the skin mane, Aurora cycles), trail_fx particles per type (dust, star, heart, snow, ember, spark, gold) from the TFX table.
  Pets: art/pet_<kind>.png are 8 frame sheets from tools/make_phase8_art.py (port of petDraw). Fairy power-ups x1.5 with glow and ring while one is active, Kitten +5 coins every 10 coins, double heart weight and walks on the ground, Dragon score x1.2, Phoenix one free rescue per run that clears the path.
  Hearts: saved currency (key "hearts"). Heart pickups add 1, revive costs 1, 2, 4 hearts, up to 3 revives, endless only (as in Kotlin). In run lives are gone, one hit without shield or phoenix ends the run. The old Extra Heart upgrade is now Free Revive (id life, one free revive per level per endless run).
  Save: key v8. Older saves are migrated once: bought skins, trails, horns and pets are refunded at their old prices, equips reset.

Phase 9 notes
  Missions: MISSIONS pool of 8 (per-mission target and reward, run-max flags), 3 picked per day by hs(day). dstate key v9 marks the new format.
  Daily challenge: daily_cfg() gives zone, level and rule (noduck, nodj, sprint) from hs(day). run_rule is applied in update_play and do_jump. Sprint ends at 30 s. Daily stars: finish, 80% pickups, no damage (run_hurt).
  Gift: check_gift() at boot, 20+10*min(streak,7) coins, dialog panels.show_gift, keys gs and glast in dstate.
  Spin: 10 segments, SPIN_HEARTS marks heart prizes (added to hearts). Paid extra spins kept.
  Awards: 31 in ACHS (ids a00..a30), new stat keys zone1, perfect, skins, gstreak, dcstreak, dist, dodge, near, dcrule.
  Leaderboard: lb dict per zone (top 10, endless), board has zone arrows. Old records migrate into lb.
  Ghost: key is zone (endless), D (daily) or L<zone>_<level>; levels and daily keep the fastest run.
  Settings: EXPORT copies the save (without ghosts) to the clipboard as base64, IMPORT reads it back, RESET needs two taps within 4 s.
  Play: near miss +15 score, endless bonus life at 1500 then every 2000, milestone toasts every 250.


Phase 10 notes
  tools/cv_kit.py (canvas port) + tools/zone_layers.py (port of BackdropA/B z0..z17 far / near / mid / ground) + tools/make_phase10_art.py bake 72 seamless strips (1600 units wide, 1.6 px per unit) into art/zones/z<N>_<layer>.png and write zone_art.gd (Kotlin zone colours, layer file and y offsets). Run  python3 tools/make_phase10_art.py  then  python3 tools/make_imports.py art/zones/*.png  after changing them.
  Parallax factors are the Kotlin ones (far 0.08, near 0.2, mid 0.45, ground 1.0). The ground surface moved to y 480 (GROUND_Y) so the hooves stand on it. Sky is the Kotlin two colour gradient, bottom haze and soil gradient come from zone_art.gd. The old rainbow sky layer and the LUM recolour shader are gone, zone 0 uses the Kotlin rainbow arcs.
  cp_sky.gd: night stars, shooting star (night > 0.55), sun / moon with two halos and craters at night. cp_amb.gd: 38 ambient particles with the 13 Kotlin modes (fireflies, petals, snow, dust, bubbles, leaves, rain, mist, sparkle, rainbow sparkle) and the dash speed lines. Both read zk[zone] from zone_art.gd. art/cloud_k.png replaces the old clouds (round, no flat bottom), hidden in cave, space, city, ocean and ember zones.
  Camera (apply_camera): punch zoom 3 percent, sin shake, jump lift, dash zoom 4.5 percent, applied to bg and world. Radial vignette shader and red hit flash sit under the HUD.
  Death: tumble physics with ground contact from the Kotlin leg points (low_y), slow start, one bounce, rest angle. Kinds: pit, zap (shake in place with yellow flicker, panel 1.15 s later), bird, fire, pillar, crystal (smashes). Game over / revive panel appears 0.8 s after the hit.
  Victory: coast to a stop, squat, jump with colour bursts, land, rear up with neigh sound, idle sparkles, panel after 2.9 s.
  Animated flicker and sway of the baked backdrop (lanterns, lava glow, vines) is frozen at the baked pose.
  Fix: cp_shop.gd had untyped := inferences that did not compile, they are typed now.

Phase 11 notes
  Sounds hooked: gift (daily gift claim, spin result), unlock (zone unlocked panel), zone (run start banner), zap (zap deaths), fan1 / fan2 / fan3 (level complete by stars, replaces win), tick_lo / tick_hi (countdown and each wheel segment). rain, wings, mini, skill, coin2 were already hooked. All of them are in SFX_PRELOAD.
  GET READY countdown (3, 2, 1) after resume and after revive (cd, start_countdown, tick_countdown, hud.show_count). Jumps are ignored while it runs.
  Music pitch follows speed (up to +8 percent), eases down for slow power-up (-6 percent) and freeze skill (-12 percent), holds the value while paused or dead.
  Press back twice within 2 s on the home screen to quit (toast Press back again to exit).
  Haptics: vibrate_pattern(list) uses Android waveform semantics (off, on, off, on). Hit 40 30 80, death 40 30 120, level complete 30 40 30 40 80, revive 60.
