# Unicorn Dash Godot - Kotlin parity plan (5 phases)

Rules: Godot 4.3, sprite based, no comments in code, one zip per phase.
Reference: the Kotlin project (UnicornDash.zip). Everything must look, sound and animate like the Kotlin version.
To continue on another account: upload the latest phase zip (and UnicornDash.zip for reference) and say "Phase N শুরু করো, PHASES.md দেখো".

Phase 1 - Sound (DONE)
  tools/kotlin_synth.py is a line by line port of Synth.kt, SynthVoice.kt, Reverb.kt and the compressor.
  tools/bake_kotlin_audio.py ports Sfx.kt and MusicSeq.kt, then renders into audio/:
    47 sound effects (jump, djump, land_soft/hard, coin_1..5, shield, magnet, sx2, slow, life, break, die, fall, near, win, star, buy, deny, mission, ready, revive, click, tick, pop ...)
    music_menu.ogg and music_z0..z17.ogg (one seamless loop per zone, key / progression / tempo from the Kotlin ZN table)
  main.gd: new audio system (SFX player pools, Music bus with low-pass on pause and game over, music cross-fade between menu and zone tracks),
  new sound hooks: double jump, landing, coin combo pitch ladder, power-up per type, shield break, near miss, fall, die, revive, buy, deny, ready.
  Run  python3 tools/bake_kotlin_audio.py  to re-render (needs numpy and scipy).

Phase 2 - Design system and Home screen (DONE)
  New files: cp_kit.gd (Pal, shape shader for Glass / GButton / Pill / Bar, text fit, spring motion, press / enter / popIn), cp_loading.gd, cp_home.gd.
  tools/make_phase2_ui.py renders the 20 icon sprites into art/ui/cp_*.png. Home BOARD tile opens Stats until the Board screen arrives in Phase 5.
  Old art/ui kit and make_button stay for screens that Phase 3-5 will migrate.
  Rebuild art/ui from the Kotlin theme (CpTheme.kt): Pal colours, Glass panel, GButton primary / gold / danger gradients, Pill, RoundBtn, Bar.
  Icon sprites matching Kotlin vector icons: coin, heart, star, lock, gear, sound, pause, arrow, back, play, loop, bag, medal, board, spin, calendar, check.
  Text style (extra bold, soft shadow, auto shrink), motion helpers (pressable, enter, popIn, sheen, pulse glow).
  Loading screen (CpLoading.kt) and Home screen (CpHome.kt): profile capsule with XP bar, star chip, coin pill, missions card, daily card, best card, dock tiles, rainbow arc, mascot.

Phase 3 - Zones, levels, shop (DONE)
  CpZones.kt: zone cards with sky previews, page dots, level buttons with star pop, boss tiles, locked state.
  CpShop.kt: shop cards with live previews, tabs, buy / equip animation.

Phase 4 - In-game HUD and run panels (DONE)
  CpHud.kt: HUD pills, skill buttons, power-up rings, combo badge, countdown, toast layer.
  CpMenu.kt: pause, game over, level complete (count-up + star pop + confetti), unlock, revive, gift dialog.

Phase 5 - Extra screens and final polish (DONE)
  CpMisc.kt: settings toggles, stats, awards, board, spin wheel, missions.
  Bengali layout check, performance pass, README update.

Fix pass after Phase 2
  art/rainbow.png is rebuilt by tools/make_rainbow.py (2560x940, full arc, anti-aliased, shown at 0.5 scale).
  Unicorn is planted GROUND_SINK px into the grass and has a ground shadow during runs.
  cp_lobby.gd is the separate lobby scene ported from lobbyScene / dreamAmbient / lobbyTick (beam, rainbow arc, rays, pedestal, sparkles, wandering unicorn).
  The gameplay rainbow layer is hidden while the lobby is shown.
  Lobby polish: background layers no longer scroll on the home screen; lobby unicorn uses a distance driven walk cycle (frame follows the distance walked, frame 0 when stopped), turn-around squash, breathing, lean, hop squash and stretch, rare idle hops.
  Standing lobby unicorn: art/unicorn_stand.png (frame 0 with the eye removed) drawn through uni_stand.gdshader - head bend (nod and gaze), blink, eye look, tail wave. Values come from cp_lobby.gd (nod, blink_amount, tail_amp).

Phase 3 notes
  cp_zones.gd builds both the zone screen (3x2 cards with drawn sky previews, page dots, arrow buttons) and the level screen (5x2 buttons, star rows, boss tiles, pulsing next level, note pill).
  cp_shop.gd is the shop: 5 tabs, card row with live previews (unicorn skin shader, trail bands, horn, pet art, skill discs), selected card lift, buy / equip button, sparkle burst on purchase.
  The running unicorn on the left of the shop wears the selected skin / trail / horn / pet before you buy (pv_* preview vars in main.gd, cleared when the shop closes).
  The lobby unicorn now also wears the equipped skin (uni_stand.gdshader).
  Swipe paging is not done because taps fire on press; zones use arrow buttons.

Phase 4 notes
  cp_hud.gd: score + zone line, coin pill, heart pill, level progress bar with star, round pause button, distance, power-up rings with drawn glyphs,
  combo badge (follows the unicorn, spring pop, timer ring), banner (GradText), control hint pills. main.update_hud() builds one snapshot dictionary and calls hud.apply().
  cp_panels.gd: scrim + pop-in dialogs: pause (resume / restart / menu / music + sfx toggles), game over (count-up, 3 stat tiles, XP bar, confetti on new best),
  level complete (3 star pops with sfx, stat tiles, XP bar, confetti), revive (5 s heart ring, REVIVE / NO THANKS, auto skip), zone unlocked (sky preview, confetti),
  ready screen (title, zone, pulsing TAP TO RUN, hint pills, back button) and the glass toast layer.
  Flow change: after dying with revives left the REVIVE dialog comes first, game over follows on NO THANKS or after 5 s.
  Zone unlock dialog comes before the level complete dialog.
  The Kotlin hero skill button has no Godot counterpart (skills here are shop upgrades), so it is not ported. Daily gift dialog is not ported (no gift mechanic in Godot).

Phase 5 notes
  cp_misc.gd builds seven screens from the Kotlin CpMisc layouts, one instance per screen kind (settings, missions, daily, spin, awards, stats, board):
  settings (glass toggle list + language chip + STATS / LEADERBOARD side panel), missions (glass card, bars, claim buttons), daily challenge (zone preview card, reward, streak, START),
  spin (drawn wheel with pointer and hub, DAILY SPIN panel, gold / off button), awards (2 x 3 cards per page, claim buttons, pager arrows), stats (4 x 3 tiles),
  leaderboard (top 8 records with gold / silver / bronze, ghost status). Home BOARD tile now opens the leaderboard.
  Screens rebuild only when shown (visibility_changed) and on resize while visible. Toggles animate locally, so on_setting no longer rebuilds the screen.
  Export / Import / Reset progress from Kotlin settings are not ported (Godot has no such save tools).
  Bengali: every label goes through Cp.fit and shrinks to the available width; titles stay uppercase only for English.
