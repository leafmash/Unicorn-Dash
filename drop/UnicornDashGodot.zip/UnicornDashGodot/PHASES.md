# Unicorn Dash Godot - Kotlin parity plan (5 phases)

Rules: Godot 4.3, sprite based, no comments in code, one zip per phase.
Reference: the Kotlin project (UnicornDash.zip). Everything must look, sound and animate like the Kotlin version.
To continue on another account: upload the latest phase zip (and UnicornDash.zip for reference) and say "Phase N শুরু করো, PHASES.md দেখো".

Phase 1 - Sound (DONE)
  tools/kotlin_synth.py is a line by line port of Synth.kt, SynthVoice.kt, Reverb.kt and the compressor.
  tools/bake_kotlin_audio.py ports Sfx.kt and MusicSeq.kt, then renders into audio/:
    47 sound effects (jump, djump, land_soft/hard, coin_1..5, shield, magnet, sx2, slow, life, break, die, fall, near, win, star, buy, deny, mission, ready, revive, click, tick, pop ...)
    music_menu.ogg and music_z0..z17.ogg (one seamless loop per zone, key / progression / tempo from the Kotlin ZN table)
  main.gd: new audio system (SFX player pools, Music bus with low-pass on pause and game over, music cross-fade between menu and zone tracks),
  new sound hooks: double jump, landing, coin combo pitch ladder, power-up per type, shield break, near miss, fall, die, revive, buy, deny, ready.
  Run  python3 tools/bake_kotlin_audio.py  to re-render (needs numpy and scipy).

Phase 2 - Design system and Home screen
  Rebuild art/ui from the Kotlin theme (CpTheme.kt): Pal colours, Glass panel, GButton primary / gold / danger gradients, Pill, RoundBtn, Bar.
  Icon sprites matching Kotlin vector icons: coin, heart, star, lock, gear, sound, pause, arrow, back, play, loop, bag, medal, board, spin, calendar, check.
  Text style (extra bold, soft shadow, auto shrink), motion helpers (pressable, enter, popIn, sheen, pulse glow).
  Loading screen (CpLoading.kt) and Home screen (CpHome.kt): profile capsule with XP bar, star chip, coin pill, missions card, daily card, best card, dock tiles, rainbow arc, mascot.

Phase 3 - Zones, levels, shop
  CpZones.kt: zone cards with sky previews, page dots, level buttons with star pop, boss tiles, locked state.
  CpShop.kt: shop cards with live previews, tabs, buy / equip animation.

Phase 4 - In-game HUD and run panels
  CpHud.kt: HUD pills, skill buttons, power-up rings, combo badge, countdown, toast layer.
  CpMenu.kt: pause, game over, level complete (count-up + star pop + confetti), unlock, revive, gift dialog.

Phase 5 - Extra screens and final polish
  CpMisc.kt: settings toggles, stats, awards, board, spin wheel, missions.
  Bengali layout check, performance pass, README update.
