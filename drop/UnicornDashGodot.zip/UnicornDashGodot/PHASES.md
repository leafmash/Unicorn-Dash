# UI Polish Plan (5 phases)

Rules: Godot 4.3, sprite based, no comments in code, one zip per phase.
To continue on another account: upload the latest phase zip and say "Phase N শুরু করো, PHASES.md দেখো".

Phase 1 - UI foundation (DONE)
  tools/make_ui_art.py bakes the sprite kit into art/ui/ (glossy candy buttons s/l in 10 colours, glass panel, row card, coin chip, dim vignette).
  main.gd: kit_box / kit_pick / button_style / make_panel / row_style now use 9-slice sprites; bold Poppins font with soft shadow on all labels;
  press punch animation on every button (tap_button -> punch); pop-in / fade-in intro on every screen and panel (watch_show);
  coin bank is now a chip.

Phase 2 - Home screen
  Animated logo, mascot unicorn running on the home screen, staggered button entrance, icon sprites for MISSIONS / DAILY / SPIN / AWARDS / STATS / SETTINGS,
  notification badges, sheen sweep on the main button, idle pulse on ADVENTURE, coin counter roll-up.

Phase 3 - Zone select, level select, shop
  Zone cards with sky gradient previews, level path tiles with star pop-in, boss tiles, shop cards with live item previews
  (skin / trail / horn / pet sprites), tab bar with sliding highlight, buy / equip animations.

Phase 4 - In-game HUD and run panels
  HUD chips for score / coins / hearts, power-up timer rings, combo pop, level banner, READY screen, pause / game over / win panels
  with dim overlay, animated star reveal, score count-up, confetti, nicer screen transition.

Phase 5 - Extra screens and final polish
  Missions, daily, lucky spin wheel (sprite based), awards, stats, settings toggles, toast, page arrows,
  Bengali layout check, performance pass, README update.
