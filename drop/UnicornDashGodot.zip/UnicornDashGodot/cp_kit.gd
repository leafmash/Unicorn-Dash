extends RefCounted

const U := 1.6
const ICON_PAD := 16.0 / 96.0

const SHAPE_CODE := """shader_type canvas_item;

uniform vec2 size = vec2(100.0, 40.0);
uniform float radius = 12.0;
uniform vec4 c_top = vec4(1.0);
uniform vec4 c_mid = vec4(1.0);
uniform vec4 c_bot = vec4(1.0);
uniform vec4 rim_top = vec4(0.0);
uniform vec4 rim_bot = vec4(0.0);
uniform float rim_w = 1.6;
uniform float gloss = 0.0;
uniform float sheen = 0.0;

float box_sd(vec2 p, vec2 h, float r) {
	vec2 q = abs(p) - h + vec2(r);
	return length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}

void fragment() {
	float r = min(radius, min(size.x, size.y) * 0.5);
	vec2 p = UV * size - size * 0.5;
	float d = box_sd(p, size * 0.5, r);
	float inside = 1.0 - smoothstep(-0.7, 0.7, d);
	float y = UV.y;
	vec4 col = y < 0.5 ? mix(c_top, c_mid, y * 2.0) : mix(c_mid, c_bot, (y - 0.5) * 2.0);
	if (gloss > 0.0) {
		float g = clamp(1.0 - y / 0.55, 0.0, 1.0) * 0.333 * gloss;
		col.rgb = mix(col.rgb, vec3(1.0), g);
	}
	if (sheen > 0.0) {
		float s = fract(TIME / 2.8) * 2.0 - 0.5;
		float band = max(0.0, 1.0 - abs(UV.x - s) / 0.22) * 0.25;
		col.rgb = mix(col.rgb, vec3(1.0), band);
	}
	float rk = smoothstep(-rim_w - 0.6, -rim_w + 0.6, d) * mix(rim_top.a, rim_bot.a, y);
	vec3 rc = mix(rim_top.rgb, rim_bot.rgb, y);
	float oa = rk + col.a * (1.0 - rk);
	vec3 orgb = col.rgb;
	if (oa > 0.0001) {
		orgb = (rc * rk + col.rgb * col.a * (1.0 - rk)) / oa;
	}
	COLOR = vec4(orgb, oa * inside);
}
"""

const GRAD_CODE := """shader_type canvas_item;

uniform float width = 100.0;
uniform vec4 g0 = vec4(1.0);
uniform vec4 g1 = vec4(1.0);
uniform vec4 g2 = vec4(1.0);
uniform vec4 g3 = vec4(1.0);
uniform vec4 g4 = vec4(1.0);

varying float lx;

void vertex() {
	lx = VERTEX.x;
}

void fragment() {
	float k = clamp(lx / width, 0.0, 1.0) * 4.0;
	vec4 c = mix(g0, g1, clamp(k, 0.0, 1.0));
	c = mix(c, g2, clamp(k - 1.0, 0.0, 1.0));
	c = mix(c, g3, clamp(k - 2.0, 0.0, 1.0));
	c = mix(c, g4, clamp(k - 3.0, 0.0, 1.0));
	COLOR = vec4(c.rgb, COLOR.a);
}
"""

static var font: Font
static var shape_shader: Shader
static var grad_shader: Shader
static var tex_cache: Dictionary = {}

static var PINK := Color("ff9be0")
static var PURPLE := Color("9a5cff")
static var VIOLET := Color("5b34c8")
static var SUN := Color("ffe27a")
static var AMBER := Color("ffa23f")
static var MINT := Color("7dffd4")
static var ROSE := Color("ffb0cf")
static var CYAN := Color("9fefff")
static var LILAC := Color("d9ccff")
static var DIM := Color("a89cd4")
static var GOLD := Color("ffd23f")
static var GOLD_DARK := Color("ffb000")
static var HEART := Color("ff5a8c")
static var RUBY := Color("d23c5c")
static var INK := Color("2a1458")
static var NIGHT := Color("140a33")
static var GLASS_TOP := Color("3c2688dc")
static var GLASS_BOT := Color("1a0e4eec")
static var PANEL := Color("180b40cc")
static var PANEL_RIM := Color("ffffff2e")
static var TEAL := Color("2fd6b4")
static var RIM := Color("ffffff66")
static var RIM_TOP := Color("ffffff77")
static var RIM_BOT := Color("ffffff14")
static var BADGE := Color("ff4f93")
static var BADGE_RIM := Color("2a1670")


static func dp(v: float) -> float:
	return v * U


static func spring(t: float, zeta: float, k: float) -> float:
	if t <= 0.0:
		return 0.0
	var w := sqrt(k)
	if zeta < 1.0:
		var wd := w * sqrt(1.0 - zeta * zeta)
		var e := exp(-zeta * w * t)
		return 1.0 - e * (cos(wd * t) + (zeta * w / wd) * sin(wd * t))
	var e2 := exp(-w * t)
	return 1.0 - e2 * (1.0 + w * t)


static func fast_out_slow_in(x: float) -> float:
	if x <= 0.0:
		return 0.0
	if x >= 1.0:
		return 1.0
	var lo := 0.0
	var hi := 1.0
	var t := x
	for i in 14:
		t = (lo + hi) * 0.5
		var bx := 3.0 * (1.0 - t) * (1.0 - t) * t * 0.4 + 3.0 * (1.0 - t) * t * t * 0.2 + t * t * t
		if bx < x:
			lo = t
		else:
			hi = t
	return 3.0 * (1.0 - t) * t * t + t * t * t


static func reverse_wave(t: float, period: float) -> float:
	var ph := fmod(t, period * 2.0) / period
	var x := ph if ph <= 1.0 else 2.0 - ph
	return fast_out_slow_in(x)


static func tex(nm: String) -> Texture2D:
	if not tex_cache.has(nm):
		tex_cache[nm] = load("res://art/ui/cp_%s.png" % nm)
	return tex_cache[nm]


static func get_shape_shader() -> Shader:
	if shape_shader == null:
		shape_shader = Shader.new()
		shape_shader.code = SHAPE_CODE
	return shape_shader


static func get_grad_shader() -> Shader:
	if grad_shader == null:
		grad_shader = Shader.new()
		grad_shader.code = GRAD_CODE
	return grad_shader


static func shape(sz: Vector2, radius: float, o: Dictionary = {}) -> ColorRect:
	var r := ColorRect.new()
	r.size = sz
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var top: Color = o.get("top", Color.WHITE)
	var bot: Color = o.get("bot", top)
	var mid: Color = o.get("mid", top.lerp(bot, 0.5))
	var none := Color(1.0, 1.0, 1.0, 0.0)
	var mat := ShaderMaterial.new()
	mat.shader = get_shape_shader()
	mat.set_shader_parameter("size", sz)
	mat.set_shader_parameter("radius", radius)
	mat.set_shader_parameter("c_top", top)
	mat.set_shader_parameter("c_mid", mid)
	mat.set_shader_parameter("c_bot", bot)
	mat.set_shader_parameter("rim_top", o.get("rim_t", none))
	mat.set_shader_parameter("rim_bot", o.get("rim_b", none))
	mat.set_shader_parameter("rim_w", float(o.get("rim_w", U)))
	mat.set_shader_parameter("gloss", float(o.get("gloss", 0.0)))
	mat.set_shader_parameter("sheen", float(o.get("sheen", 0.0)))
	r.material = mat
	r.resized.connect(func() -> void: mat.set_shader_parameter("size", r.size))
	return r


static func glass(sz: Vector2, radius_dp: float) -> ColorRect:
	return shape(sz, radius_dp * U, {"top": GLASS_TOP, "bot": GLASS_BOT, "rim_t": RIM_TOP, "rim_b": RIM_BOT, "rim_w": U})


static func label(text: String, sp: float, color: Color, shadow: bool = true) -> Label:
	var l := Label.new()
	l.text = text
	l.set_meta("sp", sp)
	l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", roundi(sp * U))
	l.add_theme_color_override("font_color", color)
	if shadow:
		l.add_theme_color_override("font_shadow_color", Color(0.157, 0.078, 0.314, 0.42))
		l.add_theme_constant_override("shadow_offset_x", 0)
		l.add_theme_constant_override("shadow_offset_y", roundi(2.0 * U))
		l.add_theme_constant_override("shadow_outline_size", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func text_w(text: String, sp: float) -> float:
	return font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, roundi(sp * U)).x


static func set_text(l: Label, text: String) -> void:
	l.text = text
	l.custom_minimum_size.x = text_w(text, float(l.get_meta("sp")))


static func fit(l: Label, max_w: float) -> void:
	var base := roundi(float(l.get_meta("sp")) * U)
	var s := base
	while s > roundi(base * 0.5) and font.get_string_size(l.text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, s).x > max_w:
		s = int(s * 0.92)
	l.add_theme_font_size_override("font_size", s)
	l.custom_minimum_size.x = font.get_string_size(l.text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, s).x


static func place(l: Label, x: float, y: float, w: float, h: float, halign: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	l.position = Vector2(x, y)
	l.size = Vector2(w, h)
	l.horizontal_alignment = halign
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l


static func gap(px: float) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(px, 0.0)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


static func grad_title(text: String, sp: float) -> Control:
	var tw := text_w(text, sp) + 2.0
	var fh := font.get_height(roundi(sp * U))
	var root := Control.new()
	root.custom_minimum_size = Vector2(tw, fh)
	root.size = Vector2(tw, fh)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var back := label(text, sp, Color(0.157, 0.078, 0.314, 0.5), false)
	back.position = Vector2(0.0, 3.0 * U)
	back.size = Vector2(tw, fh)
	root.add_child(back)
	var front := label(text, sp, Color.WHITE, false)
	front.size = Vector2(tw, fh)
	var mat := ShaderMaterial.new()
	mat.shader = get_grad_shader()
	mat.set_shader_parameter("width", maxf(tw, 1.0))
	mat.set_shader_parameter("g0", PINK)
	mat.set_shader_parameter("g1", SUN)
	mat.set_shader_parameter("g2", MINT)
	mat.set_shader_parameter("g3", CYAN)
	mat.set_shader_parameter("g4", PURPLE)
	front.material = mat
	root.add_child(front)
	return root


static func icon(nm: String, size_dp: float, tint_c: Color = Color.WHITE) -> Control:
	var px := size_dp * U
	var w := Control.new()
	w.custom_minimum_size = Vector2(px, px)
	w.size = Vector2(px, px)
	w.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var t := TextureRect.new()
	t.texture = tex(nm)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_SCALE
	var pad := px * ICON_PAD
	t.position = Vector2(-pad, -pad)
	t.size = Vector2(px + pad * 2.0, px + pad * 2.0)
	t.self_modulate = tint_c
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	w.add_child(t)
	w.set_meta("tex", t)
	return w


static func set_icon(w: Control, nm: String) -> void:
	var t: TextureRect = w.get_meta("tex")
	t.texture = tex(nm)


static func tint(w: Control, c: Color) -> void:
	var t: TextureRect = w.get_meta("tex")
	t.self_modulate = c


static func skin(kind: String) -> Dictionary:
	if kind == "gold":
		return {"top": Color("ffeb8a"), "mid": Color("ffc23c"), "bot": Color("ffa61f"), "lip": Color("b86a00"), "rim": Color("ffffffaa"), "text": Color("5a3000"), "glow": false}
	if kind == "danger":
		return {"top": Color("ff9aa8"), "mid": Color("ef5470"), "bot": Color("d13a5a"), "lip": Color("86183a"), "rim": Color("ffffff99"), "text": Color.WHITE, "glow": true}
	if kind == "mint":
		return {"top": Color("8cffe2"), "mid": Color("36ddbe"), "bot": Color("16b8a2"), "lip": Color("0b6d69"), "rim": Color("ffffff99"), "text": Color("053b3a"), "glow": false}
	if kind == "soft":
		return {"top": Color("4b3299"), "mid": Color("42297f"), "bot": Color("38227c"), "lip": Color("1b0d4a"), "rim": Color("ffffff44"), "text": Color.WHITE, "glow": true}
	if kind == "off":
		return {"top": Color("3d3366"), "mid": Color("352c60"), "bot": Color("30285a"), "lip": Color("1b1538"), "rim": Color("ffffff22"), "text": Color("ffffff77"), "glow": false}
	return {"top": Color("ff8fdc"), "mid": Color("b45cff"), "bot": Color("8b45ee"), "lip": Color("4f25b0"), "rim": Color("ffffff99"), "text": Color.WHITE, "glow": true}


static func flat_button(sz: Vector2) -> Button:
	var b := Button.new()
	b.flat = true
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = sz
	b.size = sz
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for st in ["normal", "hover", "pressed", "disabled", "focus"]:
		b.add_theme_stylebox_override(st, StyleBoxEmpty.new())
	return b


static func face_button(sz: Vector2, radius: float, kind: String, lip: float, sheen: bool = false) -> Button:
	var sk := skin(kind)
	var b := flat_button(sz)
	b.disabled = kind == "off"
	var lip_rect := shape(sz, radius, {"top": sk["lip"], "rim_w": 0.0})
	b.add_child(lip_rect)
	var face := shape(
		Vector2(sz.x, sz.y - lip),
		radius,
		{"top": sk["top"], "mid": sk["mid"], "bot": sk["bot"], "rim_t": sk["rim"], "rim_b": sk["rim"], "rim_w": U, "gloss": 1.0, "sheen": 1.0 if sheen else 0.0}
	)
	b.add_child(face)
	var content := Control.new()
	content.size = face.size
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	face.add_child(content)
	b.set_meta("face", face)
	b.set_meta("content", content)
	b.set_meta("lip", lip)
	b.set_meta("skin", sk)
	b.set_meta("cp_press", true)
	return b


static func g_button(text: String, w: float, h_dp: float, kind: String, sp: float, o: Dictionary = {}) -> Button:
	var h := h_dp * U
	var lip := (5.0 if h_dp >= 52.0 else 4.0 if h_dp >= 40.0 else 3.0) * U
	var want_sheen: bool = bool(o.get("sheen", false)) and (kind == "primary" or kind == "gold" or kind == "mint")
	var b := face_button(Vector2(w, h), h * 0.3, kind, lip, want_sheen)
	var sk: Dictionary = b.get_meta("skin")
	var content: Control = b.get_meta("content")
	var row := HBoxContainer.new()
	row.size = content.size
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 0)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(row)
	var used := 0.0
	if o.has("lead"):
		var ldp: float = float(o.get("lead_dp", 20.0))
		var ic := icon(String(o["lead"]), ldp, o.get("lead_tint", Color.WHITE))
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(ic)
		row.add_child(gap(8.0 * U))
		used += ldp * U + 8.0 * U
	if bool(o.get("coin", false)):
		var cic := icon("coin", sp * 1.1)
		cic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(cic)
		row.add_child(gap(6.0 * U))
		used += sp * 1.1 * U + 6.0 * U
	if bool(o.get("heart", false)):
		var hic := icon("heart", sp * 1.1)
		hic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(hic)
		row.add_child(gap(6.0 * U))
		used += sp * 1.1 * U + 6.0 * U
	var l := label(text, sp, sk["text"], bool(sk["glow"]))
	l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(l)
	fit(l, w - 28.0 * U - used)
	b.set_meta("label", l)
	return b


static func round_btn(size_dp: float, icon_name: String, icon_dp: float, tint_c: Color = Color.WHITE) -> Button:
	var s := size_dp * U
	var b := face_button(Vector2(s, s), s * 0.32, "soft", 3.0 * U)
	var content: Control = b.get_meta("content")
	var ic := icon(icon_name, icon_dp, tint_c)
	ic.position = Vector2((content.size.x - ic.size.x) * 0.5, (content.size.y - ic.size.y) * 0.5)
	content.add_child(ic)
	b.set_meta("icon", ic)
	return b


static func pill(h_dp: float) -> Control:
	var h := h_dp * U
	var root := Control.new()
	root.custom_minimum_size = Vector2(24.0 * U, h)
	root.size = Vector2(24.0 * U, h)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := shape(Vector2(24.0 * U, h), h * 0.34, {"top": PANEL, "rim_t": PANEL_RIM, "rim_b": PANEL_RIM, "rim_w": U})
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(bg)
	var row := HBoxContainer.new()
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 0)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(row)
	root.set_meta("row", row)
	return root


static func pill_add(root: Control, c: Control) -> void:
	var row: HBoxContainer = root.get_meta("row")
	c.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(c)


static func pill_update(root: Control) -> void:
	var row: HBoxContainer = root.get_meta("row")
	var w := 24.0 * U
	for c in row.get_children():
		w += (c as Control).custom_minimum_size.x
	root.custom_minimum_size.x = w
	root.size.x = w


static func bar(sz: Vector2, c0: Color = PINK, c1: Color = PURPLE) -> Control:
	var root := Control.new()
	root.custom_minimum_size = sz
	root.size = sz
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := shape(sz, sz.y * 0.5, {"top": Color(1.0, 1.0, 1.0, 0.16)})
	root.add_child(bg)
	var fill := shape(Vector2(0.0, sz.y), sz.y * 0.5, {"top": c0, "bot": c1})
	fill.visible = false
	root.add_child(fill)
	root.set_meta("fill", fill)
	root.set_meta("full", sz.x)
	root.set_meta("frac", 0.0)
	return root


static func bar_set(root: Control, frac: float, animate: bool = true) -> void:
	var f := clampf(frac, 0.0, 1.0)
	var fill: Control = root.get_meta("fill")
	var full: float = root.get_meta("full")
	var from: float = root.get_meta("frac")
	root.set_meta("frac", f)
	if root.has_meta("tw"):
		var old: Tween = root.get_meta("tw")
		if old != null and old.is_valid():
			old.kill()
	if not animate or not root.is_inside_tree() or absf(f - from) < 0.0005:
		fill.size.x = full * f
		fill.visible = f > 0.001
		return
	var tw := root.create_tween()
	root.set_meta("tw", tw)
	var step: Callable = func(t: float) -> void:
		var v := clampf(from + (f - from) * spring(t, 0.8, 120.0), 0.0, 1.0)
		fill.size.x = full * v
		fill.visible = v > 0.001
	tw.tween_method(step, 0.0, 0.8, 0.8)


static func badge() -> Control:
	var s := 15.0 * U
	var r := shape(Vector2(s, s), s * 0.5, {"top": BADGE, "rim_t": BADGE_RIM, "rim_b": BADGE_RIM, "rim_w": 2.0 * U})
	r.pivot_offset = Vector2(s, s) * 0.5
	return r


static func pulse_glow(color: Color, radius_dp: float) -> TextureRect:
	var g := Gradient.new()
	g.set_color(0, Color(color.r, color.g, color.b, 0.45))
	g.set_color(1, Color(color.r, color.g, color.b, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	var t := TextureRect.new()
	t.texture = gt
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_SCALE
	t.size = Vector2.ONE * radius_dp * 2.0 * U
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t


static func press(b: Button) -> void:
	if not b.is_inside_tree():
		return
	var face: Control = b.get_meta("face")
	var lip: float = b.get_meta("lip")
	if b.has_meta("fx"):
		var old: Tween = b.get_meta("fx")
		if old != null and old.is_valid():
			old.kill()
	b.pivot_offset = b.size * 0.5
	face.position.y = lip
	var tw := b.create_tween()
	b.set_meta("fx", tw)
	tw.set_parallel(true)
	tw.tween_property(face, "position:y", 0.0, 0.09).set_delay(0.06)
	var step: Callable = func(t: float) -> void:
		var sc := 0.93 + 0.07 * spring(t, 0.42, 650.0)
		b.scale = Vector2(sc, sc)
	tw.tween_method(step, 0.0, 0.6, 0.6)
	tw.chain().tween_callback(func() -> void: b.scale = Vector2.ONE)


static func enter(n: Control, base_y: float, index: int, dy: float = 22.0) -> void:
	if not n.is_inside_tree():
		return
	if n.has_meta("enter_tw"):
		var old: Tween = n.get_meta("enter_tw")
		if old != null and old.is_valid():
			old.kill()
	n.modulate.a = 0.0
	n.position.y = base_y + dy * U
	var tw := n.create_tween()
	n.set_meta("enter_tw", tw)
	tw.tween_interval(index * 0.05)
	var step: Callable = func(t: float) -> void:
		var v := spring(t, 0.7, 240.0)
		n.modulate.a = clampf(v, 0.0, 1.0)
		n.position.y = base_y + (1.0 - v) * dy * U
	tw.tween_method(step, 0.0, 0.7, 0.7)
	var done: Callable = func() -> void:
		n.modulate.a = 1.0
		n.position.y = base_y
	tw.tween_callback(done)


static func pop_in(n: Control, delay: float = 0.0) -> void:
	if not n.is_inside_tree():
		return
	if n.has_meta("pop_tw"):
		var old: Tween = n.get_meta("pop_tw")
		if old != null and old.is_valid():
			old.kill()
	n.pivot_offset = n.size * 0.5
	n.modulate.a = 0.0
	n.scale = Vector2(0.84, 0.84)
	var tw := n.create_tween()
	n.set_meta("pop_tw", tw)
	tw.tween_interval(delay)
	var step: Callable = func(t: float) -> void:
		var v := spring(t, 0.62, 320.0)
		var sc := 0.84 + 0.16 * v
		n.scale = Vector2(sc, sc)
		n.modulate.a = clampf(v, 0.0, 1.0)
	tw.tween_method(step, 0.0, 0.7, 0.7)
	var done: Callable = func() -> void:
		n.modulate.a = 1.0
		n.scale = Vector2.ONE
	tw.tween_callback(done)


static func rainbow_arc(sz: Vector2) -> Control:
	var c := Control.new()
	c.size = sz
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bands: Array = [PINK, SUN, MINT, CYAN, PURPLE]
	var painter: Callable = func() -> void:
		var sw := 3.0 * U
		var gp := 5.0 * U
		var cx := c.size.x * 0.5
		for i in bands.size():
			var rx := c.size.x * 0.5 - 4.0 * U - i * gp
			var ry := c.size.y * 0.95 - i * gp
			if rx <= 0.0 or ry <= 0.0:
				continue
			var col: Color = bands[i]
			col.a = 0.5
			var pts := PackedVector2Array()
			for k in 61:
				var a := PI + PI * float(k) / 60.0
				pts.append(Vector2(cx + rx * cos(a), c.size.y + ry * sin(a)))
			c.draw_polyline(pts, col, sw, true)
			c.draw_circle(pts[0], sw * 0.5, col)
			c.draw_circle(pts[60], sw * 0.5, col)
	c.draw.connect(painter)
	c.resized.connect(func() -> void: c.queue_redraw())
	return c


static var soft_disc: Texture2D = null


static func soft_disc_tex() -> Texture2D:
	if soft_disc == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
		g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.55), Color(1, 1, 1, 0)])
		var t := GradientTexture2D.new()
		t.gradient = g
		t.width = 128
		t.height = 128
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		soft_disc = t
	return soft_disc


static var halo_t: Texture2D = null


static func halo_tex() -> Texture2D:
	if halo_t == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.35, 1.0])
		g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.4), Color(1, 1, 1, 0)])
		var t := GradientTexture2D.new()
		t.gradient = g
		t.width = 64
		t.height = 64
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		halo_t = t
	return halo_t


static func hue_col(hue: float, l: float) -> Color:
	return Color.from_hsv(fposmod(hue, 360.0) / 360.0, clampf(2.0 * (1.0 - l / 100.0), 0.0, 1.0), 1.0)


static func draw_glyph(ci: CanvasItem, kind: String, col: Color, c: Vector2, h: float) -> void:
	var sw := h * 0.38
	if kind == "aura":
		ci.draw_arc(c, h * 0.95, 0.0, TAU, 24, col, sw, true)
		ci.draw_circle(c, h * 0.34, col)
	elif kind == "candy":
		ci.draw_circle(c, h * 0.62, col)
		ci.draw_line(c + Vector2(-h * 1.1, 0.0), c + Vector2(-h * 0.7, 0.0), col, sw, true)
		ci.draw_line(c + Vector2(h * 0.7, 0.0), c + Vector2(h * 1.1, 0.0), col, sw, true)
	elif kind == "blast":
		ci.draw_circle(c, h * 0.42, col)
		for i in 8:
			var a := float(i) * PI * 0.25
			var dir := Vector2(cos(a), sin(a))
			ci.draw_line(c + dir * h * 0.74, c + dir * h * 1.2, col, sw * 0.8, true)
	elif kind == "dash":
		for i in 3:
			var ly := c.y + (float(i) - 1.0) * h * 0.56
			var lx := h * (0.2 if i % 2 == 1 else 0.05)
			ci.draw_line(Vector2(c.x - h * 1.1, ly), Vector2(c.x + lx, ly), col, sw * 0.8, true)
		ci.draw_circle(c + Vector2(h * 0.75, 0.0), h * 0.4, col)
	elif kind == "moon":
		ci.draw_arc(c, h * 0.9, deg_to_rad(120.0), deg_to_rad(420.0), 28, col, sw * 1.2, true)
	elif kind == "fire":
		ci.draw_circle(c + Vector2(0.0, h * 0.35), h * 0.6, col)
		ci.draw_circle(c + Vector2(0.0, -h * 0.55), h * 0.36, col)
	elif kind == "warp":
		var pts := PackedVector2Array()
		for i in 10:
			var rr := h * (1.15 if i % 2 == 0 else 0.5)
			var an := -PI * 0.5 + float(i) * PI / 5.0
			pts.append(c + Vector2(cos(an), sin(an)) * rr)
		ci.draw_colored_polygon(pts, col)
	elif kind == "shrink":
		for sx in [-1.0, 1.0]:
			var tip := c + Vector2(sx * h * 0.25, 0.0)
			ci.draw_line(c + Vector2(sx * h * 1.1, 0.0), tip, col, sw * 0.8, true)
			ci.draw_colored_polygon(PackedVector2Array([tip, tip + Vector2(sx * h * 0.5, -h * 0.45), tip + Vector2(sx * h * 0.5, h * 0.45)]), col)
	elif kind == "star":
		var pts2 := PackedVector2Array()
		for i in 10:
			var rr2 := h * (1.15 if i % 2 == 0 else 0.5)
			var an2 := -PI * 0.5 + float(i) * PI / 5.0
			pts2.append(c + Vector2(cos(an2), sin(an2)) * rr2)
		ci.draw_colored_polygon(pts2, col)
	elif kind == "score":
		ci.draw_string(font, c + Vector2(-h * 1.1, h * 0.45), "x2", HORIZONTAL_ALIGNMENT_CENTER, h * 2.2, int(h * 1.5), col)
	elif kind == "drops":
		ci.draw_circle(c + Vector2(-h * 0.7, -h * 0.5), h * 0.38, col)
		ci.draw_circle(c + Vector2(h * 0.6, -h * 0.1), h * 0.38, col)
		ci.draw_circle(c + Vector2(-h * 0.1, h * 0.6), h * 0.38, col)
	elif kind == "wing":
		var wp := PackedVector2Array([c + Vector2(-h, h * 0.7), c + Vector2(-h * 0.7, -h * 0.2), c + Vector2(-h * 0.1, -h), c + Vector2(h, -h * 0.8), c + Vector2(h * 0.5, -h * 0.1), c + Vector2(h * 0.6, h * 0.4), c + Vector2(h * 0.1, h * 0.3), c + Vector2(-h * 0.2, h * 0.8)])
		ci.draw_colored_polygon(wp, col)
	else:
		for i in 3:
			var a2 := float(i) * PI / 3.0
			var dir2 := Vector2(cos(a2), sin(a2))
			ci.draw_line(c + dir2 * h * 1.05, c - dir2 * h * 1.05, col, sw * 0.8, true)
