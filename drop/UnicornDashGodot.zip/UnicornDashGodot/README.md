# Unicorn Dash (Godot 4.3, sprite based)

Right side of the screen: tap to jump, hold to jump higher, tap again in the air for a double jump.
Left side: hold to duck.

Art lives in art/. Unicorn frames are in art/unicorn2.png (384x384 frames: run x8, jump, duck x4, dead).
Obstacles are art/obs_*.png strips of 384x384 frames.
