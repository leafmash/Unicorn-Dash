# Unicorn Dash (Godot 4.3)

Phase 1: new vector unicorn, original physics and controls, 15 obstacle types, coins and combos, menu, pause and game over.

Controls: right side of the screen jumps (hold = higher, tap again in the air = double jump), left side ducks.
On a computer: Space or Up to jump, Down to duck, P to pause.
