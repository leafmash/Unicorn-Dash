extends Node2D

const Cp := preload("res://cp_kit.gd")
const GAP_COLS := [Color(1.0, 0.745, 1.0, 0.55), Color(1.0, 0.745, 1.0, 0.55), Color(0.588, 0.392, 1.0, 0.3), Color(0.392, 0.235, 0.863, 0.0)]
const GAP_POS := [0.0, 0.0714, 0.5857, 1.0]
const WALK_MAX := 58.0
const STRIDE := 69.0
const ACCEL := 3.4
const BRAKE := 7.0

var clock := 0.0
var vw := 1280.0
var vh := 576.0
var u := 1.6
var px := 0.0
var ptx := 0.0
var wk := 0.0
var vx := 0.0
var walk_mix := 0.0
var wnext := 1.2
var fx := 1.0
var tg := 1.0
var nxt := 3.0
var hop := 0.0
var moving := false
var stride := 0.0
var idle_hop := 5.0
var gaze := 0.0
var gaze_t := 0.0
var gaze_hold := 0.0
var blink_t := 2.0
var blink_v := 0.0
var blink_left := 0.0


func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR


func fy() -> float:
	return 254.0


func screen_origin() -> Vector2:
	return Vector2(vw * 0.5, fy() * u)


func hs(n: float) -> float:
	var v := sin(n * 127.1 + 311.7) * 43758.5453
	return v - floor(v)


func hsl(h: float, s: float, l: float, a: float) -> Color:
	var hh := fposmod(h, 360.0) / 360.0
	var ss := s / 100.0
	var ll := l / 100.0
	var v := ll + ss * minf(ll, 1.0 - ll)
	var sv := 0.0 if v <= 0.0 else 2.0 * (1.0 - ll / v)
	return Color.from_hsv(hh, sv, v, a)


func damp(cur: float, target: float, rate: float, dt: float) -> float:
	return target + (cur - target) * exp(-rate * dt)


func hop_now() -> void:
	if hop <= 0.0:
		hop = 0.75


func hop_phase() -> float:
	if hop <= 0.0:
		return 0.0
	return sin(PI * (1.0 - hop / 0.75))


func walking() -> bool:
	return moving


func walk_phase() -> float:
	return stride / STRIDE * TAU


func walk_scaled() -> float:
	return stride / STRIDE * 8.0


func walk_frame() -> int:
	return int(floorf(walk_scaled())) % 8


func walk_next() -> int:
	return (walk_frame() + 1) % 8


func walk_frac() -> float:
	var q := walk_scaled()
	var t := q - floorf(q)
	return t * t * (3.0 - 2.0 * t)


func stand_alpha() -> float:
	var t := 1.0 - clampf((walk_mix - 0.5) * 2.0, 0.0, 1.0)
	return t * t * (3.0 - 2.0 * t)


func walk_alpha() -> float:
	var t := clampf(walk_mix * 2.0, 0.0, 1.0)
	return t * t * (3.0 - 2.0 * t)


func squash() -> float:
	var br := sin(clock * 1.9)
	var q := 1.0 + br * 0.011
	if hop > 0.0:
		var hp := hop_phase()
		q += -0.07 if (hp < 0.12 or hop < 0.1) else 0.045
	return q


func nod() -> float:
	return gaze * 0.2 + sin(clock * 0.8) * 0.03 + sin(walk_phase() + 1.7) * 0.05 * wk


func blink_amount() -> float:
	return blink_v


func tail_amp() -> float:
	return 3.0 + 4.0 * wk


func lean() -> float:
	return sin(clock * 0.7) * 0.012 + tg * 0.035 * wk + sin(walk_phase() + 0.9) * 0.014 * wk


func bob() -> float:
	return absf(sin(walk_phase())) * 1.7 * wk


func _process(dt: float) -> void:
	if not visible:
		return
	dt = minf(dt, 0.05)
	var vs := get_viewport_rect().size
	vw = vs.x
	vh = vs.y
	u = vh / 360.0
	clock += dt
	tick(dt)
	queue_redraw()


func tick(dt: float) -> void:
	var dx := ptx - px
	var going := absf(dx) > 1.5
	var desired := 0.0
	if going:
		var dir := 1.0 if dx > 0.0 else -1.0
		tg = dir
		if absf(fx - dir) < 0.4 and hop <= 0.0:
			desired = dir * clampf(2.6 * absf(dx), 7.0, WALK_MAX)
	else:
		wnext -= dt
		if wnext <= 0.0:
			var tgt := lerpf(-86.0, 120.0, randf())
			if absf(tgt - px) < 60.0:
				tgt = lerpf(-86.0, -20.0, randf()) if px > 17.0 else lerpf(60.0, 120.0, randf())
			ptx = tgt
			wnext = 0.8 + randf() * 1.6
	var rate := ACCEL if absf(desired) > absf(vx) else BRAKE
	vx = damp(vx, desired, rate, dt)
	var step := vx * dt
	if absf(step) > absf(dx) and signf(step) == signf(dx):
		step = dx
	px += step
	stride += absf(step)
	wk = clampf(absf(vx) / WALK_MAX, 0.0, 1.0)
	moving = absf(vx) > 3.0
	var busy := going or moving
	var want := 1.0 if (moving or hop_phase() > 0.15) else 0.0
	walk_mix = move_toward(walk_mix, want, dt / 0.16)
	nxt -= dt
	if nxt <= 0.0:
		if randf() < 0.38 and not busy:
			tg = -tg
			nxt = 4.5 + randf() * 3.0
		else:
			gaze_t = 1.0 if randf() < 0.5 else -1.0
			gaze_hold = 0.9
			nxt = 2.4 + randf() * 2.6
	idle_hop -= dt
	if idle_hop <= 0.0:
		idle_hop = 9.0 + randf() * 8.0
		if not busy and hop <= 0.0 and randf() < 0.5:
			hop = 0.75
	if gaze_hold > 0.0:
		gaze_hold -= dt
		if gaze_hold <= 0.0:
			gaze_t = 0.0
	gaze = damp(gaze, gaze_t, 5.0, dt)
	blink_t -= dt
	if blink_t <= 0.0:
		blink_left = 0.17
		blink_t = 1.8 + randf() * 3.4
		if randf() < 0.25:
			blink_t = 0.28
	if blink_left > 0.0:
		blink_left = maxf(0.0, blink_left - dt)
		blink_v = sin(PI * (1.0 - blink_left / 0.17))
	else:
		blink_v = 0.0
	fx = damp(fx, tg, 4.2, dt)
	if hop > 0.0:
		hop = maxf(0.0, hop - dt)


func halo(p: Vector2, r: float, h: float, s: float, l: float, a: float) -> void:
	if a <= 0.0 or r <= 0.0:
		return
	var c := hsl(h, s, l, minf(a, 1.0))
	draw_texture_rect(Cp.soft_disc_tex(), Rect2(p.x - r, p.y - r, r * 2.0, r * 2.0), false, c)


func sparkle(p: Vector2, s: float, ph: float) -> void:
	var k := 0.5 + 0.5 * sin(clock * 3.0 + ph)
	var r := s * (0.4 + 0.6 * k)
	var ang := clock * 0.4 + ph
	var pts := PackedVector2Array()
	var q := 0.12
	var base := [Vector2(0, -r), Vector2(r * q, -r * q), Vector2(r, 0), Vector2(r * q, r * q), Vector2(0, r), Vector2(-r * q, r * q), Vector2(-r, 0), Vector2(-r * q, -r * q)]
	for v in base:
		pts.append(p + (v as Vector2).rotated(ang))
	draw_colored_polygon(pts, Color(1, 1, 1, 0.4 + 0.6 * k))
	halo(p, r * 2.2, 50.0, 100.0, 80.0, 0.3 * k)


func ellipse_pts(c: Vector2, rx: float, ry: float, n: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a := TAU * float(i) / float(n)
		pts.append(c + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func grad_at(t: float) -> Color:
	t = clampf(t, 0.0, 1.0)
	for i in range(GAP_POS.size() - 1):
		var a: float = GAP_POS[i]
		var b: float = GAP_POS[i + 1]
		if t <= b:
			return (GAP_COLS[i] as Color).lerp(GAP_COLS[i + 1], (t - a) / maxf(b - a, 0.0001))
	return GAP_COLS[GAP_COLS.size() - 1]


func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(u, u))
	var L := vw / u
	var cx := L * 0.5
	var f := fy()
	dream_ambient(L, f)
	beam(cx, f)
	rainbow_arc(cx, f - 10.0)
	rays(cx)
	halo(Vector2(cx, 190.0), 150.0, fposmod(clock * 12.0 + 280.0, 360.0), 100.0, 70.0, 0.3)
	pedestal(cx, f)
	shadow(cx, f)
	orbit(cx)


func beam(cx: float, f: float) -> void:
	var pts := PackedVector2Array([Vector2(cx - 34.0, 40.0), Vector2(cx + 34.0, 40.0), Vector2(cx + 128.0, f), Vector2(cx - 128.0, f)])
	var top := Color(1, 1, 1, 0.0)
	var bot := Color(1.0, 0.82, 1.0, 0.2)
	draw_polygon(pts, PackedColorArray([top, top, bot, bot]))


func rainbow_arc(cx: float, cy: float) -> void:
	for b in 7:
		var col := hsl(float(b) * 48.0 + fposmod(clock * 8.0, 360.0), 95.0, 68.0, 0.13 + 0.04 * sin(clock * 0.8 + float(b)))
		draw_arc(Vector2(cx, cy), 196.0 - float(b) * 8.5, PI, TAU, 120, col, 9.0, true)


func rays(cx: float) -> void:
	var c := Vector2(cx, 190.0)
	var rot := clock * 0.08
	for i in 12:
		rot += PI / 6.0
		var a := Vector2(0, 0)
		var b := Vector2(-18.0, -230.0).rotated(rot)
		var d := Vector2(18.0, -230.0).rotated(rot)
		draw_colored_polygon(PackedVector2Array([c + a, c + b, c + d]), Color(1, 1, 1, 0.055))


func pedestal(cx: float, f: float) -> void:
	var c := Vector2(cx, f + 4.0)
	var n := 64
	var ring := ellipse_pts(c, 140.0, 28.0, n)
	var pts := PackedVector2Array()
	var cols := PackedColorArray()
	pts.append(c)
	cols.append(grad_at(0.0))
	for p in ring:
		pts.append(p)
		cols.append(grad_at((p - c).length() / 140.0))
	pts.append(ring[0])
	cols.append(cols[1])
	draw_polygon(pts, cols)
	draw_colored_polygon(ellipse_pts(c, 104.0, 18.0, n), Color(0.118, 0.055, 0.314, 0.55))
	var rim := ellipse_pts(c, 104.0, 18.0, n)
	rim.append(rim[0])
	draw_polyline(rim, Color(1, 1, 1, 0.7), 2.0, true)
	var pr := fposmod(clock * 0.5, 1.0)
	var ring2 := ellipse_pts(c, 104.0 + 40.0 * pr, 18.0 + 8.0 * pr, n)
	ring2.append(ring2[0])
	draw_polyline(ring2, Color(1.0, 0.784, 1.0, 0.6 * (1.0 - pr)), 2.2, true)
	var m := 160
	var dash := ellipse_pts(c, 122.0, 22.0, m)
	dash.append(dash[0])
	var acc := -clock * 14.0
	for i in m:
		var seg := dash[i].distance_to(dash[i + 1])
		var ph := fposmod(acc, 19.0)
		if ph < 10.0:
			draw_line(dash[i], dash[i + 1], Color(0.588, 0.941, 1.0, 0.75), 1.6, true)
		acc += seg


func shadow(cx: float, f: float) -> void:
	var hp := hop_phase()
	var k := 1.0 - hp * 0.3
	var c := Vector2(cx + px, f + 4.0)
	draw_colored_polygon(ellipse_pts(c, 64.0 * k, 9.0 * k, 48), Color(0, 0, 0, 0.3))


func orbit(cx: float) -> void:
	for i in 9:
		var a := clock * 0.35 + float(i) * TAU / 9.0
		var rr := 118.0 + 14.0 * sin(clock + float(i))
		var p := Vector2(cx + cos(a) * rr, 186.0 + sin(a) * 66.0 + sin(clock * 1.4 + float(i)) * 8.0)
		if sin(a) > -0.2 or i % 2 == 1:
			sparkle(p, 3.0 + float(i % 3) * 1.6, float(i))


func dream_ambient(L: float, f: float) -> void:
	for i in 16:
		var speed := 4.0 + float(i % 4) * 2.5
		var p := Vector2(fposmod(hs(float(i)) * L + sin(clock * 0.2 + float(i)) * 20.0 + clock * speed, L), 30.0 + hs(float(i + 40)) * 250.0 + sin(clock * 0.5 + float(i) * 1.7) * 14.0)
		var r := 6.0 + hs(float(i + 80)) * 16.0
		var hue := fposmod(hs(float(i + 120)) * 360.0 + clock * 10.0, 360.0)
		halo(p, r * 2.0, hue, 90.0, 78.0, 0.12 + 0.1 * sin(clock * 1.3 + float(i)))
	for i in 7:
		var k := fposmod(clock * 0.12 + float(i) / 7.0, 1.0)
		var p := Vector2(L * (0.08 + 0.84 * hs(float(i + 200))) + sin(clock * 0.9 + float(i) * 2.0) * 26.0, f + 6.0 - k * 300.0)
		var a := sin(k * PI) * 0.7
		sparkle(p, 2.6 + float(i % 3) * 1.1, float(i) + clock)
		halo(p, 10.0, 300.0 - k * 120.0, 100.0, 80.0, a * 0.35)
