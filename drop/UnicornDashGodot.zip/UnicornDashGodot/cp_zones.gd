extends Control

signal action(key: String)
signal built(list: Array)

const Cp := preload("res://cp_kit.gd")
const U := 1.6
const PAD_X := 14.0
const PAD_Y := 10.0
const COLS := 3
const ROWS := 2

var m
var mode := "zones"
var buttons: Array = []
var items: Array = []
var built_w := 0.0
var built_h := 0.0


func setup(main: Node, which: String) -> void:
	m = main
	mode = which
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(on_resized)
	visibility_changed.connect(on_visible)


func d(v: float) -> float:
	return v * U


func on_resized() -> void:
	if size.x < 200.0:
		return
	if is_equal_approx(size.x, built_w) and is_equal_approx(size.y, built_h):
		return
	built_w = size.x
	built_h = size.y
	refresh()


func on_visible() -> void:
	if not is_visible_in_tree():
		return
	refresh()


func reg(n: Control, index: int, dy: float = 22.0) -> void:
	items.append([n, n.position.y, index, dy])


func play_enter() -> void:
	for it in items:
		var n: Control = it[0]
		if is_instance_valid(n):
			Cp.enter(n, float(it[1]), int(it[2]), float(it[3]))


func refresh() -> void:
	if size.x < 200.0 or m == null:
		return
	built_w = size.x
	built_h = size.y
	for c in get_children():
		remove_child(c)
		c.queue_free()
	buttons.clear()
	items.clear()
	var bgc := Cp.shape(size, 0.0, {"top": Color(0.078, 0.039, 0.2, 0.7), "bot": Color(0.102, 0.055, 0.239, 0.8)})
	add_child(bgc)
	if mode == "zones":
		build_zones()
	else:
		build_levels()
	play_enter()
	built.emit(buttons)


func star_pill(text: String) -> Control:
	var pill := Cp.pill(30.0)
	Cp.pill_add(pill, Cp.icon("star_on", 16.0))
	Cp.pill_add(pill, Cp.gap(d(5.0)))
	var l := Cp.label(text, 12.0, Cp.SUN)
	Cp.set_text(l, text)
	Cp.pill_add(pill, l)
	Cp.pill_update(pill)
	return pill


func coin_pill(text: String) -> Control:
	var pill := Cp.pill(30.0)
	Cp.pill_add(pill, Cp.icon("coin", 18.0))
	Cp.pill_add(pill, Cp.gap(d(5.0)))
	var l := Cp.label(text, 14.0, Cp.SUN)
	Cp.set_text(l, text)
	Cp.pill_add(pill, l)
	Cp.pill_update(pill)
	return pill


func build_header(title: String, sub: String, right: Control) -> void:
	var back := Cp.round_btn(40.0, "back", 22.0)
	back.position = Vector2(d(PAD_X), d(PAD_Y))
	back.pressed.connect(emit_action.bind("back"))
	add_child(back)
	buttons.append(back)
	reg(back, 0)
	var box := Control.new()
	box.size = Vector2(size.x - d(PAD_X * 2.0 + 40.0 + 40.0 + 120.0), d(40.0))
	box.position = Vector2((size.x - box.size.x) * 0.5, d(PAD_Y))
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(box)
	reg(box, 0)
	var sp := 26.0
	while Cp.text_w(title, sp) > box.size.x and sp > 13.0:
		sp *= 0.92
	var gt := Cp.grad_title(title, sp)
	var sub_h := d(15.0) if sub != "" else 0.0
	var total := gt.size.y * 0.85 + sub_h
	var top := (box.size.y - total) * 0.5
	gt.position = Vector2((box.size.x - gt.size.x) * 0.5, top)
	box.add_child(gt)
	if sub != "":
		var sl := Cp.label(sub, 11.5, Color("e9dcff"), false)
		Cp.place(sl, 0.0, top + gt.size.y * 0.85, box.size.x, sub_h, HORIZONTAL_ALIGNMENT_CENTER)
		Cp.fit(sl, box.size.x)
		box.add_child(sl)
	right.position = Vector2(size.x - d(PAD_X) - right.size.x, d(PAD_Y) + (d(40.0) - right.size.y) * 0.5)
	add_child(right)
	reg(right, 0)


func emit_action(key: String) -> void:
	action.emit(key)


func max_stars() -> int:
	return m.ZONES.size() * m.LEVELS_PER_ZONE * 3


func build_zones() -> void:
	var endless: bool = m.zone_mode == m.Mode.ENDLESS
	var title: String = m.T("ENDLESS") if endless else m.T("ADVENTURE")
	var sub: String = m.T("Pick a zone to run forever") if endless else m.T("Pick a zone")
	var right: Control = coin_pill("%d" % m.bank) if endless else star_pill("%d/%d" % [m.total_stars(), max_stars()])
	build_header(title, sub, right)
	var pages: int = m.page_count()
	var page: int = m.cur_page
	var top := d(PAD_Y + 40.0 + 8.0)
	var bottom := size.y - d(PAD_Y + 6.0 + 10.0)
	var side := d(PAD_X + 34.0)
	var gap := d(10.0)
	var gw := size.x - side * 2.0
	var cw := (gw - gap * (COLS - 1)) / float(COLS)
	var ch := (bottom - top - gap * (ROWS - 1)) / float(ROWS)
	for r in ROWS:
		for c in COLS:
			var z: int = page * m.PER_PAGE + r * COLS + c
			if z >= m.ZONES.size():
				continue
			var card := make_zone_card(z, Vector2(cw, ch), endless)
			card.position = Vector2(side + c * (cw + gap), top + r * (ch + gap))
			add_child(card)
			reg(card, r * COLS + c)
	var dots := make_dots(pages, page)
	dots.position = Vector2((size.x - dots.size.x) * 0.5, size.y - d(PAD_Y + 6.0 + 2.0))
	add_child(dots)
	reg(dots, 6)
	if pages > 1:
		var ay := top + (bottom - top - d(40.0)) * 0.5
		var prev := Cp.round_btn(36.0, "arrow_l", 18.0)
		prev.position = Vector2(d(PAD_X - 2.0), ay)
		prev.pressed.connect(emit_action.bind("pg-1"))
		prev.modulate.a = 0.35 if page <= 0 else 1.0
		prev.disabled = page <= 0
		add_child(prev)
		buttons.append(prev)
		var nxt := Cp.round_btn(36.0, "arrow_r", 18.0)
		nxt.position = Vector2(size.x - d(PAD_X - 2.0) - nxt.size.x, ay)
		nxt.pressed.connect(emit_action.bind("pg1"))
		nxt.modulate.a = 0.35 if page >= pages - 1 else 1.0
		nxt.disabled = page >= pages - 1
		add_child(nxt)
		buttons.append(nxt)


func make_dots(count: int, cur: int) -> Control:
	var h := d(6.0)
	var gp := d(6.0)
	var w := 0.0
	for k in count:
		w += d(18.0) if k == cur else d(6.0)
	w += gp * maxf(count - 1, 0)
	var c := Control.new()
	c.size = Vector2(w, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var x := 0.0
	for k in count:
		var dw := d(18.0) if k == cur else d(6.0)
		var col := Color.WHITE if k == cur else Color(1, 1, 1, 0.3)
		var dot := Cp.shape(Vector2(dw, h), h * 0.5, {"top": col})
		dot.position = Vector2(x, 0.0)
		c.add_child(dot)
		x += dw + gp
	return c


func make_zone_card(z: int, sz: Vector2, endless: bool) -> Control:
	var zd: Dictionary = m.ZONES[z]
	var is_open: bool = m.zone_open(z)
	var full: bool = (not endless) and m.zone_stars(z) >= m.LEVELS_PER_ZONE * 3
	var current: bool = z == m.zone
	var rim := Color(1, 1, 1, 0.2)
	var rw := 1.3 * U
	if full:
		rim = Cp.GOLD
		rw = 2.0 * U
	elif current and is_open:
		rim = Color(1, 1, 1, 0.8)
	elif is_open:
		rim = Color(1, 1, 1, 0.5)
	var top_c := Color(1, 1, 1, 0.19) if is_open else Color(1, 1, 1, 0.08)
	var bot_c := Color(1, 1, 1, 0.08) if is_open else Color(1, 1, 1, 0.04)
	var root := Control.new()
	root.size = sz
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var card := Cp.shape(sz, d(18.0), {"top": top_c, "bot": bot_c, "rim_t": rim, "rim_b": rim, "rim_w": rw})
	root.add_child(card)
	var pad := d(7.0)
	var text_h := d(14.0 + 4.0 + 2.0 + 15.0)
	var pw := sz.x - pad * 2.0
	var ph := pw * 84.0 / 150.0
	var max_ph := sz.y - pad * 2.0 - text_h
	if ph > max_ph:
		ph = max_ph
		pw = ph * 150.0 / 84.0
	var pv := Control.new()
	pv.size = Vector2(pw, ph)
	pv.position = Vector2((sz.x - pw) * 0.5, pad)
	pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(pv)
	var art := Control.new()
	art.size = pv.size
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var amat := ShaderMaterial.new()
	amat.shader = round_shader()
	amat.set_shader_parameter("size", pv.size)
	amat.set_shader_parameter("radius", d(12.0))
	art.material = amat
	art.draw.connect(draw_preview.bind(art, zd))
	pv.add_child(art)
	if not is_open:
		var veil := Cp.shape(pv.size, d(12.0), {"top": Color(0.078, 0.039, 0.2, 0.64)})
		pv.add_child(veil)
		var lk := Cp.icon("lock", 24.0)
		lk.position = (pv.size - lk.size) * 0.5
		pv.add_child(lk)
	var nm: String = zd["name"]
	var ty := pad + ph + d(4.0)
	var nl := Cp.label(m.T(nm), 11.5, Color.WHITE if is_open else Cp.DIM)
	Cp.place(nl, 0.0, ty, sz.x, d(15.0), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(nl, sz.x - pad * 2.0)
	root.add_child(nl)
	var sy := ty + d(15.0) + d(2.0)
	if not is_open:
		var ll := Cp.label(m.T("Locked"), 10.0, Cp.DIM, false)
		Cp.place(ll, 0.0, sy, sz.x, d(15.0), HORIZONTAL_ALIGNMENT_CENTER)
		root.add_child(ll)
	elif not endless:
		var got: int = m.zone_stars(z)
		var txt := "%d/%d" % [got, m.LEVELS_PER_ZONE * 3]
		var tw := Cp.text_w(txt, 10.5)
		var total := d(13.0) + d(4.0) + tw
		var sx := (sz.x - total) * 0.5
		var ic := Cp.icon("star_on" if got > 0 else "star_off", 13.0)
		ic.position = Vector2(sx, sy + d(1.0))
		root.add_child(ic)
		var sl := Cp.label(txt, 10.5, Cp.SUN)
		Cp.place(sl, sx + d(13.0) + d(4.0), sy, tw + d(4.0), d(15.0))
		root.add_child(sl)
	else:
		var bl := Cp.label(m.T("BEST %d") % int(m.eb[z]), 10.5, Cp.LILAC, false)
		Cp.place(bl, 0.0, sy, sz.x, d(15.0), HORIZONTAL_ALIGNMENT_CENTER)
		root.add_child(bl)
	if is_open:
		var btn := Cp.flat_button(sz)
		btn.set_meta("punch_node", root)
		btn.pressed.connect(emit_action.bind("zc%d" % z))
		root.add_child(btn)
		buttons.append(btn)
	return root


static var rshader: Shader = null


func round_shader() -> Shader:
	if rshader == null:
		rshader = Shader.new()
		rshader.code = """shader_type canvas_item;
uniform vec2 size = vec2(100.0, 50.0);
uniform float radius = 12.0;
varying vec2 pos;
void vertex() {
	pos = VERTEX;
}
void fragment() {
	vec2 q = abs(pos - size * 0.5) - size * 0.5 + vec2(radius);
	float dist = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - radius;
	COLOR.a *= 1.0 - smoothstep(-0.7, 0.7, dist);
}
"""
	return rshader


func draw_preview(c: Control, zd: Dictionary) -> void:
	var w := c.size.x
	var h := c.size.y
	var sky: Array = zd["sky"]
	var s0: Color = m.hc(sky[0])
	var s1: Color = m.hc(sky[1])
	var s2: Color = m.hc(sky[2])
	var night: float = zd["night"]
	var y1 := h * 0.6
	c.draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, y1), Vector2(0, y1)]), PackedColorArray([s0, s0, s1, s1]))
	c.draw_polygon(PackedVector2Array([Vector2(0, y1), Vector2(w, y1), Vector2(w, h), Vector2(0, h)]), PackedColorArray([s1, s1, s2, s2]))
	if night > 0.45:
		for i in 16:
			var sx := fposmod(sin(float(i) * 12.9898) * 43758.5453, 1.0) * w
			var sy := fposmod(sin(float(i) * 78.233) * 12345.6789, 1.0) * h * 0.5
			c.draw_rect(Rect2(sx, sy, 1.6, 1.6), Color(1, 1, 1, 0.8))
	var sun := Vector2(w * 0.76, h * (0.26 + 0.1 * night))
	var sun_c := Color(0.86, 0.9, 1.0) if night > 0.5 else Color(1.0, 0.96, 0.82)
	c.draw_circle(sun, h * 0.26, Color(sun_c.r, sun_c.g, sun_c.b, 0.18))
	c.draw_circle(sun, h * 0.15, Color(sun_c.r, sun_c.g, sun_c.b, 0.9))
	var cl := Color(1, 1, 1, 0.55 - 0.3 * night)
	for cp in [Vector2(0.2, 0.2), Vector2(0.52, 0.12)]:
		var p: Vector2 = Vector2(cp.x * w, cp.y * h)
		c.draw_circle(p, h * 0.07, cl)
		c.draw_circle(p + Vector2(h * 0.09, -h * 0.02), h * 0.09, cl)
		c.draw_circle(p + Vector2(h * 0.2, 0), h * 0.065, cl)
	var far_c: Array = zd["far"]
	var near_c: Array = zd["near"]
	var gr_c: Array = zd["gr"]
	c.draw_colored_polygon(hills(w, h, h * 0.62, h * 0.12, 2.1, 0.7), m.hc(far_c[0]))
	c.draw_colored_polygon(hills(w, h, h * 0.74, h * 0.09, 3.3, 2.1), m.hc(near_c[0]))
	var gy := h * 0.86
	c.draw_rect(Rect2(0, gy, w, h - gy), m.hc(gr_c[0]))
	c.draw_rect(Rect2(0, gy, w, h * 0.035), m.hc(gr_c[1]))


func hills(w: float, h: float, base: float, amp: float, freq: float, ph: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var n := 24
	for i in n + 1:
		var t := float(i) / float(n)
		var y := base - amp * (0.5 + 0.5 * sin(t * TAU * freq * 0.5 + ph)) - amp * 0.35 * sin(t * TAU * freq * 1.3 + ph * 2.0)
		pts.append(Vector2(t * w, y))
	pts.append(Vector2(w, h))
	pts.append(Vector2(0, h))
	return pts


func build_levels() -> void:
	var z: int = m.zone
	var nm: String = m.ZONES[z]["name"]
	var total: int = m.zone_stars(z)
	build_header(m.T(nm), "", star_pill("%d/%d" % [total, m.LEVELS_PER_ZONE * 3]))
	var bsz := d(66.0)
	var gx := d(16.0)
	var gy := d(16.0)
	var per_row := 5
	var grid_w := bsz * per_row + gx * (per_row - 1)
	var note_h := d(34.0)
	var block_h := bsz * 2.0 + gy + d(18.0) + note_h
	var top := d(PAD_Y + 40.0) + (size.y - d(PAD_Y + 40.0) - d(PAD_Y) - block_h) * 0.5
	var next_i := -1
	for l in m.LEVELS_PER_ZONE:
		if m.level_open(z, l) and m.stars_of(z, l) == 0:
			next_i = l
			break
	for l in m.LEVELS_PER_ZONE:
		var r: int = l / per_row
		var c: int = l % per_row
		var pos := Vector2((size.x - grid_w) * 0.5 + c * (bsz + gx), top + r * (bsz + gy))
		var node := make_level_button(z, l, bsz, l == next_i)
		node.position = pos
		add_child(node)
		reg(node, l)
		if node.has_meta("glow"):
			pulse(node.get_meta("glow"))
	var done: int = m.cleared(z)
	var ok: bool = done >= m.ZONE_NEED
	var note: String
	if ok and z + 1 < m.ZONES.size():
		note = m.T("Next zone unlocked")
	else:
		note = m.T("Clear %d levels to unlock the next zone") % m.ZONE_NEED
	var nw := Cp.text_w(note, 12.0) + d(32.0)
	var glass := Cp.glass(Vector2(nw, note_h), 16.0)
	glass.position = Vector2((size.x - nw) * 0.5, top + bsz * 2.0 + gy + d(18.0))
	add_child(glass)
	reg(glass, 10)
	var nl := Cp.label(note, 12.0, Cp.MINT if ok else Color("e9dcff"), false)
	Cp.place(nl, 0.0, 0.0, nw, note_h, HORIZONTAL_ALIGNMENT_CENTER)
	glass.add_child(nl)


func pulse(glow: Control) -> void:
	glow.pivot_offset = glow.size * 0.5
	var tw := glow.create_tween().set_loops()
	tw.tween_property(glow, "scale", Vector2(1.12, 1.12), 0.8).set_trans(Tween.TRANS_SINE)
	tw.tween_property(glow, "scale", Vector2(0.9, 0.9), 0.8).set_trans(Tween.TRANS_SINE)


func make_level_button(z: int, l: int, bsz: float, is_next: bool) -> Control:
	var boss: bool = l == m.LEVELS_PER_ZONE - 1
	var is_open: bool = m.level_open(z, l)
	var got: int = m.stars_of(z, l)
	var root := Control.new()
	root.size = Vector2(bsz, bsz)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if is_next:
		var glow := Cp.pulse_glow(Cp.RUBY if boss else Cp.PINK, 56.0)
		glow.position = (root.size - glow.size) * 0.5
		root.add_child(glow)
		root.set_meta("glow", glow)
	var kind := "off"
	if is_open:
		kind = "danger" if boss else ("primary" if got > 0 else "soft")
	var btn := Cp.face_button(Vector2(bsz, bsz), d(20.0), kind, d(3.0))
	var content: Control = btn.get_meta("content")
	if not is_open:
		var lk := Cp.icon("lock", 24.0)
		lk.position = (content.size - lk.size) * 0.5
		content.add_child(lk)
	else:
		var ny := d(14.0)
		if boss:
			var bl := Cp.label(m.T("BOSS"), 9.5, Color("fff3c4"))
			Cp.place(bl, 0.0, d(4.0), content.size.x, d(12.0), HORIZONTAL_ALIGNMENT_CENTER)
			content.add_child(bl)
			ny = d(15.0)
		var nl := Cp.label("%d" % (l + 1), 24.0, Color.WHITE)
		Cp.place(nl, 0.0, ny, content.size.x, d(28.0), HORIZONTAL_ALIGNMENT_CENTER)
		content.add_child(nl)
		var sw := d(13.0)
		var sx := (content.size.x - (sw * 3.0 + d(2.0))) * 0.5
		for k in 3:
			var ic := Cp.icon("star_on" if k < got else "star_off", 13.0)
			ic.position = Vector2(sx + k * (sw + d(1.0)), content.size.y - sw - d(5.0))
			content.add_child(ic)
	if is_open:
		btn.pressed.connect(emit_action.bind("lv%d" % l))
		buttons.append(btn)
	root.add_child(btn)
	return root
