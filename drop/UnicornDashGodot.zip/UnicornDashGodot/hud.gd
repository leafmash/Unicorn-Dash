extends CanvasLayer

signal retry_pressed
signal home_pressed
signal pause_pressed
signal resume_pressed

const ART := "res://art/ui/"
const FONT_PATH := "res://fonts/Poppins-Bold.ttf"
const INK := Color("2a1458")
const GOLD := Color("ffe27a")
const LILAC := Color("d9ccff")
const DIM := Color("b9a9f0")
const BROWN := Color("5a3000")
const STAR_AT := [300, 900, 1800]
const LOGO_W := 540.0
const LOGO_TOP := 4.0
const BTN_TEXT := {
	"primary": Color("ffffff"),
	"gold": Color("5a3000"),
	"mint": Color("053b3a"),
	"soft": Color("ffffff")
}
const BTN_OUTLINE := {
	"primary": Color("4f25b0"),
	"gold": Color(0, 0, 0, 0),
	"mint": Color(0, 0, 0, 0),
	"soft": Color("1b0d4a")
}

var font: Font
var coin_tex: Texture2D
var vignette: TextureRect
var hud_root: Control
var score_pill: PanelContainer
var score_label: Label
var coin_pill: PanelContainer
var coin_label: Label
var coin_icon: TextureRect
var pause_btn: TextureButton
var ready_root: Control
var logo: TextureRect
var tap_btn: Button
var best_pill: PanelContainer
var best_label: Label
var count_label: Label
var toast_label: Label
var fps_label: Label
var dim: ColorRect
var pause_root: Control
var pause_panel: PanelContainer
var over_root: Control
var over_panel: PanelContainer
var over_caption: Label
var over_badge: PanelContainer
var over_score: Label
var over_best: Label
var over_coins: Label
var star_on: Array[TextureRect] = []
var flash_rect: ColorRect
var tap_tween: Tween
var logo_tween: Tween
var badge_tween: Tween
var over_tween: Tween
var toast_tween: Tween


func _ready() -> void:
	layer = 10
	font = load(FONT_PATH)
	coin_tex = load("res://art/coin.png")
	build_vignette()
	build_hud()
	build_ready()
	build_overlays()
	build_pause()
	build_over()
	build_flash()
	fix_mouse(self)
	tap_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE


func tex(name: String) -> Texture2D:
	return load(ART + name + ".png")


func fix_mouse(node: Node) -> void:
	for c in node.get_children():
		if c is Control and not (c is BaseButton):
			c.mouse_filter = Control.MOUSE_FILTER_IGNORE
		fix_mouse(c)


func make_label(text: String, size: int, color: Color, outline: int = 8, outline_color: Color = INK) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", outline_color)
	l.add_theme_constant_override("outline_size", outline)
	if outline > 0:
		l.add_theme_color_override("font_shadow_color", Color(0.1, 0.0, 0.25, 0.4))
		l.add_theme_constant_override("shadow_offset_y", 3)
		l.add_theme_constant_override("shadow_outline_size", outline)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l


func make_box(name: String, l: float, t: float, r: float, b: float, cl: float = -1.0, ct: float = -1.0, cr: float = -1.0, cb: float = -1.0) -> StyleBoxTexture:
	var s := StyleBoxTexture.new()
	s.texture = tex(name)
	s.texture_margin_left = l
	s.texture_margin_top = t
	s.texture_margin_right = r
	s.texture_margin_bottom = b
	if cl >= 0.0:
		s.content_margin_left = cl
	if ct >= 0.0:
		s.content_margin_top = ct
	if cr >= 0.0:
		s.content_margin_right = cr
	if cb >= 0.0:
		s.content_margin_bottom = cb
	return s


func make_pill(pad_l: float = 34.0, pad_r: float = 34.0) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", make_box("pill", 44, 36, 44, 36, pad_l, 12, pad_r, 14))
	p.resized.connect(func() -> void: p.pivot_offset = p.size * 0.5)
	return p


func make_panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", make_box("panel", 64, 64, 64, 64, 56, 36, 56, 48))
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BOTH
	p.anchor_left = 0.5
	p.anchor_right = 0.5
	p.anchor_top = 0.5
	p.anchor_bottom = 0.5
	return p


func make_chip(icon: Texture2D, caption: String) -> Array:
	var c := PanelContainer.new()
	c.add_theme_stylebox_override("panel", make_box("chip", 28, 28, 28, 28, 18, 6, 22, 8))
	c.custom_minimum_size = Vector2(386, 64)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	c.add_child(row)
	row.add_child(icon_rect(icon, 40))
	row.add_child(make_label(caption, 22, LILAC, 0))
	var v := make_label("0", 34, Color.WHITE, 6)
	v.custom_minimum_size = Vector2(110, 0)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(v)
	return [c, v]


func icon_rect(t: Texture2D, size: float) -> TextureRect:
	var r := TextureRect.new()
	r.texture = t
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.custom_minimum_size = Vector2(size, size)
	return r


func title_rect(name: String) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex(name)
	r.stretch_mode = TextureRect.STRETCH_KEEP
	r.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	return r


func make_button(text: String, kind: String, min_w: float, font_size: int = 44) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(min_w, 124)
	b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", font_size)
	var tc: Color = BTN_TEXT[kind]
	for k in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color", "font_focus_color", "font_disabled_color"]:
		b.add_theme_color_override(k, tc)
	var oc: Color = BTN_OUTLINE[kind]
	b.add_theme_color_override("font_outline_color", oc)
	b.add_theme_constant_override("outline_size", 0 if oc.a == 0.0 else 8)
	var n := btn_box(kind, false)
	var p := btn_box(kind, true)
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", n)
	b.add_theme_stylebox_override("disabled", n)
	b.add_theme_stylebox_override("pressed", p)
	b.add_theme_stylebox_override("hover_pressed", p)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	return b


func btn_box(kind: String, pressed: bool) -> StyleBoxTexture:
	var name := "btn_%s_%s" % [kind, "p" if pressed else "n"]
	var top := 12.0 if pressed else 4.0
	var bottom := 16.0 if pressed else 24.0
	return make_box(name, 44, 44, 44, 44, 34, top, 34, bottom)


func round_button(icon: String) -> TextureButton:
	var b := TextureButton.new()
	b.texture_normal = tex("round_%s_n" % icon)
	b.texture_pressed = tex("round_%s_p" % icon)
	b.focus_mode = Control.FOCUS_NONE
	return b


func place_top_center(c: Control, w: float, h: float, top: float) -> void:
	c.anchor_left = 0.5
	c.anchor_right = 0.5
	c.anchor_top = 0.0
	c.anchor_bottom = 0.0
	c.offset_left = -w * 0.5
	c.offset_right = w * 0.5
	c.offset_top = top
	c.offset_bottom = top + h
	c.pivot_offset = Vector2(w * 0.5, h * 0.5)


func full_rect(c: Control) -> void:
	c.anchor_left = 0.0
	c.anchor_top = 0.0
	c.anchor_right = 1.0
	c.anchor_bottom = 1.0
	c.offset_left = 0.0
	c.offset_top = 0.0
	c.offset_right = 0.0
	c.offset_bottom = 0.0


func center_in(c: Control) -> void:
	c.anchor_left = 0.5
	c.anchor_right = 0.5
	c.anchor_top = 0.5
	c.anchor_bottom = 0.5
	c.offset_left = 0.0
	c.offset_right = 0.0
	c.offset_top = 0.0
	c.offset_bottom = 0.0
	c.grow_horizontal = Control.GROW_DIRECTION_BOTH
	c.grow_vertical = Control.GROW_DIRECTION_BOTH


func build_vignette() -> void:
	vignette = TextureRect.new()
	vignette.texture = tex("vignette")
	vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vignette.stretch_mode = TextureRect.STRETCH_SCALE
	full_rect(vignette)
	add_child(vignette)


func build_hud() -> void:
	hud_root = Control.new()
	full_rect(hud_root)
	add_child(hud_root)

	score_pill = make_pill(32.0, 38.0)
	score_pill.anchor_left = 0.0
	score_pill.anchor_right = 0.0
	score_pill.offset_left = 24.0
	score_pill.offset_top = 24.0
	hud_root.add_child(score_pill)
	var srow := HBoxContainer.new()
	srow.add_theme_constant_override("separation", 14)
	score_pill.add_child(srow)
	var scap := make_label("SCORE", 18, DIM, 0)
	scap.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	srow.add_child(scap)
	score_label = make_label("0", 42, Color.WHITE, 8)
	score_label.custom_minimum_size = Vector2(96, 0)
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	srow.add_child(score_label)

	pause_btn = round_button("pause")
	pause_btn.anchor_left = 1.0
	pause_btn.anchor_right = 1.0
	pause_btn.offset_left = -136.0
	pause_btn.offset_right = -24.0
	pause_btn.offset_top = 14.0
	pause_btn.offset_bottom = 134.0
	pause_btn.pressed.connect(func() -> void: pause_pressed.emit())
	hud_root.add_child(pause_btn)

	coin_pill = make_pill(26.0, 34.0)
	coin_pill.anchor_left = 1.0
	coin_pill.anchor_right = 1.0
	coin_pill.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	coin_pill.offset_left = -146.0
	coin_pill.offset_right = -146.0
	coin_pill.offset_top = 24.0
	hud_root.add_child(coin_pill)
	var crow := HBoxContainer.new()
	crow.add_theme_constant_override("separation", 10)
	coin_pill.add_child(crow)
	coin_icon = icon_rect(coin_tex, 52)
	crow.add_child(coin_icon)
	coin_label = make_label("0", 42, GOLD, 8)
	coin_label.custom_minimum_size = Vector2(64, 0)
	coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	crow.add_child(coin_label)

	fps_label = make_label("", 14, Color(0.85, 0.8, 1.0, 0.55), 0)
	fps_label.anchor_top = 1.0
	fps_label.anchor_bottom = 1.0
	fps_label.offset_left = 14.0
	fps_label.offset_top = -30.0
	fps_label.offset_right = 120.0
	fps_label.offset_bottom = -6.0
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	add_child(fps_label)


func build_ready() -> void:
	ready_root = Control.new()
	full_rect(ready_root)
	add_child(ready_root)

	var glow := TextureRect.new()
	glow.texture = tex("glow")
	glow.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	glow.stretch_mode = TextureRect.STRETCH_SCALE
	place_top_center(glow, 860.0, 460.0, -70.0)
	ready_root.add_child(glow)

	logo = TextureRect.new()
	logo.texture = tex("logo")
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	var lh := LOGO_W * float(logo.texture.get_height()) / float(logo.texture.get_width())
	place_top_center(logo, LOGO_W, lh, LOGO_TOP)
	ready_root.add_child(logo)

	tap_btn = make_button("TAP TO RUN", "gold", 420.0)
	place_top_center(tap_btn, 420.0, 124.0, 312.0)
	ready_root.add_child(tap_btn)

	var hints := HBoxContainer.new()
	hints.add_theme_constant_override("separation", 14)
	hints.anchor_left = 0.5
	hints.anchor_right = 0.5
	hints.anchor_top = 1.0
	hints.anchor_bottom = 1.0
	hints.grow_horizontal = Control.GROW_DIRECTION_BOTH
	hints.grow_vertical = Control.GROW_DIRECTION_BEGIN
	hints.offset_left = 0.0
	hints.offset_right = 0.0
	hints.offset_top = -22.0
	hints.offset_bottom = -22.0
	hints.add_child(hint_chip("HOLD", "jump higher"))
	hints.add_child(hint_chip("TAP IN AIR", "double jump"))
	ready_root.add_child(hints)

	best_pill = make_pill(24.0, 34.0)
	best_pill.anchor_left = 0.0
	best_pill.anchor_right = 0.0
	best_pill.offset_left = 24.0
	best_pill.offset_top = 24.0
	ready_root.add_child(best_pill)
	var brow := HBoxContainer.new()
	brow.add_theme_constant_override("separation", 10)
	best_pill.add_child(brow)
	brow.add_child(icon_rect(tex("trophy"), 46))
	brow.add_child(make_label("BEST", 18, DIM, 0))
	best_label = make_label("0", 38, Color.WHITE, 8)
	brow.add_child(best_label)


func hint_chip(head: String, tail: String) -> PanelContainer:
	var c := PanelContainer.new()
	c.add_theme_stylebox_override("panel", make_box("chip", 28, 28, 28, 28, 22, 8, 22, 10))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	c.add_child(row)
	row.add_child(make_label(head, 22, GOLD, 0))
	row.add_child(make_label(tail, 22, LILAC, 0))
	return c


func build_overlays() -> void:
	count_label = make_label("", 190, Color.WHITE, 18)
	count_label.anchor_left = 0.5
	count_label.anchor_right = 0.5
	count_label.anchor_top = 0.5
	count_label.anchor_bottom = 0.5
	count_label.offset_left = -170.0
	count_label.offset_right = 170.0
	count_label.offset_top = -150.0
	count_label.offset_bottom = 150.0
	count_label.pivot_offset = Vector2(170.0, 150.0)
	count_label.visible = false
	add_child(count_label)

	toast_label = make_label("", 60, GOLD, 12)
	place_top_center(toast_label, 600.0, 90.0, 120.0)
	toast_label.visible = false
	add_child(toast_label)

	dim = ColorRect.new()
	dim.color = Color(0.06, 0.02, 0.18, 0.62)
	full_rect(dim)
	dim.visible = false
	add_child(dim)


func build_pause() -> void:
	pause_root = Control.new()
	full_rect(pause_root)
	pause_root.visible = false
	add_child(pause_root)

	pause_panel = make_panel()
	pause_root.add_child(pause_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 22)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	pause_panel.add_child(v)
	v.add_child(title_rect("paused"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 18)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(row)
	var home := round_button("home")
	home.pressed.connect(func() -> void: home_pressed.emit())
	var resume := make_button("RESUME", "primary", 300.0)
	resume.pressed.connect(func() -> void: resume_pressed.emit())
	var again := round_button("retry")
	again.pressed.connect(func() -> void: retry_pressed.emit())
	row.add_child(home)
	row.add_child(resume)
	row.add_child(again)


func build_over() -> void:
	over_root = Control.new()
	full_rect(over_root)
	over_root.visible = false
	add_child(over_root)

	over_panel = make_panel()
	over_root.add_child(over_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	over_panel.add_child(v)
	v.add_child(title_rect("gameover"))

	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 44)
	cols.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(cols)

	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 0)
	left.alignment = BoxContainer.ALIGNMENT_CENTER
	cols.add_child(left)

	var cap := Control.new()
	cap.custom_minimum_size = Vector2(320, 48)
	left.add_child(cap)
	over_caption = make_label("SCORE", 24, DIM, 0)
	full_rect(over_caption)
	cap.add_child(over_caption)
	over_badge = PanelContainer.new()
	over_badge.add_theme_stylebox_override("panel", make_box("badge", 40, 32, 40, 38, 30, 4, 30, 14))
	over_badge.add_child(make_label("NEW BEST!", 26, BROWN, 0))
	center_in(over_badge)
	over_badge.visible = false
	cap.add_child(over_badge)

	over_score = make_label("0", 96, Color.WHITE, 12)
	over_score.custom_minimum_size = Vector2(320, 112)
	left.add_child(over_score)

	var stars := HBoxContainer.new()
	stars.add_theme_constant_override("separation", 6)
	stars.alignment = BoxContainer.ALIGNMENT_CENTER
	left.add_child(stars)
	for i in 3:
		var slot := Control.new()
		slot.custom_minimum_size = Vector2(100, 108)
		var y := 6.0 if i == 1 else 18.0
		var off := star_rect("star_off", y, i)
		var on := star_rect("star_on", y, i)
		on.modulate.a = 0.0
		slot.add_child(off)
		slot.add_child(on)
		star_on.append(on)
		stars.add_child(slot)

	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 12)
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	cols.add_child(right)
	var best_chip := make_chip(tex("trophy"), "BEST")
	over_best = best_chip[1]
	right.add_child(best_chip[0])
	var coin_chip := make_chip(coin_tex, "COINS")
	over_coins = coin_chip[1]
	right.add_child(coin_chip[0])
	var brow := HBoxContainer.new()
	brow.add_theme_constant_override("separation", 14)
	brow.alignment = BoxContainer.ALIGNMENT_CENTER
	right.add_child(brow)
	var home := round_button("home")
	home.pressed.connect(func() -> void: home_pressed.emit())
	var retry := make_button("RETRY", "primary", 260.0)
	retry.pressed.connect(func() -> void: retry_pressed.emit())
	brow.add_child(home)
	brow.add_child(retry)


func star_rect(name: String, y: float, i: int) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex(name)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.size = Vector2(88, 88)
	r.position = Vector2(6, y)
	r.pivot_offset = Vector2(44, 44)
	r.rotation_degrees = float(i - 1) * 14.0
	return r


func build_flash() -> void:
	flash_rect = ColorRect.new()
	flash_rect.color = Color(1, 1, 1, 1)
	full_rect(flash_rect)
	flash_rect.modulate.a = 0.0
	add_child(flash_rect)


func kill_loops() -> void:
	for t in [tap_tween, logo_tween, badge_tween, over_tween]:
		if t != null and t.is_valid():
			t.kill()
	over_badge.rotation_degrees = 0.0
	tap_btn.scale = Vector2.ONE


func hide_all() -> void:
	kill_loops()
	ready_root.visible = false
	hud_root.visible = false
	pause_root.visible = false
	over_root.visible = false
	dim.visible = false
	count_label.visible = false


func show_ready(best: int) -> void:
	hide_all()
	ready_root.visible = true
	best_pill.visible = best > 0
	best_label.text = str(best)
	logo.scale = Vector2(0.7, 0.7)
	logo.modulate.a = 0.0
	var intro := create_tween().set_parallel(true)
	intro.tween_property(logo, "scale", Vector2.ONE, 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	intro.tween_property(logo, "modulate:a", 1.0, 0.3)
	logo_tween = create_tween().set_loops()
	logo.position.y = LOGO_TOP
	logo_tween.tween_property(logo, "position:y", LOGO_TOP - 7.0, 1.3).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	logo_tween.tween_property(logo, "position:y", LOGO_TOP, 1.3).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tap_tween = create_tween().set_loops()
	tap_tween.tween_property(tap_btn, "scale", Vector2(1.06, 1.06), 0.55).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tap_tween.tween_property(tap_btn, "scale", Vector2.ONE, 0.55).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func show_play() -> void:
	hide_all()
	hud_root.visible = true
	score_label.text = "0"
	coin_label.text = "0"


func show_paused() -> void:
	dim.visible = true
	pause_root.visible = true
	pop_panel(pause_panel)


func hide_paused() -> void:
	dim.visible = false
	pause_root.visible = false


func pop_panel(p: Control) -> void:
	dim.modulate.a = 0.0
	p.modulate.a = 0.0
	p.scale = Vector2(0.8, 0.8)
	p.pivot_offset = p.get_combined_minimum_size() * 0.5
	var t := create_tween().set_parallel(true)
	t.tween_property(dim, "modulate:a", 1.0, 0.22)
	t.tween_property(p, "modulate:a", 1.0, 0.18)
	t.tween_property(p, "scale", Vector2.ONE, 0.42).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func show_count(n: int) -> void:
	count_label.text = str(n)
	count_label.visible = true
	count_label.scale = Vector2(1.7, 1.7)
	count_label.modulate.a = 0.0
	var t := create_tween().set_parallel(true)
	t.tween_property(count_label, "scale", Vector2.ONE, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(count_label, "modulate:a", 1.0, 0.15)


func hide_count() -> void:
	count_label.visible = false


func set_score(v: int) -> void:
	score_label.text = str(v)
	if v > 0 and v % 100 == 0:
		bump(score_pill, 1.12)


func set_coins(v: int) -> void:
	coin_label.text = str(v)


func set_fps(t: String) -> void:
	fps_label.text = t


func bump(c: Control, amount: float) -> void:
	c.scale = Vector2(amount, amount)
	var t := create_tween()
	t.tween_property(c, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func toast(text: String) -> void:
	if toast_tween != null and toast_tween.is_valid():
		toast_tween.kill()
	toast_label.text = text
	toast_label.visible = true
	toast_label.modulate.a = 1.0
	toast_label.scale = Vector2(0.6, 0.6)
	toast_label.position.y = 120.0
	toast_tween = create_tween()
	toast_tween.tween_property(toast_label, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	toast_tween.tween_interval(0.7)
	toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.4)
	toast_tween.tween_callback(func() -> void: toast_label.visible = false)
	var rise := create_tween()
	rise.tween_property(toast_label, "position:y", 84.0, 1.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func fly_coin(from: Vector2) -> void:
	var s := Sprite2D.new()
	s.texture = coin_tex
	s.scale = Vector2(0.3, 0.3)
	s.position = from
	add_child(s)
	var target := coin_icon.global_position + coin_icon.size * 0.5
	var t := create_tween().set_parallel(true)
	t.tween_property(s, "position", target, 0.45).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	t.tween_property(s, "scale", Vector2(0.17, 0.17), 0.45)
	t.chain().tween_callback(finish_coin.bind(s))


func finish_coin(s: Sprite2D) -> void:
	s.queue_free()
	bump(coin_pill, 1.14)


func flash() -> void:
	var t := create_tween()
	t.tween_property(flash_rect, "modulate:a", 0.0, 0.4).from(0.7)


func show_over(score: int, best: int, coins: int, new_best: bool, delay: float) -> void:
	over_best.text = str(best)
	over_coins.text = str(coins)
	over_score.text = "0"
	over_caption.visible = not new_best
	over_badge.visible = new_best
	for s in star_on:
		s.modulate.a = 0.0
		s.scale = Vector2.ONE
	var earned := 0
	for i in 3:
		if score >= STAR_AT[i]:
			earned += 1
	if over_tween != null and over_tween.is_valid():
		over_tween.kill()
	over_tween = create_tween()
	over_tween.tween_interval(delay)
	over_tween.tween_callback(reveal_over.bind(score, earned, new_best))


func reveal_over(score: int, earned: int, new_best: bool) -> void:
	hud_root.visible = false
	over_root.visible = true
	dim.visible = true
	pop_panel(over_panel)
	var c := create_tween()
	c.tween_interval(0.3)
	c.tween_method(set_over_score, 0.0, float(score), 0.9).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	var st := create_tween()
	st.tween_interval(0.75)
	for i in earned:
		st.tween_callback(pop_star.bind(i))
		st.tween_interval(0.3)
	if new_best:
		badge_tween = create_tween().set_loops()
		over_badge.pivot_offset = over_badge.size * 0.5
		badge_tween.tween_property(over_badge, "rotation_degrees", 4.0, 0.45).from(-4.0).set_trans(Tween.TRANS_SINE)
		badge_tween.tween_property(over_badge, "rotation_degrees", -4.0, 0.45).set_trans(Tween.TRANS_SINE)


func set_over_score(v: float) -> void:
	over_score.text = str(int(v))


func pop_star(i: int) -> void:
	var s := star_on[i]
	s.modulate.a = 1.0
	s.scale = Vector2(2.0, 2.0)
	var t := create_tween()
	t.tween_property(s, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
