extends Control

signal action(key: String)
signal built(list: Array)

const Cp := preload("res://cp_kit.gd")
const U := 1.6
const PAD_X := 14.0
const PAD_Y := 10.0
const TAB_NAMES := ["UNICORNS", "TRAILS", "HORNS", "PETS", "SKILLS"]
const SKILL_COL := {"magnet": "ff5fa8", "shield": "5fb8ff", "x2": "ffe066", "slow": "7ae4dc", "life": "ff5a8c", "luck": "6fe3a5", "combo": "a56bff", "float": "ffb05f"}
const SKILL_ICON := {"magnet": "pu_magnet", "shield": "pu_shield", "x2": "pu_x2", "slow": "pu_slow", "life": "pu_heart", "luck": "star_on", "combo": "coin", "float": "spark"}

var m
var buttons: Array = []
var items: Array = []
var cards: Array = []
var built_w := 0.0
var built_h := 0.0
var coin_label: Label
var heart_label: Label
var skin_shader: Shader
var left_edge := 0.0


func setup(main: Node) -> void:
	m = main
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(on_resized)
	visibility_changed.connect(on_visible)
	skin_shader = Shader.new()
	skin_shader.code = m.SKIN_SHADER


func uni_x() -> float:
	return left_edge - d(66.0)


func d(v: float) -> float:
	return v * U


func on_resized() -> void:
	if size.x < 200.0:
		return
	if is_equal_approx(size.x, built_w) and is_equal_approx(size.y, built_h):
		return
	refresh(true)


func on_visible() -> void:
	if not is_visible_in_tree():
		return
	refresh(true)


func reg(n: Control, index: int, dy: float = 22.0) -> void:
	items.append([n, n.position.y, index, dy])


func emit_action(key: String) -> void:
	action.emit(key)


func refresh(animate: bool = false, lift_sel: bool = false) -> void:
	if size.x < 200.0 or m == null:
		return
	built_w = size.x
	built_h = size.y
	for c in get_children():
		remove_child(c)
		c.queue_free()
	buttons.clear()
	items.clear()
	cards.clear()
	build()
	if animate:
		for it in items:
			var n: Control = it[0]
			if is_instance_valid(n):
				Cp.enter(n, float(it[1]), int(it[2]), float(it[3]))
	if lift_sel:
		lift_selected()
	built.emit(buttons)


func lift_selected() -> void:
	var i: int = m.shop_sel
	if i < 0 or i >= cards.size():
		return
	var n: Control = cards[i]
	var base: float = n.get_meta("base_y")
	n.position.y = base
	var tw := n.create_tween()
	var step: Callable = func(t: float) -> void:
		var v := Cp.spring(t, 0.55, 500.0)
		n.position.y = base - d(6.0) * v
	tw.tween_method(step, 0.0, 0.7, 0.7)


func make_pill(icon_name: String, text: String, col: Color, h_dp: float) -> Array:
	var pill := Cp.pill(h_dp)
	Cp.pill_add(pill, Cp.icon(icon_name, h_dp * 0.6))
	Cp.pill_add(pill, Cp.gap(d(5.0)))
	var l := Cp.label(text, h_dp * 0.46, col)
	Cp.set_text(l, text)
	Cp.pill_add(pill, l)
	Cp.pill_update(pill)
	return [pill, l]


func update_pill(pill: Control, l: Label, text: String) -> void:
	Cp.set_text(l, text)
	Cp.pill_update(pill)


func build() -> void:
	var tab: int = m.shop_tab
	var list: Array = m.shop_list(tab)
	var left_w := d((size.x / U - PAD_X * 2.0) * 0.24)
	var px := d(PAD_X) + left_w + d(10.0)
	var panel_w := size.x - px - d(PAD_X)
	var panel_h := size.y - d(PAD_Y * 2.0)
	left_edge = px

	var back := Cp.round_btn(40.0, "back", 22.0)
	back.position = Vector2(d(PAD_X), d(PAD_Y))
	back.pressed.connect(emit_action.bind("back"))
	add_child(back)
	buttons.append(back)
	reg(back, 0)

	var note_text := note_for(tab)
	var nw := left_w
	var nh := d(70.0)
	var note := Cp.glass(Vector2(nw, nh), 16.0)
	note.position = Vector2(d(PAD_X), d(PAD_Y + 40.0 + 10.0))
	add_child(note)
	reg(note, 2)
	var nl := Cp.label(note_text, 11.0, Cp.LILAC, false)
	nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nl.position = Vector2(d(10.0), d(6.0))
	nl.size = Vector2(nw - d(20.0), nh - d(12.0))
	nl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	note.add_child(nl)

	var panel := Cp.glass(Vector2(panel_w, panel_h), 26.0)
	panel.position = Vector2(px, d(PAD_Y))
	add_child(panel)
	reg(panel, 0)
	var pad := d(12.0)
	var iw := panel_w - pad * 2.0

	var title := Cp.grad_title(m.T("SHOP"), 24.0)
	title.position = Vector2(pad, pad - d(2.0))
	panel.add_child(title)
	var cp: Array = make_pill("coin", "%d" % m.bank, Cp.SUN, 28.0)
	var cpill: Control = cp[0]
	cpill.position = Vector2(panel_w - pad - cpill.size.x, pad)
	panel.add_child(cpill)
	coin_label = cp[1]
	var hp: Array = make_pill("heart", "%d" % m.start_lives(), Color("ffd0e0"), 28.0)
	var hpill: Control = hp[0]
	hpill.position = Vector2(cpill.position.x - d(8.0) - hpill.size.x, pad)
	panel.add_child(hpill)
	heart_label = hp[1]

	var ty := pad + d(28.0) + d(8.0)
	var tgap := d(5.0)
	var tw := (iw - tgap * 4.0) / 5.0
	for k in 5:
		var on: bool = k == tab
		var tb := Cp.flat_button(Vector2(tw, d(28.0)))
		tb.position = Vector2(pad + k * (tw + tgap), ty)
		var bgs: Dictionary = {"top": Color(1, 1, 1, 0.14), "bot": Color(1, 1, 1, 0.08), "rim_t": Color(1, 1, 1, 0.25), "rim_b": Color(1, 1, 1, 0.25), "rim_w": U}
		if on:
			bgs = {"top": Color("ff8fdc"), "mid": Color("b45cff"), "bot": Color("8b45ee"), "rim_t": Color(1, 1, 1, 0.8), "rim_b": Color(1, 1, 1, 0.8), "rim_w": U}
		var bg := Cp.shape(tb.size, d(14.0), bgs)
		tb.add_child(bg)
		var tl := Cp.label(m.T(TAB_NAMES[k]), 10.0, Color.WHITE)
		Cp.place(tl, 0.0, 0.0, tw, d(28.0), HORIZONTAL_ALIGNMENT_CENTER)
		Cp.fit(tl, tw - d(6.0))
		tb.add_child(tl)
		tb.pressed.connect(emit_action.bind("tab%d" % k))
		tb.set_meta("punch_node", tb)
		panel.add_child(tb)
		buttons.append(tb)

	var bottom_h := d(40.0) + d(8.0)
	var cy := ty + d(28.0) + d(8.0)
	var area_h := panel_h - pad - bottom_h - cy
	var gap := d(8.0)
	var pref_w := d(84.0)
	var per_row := maxi(1, int(floor((iw + gap) / (pref_w + gap))))
	var rows := int(ceil(float(list.size()) / float(per_row)))
	var cols := int(ceil(float(list.size()) / float(rows)))
	var cw := minf(d(112.0), (iw - gap * (cols - 1)) / float(cols))
	var ch := minf(d(190.0), (area_h - d(8.0) - gap * (rows - 1)) / float(rows))
	for i in list.size():
		var r := i / cols
		var c := i % cols
		var in_row := mini(cols, list.size() - r * cols)
		var row_w := cw * in_row + gap * (in_row - 1)
		var card := make_card(tab, i, Vector2(cw, ch))
		var base := cy + d(6.0) + r * (ch + gap)
		card.position = Vector2(pad + (iw - row_w) * 0.5 + c * (cw + gap), base)
		card.set_meta("base_y", base)
		if i == m.shop_sel:
			card.position.y = base - d(6.0)
		panel.add_child(card)
		cards.append(card)
		reg(card, i, 14.0)

	build_action(panel, panel_w, panel_h, pad, tab, list)


func note_for(tab: int) -> String:
	var list: Array = m.shop_list(tab)
	var i: int = clampi(m.shop_sel, 0, list.size() - 1)
	var it: Dictionary = list[i]
	if tab == 3:
		return m.T(String(it["desc"]))
	if tab == 4:
		var id: String = it["id"]
		return "%s\n%s" % [m.T(String(it["desc"])), m.T("Lv %d/%d") % [m.skill_lv(id), m.skill_max(id)]]
	return m.T("Tap a card to try it on your unicorn")


func make_card(tab: int, i: int, sz: Vector2) -> Control:
	var list: Array = m.shop_list(tab)
	var it: Dictionary = list[i]
	var selected: bool = i == m.shop_sel
	var owned: bool = true if tab == 4 else m.is_owned(tab, i)
	var equipped: bool = false if tab == 4 else m.is_equipped(tab, i)
	var root := Control.new()
	root.size = sz
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var rim := Color(1, 1, 1, 0.25)
	var rw := 1.4 * U
	if equipped:
		rim = Cp.MINT
		rw = 2.4 * U
	elif selected:
		rim = Color(1, 1, 1, 0.8)
	var top_c := Color(1, 1, 1, 0.25) if selected else Color(1, 1, 1, 0.12)
	var bot_c := Color(1, 1, 1, 0.15) if selected else Color(1, 1, 1, 0.06)
	root.add_child(Cp.shape(sz, d(18.0), {"top": top_c, "bot": bot_c, "rim_t": rim, "rim_b": rim, "rim_w": rw}))
	var nl := Cp.label(m.T(String(it["name"])), 11.5, Color.WHITE)
	Cp.place(nl, 0.0, d(8.0), sz.x, d(16.0), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(nl, sz.x - d(8.0))
	root.add_child(nl)
	var foot_h := d(20.0)
	var pv := Control.new()
	pv.position = Vector2(d(4.0), d(26.0))
	pv.size = Vector2(sz.x - d(8.0), sz.y - d(26.0) - foot_h - d(8.0))
	pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(pv)
	fill_preview(pv, tab, i, it)
	if tab != 4 and not owned:
		pv.modulate.a = 0.6
	var fy := sz.y - foot_h - d(6.0)
	if tab == 4:
		var id: String = it["id"]
		var lv: int = m.skill_lv(id)
		var mx: int = m.skill_max(id)
		if lv >= mx:
			var ml := Cp.label(m.T("MAX"), 10.0, Cp.MINT)
			Cp.place(ml, 0.0, fy, sz.x, foot_h, HORIZONTAL_ALIGNMENT_CENTER)
			root.add_child(ml)
		else:
			price_row(root, sz, fy, foot_h, "%d" % m.skill_cost(i), "coin", Cp.SUN)
	elif equipped:
		var el := Cp.label(m.T("EQUIPPED"), 10.0, Cp.MINT)
		Cp.place(el, 0.0, fy, sz.x, foot_h, HORIZONTAL_ALIGNMENT_CENTER)
		Cp.fit(el, sz.x - d(6.0))
		root.add_child(el)
	elif owned:
		var ol := Cp.label(m.T("OWNED"), 10.5, Color("b8ffe6"))
		Cp.place(ol, 0.0, fy, sz.x, foot_h, HORIZONTAL_ALIGNMENT_CENTER)
		root.add_child(ol)
	else:
		price_row(root, sz, fy, foot_h, "%d" % int(it["cost"]), "coin", Cp.SUN)
	var btn := Cp.flat_button(sz)
	btn.set_meta("punch_node", root)
	btn.pressed.connect(emit_action.bind("card%d" % i))
	root.add_child(btn)
	buttons.append(btn)
	return root


func price_row(root: Control, sz: Vector2, y: float, h: float, text: String, icon_name: String, col: Color) -> void:
	var tw := Cp.text_w(text, 12.0)
	var total := d(14.0) + d(4.0) + tw
	var sx := (sz.x - total) * 0.5
	var ic := Cp.icon(icon_name, 14.0)
	ic.position = Vector2(sx, y + (h - ic.size.y) * 0.5)
	root.add_child(ic)
	var l := Cp.label(text, 12.0, col)
	Cp.place(l, sx + d(18.0), y, tw + d(6.0), h)
	root.add_child(l)


func fill_preview(pv: Control, tab: int, i: int, it: Dictionary) -> void:
	if tab == 0:
		var t := TextureRect.new()
		t.texture = m.get_tex("res://art/unicorn_prev.png")
		t.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		t.mouse_filter = Control.MOUSE_FILTER_IGNORE
		if i > 0:
			var mat := ShaderMaterial.new()
			mat.shader = skin_shader
			mat.set_shader_parameter("body", m.hc(it["body"]))
			mat.set_shader_parameter("hue", float(it["hue"]))
			t.material = mat
		pv.add_child(t)
	elif tab == 3:
		var t2 := TextureRect.new()
		t2.texture = m.get_tex("res://art/pet_%d.png" % i)
		t2.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		t2.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t2.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		t2.mouse_filter = Control.MOUSE_FILTER_IGNORE
		pv.add_child(t2)
	else:
		pv.draw.connect(draw_preview.bind(pv, tab, i, it))


func draw_preview(c: Control, tab: int, i: int, it: Dictionary) -> void:
	var w := c.size.x
	var h := c.size.y
	if tab == 1:
		draw_trail(c, w, h, it["c"])
	elif tab == 2:
		draw_horn(c, w, h, it)
	else:
		draw_skill(c, w, h, it)


func draw_trail(c: Control, w: float, h: float, cols: Array) -> void:
	var lw := h * 0.1
	for k in 6:
		var col: Color = m.hc(cols[k])
		var pts := PackedVector2Array()
		var cs := PackedColorArray()
		var n := 20
		for s in n + 1:
			var t := float(s) / float(n)
			var x := w * (0.08 + 0.84 * t)
			var y := h * 0.5 + (float(k) - 2.5) * lw + sin(t * PI * 1.4 + 0.3) * h * 0.14 - h * 0.04
			pts.append(Vector2(x, y))
			cs.append(Color(col.r, col.g, col.b, 0.15 + 0.85 * t))
		c.draw_polyline_colors(pts, cs, lw, true)


func star_poly(p: Vector2, r: float) -> PackedVector2Array:
	var q := 0.2
	return PackedVector2Array([p + Vector2(0, -r), p + Vector2(r * q, -r * q), p + Vector2(r, 0), p + Vector2(r * q, r * q), p + Vector2(0, r), p + Vector2(-r * q, r * q), p + Vector2(-r, 0), p + Vector2(-r * q, -r * q)])


func draw_horn(c: Control, w: float, h: float, it: Dictionary) -> void:
	var col: Color = m.hc(it["c"])
	var cx := w * 0.5
	var cy := h * 0.52
	var hh := h * 0.7
	if int(it["n"]) > 0:
		c.draw_circle(Vector2(cx, cy), h * 0.42, Color(col.r, col.g, col.b, 0.22))
		c.draw_circle(Vector2(cx, cy), h * 0.3, Color(col.r, col.g, col.b, 0.22))
	var base_w := hh * 0.26
	var tip := Vector2(cx, cy - hh * 0.5)
	var bl := Vector2(cx - base_w, cy + hh * 0.5)
	var br := Vector2(cx + base_w, cy + hh * 0.5)
	var hc := Color("ffe9a8")
	c.draw_polygon(PackedVector2Array([tip, br, bl]), PackedColorArray([hc, hc, hc]))
	for k in 4:
		var t := 0.25 + 0.17 * float(k)
		var a := tip.lerp(bl, t)
		var b := tip.lerp(br, t)
		c.draw_line(a, b, Color("e8b84c", 0.8), maxf(1.6, h * 0.025), true)
	c.draw_polyline(PackedVector2Array([bl, tip, br, bl]), Color("2a1458"), maxf(1.6, h * 0.03), true)
	if int(it["n"]) > 0:
		for k in 4:
			var ang := float(k) * 1.57 + 0.5
			var p := Vector2(cx + cos(ang) * w * 0.32, cy + sin(ang) * h * 0.34)
			c.draw_colored_polygon(star_poly(p, h * (0.07 + 0.02 * float(k % 2))), col.lightened(0.3))


func draw_skill(c: Control, w: float, h: float, it: Dictionary) -> void:
	var id: String = it["id"]
	var col: Color = m.hc(SKILL_COL[id])
	var ctr := Vector2(w * 0.5, h * 0.44)
	var r := minf(w, h) * 0.36
	c.draw_circle(ctr, r * 1.35, Color(col.r, col.g, col.b, 0.22))
	c.draw_circle(ctr, r, Color(col.r, col.g, col.b, 0.35))
	c.draw_arc(ctr, r, 0.0, TAU, 40, Color(col.r, col.g, col.b, 0.9), maxf(1.6, r * 0.08), true)
	var tex: Texture2D = m.get_tex("res://art/%s.png" % SKILL_ICON[id])
	var s := r * 1.25
	c.draw_texture_rect(tex, Rect2(ctr - Vector2(s, s) * 0.5, Vector2(s, s)), false)
	var lv: int = m.skill_lv(id)
	var mx: int = m.skill_max(id)
	var pr := h * 0.045
	var total := float(mx) * pr * 2.0 + float(mx - 1) * pr
	for k in mx:
		var p := Vector2(w * 0.5 - total * 0.5 + pr + float(k) * pr * 3.0, h * 0.92)
		c.draw_circle(p, pr, col if k < lv else Color(1, 1, 1, 0.25))


func build_action(panel: Control, panel_w: float, panel_h: float, pad: float, tab: int, list: Array) -> void:
	var i: int = clampi(m.shop_sel, 0, list.size() - 1)
	var it: Dictionary = list[i]
	var nl := Cp.label(m.T(String(it["name"])), 15.0, Color.WHITE)
	Cp.place(nl, pad, panel_h - pad - d(40.0), panel_w - pad * 2.0 - d(160.0), d(40.0))
	Cp.fit(nl, panel_w - pad * 2.0 - d(160.0))
	panel.add_child(nl)
	var bw := d(150.0)
	var btn: Button
	if tab == 4:
		var id: String = it["id"]
		if m.skill_lv(id) >= m.skill_max(id):
			btn = Cp.g_button(m.T("MAX"), bw, 40.0, "off", 15.0)
		else:
			btn = Cp.g_button(m.T("UPGRADE %d") % m.skill_cost(i), bw, 40.0, "gold", 15.0, {"coin": true})
	elif m.is_owned(tab, i):
		if m.is_equipped(tab, i):
			if tab == 3:
				btn = Cp.g_button(m.T("UNEQUIP"), bw, 40.0, "primary", 15.0)
			else:
				btn = Cp.g_button(m.T("EQUIPPED"), bw, 40.0, "off", 15.0)
		else:
			btn = Cp.g_button(m.T("EQUIP"), bw, 40.0, "primary", 15.0)
	else:
		btn = Cp.g_button(m.T("BUY %d") % int(it["cost"]), bw, 40.0, "gold", 15.0, {"coin": true})
	btn.position = Vector2(panel_w - pad - bw, panel_h - pad - btn.size.y)
	btn.pressed.connect(emit_action.bind("buy"))
	panel.add_child(btn)
	buttons.append(btn)


func celebrate() -> void:
	var i: int = m.shop_sel
	if i < 0 or i >= cards.size():
		return
	var n: Control = cards[i]
	var ctr := n.get_global_rect().get_center() - global_position
	for k in 9:
		var s := TextureRect.new()
		s.texture = m.get_tex("res://art/spark.png")
		s.size = Vector2.ONE * d(16.0)
		s.pivot_offset = s.size * 0.5
		s.position = ctr - s.size * 0.5
		s.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(s)
		var ang := TAU * float(k) / 9.0 + randf() * 0.4
		var dist := d(46.0 + randf() * 30.0)
		var tw := s.create_tween().set_parallel(true)
		tw.tween_property(s, "position", s.position + Vector2(cos(ang), sin(ang)) * dist, 0.6).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		tw.tween_property(s, "modulate:a", 0.0, 0.6).set_delay(0.15)
		tw.tween_property(s, "scale", Vector2(0.3, 0.3), 0.6)
		tw.chain().tween_callback(s.queue_free)
	var pop := n.create_tween()
	n.pivot_offset = n.size * 0.5
	var step: Callable = func(t: float) -> void:
		var v := Cp.spring(t, 0.45, 520.0)
		var sc := 1.0 + 0.18 * (1.0 - v)
		n.scale = Vector2(sc, sc)
	pop.tween_method(step, 0.0, 0.7, 0.7)
	pop.tween_callback(func() -> void: n.scale = Vector2.ONE)
