extends Control

signal action(key: String)
signal built(list: Array)

const Cp := preload("res://cp_kit.gd")
const U := 1.6
const PAD_X := 14.0
const PAD_Y := 10.0

var m
var buttons: Array = []
var items: Array = []
var pulse_nodes: Array = []
var tile_badges: Dictionary = {}
var clock := 0.0
var built_w := 0.0
var built_h := 0.0
var shown_coins := -1.0
var coin_tw: Tween = null

var level_label: Label
var xp_label: Label
var xp_bar: Control
var missions_sub: Label
var missions_check: Control
var missions_badge: Control
var best_label: Label
var zone_label: Label
var star_pill: Control
var star_label: Label
var coin_pill: Control
var coin_label: Label
var heart_pill: Control
var heart_label: Label
var sound_btn: Button
var daily_gold: Button
var daily_soft: Button
var gold_sub: Label
var soft_sub: Label


func setup(main: Node) -> void:
	m = main
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(on_resized)
	visibility_changed.connect(on_visible)


func d(v: float) -> float:
	return v * U


func emit_action(key: String) -> void:
	action.emit(key)


func reg(n: Control, index: int, dy: float = 22.0) -> void:
	items.append([n, n.position.y, index, dy])


func on_resized() -> void:
	if size.x < 200.0:
		return
	if is_equal_approx(size.x, built_w) and is_equal_approx(size.y, built_h):
		return
	built_w = size.x
	built_h = size.y
	build()
	refresh(false)
	built.emit(buttons)


func on_visible() -> void:
	if not is_visible_in_tree():
		return
	if built_w == 0.0:
		on_resized()
	refresh(false)
	play_enter()


func play_enter() -> void:
	for it in items:
		var n: Control = it[0]
		if is_instance_valid(n):
			Cp.enter(n, float(it[1]), int(it[2]), float(it[3]))


func build() -> void:
	for c in get_children():
		remove_child(c)
		c.queue_free()
	buttons.clear()
	items.clear()
	pulse_nodes.clear()
	tile_badges.clear()
	var wd := size.x / U
	var roomy := wd >= 760.0
	var side_w := 232.0 if roomy else 208.0
	var cta_w := 188.0 if roomy else 150.0
	var medal := 60.0 if roomy else 50.0
	var right_w := 190.0 if roomy else 160.0
	var title_w := maxf(120.0, wd - PAD_X * 2.0 - side_w - 350.0 - 44.0)
	var title_sp := clampf(title_w / 8.8, 15.0, 26.0)

	var mascot := Cp.flat_button(Vector2(d(190.0), d(170.0)))
	mascot.position = Vector2(size.x * 0.5 - d(95.0), size.y * 0.5 + d(5.0) - d(85.0))
	mascot.set_meta("quiet", true)
	mascot.pressed.connect(emit_action.bind("pet"))
	add_child(mascot)
	buttons.append(mascot)

	build_profile(side_w)
	build_missions(side_w)
	build_best(side_w)
	build_title(side_w, title_w, title_sp)
	build_status()
	build_daily(right_w)
	build_dock(cta_w, medal)


func build_profile(side_w: float) -> void:
	var profile := Cp.glass(Vector2(d(side_w), d(54.0)), 18.0)
	profile.position = Vector2(d(PAD_X), d(PAD_Y))
	add_child(profile)
	reg(profile, 0)
	var badge := Cp.shape(
		Vector2(d(42.0), d(42.0)),
		d(21.0),
		{"top": Cp.PINK, "bot": Cp.PURPLE, "rim_t": Color(1.0, 1.0, 1.0, 0.867), "rim_b": Color(1.0, 1.0, 1.0, 0.867), "rim_w": d(2.0)}
	)
	badge.position = Vector2(d(6.0), d(6.0))
	profile.add_child(badge)
	level_label = Cp.label("1", 42.0 * 0.42, Color.WHITE)
	Cp.place(level_label, 0.0, 0.0, d(42.0), d(42.0), HORIZONTAL_ALIGNMENT_CENTER)
	badge.add_child(level_label)
	var x0 := d(58.0)
	var colw := d(side_w - 58.0 - 12.0)
	var player := Cp.label(m.T("PLAYER"), 11.0, Cp.SUN)
	Cp.place(player, x0, d(12.5), colw * 0.5, d(17.0))
	profile.add_child(player)
	xp_label = Cp.label("", 9.5, Cp.LILAC, false)
	Cp.place(xp_label, x0 + colw * 0.5, d(12.5), colw * 0.5, d(17.0), HORIZONTAL_ALIGNMENT_RIGHT)
	profile.add_child(xp_label)
	xp_bar = Cp.bar(Vector2(colw, d(7.0)))
	xp_bar.position = Vector2(x0, d(32.5))
	profile.add_child(xp_bar)


func build_missions(side_w: float) -> void:
	var btn := Cp.face_button(Vector2(d(side_w), d(54.0)), d(16.0), "soft", d(4.0))
	btn.position = Vector2(d(PAD_X), d(PAD_Y + 64.0))
	btn.pressed.connect(emit_action.bind("missions"))
	add_child(btn)
	buttons.append(btn)
	reg(btn, 2)
	var content: Control = btn.get_meta("content")
	missions_check = Cp.icon("check", 24.0, Cp.SUN)
	missions_check.position = Vector2(d(12.0), (content.size.y - d(24.0)) * 0.5)
	content.add_child(missions_check)
	var tx := d(45.0)
	var tw := d(side_w - 45.0 - 12.0 - 16.0 - 6.0)
	var title := Cp.label(m.T("DAILY MISSIONS"), 11.0, Cp.SUN)
	Cp.place(title, tx, d(7.0), tw, d(17.0))
	Cp.fit(title, tw)
	content.add_child(title)
	missions_sub = Cp.label("", 9.5, Cp.LILAC, false)
	missions_sub.set_meta("maxw", tw)
	Cp.place(missions_sub, tx, d(24.0), tw, d(16.0))
	content.add_child(missions_sub)
	var arrow := Cp.icon("arrow_r", 16.0, Cp.LILAC)
	arrow.position = Vector2(d(side_w - 12.0 - 16.0), (content.size.y - d(16.0)) * 0.5)
	content.add_child(arrow)
	missions_badge = Cp.badge()
	missions_badge.position = Vector2(d(side_w) - d(15.0) + d(4.0), -d(4.0))
	btn.add_child(missions_badge)


func build_best(side_w: float) -> void:
	var card := Cp.glass(Vector2(d(side_w), d(54.0)), 16.0)
	card.position = Vector2(d(PAD_X), d(PAD_Y + 64.0 + 54.0 + 8.0))
	add_child(card)
	reg(card, 5)
	var row := HBoxContainer.new()
	row.size = card.size
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 0)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(row)
	var ic := Cp.icon("board", 22.0, Cp.CYAN)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(ic)
	row.add_child(Cp.gap(d(9.0)))
	best_label = Cp.label("", 14.0, Cp.SUN)
	best_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(best_label)


func build_title(side_w: float, title_w: float, title_sp: float) -> void:
	var box := Control.new()
	box.size = Vector2(d(title_w), d(54.0))
	box.position = Vector2(d(PAD_X + side_w + 22.0), d(PAD_Y))
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(box)
	reg(box, 1)
	var txt: String = m.T("UNICORN DASH")
	var sp := title_sp
	while Cp.text_w(txt, sp) > d(title_w) and sp > title_sp * 0.5:
		sp *= 0.92
	var title := Cp.grad_title(txt, sp)
	zone_label = Cp.label("", 10.5, Cp.LILAC, false)
	zone_label.set_meta("maxw", d(title_w))
	var zh := d(16.0)
	var total := title.size.y * 0.85 + zh
	var top := (d(54.0) - total) * 0.5
	title.position = Vector2((d(title_w) - title.size.x) * 0.5, top)
	box.add_child(title)
	Cp.place(zone_label, 0.0, top + title.size.y * 0.85, d(title_w), zh, HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(zone_label)


func build_status() -> void:
	var status := HBoxContainer.new()
	status.add_theme_constant_override("separation", roundi(d(8.0)))
	status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status.anchor_left = 1.0
	status.anchor_right = 1.0
	status.anchor_top = 0.0
	status.anchor_bottom = 0.0
	status.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	status.offset_left = -d(PAD_X)
	status.offset_right = -d(PAD_X)
	status.offset_top = d(PAD_Y)
	status.offset_bottom = d(PAD_Y + 54.0)
	add_child(status)
	reg(status, 0)

	star_pill = Cp.pill(34.0)
	Cp.pill_add(star_pill, Cp.icon("star_on", 16.0))
	Cp.pill_add(star_pill, Cp.gap(d(6.0)))
	star_label = Cp.label("", 12.0, Cp.SUN)
	Cp.pill_add(star_pill, star_label)
	star_pill.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	status.add_child(star_pill)

	coin_pill = Cp.pill(34.0)
	Cp.pill_add(coin_pill, Cp.icon("coin", 34.0 * 0.62))
	Cp.pill_add(coin_pill, Cp.gap(d(6.0)))
	coin_label = Cp.label("", 34.0 * 0.48, Cp.SUN)
	Cp.pill_add(coin_pill, coin_label)
	coin_pill.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	status.add_child(coin_pill)

	heart_pill = Cp.pill(34.0)
	Cp.pill_add(heart_pill, Cp.icon("heart", 34.0 * 0.62))
	Cp.pill_add(heart_pill, Cp.gap(d(6.0)))
	heart_label = Cp.label("", 34.0 * 0.48, Color("ffd0e0"))
	Cp.pill_add(heart_pill, heart_label)
	heart_pill.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	status.add_child(heart_pill)

	var gear := Cp.round_btn(34.0, "gear", 18.0)
	gear.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	gear.pressed.connect(emit_action.bind("settings"))
	status.add_child(gear)
	buttons.append(gear)

	sound_btn = Cp.round_btn(34.0, "sound_on", 18.0)
	sound_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sound_btn.pressed.connect(emit_action.bind("mute"))
	status.add_child(sound_btn)
	buttons.append(sound_btn)


func make_daily(done: bool, right_w: float) -> Button:
	var btn := Cp.face_button(Vector2(d(right_w), d(54.0)), d(16.0), "soft" if done else "gold", d(4.0))
	btn.position = Vector2(size.x - d(PAD_X + right_w), d(PAD_Y + 64.0))
	btn.pressed.connect(emit_action.bind("daily"))
	var content: Control = btn.get_meta("content")
	var ink := Color.WHITE if done else Color("5a3000")
	var ic := Cp.icon("calendar", 24.0, Cp.MINT if done else ink)
	ic.position = Vector2(d(12.0), (content.size.y - d(24.0)) * 0.5)
	content.add_child(ic)
	var tx := d(45.0)
	var tw := d(right_w - 45.0 - 12.0 - 16.0 - 6.0)
	var title := Cp.label(m.T("DAILY"), 11.0, ink, done)
	Cp.place(title, tx, d(7.0), tw, d(17.0))
	Cp.fit(title, tw)
	content.add_child(title)
	var sub := Cp.label("", 9.5, Cp.MINT if done else Color("7a4500"), false)
	sub.set_meta("maxw", tw)
	Cp.place(sub, tx, d(24.0), tw, d(16.0))
	content.add_child(sub)
	if done:
		soft_sub = sub
	else:
		gold_sub = sub
	var arrow := Cp.icon("arrow_r", 16.0, Cp.LILAC if done else ink)
	arrow.position = Vector2(d(right_w - 12.0 - 16.0), (content.size.y - d(16.0)) * 0.5)
	content.add_child(arrow)
	add_child(btn)
	buttons.append(btn)
	reg(btn, 5)
	return btn


func build_daily(right_w: float) -> void:
	daily_gold = make_daily(false, right_w)
	daily_soft = make_daily(true, right_w)


func make_tile(key: String, text: String, icon_name: String, accent: Color, medal: float, lift: float, x: float, dock_h: float, index: int) -> Control:
	var lab_h := 14.0
	var tile := Control.new()
	tile.size = Vector2(d(medal), d(medal + 3.0 + lab_h))
	tile.position = Vector2(x, d(dock_h - lift - lab_h - 3.0 - medal))
	tile.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var btn := Cp.face_button(Vector2(d(medal), d(medal)), d(medal) * 0.5, "soft", d(4.0))
	var content: Control = btn.get_meta("content")
	var ic := Cp.icon(icon_name, medal * 0.46, accent)
	ic.position = Vector2((content.size.x - ic.size.x) * 0.5, (content.size.y - ic.size.y) * 0.5)
	content.add_child(ic)
	btn.pressed.connect(emit_action.bind(key))
	tile.add_child(btn)
	buttons.append(btn)
	var lab := Cp.label(text, 10.0, Color.WHITE)
	Cp.place(lab, -d(10.0), d(medal + 3.0), d(medal + 20.0), d(lab_h), HORIZONTAL_ALIGNMENT_CENTER)
	Cp.fit(lab, d(medal + 20.0))
	tile.add_child(lab)
	if key == "awards" or key == "spin":
		var dot := Cp.badge()
		dot.position = Vector2(d(medal) - d(15.0) + d(2.0), d(2.0))
		btn.add_child(dot)
		tile_badges[key] = dot
		pulse_nodes.append(dot)
	return tile


func build_dock(cta_w: float, medal: float) -> void:
	var row_w := 28.0 + medal * 4.0 + cta_w * 2.0 + 10.0 * 5.0
	var dock_h := 16.0 + medal + 3.0 + 14.0
	var dock := Control.new()
	dock.size = Vector2(d(row_w), d(dock_h))
	dock.position = Vector2((size.x - d(row_w)) * 0.5, size.y - d(PAD_Y) - d(dock_h))
	dock.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(dock)
	dock.add_child(Cp.rainbow_arc(dock.size))
	var x := d(14.0)
	var gap := d(10.0)

	var shop := make_tile("shop", m.T("SHOP"), "bag", Cp.PINK, medal, 0.0, x, dock_h, 1)
	dock.add_child(shop)
	reg(shop, 1)
	x += d(medal) + gap

	var awards := make_tile("awards", m.T("AWARDS"), "medal", Cp.SUN, medal, 16.0, x, dock_h, 2)
	dock.add_child(awards)
	reg(awards, 2)
	x += d(medal) + gap

	var adv := Cp.g_button(m.T("ADVENTURE"), d(cta_w), 60.0, "primary", 17.0, {"lead": "play", "lead_dp": 20.0, "sheen": true})
	adv.position = Vector2(x, d(dock_h - 16.0 - 60.0))
	adv.pressed.connect(emit_action.bind("adv"))
	dock.add_child(adv)
	buttons.append(adv)
	reg(adv, 3, 30.0)
	x += d(cta_w) + gap

	var endless := Cp.g_button(m.T("ENDLESS"), d(cta_w), 60.0, "mint", 17.0, {"lead": "loop", "lead_dp": 22.0, "lead_tint": Color("053b3a")})
	endless.position = Vector2(x, d(dock_h - 16.0 - 60.0))
	endless.pressed.connect(emit_action.bind("end"))
	dock.add_child(endless)
	buttons.append(endless)
	reg(endless, 4, 30.0)
	x += d(cta_w) + gap

	var board := make_tile("board", m.T("BOARD"), "board", Cp.CYAN, medal, 16.0, x, dock_h, 5)
	dock.add_child(board)
	reg(board, 5)
	x += d(medal) + gap

	var spin := make_tile("spin", m.T("SPIN"), "spin", Cp.MINT, medal, 0.0, x, dock_h, 6)
	dock.add_child(spin)
	reg(spin, 6)


func set_coins(v: float) -> void:
	Cp.set_text(coin_label, str(int(v)))
	Cp.pill_update(coin_pill)


func refresh(animate: bool = true) -> void:
	if level_label == null:
		return
	m.ensure_day()
	var lv: int = m.player_level()
	var need: int = m.xp_need(lv)
	var cur: int = m.xp_into()
	level_label.text = str(lv)
	xp_label.text = m.T("%d/%d XP") % [cur, need]
	Cp.bar_set(xp_bar, float(cur) / float(maxi(need, 1)), animate)

	var ms: Array = m.dstate["m"]
	var done := 0
	for e in ms:
		if int(e["got"]) >= int(e["target"]):
			done += 1
	var total := ms.size()
	var streak: int = m.streak_now()
	Cp.set_text(missions_sub, "%d/%d  -  " % [done, total] + String(m.T("Day %d streak")) % streak)
	Cp.fit(missions_sub, float(missions_sub.get_meta("maxw")))
	Cp.tint(missions_check, Cp.MINT if done == total and total > 0 else Cp.SUN)
	missions_badge.visible = done < total

	Cp.set_text(best_label, String(m.T("BEST %d")) % int(m.stat_value("best")))

	var zn: String = m.ZONES[m.zone]["name"]
	Cp.set_text(zone_label, m.T(zn))
	Cp.fit(zone_label, float(zone_label.get_meta("maxw")))

	var star_max: int = m.ZONES.size() * m.LEVELS_PER_ZONE * 3
	Cp.set_text(star_label, "%d/%d" % [int(m.total_stars()), star_max])
	Cp.pill_update(star_pill)
	Cp.set_text(heart_label, "x%d" % int(m.start_lives()))
	Cp.pill_update(heart_pill)

	var target := float(m.bank)
	if coin_tw != null and coin_tw.is_valid():
		coin_tw.kill()
	if shown_coins < 0.0 or not animate or not is_visible_in_tree() or is_equal_approx(target, shown_coins):
		shown_coins = target
		set_coins(target)
	else:
		var from := shown_coins
		coin_tw = create_tween()
		var step: Callable = func(k: float) -> void:
			shown_coins = lerpf(from, target, Cp.fast_out_slow_in(k))
			set_coins(shown_coins)
		coin_tw.tween_method(step, 0.0, 1.0, 0.7)

	var sound_on: bool = bool(m.snd_on) or bool(m.mus_on)
	Cp.set_icon(sound_btn.get_meta("icon"), "sound_on" if sound_on else "sound_off")

	var chal_done: bool = bool(m.dstate["chal"])
	daily_gold.visible = not chal_done
	daily_soft.visible = chal_done
	var dz: String = m.ZONES[m.daily_zone()]["name"]
	Cp.set_text(gold_sub, m.T(dz))
	Cp.fit(gold_sub, float(gold_sub.get_meta("maxw")))
	Cp.set_text(soft_sub, m.T("DONE"))
	Cp.fit(soft_sub, float(soft_sub.get_meta("maxw")))

	for key in tile_badges:
		var dot: Control = tile_badges[key]
		dot.visible = bool(m.attention(String(key)))


func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	clock += delta
	var k := 0.85 + 0.35 * Cp.reverse_wave(clock, 0.7)
	for n in pulse_nodes:
		if is_instance_valid(n) and n.visible:
			n.scale = Vector2(k, k)
