import os
import wave

import numpy as np

RATE = 22050
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "audio"))


def save(name, data):
    data = np.clip(data, -1.0, 1.0)
    pcm = (data * 32767).astype(np.int16)
    with wave.open(os.path.join(OUT, name), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())


def t_axis(sec):
    return np.arange(int(RATE * sec)) / RATE


def env(n, attack=0.005, release=0.6):
    e = np.ones(n)
    a = max(1, int(RATE * attack))
    e[:a] = np.linspace(0, 1, a)
    r = max(1, int(n * release))
    e[-r:] = np.linspace(1, 0, r)
    return e


def tone(freq, sec, kind="sine", vol=0.5, release=0.6):
    t = t_axis(sec)
    ph = 2 * np.pi * freq * t
    if kind == "square":
        w = np.sign(np.sin(ph))
    elif kind == "tri":
        w = 2 * np.abs(2 * ((freq * t) % 1.0) - 1) - 1
    else:
        w = np.sin(ph)
    return w * env(len(t), release=release) * vol


def sweep(f0, f1, sec, kind="sine", vol=0.5):
    t = t_axis(sec)
    f = np.linspace(f0, f1, len(t))
    ph = 2 * np.pi * np.cumsum(f) / RATE
    w = np.sign(np.sin(ph)) if kind == "square" else np.sin(ph)
    return w * env(len(t), release=0.7) * vol


def seq(notes, sec, kind="sine", vol=0.5, gap=0.0):
    parts = []
    for f in notes:
        parts.append(tone(f, sec, kind, vol))
        if gap > 0:
            parts.append(np.zeros(int(RATE * gap)))
    return np.concatenate(parts)


def make_sfx():
    save("jump.wav", sweep(320, 760, 0.16, "square", 0.28))
    save("coin.wav", np.concatenate([tone(988, 0.06, "square", 0.25), tone(1319, 0.14, "square", 0.25)]))
    rng = np.random.default_rng(3)
    n = int(RATE * 0.32)
    noise = rng.uniform(-1, 1, n) * env(n, release=0.95) * 0.5
    low = sweep(220, 70, 0.32, "sine", 0.6)
    save("hit.wav", noise + low)
    save("power.wav", seq([523, 659, 784, 1047], 0.08, "square", 0.25))
    save("win.wav", seq([523, 659, 784, 1047, 784, 1047], 0.14, "tri", 0.5))
    save("lose.wav", seq([392, 330, 262, 196], 0.18, "tri", 0.5))
    save("click.wav", tone(740, 0.04, "square", 0.2))
    save("spin.wav", tone(1200, 0.03, "square", 0.18))
    save("claim.wav", seq([660, 880, 1320], 0.09, "square", 0.25))


def make_music():
    bpm = 118
    beat = 60.0 / bpm
    notes = {
        "C": 261.63, "D": 293.66, "E": 329.63, "F": 349.23, "G": 392.0, "A": 440.0, "B": 493.88,
    }
    prog = [
        ("C", ["C", "E", "G"]),
        ("A", ["A", "C", "E"]),
        ("F", ["F", "A", "C"]),
        ("G", ["G", "B", "D"]),
    ]
    total = int(RATE * beat * 4 * 8)
    mix = np.zeros(total)

    def put(buf, data, start):
        end = min(len(buf), start + len(data))
        buf[start:end] += data[: end - start]

    lead_scale = [523.25, 587.33, 659.25, 783.99, 880.0, 783.99, 659.25, 587.33]
    for bar in range(8):
        root, chord = prog[bar % 4]
        base = int(RATE * beat * 4 * bar)
        bass_f = notes[root] / 2
        for b in range(4):
            put(mix, tone(bass_f, beat * 0.9, "tri", 0.32), base + int(RATE * beat * b))
        for b in range(8):
            f = notes[chord[b % 3]] * 2
            put(mix, tone(f, beat * 0.45, "square", 0.07, release=0.8), base + int(RATE * beat * 0.5 * b))
        for b in range(8):
            idx = (bar * 3 + b * 2) % len(lead_scale)
            if (b + bar) % 3 != 2:
                put(mix, tone(lead_scale[idx], beat * 0.4, "tri", 0.16, release=0.7), base + int(RATE * beat * 0.5 * b))
    mix = mix / max(1.0, np.max(np.abs(mix)) / 0.8)
    save("music.wav", mix * 0.9)


def main():
    os.makedirs(OUT, exist_ok=True)
    make_sfx()
    make_music()


if __name__ == "__main__":
    main()
