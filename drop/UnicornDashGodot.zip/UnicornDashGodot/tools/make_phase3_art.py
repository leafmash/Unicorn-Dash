import math
import os

from PIL import ImageFont

from make_phase2_art import D, SS, OUT

FONT = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"


def badge(d, glow_col):
    d.glow(6, lambda t: t.ell(64, 64, 58, 58, fill=glow_col))
    d.ell(64, 64, 56, 56, fill=(40, 20, 100, 170), outline=(233, 210, 255, 255), width=4)


def make_shield():
    d = D(128, 128)
    badge(d, (110, 190, 255, 140))
    p = [(64, 24), (96, 34), (94, 68), (64, 100), (34, 68), (32, 34)]
    d.grad_poly(p, (120, 200, 255), (50, 110, 230))
    d.poly(p, outline=(255, 255, 255, 255), width=4)
    d.poly([(64, 38), (80, 44), (78, 66), (64, 82), (50, 66), (48, 44)], fill=(255, 255, 255, 70))
    d.save("pu_shield.png")


def make_magnet():
    d = D(128, 128)
    badge(d, (255, 110, 130, 140))
    pts = []
    for i in range(0, 181, 6):
        a = math.radians(180 + i)
        pts.append((64 + math.cos(a) * 24, 56 + math.sin(a) * 24))
    d.line([(40, 92)] + [(40, 56)] + pts + [(88, 56), (88, 92)], fill=(236, 70, 100, 255), width=18)
    d.rrect(31, 82, 49, 98, 3, fill=(230, 234, 245, 255), outline=(255, 255, 255, 255), width=2)
    d.rrect(79, 82, 97, 98, 3, fill=(230, 234, 245, 255), outline=(255, 255, 255, 255), width=2)
    d.save("pu_magnet.png")


def make_x2():
    d = D(128, 128)
    badge(d, (255, 214, 74, 150))
    d.ell(64, 64, 42, 42, fill=(255, 210, 70, 255), outline=(255, 247, 205, 255), width=4)
    d.ell(64, 64, 33, 33, outline=(230, 160, 30, 255), width=3)
    img = d.im.resize((128, 128), 1)
    img.save(os.path.join(OUT, "pu_x2.png"))
    from PIL import Image, ImageDraw

    base = Image.open(os.path.join(OUT, "pu_x2.png")).convert("RGBA")
    dr = ImageDraw.Draw(base)
    font = ImageFont.truetype(FONT, 44)
    box = dr.textbbox((0, 0), "x2", font=font)
    tw = box[2] - box[0]
    th = box[3] - box[1]
    dr.text((64 - tw / 2 - box[0], 62 - th / 2 - box[1]), "x2", font=font, fill=(90, 44, 8, 255))
    base.save(os.path.join(OUT, "pu_x2.png"))


def make_slow():
    d = D(128, 128)
    badge(d, (120, 230, 220, 140))
    d.ell(64, 64, 38, 38, fill=(245, 252, 255, 255), outline=(80, 200, 220, 255), width=5)
    d.line([(64, 64), (64, 40)], fill=(60, 40, 120, 255), width=5)
    d.line([(64, 64), (82, 72)], fill=(60, 40, 120, 255), width=5)
    d.ell(64, 64, 4, 4, fill=(60, 40, 120, 255))
    for i in range(12):
        a = i * math.pi / 6
        d.line([(64 + math.cos(a) * 32, 64 + math.sin(a) * 32), (64 + math.cos(a) * 36, 64 + math.sin(a) * 36)], fill=(120, 150, 190, 255), width=2)
    d.save("pu_slow.png")


def heart_pts(cx, cy, s):
    p = []
    for i in range(0, 64):
        t = i / 64.0 * math.pi * 2
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        p.append((cx + x * s, cy + y * s))
    return p


def make_heart():
    d = D(128, 128)
    badge(d, (255, 110, 170, 140))
    p = heart_pts(64, 62, 2.2)
    d.grad_poly(p, (255, 140, 190), (230, 50, 110))
    d.poly(p, outline=(255, 255, 255, 255), width=4)
    d.ell(50, 48, 8, 5, fill=(255, 255, 255, 140))
    d.save("pu_heart.png")


def make_shield_fx():
    d = D(384, 384)
    d.glow(12, lambda t: t.ell(192, 192, 130, 130, fill=(120, 200, 255, 90)))
    d.ell(192, 192, 126, 126, fill=(150, 215, 255, 55), outline=(200, 236, 255, 230), width=6)
    d.line([(112, 150), (126, 120), (150, 98)], fill=(255, 255, 255, 200), width=7)
    d.save("fx_shield.png")


def make_bunny():
    d = D(128, 128)
    ol = (150, 130, 205, 255)
    d.ell(50, 24, 9, 26, fill=(255, 255, 255, 255), outline=ol, width=3)
    d.ell(78, 24, 9, 26, fill=(255, 255, 255, 255), outline=ol, width=3)
    d.ell(50, 26, 4, 17, fill=(255, 190, 215, 255))
    d.ell(78, 26, 4, 17, fill=(255, 190, 215, 255))
    d.ell(64, 92, 30, 24, fill=(255, 255, 255, 255), outline=ol, width=3)
    d.ell(64, 60, 28, 25, fill=(255, 255, 255, 255), outline=ol, width=3)
    d.ell(53, 58, 4, 5, fill=(60, 36, 110, 255))
    d.ell(75, 58, 4, 5, fill=(60, 36, 110, 255))
    d.ell(64, 67, 4, 3, fill=(255, 140, 180, 255))
    d.ell(46, 68, 6, 4, fill=(255, 190, 215, 200))
    d.ell(82, 68, 6, 4, fill=(255, 190, 215, 200))
    d.ell(98, 98, 9, 9, fill=(255, 255, 255, 255), outline=ol, width=3)
    d.save("pet_0.png")


def make_fox():
    d = D(128, 128)
    ol = (150, 70, 20, 255)
    d.poly([(84, 98), (120, 70), (122, 108), (96, 116)], fill=(255, 150, 60, 255), outline=ol, width=3)
    d.poly([(110, 80), (122, 70), (122, 90)], fill=(255, 255, 255, 255))
    d.ell(60, 94, 30, 22, fill=(255, 150, 60, 255), outline=ol, width=3)
    d.poly([(36, 40), (42, 12), (62, 34)], fill=(255, 150, 60, 255), outline=ol, width=3)
    d.poly([(92, 40), (86, 12), (66, 34)], fill=(255, 150, 60, 255), outline=ol, width=3)
    d.ell(64, 56, 30, 25, fill=(255, 150, 60, 255), outline=ol, width=3)
    d.poly([(40, 62), (64, 78), (88, 62), (64, 58)], fill=(255, 255, 255, 255))
    d.ell(52, 54, 4, 5, fill=(60, 30, 20, 255))
    d.ell(76, 54, 4, 5, fill=(60, 30, 20, 255))
    d.ell(64, 68, 4, 3, fill=(60, 30, 20, 255))
    d.save("pet_1.png")


def make_owl():
    d = D(128, 128)
    ol = (90, 56, 30, 255)
    d.poly([(34, 40), (38, 14), (54, 30)], fill=(150, 100, 60, 255), outline=ol, width=3)
    d.poly([(94, 40), (90, 14), (74, 30)], fill=(150, 100, 60, 255), outline=ol, width=3)
    d.ell(64, 68, 38, 42, fill=(160, 110, 66, 255), outline=ol, width=3)
    d.ell(64, 80, 22, 26, fill=(235, 210, 170, 255))
    d.ell(48, 56, 15, 15, fill=(255, 255, 255, 255), outline=ol, width=3)
    d.ell(80, 56, 15, 15, fill=(255, 255, 255, 255), outline=ol, width=3)
    d.ell(50, 57, 7, 7, fill=(40, 24, 60, 255))
    d.ell(78, 57, 7, 7, fill=(40, 24, 60, 255))
    d.poly([(58, 66), (70, 66), (64, 78)], fill=(255, 190, 60, 255), outline=ol, width=2)
    d.ell(26, 76, 10, 24, fill=(130, 86, 50, 255), outline=ol, width=3)
    d.ell(102, 76, 10, 24, fill=(130, 86, 50, 255), outline=ol, width=3)
    d.save("pet_2.png")


def make_dragon():
    d = D(128, 128)
    ol = (30, 90, 60, 255)
    d.poly([(70, 70), (118, 30), (108, 80), (84, 96)], fill=(170, 120, 230, 255), outline=(90, 56, 150, 255), width=3)
    d.poly([(30, 100), (6, 112), (20, 90)], fill=(90, 210, 140, 255), outline=ol, width=3)
    d.ell(60, 90, 30, 24, fill=(90, 210, 140, 255), outline=ol, width=3)
    d.ell(60, 98, 16, 14, fill=(255, 235, 150, 255))
    d.poly([(44, 36), (40, 10), (56, 28)], fill=(255, 235, 150, 255), outline=ol, width=3)
    d.poly([(80, 36), (84, 10), (68, 28)], fill=(255, 235, 150, 255), outline=ol, width=3)
    d.ell(62, 54, 28, 24, fill=(90, 210, 140, 255), outline=ol, width=3)
    d.ell(50, 52, 6, 7, fill=(255, 255, 255, 255))
    d.ell(74, 52, 6, 7, fill=(255, 255, 255, 255))
    d.ell(51, 53, 3, 4, fill=(40, 24, 60, 255))
    d.ell(75, 53, 3, 4, fill=(40, 24, 60, 255))
    d.ell(56, 66, 2, 2, fill=(30, 90, 60, 255))
    d.ell(68, 66, 2, 2, fill=(30, 90, 60, 255))
    d.save("pet_3.png")


def main():
    make_shield()
    make_magnet()
    make_x2()
    make_slow()
    make_heart()
    make_shield_fx()
    make_bunny()
    make_fox()
    make_owl()
    make_dragon()


if __name__ == "__main__":
    main()
