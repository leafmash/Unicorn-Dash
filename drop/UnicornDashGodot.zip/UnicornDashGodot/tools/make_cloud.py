import os
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = 3.2
S = 4
W, H = int(80 * K), int(44 * K)
im = Image.new("L", (W * S, H * S), 0)
d = ImageDraw.Draw(im)
for cx, cy, r in [(14, 28, 14), (30, 22, 18), (48, 28, 14)]:
    d.ellipse([(cx - r) * K * S, (cy - r) * K * S, (cx + r) * K * S, (cy + r) * K * S], fill=255)
im = im.resize((W, H), Image.LANCZOS)
out = Image.new("RGBA", (W, H), (255, 255, 255, 0))
out.putalpha(im)
out.save(os.path.join(ROOT, "art", "cloud_k.png"), optimize=True)
