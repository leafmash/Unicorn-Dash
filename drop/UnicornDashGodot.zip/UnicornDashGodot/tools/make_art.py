import math
import random
from PIL import Image, ImageDraw, ImageFilter

S = 3
OUT = (0x3A, 0x24, 0x68, 255)
RAINBOW = [(255, 95, 141), (255, 176, 95), (255, 224, 102), (111, 227, 165), (95, 184, 255), (165, 107, 255)]


def hexc(h, a=255):
    return ((h >> 16) & 255, (h >> 8) & 255, h & 255, a)


def sc(p):
    return (p[0] * S, p[1] * S)


def thick(d, pts, w, col):
    sp = [sc(p) for p in pts]
    d.line(sp, fill=col, width=int(w * S), joint="curve")
    r = w * S / 2
    for p in sp:
        d.ellipse((p[0] - r, p[1] - r, p[0] + r, p[1] + r), fill=col)


def ell(d, cx, cy, rx, ry, col):
    d.ellipse(((cx - rx) * S, (cy - ry) * S, (cx + rx) * S, (cy + ry) * S), fill=col)


def poly(d, pts, col):
    d.polygon([sc(p) for p in pts], fill=col)


def bez(p0, p1, p2, n=24):
    out = []
    for i in range(n + 1):
        t = i / n
        a = (1 - t) ** 2
        b = 2 * (1 - t) * t
        c = t * t
        out.append((a * p0[0] + b * p1[0] + c * p2[0], a * p0[1] + b * p1[1] + c * p2[1]))
    return out


def offset_path(pts, dist):
    out = []
    for i, p in enumerate(pts):
        a = pts[max(0, i - 1)]
        b = pts[min(len(pts) - 1, i + 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        l = math.hypot(dx, dy) or 1.0
        out.append((p[0] - dy / l * dist, p[1] + dx / l * dist))
    return out


def with_outline(layer, width):
    a = layer.split()[3]
    k = int(width * S) * 2 + 1
    grown = a.filter(ImageFilter.MaxFilter(k))
    base = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    dark = Image.new("RGBA", layer.size, OUT)
    base.paste(dark, (0, 0), grown)
    base.alpha_composite(layer)
    return base


def finish(img, size):
    return img.resize(size, Image.LANCZOS)


def leg(d, piv, phase, col, hoof, jump=None):
    if jump is None:
        th = 0.75 * math.sin(phase)
        bend = 0.95 * max(0.0, math.cos(phase))
    else:
        th, bend = jump
    lu, ll = 56, 58
    knee = (piv[0] + lu * math.sin(th), piv[1] + lu * math.cos(th))
    la = th - bend
    foot = (knee[0] + ll * math.sin(la), knee[1] + ll * math.cos(la))
    thick(d, [piv, knee, foot], 19, col)
    ell(d, foot[0] + 3, foot[1] + 1, 11, 8, hoof)


def unicorn_frame(phase, jump=False):
    W = 384
    L = Image.new("RGBA", (W * S, W * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(L)
    far = hexc(0xBFB1E8)
    near = hexc(0xE4DAFB)
    body = hexc(0xF6F0FF)
    hoof = hexc(0x7A5BC0)
    if jump:
        leg(d, (252, 232), 0, far, hoof, (1.0, 0.25))
        leg(d, (128, 230), 0, far, hoof, (-1.0, -0.15))
    else:
        leg(d, (252, 232), phase + 0.7, far, hoof)
        leg(d, (128, 230), phase + math.pi + 0.7, far, hoof)
    wob = math.sin(phase) * 8
    tail = bez((108, 186), (60, 160 + wob), (38, 232 + wob * 0.5))
    tail = [(p[0] - 8 * math.sin(i * 0.35 + phase), p[1]) for i, p in enumerate(tail)]
    for k, c in enumerate(RAINBOW):
        thick(d, offset_path(tail, (k - 2.5) * 8.5), 9.5, c + (255,))
    ell(d, 190, 200, 92, 54, body)
    poly(d, [(232, 168), (276, 96), (322, 128), (276, 238)], body)
    ell(d, 304, 124, 42, 31, body)
    ell(d, 334, 132, 22, 18, hexc(0xFFFFFF))
    poly(d, [(272, 100), (280, 66), (302, 96)], body)
    poly(d, [(296, 98), (318, 98), (342, 18)], hexc(0xFFD76A))
    for t in (0.35, 0.6, 0.82):
        x0 = 296 + (342 - 296) * t
        y0 = 98 + (18 - 98) * t
        x1 = 318 + (342 - 318) * t
        thick(d, [(x0, y0), (x1, y0 - 3)], 3, hexc(0xE9A93A))
    mane = bez((296, 92), (254, 90), (206, 188), 28)
    for k, c in enumerate(RAINBOW):
        thick(d, offset_path(mane, (k - 2.5) * 8.5 * -1), 9.5, c + (255,))
    if jump:
        leg(d, (230, 234), 0, near, hoof, (0.9, 0.45))
        leg(d, (108, 232), 0, near, hoof, (-0.8, -0.3))
    else:
        leg(d, (230, 234), phase, near, hoof)
        leg(d, (108, 232), phase + math.pi, near, hoof)
    L = with_outline(L, 5)
    d = ImageDraw.Draw(L)
    ell(d, 314, 122, 6, 7, OUT)
    ell(d, 316, 120, 2.4, 2.4, (255, 255, 255, 255))
    ell(d, 326, 140, 8, 5, hexc(0xFF9EC4, 170))
    ell(d, 344, 133, 2.2, 2.6, hexc(0x7A5BC0))
    return finish(L, (W, W))


def make_unicorn():
    sheet = Image.new("RGBA", (384 * 5, 384), (0, 0, 0, 0))
    for i in range(4):
        sheet.alpha_composite(unicorn_frame(i * math.pi / 2), (i * 384, 0))
    sheet.alpha_composite(unicorn_frame(0, True), (4 * 384, 0))
    sheet.save("art/unicorn.png")
    ic = Image.new("RGBA", (192, 192), hexc(0x4B2A8C))
    u = unicorn_frame(0.4).resize((176, 176), Image.LANCZOS)
    ic.alpha_composite(u, (8, 10))
    ic.save("icon.png")


def periodic_curve(W, base, comps):
    pts = []
    for x in range(0, W + 1, 4):
        y = base
        for amp, freq, ph in comps:
            y += amp * math.sin(2 * math.pi * freq * x / W + ph)
        pts.append((x, y))
    return pts


def fill_under(W, H, pts, top, bottom, alpha):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    grad = Image.new("RGBA", (W, H))
    gd = ImageDraw.Draw(grad)
    for y in range(H):
        t = y / max(1, H - 1)
        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3)) + (alpha,)
        gd.line([(0, y), (W, y)], fill=c)
    mask = Image.new("L", (W * 2, H * 2), 0)
    md = ImageDraw.Draw(mask)
    md.polygon([(p[0] * 2, p[1] * 2) for p in pts] + [(W * 2, H * 2), (0, H * 2)], fill=255)
    mask = mask.resize((W, H), Image.LANCZOS)
    img.paste(grad, (0, 0), mask)
    return img


def make_layers():
    W = 1280
    far = fill_under(W, 330, periodic_curve(W, 150, [(70, 2, 0.4), (34, 5, 1.7), (14, 9, 0.2)]), hexc(0x9A7BD9)[:3], hexc(0xC79BE2)[:3], 190)
    far.save("art/far.png")
    mid = fill_under(W, 250, periodic_curve(W, 110, [(46, 3, 1.1), (22, 7, 2.3), (9, 13, 0.7)]), hexc(0xB77FD3)[:3], hexc(0xE7A4D8)[:3], 215)
    mid.save("art/mid.png")
    near = Image.new("RGBA", (W, 190), (0, 0, 0, 0))
    nd = ImageDraw.Draw(near)
    rnd = random.Random(5)
    for i in range(14):
        cx = i * W / 14 + rnd.uniform(-20, 20)
        r = rnd.uniform(46, 78)
        for off in (-W, 0, W):
            nd.ellipse((cx + off - r, 190 - r * 1.1, cx + off + r, 190 + r * 0.9), fill=hexc(0x6A4FA3, 235))
            nd.ellipse((cx + off - r * 0.55, 190 - r * 1.05, cx + off + r * 0.1, 190 - r * 0.45), fill=hexc(0x8566C4, 140))
    near.save("art/near.png")
    H = 116
    edge = periodic_curve(W, 12, [(3, 16, 0.0), (2, 31, 1.0)])
    body = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(body)
    for y in range(H):
        t = y / (H - 1)
        c = (int(79 + (47 - 79) * t), int(163 + (107 - 163) * t), int(131 + (99 - 131) * t), 255)
        bd.line([(0, y), (W, y)], fill=c)
    rnd = random.Random(9)
    for i in range(40):
        x = rnd.uniform(0, W)
        y = rnd.uniform(40, 108)
        r = rnd.uniform(2, 5)
        for off in (-W, 0, W):
            bd.ellipse((x + off - r, y - r, x + off + r, y + r), fill=(255, 255, 255, 40))
    grass = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(grass).rectangle((0, 0, W, 26), fill=hexc(0x8BE0A8))
    shape = Image.new("L", (W * 2, H * 2), 0)
    ImageDraw.Draw(shape).polygon([(p[0] * 2, p[1] * 2) for p in edge] + [(W * 2, H * 2), (0, H * 2)], fill=255)
    shape = shape.resize((W, H), Image.LANCZOS)
    cut = Image.new("L", (W * 2, H * 2), 0)
    ImageDraw.Draw(cut).polygon([(p[0] * 2, p[1] * 2 + 20) for p in edge] + [(W * 2, H * 2), (0, H * 2)], fill=255)
    cut = cut.resize((W, H), Image.LANCZOS)
    ground = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ground.paste(grass, (0, 0), shape)
    ground.paste(body, (0, 0), cut)
    ground.save("art/ground.png")
    rb = Image.new("RGBA", (W, 440), (0, 0, 0, 0))
    rd = ImageDraw.Draw(rb)
    cx, cy = W / 2, 440 + 60
    for i, c in enumerate(RAINBOW):
        r = 600 - i * 26
        rd.ellipse((cx - r, cy - r, cx + r, cy + r), outline=c + (110,), width=26)
    rb = rb.filter(ImageFilter.GaussianBlur(1.5))
    rb.save("art/rainbow.png")


def make_clouds():
    rnd = random.Random(2)
    for n in range(3):
        img = Image.new("RGBA", (320, 160), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        for i in range(6):
            cx = 70 + i * 36 + rnd.uniform(-6, 6)
            r = rnd.uniform(28, 48)
            d.ellipse((cx - r, 110 - r, cx + r, 110 + r * 0.4), fill=(255, 255, 255, 235))
        d.rectangle((40, 108, 280, 130), fill=(255, 255, 255, 235))
        img = img.filter(ImageFilter.GaussianBlur(2))
        img.save(f"art/cloud{n}.png")


def make_sun():
    img = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
    px = img.load()
    for y in range(512):
        for x in range(512):
            r = math.hypot(x - 256, y - 256) / 256
            if r < 1:
                a = int(255 * (1 - r) ** 2.2 * 0.8)
                if r < 0.3:
                    a = 255
                px[x, y] = (255, 240, 190, a)
    img.save("art/sun.png")


def obstacle(kind):
    L = Image.new("RGBA", (256 * S, 256 * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(L)
    if kind == "rock":
        poly(d, [(40, 250), (30, 190), (62, 140), (110, 118), (168, 126), (214, 170), (226, 250)], hexc(0x8F86B8))
        poly(d, [(70, 160), (110, 130), (150, 136), (120, 170), (84, 200)], hexc(0xB5ACD8))
        poly(d, [(150, 190), (210, 180), (222, 250), (140, 250)], hexc(0x6F6698))
    elif kind == "crystal":
        poly(d, [(70, 250), (60, 150), (92, 80), (124, 150), (126, 250)], hexc(0xFF8FC7))
        poly(d, [(110, 250), (122, 120), (150, 40), (182, 120), (178, 250)], hexc(0xFFB0DA))
        poly(d, [(160, 250), (170, 170), (200, 120), (222, 175), (216, 250)], hexc(0xC893FF))
        poly(d, [(150, 60), (150, 40), (182, 120), (166, 120)], hexc(0xFFFFFF, 150))
    else:
        ell(d, 128, 190, 100, 60, hexc(0x4F8F6A))
        for i in range(9):
            a = math.pi * (0.1 + 0.8 * i / 8)
            bx = 128 - math.cos(a) * 82
            by = 215 - math.sin(a) * 40
            tx = 128 - math.cos(a) * 112
            ty = 215 - math.sin(a) * 130
            poly(d, [(bx - 10, by), (tx, ty), (bx + 10, by)], hexc(0x3F7A58))
        for bx, by in ((90, 180), (140, 160), (170, 196)):
            ell(d, bx, by, 9, 9, hexc(0xFF5F8D))
    L = with_outline(L, 5)
    finish(L, (256, 256)).save(f"art/{kind}.png")


def make_small():
    c = Image.new("RGBA", (128 * S, 128 * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(c)
    ell(d, 64, 64, 54, 54, OUT)
    ell(d, 64, 64, 48, 48, hexc(0xFFC93C))
    ell(d, 64, 64, 36, 36, hexc(0xFFE27A))
    star = []
    for i in range(10):
        r = 22 if i % 2 == 0 else 10
        a = -math.pi / 2 + i * math.pi / 5
        star.append((64 + r * math.cos(a), 66 + r * math.sin(a)))
    poly(d, star, hexc(0xFFB020))
    finish(c, (128, 128)).save("art/coin.png")
    s = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    px = s.load()
    for y in range(64):
        for x in range(64):
            dx, dy = abs(x - 32) / 32, abs(y - 32) / 32
            v = max(0.0, 1 - (dx + dy) ** 0.5) ** 2 + max(0.0, 1 - math.hypot(dx, dy) * 2.2)
            px[x, y] = (255, 255, 255, int(255 * min(1.0, v)))
    s.save("art/spark.png")


if __name__ == "__main__":
    make_unicorn()
    make_layers()
    make_clouds()
    make_sun()
    for k in ("rock", "crystal", "bush"):
        obstacle(k)
    make_small()
