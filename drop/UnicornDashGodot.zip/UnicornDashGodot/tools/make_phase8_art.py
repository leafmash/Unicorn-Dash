import math
import os
import numpy as np
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "art")
FR = 192
FRAMES = 8
SS = 4
UNIT = 2.6
OX = 96.0
OY = 96.0


def hexc(v, a=255):
    return ((v >> 16) & 255, (v >> 8) & 255, v & 255, a)


def hsl(h, s, l, a=255):
    h = (h % 360.0) / 360.0
    s /= 100.0
    l /= 100.0
    if s == 0:
        r = g = b = l
    else:
        q = l * (1 + s) if l < 0.5 else l + s - l * s
        p = 2 * l - q

        def f(t):
            t %= 1.0
            if t < 1 / 6:
                return p + (q - p) * 6 * t
            if t < 0.5:
                return q
            if t < 2 / 3:
                return p + (q - p) * (2 / 3 - t) * 6
            return p
        r, g, b = f(h + 1 / 3), f(h), f(h - 1 / 3)
    return (int(round(r * 255)), int(round(g * 255)), int(round(b * 255)), a)


class Mat:
    def __init__(self, m=None):
        self.m = m if m is not None else (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)

    def mul(self, o):
        a, b, c, d, e, f = self.m
        A, B, C, D, E, F = o
        return Mat((a * A + c * B, b * A + d * B, a * C + c * D, b * C + d * D, a * E + c * F + e, b * E + d * F + f))

    def translate(self, x, y):
        return self.mul((1, 0, 0, 1, x, y))

    def rotate(self, r):
        c, s = math.cos(r), math.sin(r)
        return self.mul((c, s, -s, c, 0, 0))

    def scale(self, sx, sy):
        return self.mul((sx, 0, 0, sy, 0, 0))

    def apply(self, x, y):
        a, b, c, d, e, f = self.m
        return (a * x + c * y + e, b * x + d * y + f)


class Canvas:
    def __init__(self):
        self.img = Image.new("RGBA", (FR * SS, FR * SS), (0, 0, 0, 0))
        self.base = Mat().translate(OX * SS, OY * SS).scale(UNIT * SS, UNIT * SS)
        self.m = self.base

    def sub(self, m):
        self.m = m

    def px(self, pts):
        return [self.m.apply(x, y) for x, y in pts]

    def layer(self):
        return Image.new("RGBA", self.img.size, (0, 0, 0, 0))

    def commit(self, lay):
        self.img.alpha_composite(lay)

    def poly(self, pts, fill=None, stroke=None, width=0.0, closed=True):
        lay = self.layer()
        d = ImageDraw.Draw(lay)
        p = self.px(pts)
        if fill is not None:
            d.polygon(p, fill=fill)
        self.commit(lay)
        if stroke is not None:
            self.line(pts + ([pts[0]] if closed else []), stroke, width)

    def line(self, pts, col, width):
        lay = self.layer()
        d = ImageDraw.Draw(lay)
        p = self.px(pts)
        k = UNIT * SS
        w = max(1, int(round(width * k)))
        d.line(p, fill=col, width=w, joint="curve")
        r = w / 2.0
        for x, y in (p[0], p[-1]):
            d.ellipse((x - r, y - r, x + r, y + r), fill=col)
        self.commit(lay)

    def ellipse(self, cx, cy, rx, ry, rot=0.0, fill=None, stroke=None, width=0.0):
        pts = []
        for i in range(48):
            a = i / 48.0 * math.tau
            x = math.cos(a) * rx
            y = math.sin(a) * ry
            c, s = math.cos(rot), math.sin(rot)
            pts.append((cx + x * c - y * s, cy + x * s + y * c))
        self.poly(pts, fill, stroke, width)

    def circle(self, cx, cy, r, fill=None, stroke=None, width=0.0):
        self.ellipse(cx, cy, r, r, 0.0, fill, stroke, width)

    def quad(self, p0, p1, p2, col, width):
        pts = []
        for i in range(25):
            t = i / 24.0
            x = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0]
            y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]
            pts.append((x, y))
        self.line(pts, col, width)

    def halo(self, cx, cy, r, h, s, l, a):
        x0, y0 = self.m.apply(cx, cy)
        rr = r * UNIT * SS
        ys, xs = np.mgrid[0:self.img.size[1], 0:self.img.size[0]]
        d = np.sqrt((xs - x0) ** 2 + (ys - y0) ** 2) / rr
        al = np.clip(1.0 - d, 0.0, 1.0) * a
        col = hsl(h, s, l)
        arr = np.zeros((self.img.size[1], self.img.size[0], 4), dtype=np.uint8)
        arr[..., 0] = col[0]
        arr[..., 1] = col[1]
        arr[..., 2] = col[2]
        arr[..., 3] = (al * 255).astype(np.uint8)
        self.commit(Image.fromarray(arr, "RGBA"))

    def result(self):
        return self.img.resize((FR, FR), Image.LANCZOS)


def fairy(fl, ring=False):
    c = Canvas()
    base = c.m
    c.halo(0.0, 0.0, 20.0, 315.0, 100.0, 72.0, 0.35)
    for i in range(2):
        c.sub(base.translate(-1.0, -2.0).rotate(-0.7 + i * 0.55 + fl * 0.35))
        c.ellipse(-8.0, 0.0, 9.0, 3.6, 0.0, fill=(255, 255, 255, int(0.88 * 255)))
    c.sub(base)
    c.circle(0.0, 0.0, 5.5, fill=hexc(0xffd0f4))
    c.circle(2.0, -1.5, 1.6, fill=hexc(0xffffff))
    return c.result()


def dragon(fl):
    c = Canvas()
    base = c.m
    edge = hexc(0x3aa874)
    c.sub(base.translate(-2.0, -5.0).rotate(-0.5 + fl * 0.5))
    c.ellipse(-7.0, -2.0, 9.0, 4.0, 0.0, fill=hexc(0xb9f5d2), stroke=edge, width=1.6)
    c.sub(base)
    c.quad((-8.0, 4.0), (-17.0, 9.0), (-20.0, 1.0 + fl * 2.0), hexc(0x5cc995), 3.0)
    c.ellipse(0.0, 2.0, 9.0, 7.0, 0.0, fill=hexc(0x7fe0a8), stroke=edge, width=1.6)
    c.circle(8.0, -3.0, 5.5, fill=hexc(0x7fe0a8), stroke=edge, width=1.6)
    c.poly([(7.0, -8.0), (9.0, -13.0), (11.0, -8.0)], fill=hexc(0xffe27a))
    c.circle(10.0, -4.0, 1.3, fill=hexc(0x2a1650))
    return c.result()


def cat(rn):
    c = Canvas()
    c.sub(c.base.translate(0.0, -9.0))
    body = hexc(0xffcf9c)
    c.quad((-9.0, -1.0), (-17.0, -4.0 + rn * 2.0), (-15.0, -13.0), hexc(0xe0a468), 3.0)
    c.ellipse(-4.0 + rn * 2.5, 7.0, 3.2, 2.0, 0.0, fill=body)
    c.ellipse(5.0 - rn * 2.5, 7.0, 3.2, 2.0, 0.0, fill=body)
    c.ellipse(0.0, 0.0, 10.0, 7.0, 0.0, fill=body)
    c.circle(9.0, -6.0, 6.0, fill=body)
    c.poly([(4.5, -10.0), (5.5, -16.0), (9.0, -11.5)], fill=body)
    c.poly([(9.0, -11.5), (13.0, -16.0), (14.0, -9.5)], fill=body)
    c.circle(11.0, -7.0, 1.2, fill=hexc(0x2a1650))
    c.circle(7.0, -7.0, 1.2, fill=hexc(0x2a1650))
    c.circle(9.5, -4.5, 1.0, fill=hexc(0xff8aa8))
    return c.result()


def phoenix(fl):
    c = Canvas()
    base = c.m
    c.halo(0.0, 0.0, 34.0, 20.0, 100.0, 60.0, 0.5)
    for i in range(3):
        c.quad((-6.0, 2.0), (-16.0, 3.0 + i * 4.0 + fl * 2.0), (-26.0, 7.0 + i * 6.0 + fl * 3.0), hsl(8.0 + i * 20.0, 100.0, 56.0), 3.0)
    c.sub(base.translate(-1.0, -3.0).rotate(-0.6 + fl * 0.55))
    c.ellipse(-8.0, -2.0, 11.0, 5.0, 0.0, fill=hexc(0xffb347))
    c.sub(base)
    c.ellipse(0.0, 2.0, 8.0, 6.0, 0.0, fill=hexc(0xff7a3d))
    c.circle(7.0, -3.0, 4.6, fill=hexc(0xff9a4d))
    c.poly([(11.0, -4.0), (15.0, -2.5), (11.0, -1.0)], fill=hexc(0xffe27a))
    c.poly([(5.0, -7.0), (6.0, -12.0), (8.5, -7.0)], fill=hexc(0xffe27a))
    c.circle(8.0, -4.0, 1.2, fill=hexc(0x2a1650))
    return c.result()


def sheet(fn, name):
    out = Image.new("RGBA", (FR * FRAMES, FR), (0, 0, 0, 0))
    for k in range(FRAMES):
        v = math.sin(math.tau * k / FRAMES)
        out.paste(fn(v), (k * FR, 0))
    out.save(os.path.join(OUT, name))


def ring_tex():
    n = 128
    im = Image.new("RGBA", (n * SS, n * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    r = n * SS * 0.42
    c = n * SS * 0.5
    d.ellipse((c - r, c - r, c + r, c + r), outline=(255, 255, 255, 255), width=int(n * SS * 0.03))
    im.resize((n, n), Image.LANCZOS).save(os.path.join(OUT, "fx_ring.png"))


def deco_tex():
    n = 64
    im = Image.new("RGBA", (n * SS, n * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    k = n * SS / 2.0
    pts = []
    for i in range(20):
        r = 0.92 if i % 2 == 0 else 0.36
        a = -math.pi / 2 + i * math.pi / 10
        pts.append((k + math.cos(a) * r * k, k + math.sin(a) * r * k))
    d.polygon(pts, fill=hexc(0xfffbd0))
    im.resize((n, n), Image.LANCZOS).save(os.path.join(OUT, "hd_star.png"))
    im = Image.new("RGBA", (n * SS, n * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    pts = []
    for i in range(60):
        t = i / 60.0 * math.tau
        x = 16 * math.sin(t) ** 3
        y = 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)
        pts.append((k + x / 17.0 * k * 0.9, k - y / 17.0 * k * 0.9 - k * 0.05))
    d.polygon(pts, fill=hexc(0xfff0f5))
    im.resize((n, n), Image.LANCZOS).save(os.path.join(OUT, "hd_heart.png"))


if __name__ == "__main__":
    deco_tex()
    sheet(fairy, "pet_fairy.png")
    sheet(dragon, "pet_dragon.png")
    sheet(cat, "pet_cat.png")
    sheet(phoenix, "pet_phoenix.png")
    ring_tex()
