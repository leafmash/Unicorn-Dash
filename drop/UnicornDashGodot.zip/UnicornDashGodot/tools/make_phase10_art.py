import json
import os
import re
import sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cv_kit
import zone_layers as zl
from cv_kit import Cv, SS, G, Y0

ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "art", "zones")
ZONES_KT = os.environ.get("ZONES_KT", "/home/claude/work/kotlin/app/src/main/java/com/imora/unicorndash/Zones.kt")

LAYERS = [("far", zl.FAR, 0.8), ("near", zl.NEAR, 0.5), ("mid", zl.MID, 0.3), ("ground", zl.GRND, 0.75)]


def parse_zones():
    src = open(ZONES_KT).read()
    rows = re.findall(r'ZoneDef\("([^"]+)",\s*((?:rgb\(\d+, \d+, \d+\),\s*){7})([\d.]+), ([\d.]+), (\d+), (-?\d+), (\d+), ([\d.]+)(?:, "(\w*)")?\)', src)
    zones = []
    for name, cols, night, hue, fx, key, pr, tm, zs in rows:
        c = [tuple(int(v) for v in m) for m in re.findall(r"rgb\((\d+), (\d+), (\d+)\)", cols)]
        zones.append({
            "name": name,
            "top": c[0], "bot": c[1], "far": c[2], "near": c[3], "soil": c[4], "edge": c[5], "body": c[6],
            "night": float(night), "hue": float(hue), "fx": int(fx), "zs": zs or ""
        })
    return zones


def rgba(c):
    return (float(c[0]), float(c[1]), float(c[2]), 1.0)


def bake():
    os.makedirs(OUT, exist_ok=True)
    zones = parse_zones()
    assert len(zones) == 18, len(zones)
    manifest = {"period": zl.P, "scale": 1.6, "zones": []}
    for zi, z in enumerate(zones):
        zd = {k: (rgba(v) if k in ("far", "near", "soil", "edge") else v) for k, v in z.items()}
        entry = {k: z[k] for k in ("name", "top", "bot", "far", "near", "soil", "edge", "body", "night", "hue", "fx", "zs")}
        entry["layers"] = {}
        for name, fns, alpha in LAYERS:
            cv = Cv(zl.P)
            cv.alpha = alpha
            if name == "ground":
                cv.clip = (int(round((G + 2.0 - Y0) * SS)), int(round((G + 132.0 - Y0) * SS)))
            zl.setup(cv, zd)
            fns[zi]()
            img = cv.result()
            alpha_ch = img[..., 3]
            rows = alpha_ch.max(axis=1) > 0
            if not rows.any():
                continue
            top = int(rows.argmax())
            bottom = len(rows) - int(rows[::-1].argmax())
            crop = img[top:bottom]
            fn = "z%d_%s.png" % (zi, name)
            Image.fromarray(crop, "RGBA").save(os.path.join(OUT, fn), optimize=True)
            entry["layers"][name] = {"file": fn, "y": round((Y0 * 1.6) + top, 2), "h": int(bottom - top)}
        manifest["zones"].append(entry)
        print(zi, z["name"], {k: v["h"] for k, v in entry["layers"].items()})
    text = json.dumps(manifest, separators=(",", ":"))
    code = "const DATA := " + text + "\n\n\nstatic func build() -> Array:\n\tvar out: Array = []\n\tfor e in DATA[\"zones\"]:\n\t\tvar d: Dictionary = e.duplicate(true)\n\t\tfor k in [\"top\", \"bot\", \"far\", \"near\", \"soil\", \"edge\", \"body\"]:\n\t\t\tvar c: Array = d[k]\n\t\t\td[k + \"_c\"] = Color8(int(c[0]), int(c[1]), int(c[2]))\n\t\td[\"night\"] = float(d[\"night\"])\n\t\td[\"hue\"] = float(d[\"hue\"])\n\t\td[\"fx\"] = int(d[\"fx\"])\n\t\tout.append(d)\n\treturn out\n"
    open(os.path.join(ROOT, "zone_art.gd"), "w").write(code)


if __name__ == "__main__":
    bake()
