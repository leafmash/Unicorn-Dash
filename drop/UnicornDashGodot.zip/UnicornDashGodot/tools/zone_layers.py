import math
from cv_kit import *

P = 1600.0
sin = math.sin
cos = math.cos
x = None
Z = None


def sway(a, b):
    return sin(b)


def setup(cv, zone):
    global x, Z
    x = cv
    Z = zone


def layer(cs, seed, fn):
    n = max(1, int(round(P / cs)))
    c2 = P / n
    for i in range(n):
        px = i * c2 + (hs(i * 3 + seed) - 0.5) * c2 * 0.6
        r1 = hs(i * 7 + seed)
        r2 = hs(i * 13 + seed + 9)
        for sh in (-P, 0.0, P):
            fn(px + sh, r1, r2)


def pitch(p):
    n = max(1, int(round(P / p)))
    return P / n, n


def wave(y, a, b, k):
    n1 = max(1, round(P / (TAU * b)))
    b1 = P / (TAU * n1)
    n2 = max(1, round(P / (TAU * b * k)))
    b2 = P / (TAU * n2)
    x.begin()
    x.move(0.0, G)
    i = 0.0
    while i <= P + 12.0:
        x.line(i, y - a * sin(i / b1) - a * 0.5 * sin(i / b2))
        i += 12.0
    x.line(P + 12.0, G)
    x.fill()


def pine(px, y, h, w):
    x.tri(px, y - h * 0.18, h * 0.5, w)
    x.tri(px, y - h * 0.4, h * 0.45, w * 0.78)
    x.tri(px, y - h * 0.62, h * 0.38, w * 0.55)
    x.rect(px - 2.0, y - h * 0.18, 4.0, h * 0.18)


def crys(px, h, w):
    x.move(px - w, G)
    x.line(px - w * 0.7, G - h * 0.65)
    x.line(px, G - h)
    x.line(px + w * 0.7, G - h * 0.65)
    x.line(px + w, G)


def z0f():
    x.lw = 7.0

    def f(px, r1, r2):
        for k in range(6):
            x.stroke_c = hsl(k * 55.0, 90.0, 68.0, 0.5)
            x.begin()
            x.arc(px, G + 20.0, 150.0 + 30.0 * r1 - k * 7.0, PI, PI * 2.0)
            x.stroke()
    layer(400.0, 1, f)


def z0n():
    x.fill_c = Z["near"]
    wave(G - 34.0, 18.0, 70.0, 0.43)


def z0m():
    x.fill_c = Z["edge"]
    x.begin()

    def f(px, r1, r2):
        x.disc(px, G - 6.0, 12.0 + 8.0 * r1)
        x.disc(px + 14.0, G - 4.0, 9.0 + 6.0 * r2)
        x.disc(px - 12.0, G - 4.0, 8.0 + 5.0 * r2)
    layer(80.0, 3, f)
    x.fill()


def z0g():
    x.lw = 2.0

    def f(px, r1, r2):
        x.stroke_c = Z["edge"]
        x.begin()
        x.move(px, G + 3.0)
        x.line(px, G - 9.0 - r1 * 7.0)
        x.stroke()
        x.fill_c = hsl(r2 * 360.0, 90.0, 70.0)
        x.begin()
        x.disc(px, G - 12.0 - r1 * 7.0, 3.4)
        x.fill()
    layer(46.0, 21, f)


def z1f():
    x.fill_c = Z["far"]
    x.begin()
    layer(120.0, 1, lambda px, r1, r2: x.dome(px, G, 38.0 + 46.0 * r1, 1.15))
    x.fill()
    x.fill_c = rgba(255, 255, 255, 0.6)

    def f(px, r1, r2):
        x.fill_rect(px - 8.0, G - 24.0 - r1 * 30.0, 5.0, 2.0)
        x.fill_rect(px + 6.0, G - 40.0 - r2 * 20.0, 2.0, 5.0)
    layer(120.0, 1, f)


def z1n():
    x.cap = "round"
    x.lw = 8.0

    def f(px, r1, r2):
        h = 46.0 + 44.0 * r1
        x.begin()
        x.move(px, G)
        x.line(px, G - h)
        x.arc(px + 9.0, G - h, 9.0, PI, PI * 2.0)
        x.line(px + 18.0, G - h + 8.0)
        x.stroke_c = hexc(0xffffff)
        x.stroke()
        x.dash = (5.0, 8.0)
        x.cap = "butt"
        x.stroke_c = hexc(0xff5c93)
        x.stroke()
        x.dash = None
        x.cap = "round"
    layer(110.0, 2, f)


def z1m():
    def f(px, r1, r2):
        h = 34.0 + r1 * 18.0
        x.stroke_c = rgba(255, 255, 255, 0.8)
        x.lw = 3.0
        x.begin()
        x.move(px, G)
        x.line(px, G - h)
        x.stroke()
        x.fill_c = hsl(r2 * 360.0, 85.0, 70.0)
        x.begin()
        x.disc(px, G - h - 8.0, 12.0)
        x.fill()
        x.stroke_c = rgba(255, 255, 255, 0.85)
        x.lw = 2.0
        x.begin()
        x.arc(px, G - h - 8.0, 7.0, 0.0, 4.4)
        x.stroke()
    layer(150.0, 3, f)


def z1g():
    p, n = pitch(28.0)
    x.fill_c = rgba(255, 255, 255, 0.92)
    x.begin()
    for i in range(n + 1):
        cc = i * p + p / 2.0
        x.move(cc + p / 2.0, G)
        x.arc(cc, G, p / 2.0, 0.0, PI)
    x.fill()

    def g(px, r1, r2):
        x.fill_c = hsl(r2 * 360.0, 90.0, 65.0)
        x.fill_rect(px, G + 30.0 + r1 * 30.0, 6.0, 2.5)
    layer(50.0, 22, g)


def z2f():
    x.fill_c = Z["far"]
    x.begin()
    layer(62.0, 1, lambda px, r1, r2: pine(px, G, 70.0 + 80.0 * r1, 18.0 + 8.0 * r1))
    x.fill()


def z2n():
    x.fill_c = Z["near"]
    x.begin()
    layer(90.0, 2, lambda px, r1, r2: pine(px, G, 50.0 + 50.0 * r1, 16.0))
    x.fill()


def z2m():
    def f(px, r1, r2):
        x.fill_c = rgba(10, 6, 30, 0.9)
        x.begin()
        x.rect(px - 14.0, G - 20.0, 28.0, 20.0)
        x.tri(px, G - 20.0, 16.0, 20.0)
        x.rect(px + 8.0, G - 34.0, 5.0, 12.0)
        x.fill()
        x.halo(px - 4.0, G - 10.0, 9.0, 45.0, 100.0, 70.0, 0.8 + 0.2 * sway(3.0, r1 * 9.0))
    layer(300.0, 3, f)


def z2g():
    x.stroke_c = Z["edge"]
    x.lw = 1.6
    x.begin()

    def f(px, r1, r2):
        x.move(px, G + 3.0)
        x.quad(px + 3.0, G - 5.0 - r1 * 6.0, px + 6.0 * (r2 - 0.5), G - 10.0 - r1 * 8.0)
    layer(22.0, 21, f)
    x.stroke()


def z3f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        h = 100.0 + 80.0 * r1
        w = 70.0 + 30.0 * r2
        x.move(px - w, G)
        x.line(px - w * 0.35, G - h * 0.6)
        x.line(px - w * 0.12, G - h * 0.5)
        x.line(px, G - h)
        x.line(px + w * 0.2, G - h * 0.55)
        x.line(px + w * 0.45, G - h * 0.7)
        x.line(px + w, G)
    layer(170.0, 1, f)
    x.fill()
    x.fill_c = rgba(255, 255, 255, 0.88)
    x.begin()

    def g(px, r1, r2):
        h = 100.0 + 80.0 * r1
        w = 70.0 + 30.0 * r2
        x.move(px - w * 0.3, G - h * 0.72)
        x.line(px, G - h)
        x.line(px + w * 0.25, G - h * 0.7)
        x.line(px + w * 0.1, G - h * 0.62)
        x.line(px - w * 0.05, G - h * 0.7)
        x.line(px - w * 0.18, G - h * 0.62)
    layer(170.0, 1, g)
    x.fill()


def z3n():
    x.fill_c = Z["near"]
    x.begin()

    def f(px, r1, r2):
        x.tri(px, G, 40.0 + 60.0 * r1, 8.0 + 5.0 * r2)
        x.tri(px + 10.0, G, (40.0 + 60.0 * r1) * 0.6, 6.0)
    layer(64.0, 2, f)
    x.fill()


def z3m():
    def f(px, r1, r2):
        x.fill_c = hexc(0xffffff)
        x.begin()
        x.disc(px, G - 8.0, 9.0)
        x.disc(px, G - 22.0, 7.0)
        x.disc(px, G - 33.0, 5.0)
        x.fill()
        x.fill_c = hexc(0xff8a3c)
        x.begin()
        x.tri(px + 7.0, G - 33.0, 3.0, 2.0)
        x.fill()
        x.fill_c = hexc(0x222233)
        x.fill_rect(px - 2.5, G - 35.0, 1.6, 1.6)
        x.fill_rect(px + 1.0, G - 35.0, 1.6, 1.6)
    layer(260.0, 3, f)


def z3g():
    n1 = max(1, round(P / (TAU * 16.0)))
    b1 = P / (TAU * n1)
    n2 = max(1, round(P / (TAU * 7.0)))
    b2 = P / (TAU * n2)
    x.fill_c = hexc(0xffffff)
    x.begin()
    x.move(0.0, G + 3.0)
    i = 0.0
    while i <= P + 10.0:
        x.line(i, G - 2.0 - 3.0 * sin(i / b1) - 2.0 * sin(i / b2))
        i += 10.0
    x.line(P + 10.0, G + 3.0)
    x.fill()
    x.fill_c = rgba(180, 230, 255, 0.85)
    x.begin()
    layer(60.0, 22, lambda px, r1, r2: x.tri(px, G + 2.0, 6.0 + 6.0 * r1, 3.0))
    x.fill()


def z4f():
    x.fill_c = Z["far"]
    wave(G - 70.0, 38.0, 120.0, 0.37)


def z4n():
    x.fill_c = Z["near"]
    x.begin()
    layer(280.0, 2, lambda px, r1, r2: x.tri(px, G, 70.0 + 50.0 * r1, (70.0 + 50.0 * r1) * 0.9))
    x.fill()
    x.fill_c = rgba(0, 0, 0, 0.25)
    x.begin()

    def f(px, r1, r2):
        h = 70.0 + 50.0 * r1
        x.move(px, G - h)
        x.line(px + h * 0.9, G)
        x.line(px, G)
    layer(280.0, 2, f)
    x.fill()


def z4m():
    x.fill_c = rgba(60, 20, 40, 0.8)
    x.begin()

    def f(px, r1, r2):
        h = 34.0 + 18.0 * r1
        x.rect(px - 3.5, G - h, 7.0, h)
        x.rect(px - 12.0, G - h * 0.55, 9.0, 4.0)
        x.rect(px - 12.0, G - h * 0.55 - 12.0, 4.0, 16.0)
        x.rect(px + 3.5, G - h * 0.7, 9.0, 4.0)
        x.rect(px + 9.0, G - h * 0.7 - 10.0, 4.0, 14.0)
    layer(120.0, 3, f)
    x.fill()


def z4g():
    x.fill_c = Z["soil"]
    x.begin()
    layer(90.0, 22, lambda px, r1, r2: x.dome(px, G + 1.0, 22.0 + 10.0 * r1, 0.2))
    x.fill()
    x.stroke_c = rgba(255, 255, 255, 0.22)
    x.lw = 2.0
    x.begin()

    def f(px, r1, r2):
        x.move(px, G + 14.0 + r1 * 40.0)
        x.quad(px + 14.0, G + 10.0 + r1 * 40.0, px + 28.0, G + 14.0 + r1 * 40.0)
    layer(56.0, 21, f)
    x.stroke()


def z5f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        h = 110.0 + 50.0 * r1
        x.move(px - 130.0, G)
        x.line(px - 24.0, G - h)
        x.line(px + 24.0, G - h)
        x.line(px + 130.0, G)
    layer(230.0, 1, f)
    x.fill()
    x.stroke_c = hexc(0xff7a2a)
    x.lw = 3.0
    x.cap = "round"

    def g(px, r1, r2):
        h = 110.0 + 50.0 * r1
        x.halo(px, G - h, 44.0, 18.0, 100.0, 55.0, 0.6 + 0.2 * sway(2.0, r1 * 9.0))
        x.begin()
        x.move(px - 4.0, G - h)
        x.line(px - 30.0, G - h * 0.5)
        x.line(px - 38.0, G - h * 0.2)
        x.stroke()
    layer(230.0, 1, g)


def z5n():
    x.fill_c = Z["near"]
    x.begin()

    def f(px, r1, r2):
        h = 30.0 + 50.0 * r1
        x.move(px - 18.0, G)
        x.line(px - 10.0, G - h * 0.6)
        x.line(px - 3.0, G - h)
        x.line(px + 5.0, G - h * 0.7)
        x.line(px + 12.0, G - h * 0.85)
        x.line(px + 20.0, G)
    layer(70.0, 2, f)
    x.fill()


def z5m():
    layer(160.0, 3, lambda px, r1, r2: x.halo(px, G - 4.0, 26.0 + 10.0 * r1, 18.0, 100.0, 55.0, 0.35 + 0.2 * sway(3.0, r1 * 9.0)))


def z5g():
    x.stroke_c = hexc(0xff8a2c)
    x.lw = 2.4
    x.cap = "round"
    x.begin()

    def f(px, r1, r2):
        x.move(px, G + 6.0)
        x.line(px + 10.0, G + 16.0 + r1 * 10.0)
        x.line(px + 4.0, G + 28.0 + r1 * 10.0)
        x.line(px + 16.0, G + 40.0 + r2 * 8.0)
    layer(90.0, 21, f)
    x.stroke()
    x.fill_c = rgba(255, 140, 40, 0.85)
    x.begin()
    layer(40.0, 22, lambda px, r1, r2: x.tri(px, G + 1.0, 5.0 + 6.0 * abs(sway(6.0, r2 * 20.0)) + r1 * 3.0, 3.5))
    x.fill()


def z6f():
    y0 = Y0
    x.fill_c = Z["far"]
    x.begin()
    x.rect(0.0, y0, P, 14.0)

    def f(px, r1, r2):
        x.move(px - 14.0, y0 + 10.0)
        x.line(px, y0 + 50.0 + 110.0 * r1)
        x.line(px + 14.0, y0 + 10.0)
    layer(64.0, 1, f)
    x.fill()


def z6n():
    def f(px, r1, r2):
        for k in range(3):
            x.fill_c = hsl(Z["hue"] + k * 25.0, 75.0, 55.0 + k * 7.0, 0.55)
            x.begin()
            crys(px + (k - 1) * 14.0, 30.0 + 60.0 * (r1 if k == 1 else r2 * 0.7), 8.0 + (4.0 * k) % 3)
            x.fill()
    layer(100.0, 2, f)


def z6m():
    def f(px, r1, r2):
        py = G - 70.0 - r1 * 100.0 + sway(1.4, r2 * 9.0) * 6.0
        x.halo(px, py, 12.0, Z["hue"] + 40.0, 100.0, 75.0, 0.5 + 0.3 * sway(2.0, r1 * 7.0))
        x.fill_c = rgba(255, 255, 255, 0.85)
        x.begin()
        x.move(px, py - 5.0)
        x.line(px + 3.5, py)
        x.line(px, py + 5.0)
        x.line(px - 3.5, py)
        x.fill()
    layer(110.0, 3, f)


def z6g():
    x.fill_c = rgba(200, 170, 255, 0.7)
    x.begin()
    layer(44.0, 21, lambda px, r1, r2: x.tri(px, G + 2.0, 8.0 + 10.0 * r1, 3.5))
    x.fill()


def z7f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        b = G - 120.0 - r1 * 30.0
        x.rect(px - 7.0, b, 14.0, G - b)
        x.disc(px, b - 6.0, 40.0 + 10.0 * r2)
        x.disc(px - 28.0, b + 14.0, 28.0)
        x.disc(px + 28.0, b + 12.0, 30.0)
    layer(120.0, 1, f)
    x.fill()


def z7n():
    def f(px, r1, r2):
        h = 30.0 + 24.0 * r1
        x.fill_c = rgba(255, 250, 235, 0.9)
        x.fill_rect(px - 5.0, G - h, 10.0, h)
        x.fill_c = hsl(340.0 + r2 * 30.0, 75.0, 58.0)
        x.begin()
        x.dome(px, G - h + 4.0, 20.0 + 8.0 * r1, 0.7)
        x.fill()
        x.fill_c = hexc(0xffffff)
        x.begin()
        x.disc(px - 8.0, G - h - 4.0, 3.0)
        x.disc(px + 6.0, G - h - 8.0, 3.4)
        x.disc(px + 1.0, G - h - 1.0, 2.2)
        x.fill()
    layer(110.0, 2, f)


def z7m():
    y0 = Y0
    x.stroke_c = Z["edge"]
    x.fill_c = Z["edge"]
    x.lw = 2.0

    def f(px, r1, r2):
        ln = 40.0 + 90.0 * r1
        ex = px + sway(1.2, r2 * 9.0) * 10.0
        x.begin()
        x.move(px, y0)
        x.quad(px + sway(1.0, r2 * 9.0) * 8.0, y0 + ln * 0.5, ex, y0 + ln)
        x.stroke()
        x.begin()
        x.oval(ex, y0 + ln + 3.0, 3.0, 6.0)
        x.fill()
    layer(80.0, 3, f)


def z7g():
    x.stroke_c = Z["edge"]
    x.lw = 2.0
    x.begin()

    def f(px, r1, r2):
        x.move(px, G + 3.0)
        x.line(px - 6.0, G - 8.0 - r1 * 6.0)
        x.move(px, G + 3.0)
        x.line(px, G - 12.0 - r1 * 8.0)
        x.move(px, G + 3.0)
        x.line(px + 6.0, G - 8.0 - r2 * 6.0)
    layer(30.0, 21, f)
    x.stroke()


def z8f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        h = 90.0 + 50.0 * r1
        x.rect(px - 18.0, G - h, 36.0, h)
        x.rect(px - 46.0, G - h * 0.65, 24.0, h * 0.65)
        x.rect(px + 22.0, G - h * 0.7, 24.0, h * 0.7)
        for k in range(3):
            x.rect(px - 18.0 + k * 14.0, G - h - 6.0, 8.0, 6.0)
        x.tri(px, G - h - 6.0, 30.0, 20.0)
        x.tri(px - 34.0, G - h * 0.65, 22.0, 15.0)
        x.tri(px + 34.0, G - h * 0.7, 22.0, 15.0)
    layer(260.0, 1, f)
    x.fill()


def z8n():
    x.fill_c = Z["near"]
    x.begin()

    def f(px, r1, r2):
        x.disc(px, G - 8.0, 26.0 + 10.0 * r1)
        x.disc(px + 28.0, G - 4.0, 20.0 + 8.0 * r2)
        x.disc(px - 26.0, G - 2.0, 18.0)
    layer(90.0, 2, f)
    x.fill()


def z8m():
    def f(px, r1, r2):
        py = 70.0 + r1 * 80.0 + sway(0.8, r2 * 9.0) * 6.0
        x.fill_c = rgba(150, 120, 170)
        x.begin()
        x.move(px - 30.0, py)
        x.line(px + 30.0, py)
        x.line(px, py + 30.0)
        x.fill()
        x.fill_c = rgba(120, 210, 150)
        x.begin()
        x.oval(px, py, 32.0, 6.0)
        x.fill()
    layer(260.0, 3, f)


def z8g():
    x.fill_c = rgba(255, 255, 255, 0.95)
    x.begin()
    layer(34.0, 21, lambda px, r1, r2: x.disc(px, G + 2.0, 9.0 + 5.0 * r1))
    x.fill()


def z9f():
    def f(px, r1, r2):
        w = 36.0 + 22.0 * r2
        h = 80.0 + 110.0 * r1
        i = int(math.floor(r1 * 997.0))
        x.fill_c = Z["far"]
        x.fill_rect(px - w / 2.0, G - h, w, h)
        x.fill_c = rgba(255, 230, 120, 0.6)
        yy = G - h + 8.0
        j = 0
        while yy < G - 8.0:
            xx = px - w / 2.0 + 5.0
            k = 0
            while xx < px + w / 2.0 - 5.0:
                if hs(i + j * 7 + k * 3) > 0.55:
                    x.fill_rect(xx, yy, 4.0, 6.0)
                xx += 10.0
                k += 1
            yy += 12.0
            j += 1
    layer(64.0, 1, f)


def z9n():
    x.fill_c = Z["near"]
    x.stroke_c = Z["edge"]
    x.lw = 1.5

    def f(px, r1, r2):
        w = 44.0 + 20.0 * r2
        h = 50.0 + 70.0 * r1
        x.begin()
        x.rect(px - w / 2.0, G - h, w, h)
        x.fill()
        x.stroke()
        x.begin()
        x.move(px, G - h)
        x.line(px, G - h - 14.0)
        x.stroke()
    layer(100.0, 2, f)


def z9m():
    def f(px, r1, r2):
        py = G - 60.0 - r1 * 60.0
        hu = r2 * 360.0
        x.halo(px, py + 8.0, 26.0, hu, 100.0, 60.0, 0.25)
        x.stroke_c = hsl(hu, 100.0, 65.0)
        x.lw = 3.0
        x.stroke_rect(px - 18.0, py, 36.0, 16.0)
    layer(180.0, 3, f)


def z9g():
    x.stroke_c = Z["edge"]
    x.alpha = 0.55
    x.lw = 1.2
    x.begin()
    for k in range(3):
        x.move(0.0, G + 16.0 + k * 20.0)
        x.line(P, G + 16.0 + k * 20.0)
    p, n = pitch(40.0)
    for i in range(-1, n + 1):
        x.move(i * p, G + 6.0)
        x.line(i * p - 24.0, G + 90.0)
    x.stroke()
    x.alpha = 1.0
    x.fill_c = hexc(0xff5ad8)
    p2, n2 = pitch(60.0)
    for i in range(-1, n2 + 1):
        x.fill_rect(i * p2, G + 24.0, 26.0, 3.0)


def z10f():
    x.stroke_c = Z["far"]
    x.lw = 12.0
    x.cap = "round"

    def f(px, r1, r2):
        h = 100.0 + 80.0 * r1
        x.begin()
        x.move(px, G)
        for k in range(1, 7):
            x.line(px + sin(k * 0.8 + r2 * 9.0) * k * 3.0, G - h * k / 6.0)
        x.stroke()
    layer(70.0, 1, f)


def z10n():
    x.lw = 6.0
    x.cap = "round"

    def f(px, r1, r2):
        x.stroke_c = hsl(340.0 + r2 * 40.0, 70.0, 62.0)
        x.begin()
        x.move(px, G)
        x.line(px, G - 30.0 - 20.0 * r1)
        x.move(px, G - 14.0)
        x.line(px - 16.0, G - 34.0 - 10.0 * r1)
        x.move(px, G - 20.0)
        x.line(px + 16.0, G - 38.0 - 8.0 * r2)
        x.stroke()
    layer(120.0, 2, f)


def z10m():
    def f(px, r1, r2):
        py = 70.0 + r1 * 140.0 + sin(r2 * 9.0) * 6.0
        x.fill_c = hsl(30.0 + r2 * 30.0, 90.0, 65.0)
        x.begin()
        x.oval(px, py, 12.0, 6.0)
        x.move(px + 10.0, py)
        x.line(px + 20.0, py - 6.0)
        x.line(px + 20.0, py + 6.0)
        x.fill()
        x.fill_c = hexc(0x112233)
        x.fill_rect(px - 8.0, py - 2.0, 2.0, 2.0)
    layer(200.0, 3, f)


def z10g():
    x.fill_c = rgba(255, 255, 255, 0.3)
    x.begin()
    layer(40.0, 21, lambda px, r1, r2: x.disc(px, G + 14.0 + r1 * 30.0, 2.0 + 3.0 * r2))
    x.fill()
    x.fill_c = hexc(0xffd5e8)
    x.begin()
    layer(130.0, 22, lambda px, r1, r2: x.dome(px, G + 1.0, 7.0, 0.9))
    x.fill()


def z11f():
    x.fill_c = Z["far"]
    wave(G - 60.0, 30.0, 100.0, 0.41)


def z11n():
    def f(px, r1, r2):
        b = G - 40.0 - r1 * 20.0
        x.fill_c = rgba(90, 50, 40)
        x.fill_rect(px - 3.0, b, 6.0, G - b)
        x.fill_c = hsl(5.0 + r2 * 45.0, 80.0, 48.0 + r1 * 10.0)
        x.begin()
        x.disc(px, b - 12.0, 22.0 + 8.0 * r2)
        x.disc(px - 14.0, b - 4.0, 14.0)
        x.disc(px + 14.0, b - 4.0, 14.0)
        x.fill()
    layer(95.0, 2, f)


def z11m():
    x.stroke_c = rgba(95, 52, 32, 0.75)
    x.lw = 3.0
    x.begin()
    x.move(0.0, G - 8.0)
    x.line(P, G - 8.0)
    x.move(0.0, G - 18.0)
    x.line(P, G - 18.0)
    p, n = pitch(40.0)
    for i in range(-1, n + 1):
        x.move(i * p, G)
        x.line(i * p, G - 24.0)
    x.stroke()


def z11g():
    def f(px, r1, r2):
        x.fill_c = hexc(0xff8a1e)
        x.begin()
        x.oval(px, G - 5.0, 9.0, 7.0)
        x.fill()
        x.fill_c = hexc(0x3c8a3a)
        x.fill_rect(px - 1.5, G - 14.0, 3.0, 4.0)
    layer(200.0, 21, f)

    def g(px, r1, r2):
        x.fill_c = hsl(r2 * 50.0, 85.0, 52.0)
        x.begin()
        x.move(px + 4.0, G + 10.0 + r1 * 50.0)
        x.ellipse(px, G + 10.0 + r1 * 50.0, 4.0, 2.0, r2 * 3.0, 0.0, 7.0)
        x.fill()
    layer(30.0, 22, g)


def z12f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        w = 60.0 + 40.0 * r2
        h = 90.0 + 50.0 * r1
        x.move(px - w, G)
        x.line(px - w, G - h * 0.4)
        x.line(px - w * 0.7, G - h * 0.4)
        x.line(px - w * 0.7, G - h)
        x.line(px + w * 0.6, G - h)
        x.line(px + w * 0.6, G - h * 0.55)
        x.line(px + w, G - h * 0.55)
        x.line(px + w, G)
    layer(200.0, 1, f)
    x.fill()


def z12n():
    x.cap = "round"

    def f(px, r1, r2):
        h = 70.0 + 30.0 * r1
        x.stroke_c = rgba(110, 70, 40)
        x.lw = 5.0
        x.begin()
        x.move(px, G)
        x.quad(px + 10.0, G - h * 0.5, px + 4.0, G - h)
        x.stroke()
        x.stroke_c = Z["edge"]
        x.lw = 4.0
        x.begin()
        for k in range(-2, 3):
            x.move(px + 4.0, G - h)
            x.quad(px + 4.0 + k * 12.0, G - h - 16.0 + abs(k) * 3.0, px + 4.0 + k * 22.0, G - h + 8.0 + abs(k) * 4.0)
        x.stroke()
    layer(170.0, 2, f)


def z12m():
    x.fill_c = Z["soil"]
    x.begin()
    layer(140.0, 3, lambda px, r1, r2: x.dome(px, G, 40.0 + 20.0 * r1, 0.35))
    x.fill()


def z12g():
    x.fill_c = rgba(70, 190, 220, 0.9)
    x.begin()
    layer(260.0, 22, lambda px, r1, r2: x.oval(px, G + 10.0, 40.0 + 14.0 * r1, 5.0))
    x.fill()
    x.stroke_c = Z["edge"]
    x.lw = 2.0
    x.begin()

    def f(px, r1, r2):
        x.move(px, G + 3.0)
        x.line(px - 3.0, G - 8.0 - r1 * 4.0)
        x.move(px, G + 3.0)
        x.line(px + 4.0, G - 9.0 - r1 * 4.0)
    layer(60.0, 21, f)
    x.stroke()


def z13f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        w = 12.0 + 6.0 * r2
        h = 34.0 + 30.0 * r1
        x.move(px - w, G)
        x.line(px - w, G - h + w)
        x.arc(px, G - h + w, w, PI, PI * 2.0)
        x.line(px + w, G)
    layer(90.0, 1, f)
    x.fill()


def z13n():
    x.stroke_c = Z["near"]
    x.cap = "round"

    def f(px, r1, r2):
        h = 80.0 + 60.0 * r1
        x.lw = 7.0
        x.begin()
        x.move(px, G)
        x.line(px + 4.0, G - h * 0.5)
        x.line(px - 2.0, G - h)
        x.stroke()
        x.lw = 3.5
        x.begin()
        x.move(px + 4.0, G - h * 0.5)
        x.line(px + 26.0, G - h * 0.75)
        x.line(px + 34.0, G - h * 0.72)
        x.move(px + 1.0, G - h * 0.7)
        x.line(px - 24.0, G - h * 0.9)
        x.line(px - 32.0, G - h * 0.85)
        x.stroke()
    layer(150.0, 2, f)


def z13m():
    layer(200.0, 3, lambda px, r1, r2: x.halo(px + sway(0.4, r2 * 9.0) * 20.0, G - 14.0 - r1 * 30.0, 60.0, 200.0, 10.0, 80.0, 0.12))


def z13g():
    p, n = pitch(18.0)
    x.stroke_c = rgba(20, 24, 34, 0.9)
    x.lw = 2.0
    x.begin()
    x.move(0.0, G - 8.0)
    x.line(P, G - 8.0)
    for i in range(-1, n + 1):
        x.move(i * p, G + 2.0)
        x.line(i * p, G - 18.0)
    x.stroke()
    x.fill_c = rgba(20, 24, 34, 0.9)
    x.begin()
    for i in range(-1, n + 1):
        x.tri(i * p, G - 18.0, 6.0, 2.5)
    x.fill()


def z14f():
    def f(px, r1, r2):
        r = 26.0 + 34.0 * r1
        py = 50.0 + r2 * 110.0
        x.fill_c = Z["far"]
        x.begin()
        x.disc(px, py, r)
        x.fill()
        x.stroke_c = Z["edge"]
        x.lw = 3.0
        x.begin()
        x.move(px + r * 1.7, py)
        x.ellipse(px, py, r * 1.7, r * 0.38, -0.35, 0.0, 7.0)
        x.stroke()
    layer(340.0, 1, f)


def z14n():
    x.fill_c = Z["near"]

    def f(px, r1, r2):
        py = 40.0 + r1 * 180.0 + sway(0.7, r2 * 9.0) * 8.0
        rr = 10.0 + 10.0 * r2
        x.begin()
        for k in range(7):
            a = k / 7.0 * PI * 2.0 + r1 * 3.0
            rad = rr * (0.7 + 0.3 * hs(k + int(math.floor(r1 * 50.0))))
            if k > 0:
                x.line(px + cos(a) * rad, py + sin(a) * rad)
            else:
                x.move(px + cos(a) * rad, py + sin(a) * rad)
        x.fill()
    layer(110.0, 2, f)


def z14m():
    def f(px, r1, r2):
        py = 40.0 + r1 * 100.0
        x.fill_c = hexc(0xc9d4ff)
        x.fill_rect(px - 4.0, py - 4.0, 8.0, 8.0)
        x.fill_c = hexc(0x5aa0ff)
        x.fill_rect(px - 20.0, py - 3.0, 13.0, 6.0)
        x.fill_rect(px + 7.0, py - 3.0, 13.0, 6.0)
        x.halo(px, py - 6.0, 5.0, 0.0, 100.0, 70.0, 0.4 + 0.4 * abs(sway(3.0, r2 * 9.0)))
    layer(300.0, 3, f)


def z14g():
    p, n = pitch(50.0)
    x.stroke_c = rgba(160, 140, 255, 0.5)
    x.lw = 1.5
    x.begin()
    for i in range(-1, n + 1):
        x.move(i * p, G + 6.0)
        x.line(i * p, G + 90.0)
    x.move(0.0, G + 30.0)
    x.line(P, G + 30.0)
    x.move(0.0, G + 56.0)
    x.line(P, G + 56.0)
    x.stroke()
    layer(50.0, 21, lambda px, r1, r2: x.halo(px, G + 16.0, 5.0, 200.0 if r2 > 0.5 else 330.0, 100.0, 70.0, 0.5 + 0.4 * abs(sway(2.0, r1 * 9.0))))


def z15f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        w = 44.0 + 16.0 * r2
        h = 120.0 + 50.0 * r1
        x.move(px - w, G)
        x.line(px - w, G - h + 14.0)
        x.quad(px - w, G - h, px - w + 14.0, G - h)
        x.line(px + w - 14.0, G - h)
        x.quad(px + w, G - h, px + w, G - h + 14.0)
        x.line(px + w, G)
    layer(200.0, 1, f)
    x.fill()
    x.stroke_c = rgba(255, 255, 255, 0.7)
    x.lw = 10.0
    x.dash = (14.0, 10.0)

    def g(px, r1, r2):
        x.begin()
        x.move(px, G - 120.0 - 50.0 * r1 + 10.0)
        x.line(px, G)
        x.stroke()
    layer(200.0, 1, g)
    x.dash = None


def z15n():
    x.fill_c = Z["near"]
    x.begin()

    def f(px, r1, r2):
        for k in range(4):
            x.rect(px - 40.0 + k * 10.0, G - 14.0 * (k + 1), 80.0 - k * 20.0, 14.0)
    layer(140.0, 2, f)
    x.fill()


def z15m():
    layer(200.0, 3, lambda px, r1, r2: x.halo(px, G - 10.0, 50.0, 190.0, 40.0, 95.0, 0.25))


def z15g():
    def f(px, r1, r2):
        x.fill_c = hsl(160.0 + r2 * 60.0, 60.0, 75.0, 0.85)
        x.begin()
        x.oval(px, G + 5.0 + r1 * 20.0, 8.0 + 6.0 * r2, 4.0)
        x.fill()
    layer(44.0, 21, f)


def z16f():
    def f(px, r1, r2):
        h = 100.0 + 60.0 * r1
        x.stroke_c = Z["far"]
        x.lw = 6.0
        x.begin()
        x.move(px, G)
        x.quad(px + 10.0, G - h * 0.5, px, G - h)
        x.stroke()
        x.fill_c = Z["far"]
        for k in range(6):
            a = k * PI / 3.0 + r2
            x.begin()
            x.ellipse(px + cos(a) * 16.0, G - h + sin(a) * 16.0, 16.0, 7.0, a, 0.0, 7.0)
            x.fill()
    layer(200.0, 1, f)


def z16n():
    def f(px, r1, r2):
        h = 50.0 + 40.0 * r1
        x.stroke_c = Z["near"]
        x.lw = 3.0
        x.begin()
        x.move(px, G)
        x.quad(px + 12.0, G - h, px + 16.0, G - h)
        x.stroke()
        x.fill_c = hsl(Z["hue"] + r2 * 60.0, 70.0, 72.0, 0.85)
        x.begin()
        x.move(px + 16.0, G - h)
        x.line(px + 25.0, G - h + 18.0)
        x.line(px + 7.0, G - h + 18.0)
        x.fill()
    layer(90.0, 2, f)


def z16m():
    y0 = Y0

    def f(px, r1, r2):
        ln = 40.0 + 80.0 * r1
        x.stroke_c = rgba(255, 255, 255, 0.4)
        x.lw = 1.0
        x.begin()
        x.move(px, y0)
        x.line(px, y0 + ln)
        x.stroke()
        x.halo(px, y0 + ln + 8.0, 18.0, 50.0 + r2 * 40.0, 100.0, 75.0, 0.55 + 0.2 * sway(2.0, r2 * 9.0))
        x.fill_c = hexc(0xfff6c8)
        x.begin()
        x.disc(px, y0 + ln + 8.0, 5.0)
        x.fill()
    layer(110.0, 3, f)


def z16g():
    def f(px, r1, r2):
        x.fill_c = hsl(200.0 + r2 * 140.0, 80.0, 80.0, 0.8)
        x.begin()
        x.move(px + 4.0, G + 10.0 + r1 * 40.0)
        x.ellipse(px, G + 10.0 + r1 * 40.0, 4.0, 2.0, r2 * 3.0, 0.0, 7.0)
        x.fill()
    layer(36.0, 21, f)

    def g(px, r1, r2):
        if r2 > 0.7:
            return
        x.halo(px, G - 6.0, 5.0, 190.0 + r1 * 120.0, 100.0, 78.0, 0.5 + 0.4 * abs(sway(2.0, r1 * 9.0)))
    layer(90.0, 23, g)


def z17f():
    x.fill_c = Z["far"]
    x.begin()

    def f(px, r1, r2):
        for k in range(3):
            w = 46.0 - k * 9.0
            y = G - k * 38.0
            x.rect(px - w + 6.0, y - 26.0, 2.0 * w - 12.0, 26.0)
            x.move(px - w - 12.0, y - 26.0)
            x.line(px - w + 4.0, y - 40.0)
            x.line(px + w - 4.0, y - 40.0)
            x.line(px + w + 12.0, y - 26.0)
        x.tri(px, G - 114.0, 22.0, 3.0)
    layer(240.0, 1, f)
    x.fill()


def z17n():
    p, n = pitch(64.0)
    x.fill_c = Z["near"]
    x.begin()
    for i in range(-1, n + 1):
        cx = i * p
        x.rect(cx - 6.0, G - 62.0, 12.0, 62.0)
        x.rect(cx - 10.0, G - 66.0, 20.0, 6.0)
        x.rect(cx - 9.0, G - 6.0, 18.0, 6.0)
    x.rect(0.0, G - 76.0, P, 10.0)
    x.fill()


def z17m():
    y0 = Y0

    def f(px, r1, r2):
        ln = 40.0 + 70.0 * r1
        x.stroke_c = rgba(255, 215, 100, 0.6)
        x.lw = 1.2
        x.begin()
        x.move(px, y0)
        x.line(px, y0 + ln)
        x.stroke()
        x.halo(px, y0 + ln + 9.0, 16.0, 30.0, 100.0, 62.0, 0.4 + 0.2 * sway(2.0, r2 * 9.0))
        x.fill_c = hexc(0xe0482a)
        x.fill_rect(px - 6.0, y0 + ln, 12.0, 18.0)
        x.fill_c = hexc(0xffd24a)
        x.fill_rect(px - 7.0, y0 + ln - 2.0, 14.0, 3.0)
        x.fill_rect(px - 7.0, y0 + ln + 17.0, 14.0, 3.0)
    layer(120.0, 3, f)


def z17g():
    p, n = pitch(40.0)
    x.fill_c = rgba(255, 255, 255, 0.18)
    for i in range(-1, n + 1):
        x.fill_rect(i * p, G + 8.0, 20.0, 10.0)
        x.fill_rect(i * p + 20.0, G + 18.0, 20.0, 10.0)
    p2, n2 = pitch(20.0)
    x.stroke_c = rgba(120, 70, 10, 0.55)
    x.lw = 2.0
    x.begin()
    for i in range(-1, n2 + 1):
        cx = i * p2
        x.move(cx, G + 40.0)
        x.line(cx + 10.0, G + 40.0)
        x.line(cx + 10.0, G + 50.0)
        x.line(cx + 4.0, G + 50.0)
        x.line(cx + 4.0, G + 44.0)
    x.stroke()


FAR = [z0f, z1f, z2f, z3f, z4f, z5f, z6f, z7f, z8f, z9f, z10f, z11f, z12f, z13f, z14f, z15f, z16f, z17f]
NEAR = [z0n, z1n, z2n, z3n, z4n, z5n, z6n, z7n, z8n, z9n, z10n, z11n, z12n, z13n, z14n, z15n, z16n, z17n]
MID = [z0m, z1m, z2m, z3m, z4m, z5m, z6m, z7m, z8m, z9m, z10m, z11m, z12m, z13m, z14m, z15m, z16m, z17m]
GRND = [z0g, z1g, z2g, z3g, z4g, z5g, z6g, z7g, z8g, z9g, z10g, z11g, z12g, z13g, z14g, z15g, z16g, z17g]
