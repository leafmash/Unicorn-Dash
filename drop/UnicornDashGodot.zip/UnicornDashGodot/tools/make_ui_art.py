import os

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter

SS = 4
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "art", "ui"))


def canvas(w, h):
    return Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))


def rr_mask(w, h, box, r):
    m = Image.new("L", (w * SS, h * SS), 0)
    x0, y0, x1, y1 = box
    ImageDraw.Draw(m).rounded_rectangle([x0 * SS, y0 * SS, x1 * SS - 1, y1 * SS - 1], radius=r * SS, fill=255)
    return m


def vgrad(w, h, y0, y1, stops):
    ys = np.arange(h * SS, dtype=np.float32)
    t = np.clip((ys - y0 * SS) / max((y1 - y0) * SS, 1.0), 0.0, 1.0)
    pos = [s[0] for s in stops]
    arr = np.zeros((h * SS, w * SS, 4), dtype=np.float32)
    for ch in range(4):
        col = np.interp(t, pos, [s[1][ch] for s in stops])
        arr[:, :, ch] = col[:, None]
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGBA")


def paste_masked(base, layer, mask):
    a = ImageChops.multiply(layer.getchannel("A"), mask)
    layer = layer.copy()
    layer.putalpha(a)
    base.alpha_composite(layer)


def soft_shadow(im, w, h, box, r, dy, blur, alpha):
    m = rr_mask(w, h, (box[0], box[1] + dy, box[2], box[3] + dy), r)
    m = m.filter(ImageFilter.GaussianBlur(blur * SS))
    sh = Image.new("RGBA", im.size, (16, 6, 48, 0))
    sh.putalpha(m.point(lambda v: int(v * alpha)))
    im.alpha_composite(sh)


def finish(im, w, h, name):
    im.resize((w, h), Image.LANCZOS).save(os.path.join(OUT, name))


def make_button(w, h, r, lip, pad, tag):
    body_h = h - pad
    im = canvas(w, h)
    soft_shadow(im, w, h, (1, 1, w - 1, body_h), r, 2, pad * 0.45, 0.55)
    outer = rr_mask(w, h, (0, 0, w, body_h), r)
    paste_masked(im, Image.new("RGBA", im.size, (66, 66, 66, 255)), outer)
    in_lip = rr_mask(w, h, (3, 3, w - 3, body_h - 3), r - 3)
    paste_masked(im, Image.new("RGBA", im.size, (150, 150, 150, 255)), in_lip)
    face = rr_mask(w, h, (3, 3, w - 3, body_h - 3 - lip), r - 3)
    grad = vgrad(w, h, 3, body_h - 3 - lip, [(0.0, (255, 255, 255, 255)), (0.55, (238, 238, 238, 255)), (1.0, (206, 206, 206, 255))])
    paste_masked(im, grad, face)
    finish(im, w, h, "btn_%s.png" % tag)

    g = canvas(w, h)
    fh = body_h - 3 - lip
    top = rr_mask(w, h, (5, 5, w - 5, 5 + int(fh * 0.52)), max(r - 6, 4))
    gl = vgrad(w, h, 5, 5 + fh * 0.52, [(0.0, (255, 255, 255, 120)), (1.0, (255, 255, 255, 0))])
    paste_masked(g, gl, top)
    ring_out = rr_mask(w, h, (3, 3, w - 3, body_h - 3 - lip), r - 3)
    ring_in = rr_mask(w, h, (5, 5, w - 5, body_h - 5 - lip), r - 5)
    ring = ImageChops.subtract(ring_out, ring_in)
    rim = vgrad(w, h, 3, body_h - lip, [(0.0, (255, 255, 255, 150)), (0.5, (255, 255, 255, 40)), (1.0, (255, 255, 255, 0))])
    paste_masked(g, rim, ring)
    finish(g, w, h, "btn_%s_gloss.png" % tag)


def make_panel(w, h, r, pad, name):
    body_h = h - pad
    im = canvas(w, h)
    soft_shadow(im, w, h, (2, 2, w - 2, body_h), r, 3, pad * 0.5, 0.6)
    outer = rr_mask(w, h, (0, 0, w, body_h), r)
    edge = vgrad(w, h, 0, body_h, [(0.0, (222, 196, 255, 255)), (0.5, (160, 124, 236, 255)), (1.0, (104, 74, 196, 255))])
    paste_masked(im, edge, outer)
    inner = rr_mask(w, h, (4, 4, w - 4, body_h - 4), r - 4)
    fill = vgrad(w, h, 4, body_h - 4, [(0.0, (74, 44, 156, 255)), (0.45, (46, 24, 112, 255)), (1.0, (30, 14, 84, 255))])
    paste_masked(im, fill, inner)
    ink = rr_mask(w, h, (4, 4, w - 4, body_h - 4), r - 4)
    ink2 = rr_mask(w, h, (6, 6, w - 6, body_h - 6), r - 6)
    ring = ImageChops.subtract(ink, ink2)
    paste_masked(im, Image.new("RGBA", im.size, (18, 6, 56, 200)), ring)
    band = rr_mask(w, h, (9, 9, w - 9, 9 + int(body_h * 0.34)), r - 8)
    bg = vgrad(w, h, 9, 9 + body_h * 0.34, [(0.0, (255, 255, 255, 46)), (1.0, (255, 255, 255, 0))])
    paste_masked(im, bg, band)
    finish(im, w, h, name)


def make_row(w, h, r, pad, name):
    body_h = h - pad
    im = canvas(w, h)
    soft_shadow(im, w, h, (2, 2, w - 2, body_h), r, 2, pad * 0.5, 0.45)
    outer = rr_mask(w, h, (0, 0, w, body_h), r)
    edge = vgrad(w, h, 0, body_h, [(0.0, (176, 146, 246, 255)), (1.0, (96, 70, 190, 255))])
    paste_masked(im, edge, outer)
    inner = rr_mask(w, h, (3, 3, w - 3, body_h - 3), r - 3)
    fill = vgrad(w, h, 3, body_h - 3, [(0.0, (58, 34, 132, 255)), (1.0, (38, 20, 100, 255))])
    paste_masked(im, fill, inner)
    band = rr_mask(w, h, (6, 6, w - 6, 6 + int(body_h * 0.4)), r - 5)
    bg = vgrad(w, h, 6, 6 + body_h * 0.4, [(0.0, (255, 255, 255, 34)), (1.0, (255, 255, 255, 0))])
    paste_masked(im, bg, band)
    finish(im, w, h, name)


def make_chip(w, h, name):
    r = h // 2 - 2
    body_h = h - 4
    im = canvas(w, h)
    soft_shadow(im, w, h, (1, 1, w - 1, body_h), r, 1, 2, 0.5)
    outer = rr_mask(w, h, (0, 0, w, body_h), r)
    edge = vgrad(w, h, 0, body_h, [(0.0, (236, 218, 255, 255)), (1.0, (140, 108, 220, 255))])
    paste_masked(im, edge, outer)
    inner = rr_mask(w, h, (3, 3, w - 3, body_h - 3), r - 3)
    fill = vgrad(w, h, 3, body_h - 3, [(0.0, (52, 30, 124, 255)), (1.0, (24, 10, 70, 255))])
    paste_masked(im, fill, inner)
    band = rr_mask(w, h, (6, 5, w - 6, 5 + int(body_h * 0.4)), r - 5)
    bg = vgrad(w, h, 5, 5 + body_h * 0.4, [(0.0, (255, 255, 255, 40)), (1.0, (255, 255, 255, 0))])
    paste_masked(im, bg, band)
    finish(im, w, h, name)


def make_dim(name):
    w, h = 64, 64
    im = Image.new("RGBA", (w, h), (10, 4, 34, 0))
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
    a = np.clip(0.38 + d * 0.32, 0.0, 0.78)
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    arr[:, :, 0] = 10
    arr[:, :, 1] = 4
    arr[:, :, 2] = 34
    arr[:, :, 3] = (a * 255).astype(np.uint8)
    Image.fromarray(arr, "RGBA").save(os.path.join(OUT, name))


PALETTE = {
    "pink": (255, 95, 168),
    "blue": (74, 134, 232),
    "green": (63, 201, 138),
    "orange": (242, 169, 60),
    "purple": (180, 92, 255),
    "red": (255, 107, 107),
    "indigo": (90, 60, 176),
    "rose": (255, 95, 141),
    "grey": (87, 71, 128),
    "dark": (71, 61, 102),
}


def bake(tag, name, col):
    base = Image.open(os.path.join(OUT, "btn_%s.png" % tag)).convert("RGBA")
    gloss = Image.open(os.path.join(OUT, "btn_%s_gloss.png" % tag)).convert("RGBA")
    arr = np.array(base).astype(np.float32)
    for ch in range(3):
        arr[:, :, ch] = arr[:, :, ch] * col[ch] / 255.0
    tinted = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGBA")
    tinted.alpha_composite(gloss)
    tinted.save(os.path.join(OUT, "btn_%s_%s.png" % (tag, name)))


def main():
    os.makedirs(OUT, exist_ok=True)
    make_button(64, 72, 20, 6, 6, "s")
    make_button(128, 144, 40, 12, 10, "l")
    for tag in ("s", "l"):
        for name, col in PALETTE.items():
            bake(tag, name, col)
    make_panel(128, 136, 36, 8, "panel.png")
    make_row(96, 100, 24, 4, "row.png")
    make_chip(96, 64, "chip.png")
    make_dim("dim.png")


if __name__ == "__main__":
    main()
