import numpy as np
from PIL import Image

SC = 2
W = 1280 * SC
H = 470 * SC
CX = W / 2.0
CY = 610.0 * SC
R_OUT = 560.0 * SC
BAND = 24.0 * SC
COLS = ["ff5f8d", "ff9a5f", "ffe066", "6fe3a5", "5fb8ff", "a56bff"]
ALPHA = 0.66


def rgb(h):
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float64)


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


ys, xs = np.mgrid[0:H, 0:W].astype(np.float64)
r = np.hypot(xs + 0.5 - CX, ys + 0.5 - CY)
u = (R_OUT - r) / BAND
n = len(COLS)
cols = np.stack([rgb(c) for c in COLS])
idx = np.clip(np.floor(u), 0, n - 1).astype(int)
col = cols[idx]
soft = 1.1 * SC / BAND
for k in range(1, n):
    m = smooth(k - soft, k + soft, u)
    col = col * (1.0 - m[..., None]) + cols[k][None, None, :] * m[..., None]

edge_in = (r - (R_OUT - n * BAND)) / SC
edge_out = (R_OUT - r) / SC
cover = np.clip(edge_in + 0.5, 0.0, 1.0) * np.clip(edge_out + 0.5, 0.0, 1.0)
shade = 1.0 + 0.10 * np.clip(1.0 - np.abs(((u % 1.0) - 0.35)) * 2.2, 0.0, 1.0)
col = np.clip(col * shade[..., None], 0, 255)
glow_o = np.exp(-np.clip(-edge_out, 0, None) / (14.0 * 1.0)) * (edge_out < 0)
glow_i = np.exp(-np.clip(-edge_in, 0, None) / (14.0 * 1.0)) * (edge_in < 0)
glow = np.maximum(glow_o, glow_i) * 0.16
alpha = np.clip(cover * ALPHA + glow * (1.0 - cover), 0.0, 1.0)
gc = np.where(glow_o[..., None] > glow_i[..., None], cols[0], cols[-1])
w_c = (cover * ALPHA)[..., None]
w_g = (glow * (1.0 - cover))[..., None]
den = np.maximum(w_c + w_g, 1e-6)
out_rgb = (col * w_c + gc * w_g) / den
out = np.dstack([out_rgb, alpha * 255.0]).clip(0, 255).astype(np.uint8)
Image.fromarray(out, "RGBA").save("art/rainbow.png", optimize=True)
print(out.shape)
