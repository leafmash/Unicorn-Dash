import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

SS = 4
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "art"))


class D:
    def __init__(self, w, h):
        self.w = w
        self.h = h
        self.im = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    def pts(self, p):
        return [(x * SS, y * SS) for x, y in p]

    def poly(self, p, fill=None, outline=None, width=0):
        q = self.pts(p)
        if fill is not None:
            self.d.polygon(q, fill=fill)
        if outline is not None:
            self.d.line(q + [q[0]], fill=outline, width=int(width * SS), joint="curve")

    def line(self, p, fill, width):
        self.d.line(self.pts(p), fill=fill, width=int(width * SS), joint="curve")

    def ell(self, cx, cy, rx, ry, fill=None, outline=None, width=0):
        box = [(cx - rx) * SS, (cy - ry) * SS, (cx + rx) * SS, (cy + ry) * SS]
        self.d.ellipse(box, fill=fill, outline=outline, width=int(width * SS))

    def rrect(self, x0, y0, x1, y1, r, fill=None, outline=None, width=0):
        box = [x0 * SS, y0 * SS, x1 * SS, y1 * SS]
        self.d.rounded_rectangle(box, radius=r * SS, fill=fill, outline=outline, width=int(width * SS))

    def grad_poly(self, p, c0, c1):
        ys = [q[1] for q in p]
        y0 = min(ys) * SS
        y1 = max(ys) * SS
        mask = Image.new("L", self.im.size, 0)
        ImageDraw.Draw(mask).polygon(self.pts(p), fill=255)
        height = self.im.size[1]
        width = self.im.size[0]
        t = np.clip((np.arange(height) - y0) / max(y1 - y0, 1.0), 0.0, 1.0)
        arr = np.zeros((height, width, 4), dtype=np.uint8)
        for ch in range(3):
            row = c0[ch] * (1.0 - t) + c1[ch] * t
            arr[:, :, ch] = row[:, None].astype(np.uint8)
        arr[:, :, 3] = 255
        layer = Image.fromarray(arr, "RGBA")
        layer.putalpha(mask)
        self.im.alpha_composite(layer)

    def glow(self, blur, fn):
        t = D(self.w, self.h)
        fn(t)
        t.im = t.im.filter(ImageFilter.GaussianBlur(blur * SS))
        self.im.alpha_composite(t.im)

    def save(self, name):
        out = self.im.resize((self.w, self.h), Image.LANCZOS)
        out.save(os.path.join(OUT, name))


def star_points(cx, cy, ro, ri):
    p = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        r = ro if i % 2 == 0 else ri
        p.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    return p


def make_stars():
    on = D(96, 96)
    on.glow(5, lambda t: t.poly(star_points(48, 51, 44, 20), fill=(255, 210, 70, 160)))
    on.poly(star_points(48, 51, 40, 18), fill=(255, 214, 74, 255), outline=(255, 247, 205, 255), width=5)
    on.poly(star_points(48, 49, 22, 10), fill=(255, 240, 150, 200))
    on.save("star_on.png")
    off = D(96, 96)
    off.poly(star_points(48, 51, 40, 18), fill=(82, 56, 140, 210), outline=(150, 124, 208, 255), width=5)
    off.save("star_off.png")


def make_lock():
    d = D(64, 64)
    arc = []
    for i in range(0, 181, 6):
        a = math.radians(180 + i)
        arc.append((32 + math.cos(a) * 11, 25 + math.sin(a) * 11))
    d.line([(21, 32)] + arc + [(43, 32)], fill=(255, 255, 255, 240), width=6)
    d.rrect(13, 28, 51, 58, 8, fill=(255, 255, 255, 240), outline=(210, 190, 250, 255), width=2)
    d.ell(32, 41, 5, 5, fill=(96, 62, 156, 255))
    d.rrect(30, 42, 34, 51, 2, fill=(96, 62, 156, 255))
    d.save("lock.png")


def make_pit():
    w, h = 384, 600
    d = D(w, h)
    top = 319
    gap = [(70, top), (314, top), (302, h), (82, h)]
    d.grad_poly(gap, (52, 26, 98), (8, 3, 22))
    d.glow(18, lambda t: t.ell(192, 560, 120, 50, fill=(130, 70, 220, 90)))
    d.line([(70, top), (82, h)], fill=(196, 168, 255, 150), width=5)
    d.line([(314, top), (302, h)], fill=(196, 168, 255, 150), width=5)
    d.line([(70, top + 2), (314, top + 2)], fill=(0, 0, 0, 70), width=4)
    for i in range(7):
        y = top + 40 + i * 38
        d.line([(88 + i * 2, y), (110 + i * 2, y + 4)], fill=(120, 90, 190, 90), width=3)
        d.line([(296 - i * 2, y + 12), (276 - i * 2, y + 16)], fill=(120, 90, 190, 90), width=3)
    d.save("obs_pit.png")


def make_swing():
    d = D(768, 384)
    cx, cy = 192, 192
    for i in range(10):
        a = i * math.pi * 2 / 10
        tip = (cx + math.cos(a) * 88, cy + math.sin(a) * 88)
        l = (cx + math.cos(a - 0.2) * 52, cy + math.sin(a - 0.2) * 52)
        r = (cx + math.cos(a + 0.2) * 52, cy + math.sin(a + 0.2) * 52)
        d.poly([l, tip, r], fill=(214, 186, 232, 255), outline=(255, 238, 246, 255), width=4)
    ball = [(cx + math.cos(k * math.pi / 18) * 58, cy + math.sin(k * math.pi / 18) * 58) for k in range(36)]
    d.grad_poly(ball, (236, 122, 146), (140, 52, 84))
    d.ell(cx, cy, 58, 58, outline=(255, 232, 240, 255), width=5)
    d.ell(cx - 18, cy - 20, 16, 11, fill=(255, 255, 255, 120))
    ox = 384
    d.rrect(ox + 192 - 62, 150, ox + 192 + 62, 184, 12, fill=(206, 186, 242, 255), outline=(255, 240, 250, 255), width=4)
    d.ell(ox + 192, 212, 26, 26, fill=(160, 128, 214, 255), outline=(255, 240, 250, 255), width=5)
    d.ell(ox + 192, 212, 9, 9, fill=(255, 240, 250, 255))
    d.save("obs_swing.png")


def make_laser():
    d = D(768, 384)
    for f in range(2):
        ox = f * 384
        cx = ox + 192
        on = f == 1
        if on:
            d.glow(14, lambda t: t.rrect(cx - 34, 100, cx + 34, 330, 20, fill=(255, 70, 140, 150)))
            d.rrect(cx - 18, 108, cx + 18, 326, 10, fill=(255, 104, 160, 235))
            d.rrect(cx - 6, 108, cx + 6, 326, 4, fill=(255, 240, 246, 255))
        else:
            y = 124
            while y < 316:
                d.rrect(cx - 4, y, cx + 4, y + 16, 3, fill=(255, 130, 170, 90))
                y += 30
        lens = (255, 120, 170, 255) if on else (150, 100, 160, 255)
        d.rrect(cx - 34, 318, cx + 34, 352, 12, fill=(122, 98, 176, 255), outline=(236, 220, 255, 255), width=4)
        d.ell(cx, 318, 15, 12, fill=lens, outline=(255, 240, 250, 255), width=3)
        d.rrect(cx - 34, 76, cx + 34, 110, 12, fill=(122, 98, 176, 255), outline=(236, 220, 255, 255), width=4)
        d.ell(cx, 110, 15, 12, fill=lens, outline=(255, 240, 250, 255), width=3)
    d.save("obs_laser.png")


def make_wisp():
    d = D(3072, 384)
    for f in range(8):
        ox = f * 384
        ph = f / 8.0 * math.pi * 2
        cx = ox + 150
        cy = 192
        pulse = 1.0 + 0.1 * math.sin(ph)
        for k in range(1, 5):
            tx = cx + 52 * k
            ty = cy + math.sin(ph + k * 0.9) * 10 * k * 0.5
            rr = 26 - k * 4.5
            d.glow(6, lambda t, tx=tx, ty=ty, rr=rr, k=k: t.ell(tx, ty, rr, rr, fill=(150, 205, 255, int(150 - k * 30))))
        d.glow(22, lambda t: t.ell(cx, cy, 72 * pulse, 72 * pulse, fill=(120, 170, 255, 120)))
        d.ell(cx, cy, 40 * pulse, 40 * pulse, fill=(150, 205, 255, 255), outline=(235, 248, 255, 255), width=4)
        d.ell(cx, cy, 24 * pulse, 24 * pulse, fill=(226, 244, 255, 255))
        d.ell(cx - 6, cy - 7, 10, 10, fill=(255, 255, 255, 255))
    d.save("obs_wisp.png")


def make_jelly():
    d = D(3072, 384)
    for f in range(8):
        ox = f * 384
        ph = f / 8.0 * math.pi * 2
        cx = ox + 192
        cy = 160
        sx = 1.0 + 0.07 * math.sin(ph)
        sy = 1.0 - 0.06 * math.sin(ph)
        for k in range(5):
            bx = cx + (k - 2) * 28 * sx
            pts = []
            for j in range(0, 11):
                t = j / 10.0
                pts.append((bx + math.sin(ph + k * 1.1 + t * 4.0) * 12 * t, cy + 34 + t * 104))
            d.line(pts, fill=(240, 170, 255, 190), width=9)
            d.line(pts, fill=(255, 226, 255, 120), width=3)
        dome = []
        for k in range(0, 19):
            a = math.pi + k * math.pi / 18
            dome.append((cx + math.cos(a) * 82 * sx, cy + 30 + math.sin(a) * 86 * sy))
        dome.append((cx + 82 * sx, cy + 30))
        dome.append((cx - 82 * sx, cy + 30))
        d.glow(14, lambda t, dome=dome: t.poly(dome, fill=(236, 150, 255, 130)))
        d.grad_poly(dome, (252, 190, 255), (196, 120, 236))
        d.poly(dome, outline=(255, 238, 255, 255), width=4)
        d.ell(cx - 30 * sx, cy - 22, 20, 12, fill=(255, 255, 255, 150))
        d.ell(cx + 4, cy + 4, 7, 7, fill=(120, 60, 170, 255))
        d.ell(cx + 34, cy + 4, 7, 7, fill=(120, 60, 170, 255))
    d.save("obs_jelly.png")


def make_ghost():
    d = D(3072, 384)
    for f in range(8):
        ox = f * 384
        ph = f / 8.0 * math.pi * 2
        cx = ox + 192
        cy = 150 + math.sin(ph) * 5
        body = []
        for k in range(0, 19):
            a = math.pi + k * math.pi / 18
            body.append((cx + math.cos(a) * 74, cy + math.sin(a) * 74))
        base = cy + 96
        for k in range(0, 13):
            t = k / 12.0
            x = cx + 74 - t * 148
            y = base + math.sin(t * math.pi * 6 + ph) * 12
            body.append((x, y))
        d.glow(16, lambda t, body=body: t.poly(body, fill=(190, 200, 255, 130)))
        d.grad_poly(body, (250, 250, 255), (196, 204, 244))
        d.poly(body, outline=(255, 255, 255, 255), width=4)
        d.ell(cx - 26, cy - 6, 11, 15, fill=(44, 30, 92, 255))
        d.ell(cx + 26, cy - 6, 11, 15, fill=(44, 30, 92, 255))
        d.ell(cx, cy + 34, 12, 8 + 3 * math.sin(ph), fill=(44, 30, 92, 255))
        d.ell(cx - 22, cy - 11, 4, 4, fill=(255, 255, 255, 255))
        d.ell(cx + 30, cy - 11, 4, 4, fill=(255, 255, 255, 255))
    d.save("obs_ghost.png")


def make_finish():
    d = D(384, 384)
    for x in (62, 322):
        d.rrect(x - 11, 70, x + 11, 352, 6, fill=(244, 234, 255, 255), outline=(180, 150, 230, 255), width=4)
        d.ell(x, 62, 15, 15, fill=(255, 214, 74, 255), outline=(255, 247, 205, 255), width=4)
    cols = 13
    cw = (322 - 62) / cols
    for r in range(3):
        for c in range(cols):
            x0 = 62 + c * cw
            dark = (r + c) % 2 == 0
            col = (62, 32, 122, 255) if dark else (255, 255, 255, 255)
            d.rrect(x0, 84 + r * 24, x0 + cw + 0.5, 84 + (r + 1) * 24, 0, fill=col)
    d.rrect(62, 84, 322, 156, 4, outline=(255, 214, 74, 255), width=4)
    d.save("finish.png")


def main():
    make_stars()
    make_lock()
    make_pit()
    make_swing()
    make_laser()
    make_wisp()
    make_jelly()
    make_ghost()
    make_finish()


if __name__ == "__main__":
    main()
