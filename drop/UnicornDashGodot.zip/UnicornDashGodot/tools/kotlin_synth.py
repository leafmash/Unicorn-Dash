import math
import numpy as np
from scipy.signal import lfilter

SR = 44100
OSC_SINE, OSC_TRI, OSC_SAW, OSC_SQUARE, OSC_NOISE = 0, 1, 2, 3, 4
FLT_NONE, FLT_LOW, FLT_BAND, FLT_HIGH = 0, 1, 2, 3
BUS_FX, BUS_MUS = 0, 1
FLOOR = 0.0001
Q059 = 10.0 ** (0.5 / 20.0)
THRESH = -18.0
KNEE = 26.0
RATIO = 3.5
MAKEUP = 2.4


def tone(f, at=0.0, len=0.2, vol=0.1, type=OSC_SINE, att=0.008, hold=0.0, cut=0.0, cutTo=0.0, det=0.0, to=0.0, bus=BUS_FX):
    return dict(noise=False, f=f, at=at, len=len, vol=vol, type=type, att=att, hold=hold, cut=cut, cutTo=cutTo, det=det, to=to, q=1.122, ft=FLT_LOW if cut > 0.0 else FLT_NONE, bus=bus)


def puff(f=2000.0, at=0.0, len=0.1, vol=0.05, to=0.0, att=0.004, q=1.0, ft=FLT_BAND, bus=BUS_FX):
    qlin = 10.0 ** (q / 20.0) if ft == FLT_HIGH else q
    return dict(noise=True, f=f, at=at, len=len, vol=vol, type=OSC_NOISE, att=att, hold=0.0, cut=f, cutTo=to, det=0.0, to=0.0, q=qlin, ft=ft, bus=bus)


def bells(lst, step, ln, vol):
    out = []
    for i, f in enumerate(lst):
        at = i * step
        out.append(tone(f=f, at=at, len=ln, vol=vol, type=OSC_SINE, att=0.005))
        out.append(tone(f=f * 2.0, at=at, len=ln * 0.6, vol=vol * 0.3, type=OSC_SINE, att=0.004))
        out.append(tone(f=f * 1.005, at=at, len=ln * 0.8, vol=vol * 0.4, type=OSC_TRI, att=0.006))
    return out


def coefs(ftype, freq, q):
    f = max(10.0, min(freq, SR * 0.45))
    w0 = 2.0 * math.pi * f / SR
    cw = math.cos(w0)
    alpha = math.sin(w0) / (2.0 * max(q, 0.0001))
    a0 = 1.0 + alpha
    if ftype == FLT_LOW:
        b0 = (1.0 - cw) / 2.0 / a0
        b1 = (1.0 - cw) / a0
        b2 = b0
    elif ftype == FLT_HIGH:
        b0 = (1.0 + cw) / 2.0 / a0
        b1 = -(1.0 + cw) / a0
        b2 = b0
    else:
        b0 = alpha / a0
        b1 = 0.0
        b2 = -alpha / a0
    return np.array([b0, b1, b2]), np.array([1.0, -2.0 * cw / a0, (1.0 - alpha) / a0])


def blep(p, dt):
    out = np.zeros_like(p)
    lo = p < dt
    t = p[lo] / dt[lo]
    out[lo] = t + t - t * t - 1.0
    hi = p > 1.0 - dt
    t = (p[hi] - 1.0) / dt[hi]
    out[hi] = t * t + t + t + 1.0
    return out


def wave(osc, p, dt):
    if osc == OSC_SINE:
        return np.sin(p * 2.0 * math.pi)
    if osc == OSC_TRI:
        return np.where(p < 0.5, 4.0 * p - 1.0, 3.0 - 4.0 * p)
    if osc == OSC_SAW:
        return 2.0 * p - 1.0 - blep(p, dt)
    h = np.where(p + 0.5 >= 1.0, p - 0.5, p + 0.5)
    return np.where(p < 0.5, 1.0, -1.0) + blep(p, dt) - blep(h, dt)


def phase(dt):
    c = np.cumsum(dt) - dt
    return c - np.floor(c)


def envelope(n, vol, att, hold, length):
    lenN = max(1, int(length * SR))
    attN = max(1, int(att * SR))
    holdN = int(hold * SR) if hold > 0.0 else 0
    relN = max(1, lenN - attN - holdN)
    attR = (vol / FLOOR) ** (1.0 / attN)
    relR = (FLOOR / vol) ** (1.0 / relN)
    ga = FLOOR * attR ** (np.minimum(n, attN - 1) + 1.0)
    m = np.minimum(n, lenN - 1)
    gr = np.where(m < attN + holdN, vol, vol * relR ** (np.maximum(m - attN - holdN, 0) + 1.0))
    return np.where(n < attN, ga, gr), lenN


def run_filter(x, ftype, cut, cutTo, q, lenN, chunk):
    if ftype == FLT_NONE:
        return x
    if cutTo <= 0.0 or cut <= 0.0 or cutTo == cut:
        b, a = coefs(ftype, cut, q)
        return lfilter(b, a, x)
    ratio = (cutTo / cut) ** (1.0 / lenN)
    out = np.empty_like(x)
    zi = np.zeros(2)
    i = 0
    n = len(x)
    while i < n:
        j = min(n, i + chunk)
        cn = cut * ratio ** (min(i, lenN) + 1.0)
        b, a = coefs(ftype, cn, q)
        y, zi = lfilter(b, a, x[i:j], zi=zi)
        out[i:j] = y
        i = j
    return out


def render_voice(s, noise_tab, rng, chunk):
    length = s["len"]
    lenN = max(1, int(length * SR))
    total = int((length + 0.05) * SR)
    n = np.arange(total)
    if s["noise"]:
        pos = int(rng.random() * 0.4 * SR)
        idx = (pos + n) % len(noise_tab)
        x = noise_tab[idx]
    else:
        f = s["f"]
        to = s["to"]
        ratio = (to / f) ** (1.0 / lenN) if to > 0.0 and f > 0.0 else 1.0
        freq = f * ratio ** np.minimum(n, lenN)
        dt = freq / SR
        if s["det"] != 0.0:
            d1 = dt * 2.0 ** (-s["det"] / 1200.0)
            d2 = dt * 2.0 ** (s["det"] / 1200.0)
            x = wave(s["type"], phase(d1), d1) + wave(s["type"], phase(d2), d2)
        else:
            x = wave(s["type"], phase(dt), dt)
    x = run_filter(x, s["ft"], s["cut"], s["cutTo"], s["q"], lenN, chunk)
    g, _ = envelope(n, s["vol"], s["att"], s["hold"], length)
    return x * g


def mix_specs(specs, seconds, rng, chunk=8):
    noise_tab = rng.uniform(-1.0, 1.0, SR)
    total = int(seconds * SR)
    buses = [np.zeros(total), np.zeros(total)]
    for s in specs:
        start = int(s["at"] * SR)
        if start >= total:
            continue
        v = render_voice(s, noise_tab, rng, chunk)
        end = min(total, start + len(v))
        buses[s["bus"]][start:end] += v[: end - start]
    return buses[BUS_FX], buses[BUS_MUS]


def comb_run(x, size, fb, damp):
    n = len(x)
    out = np.zeros(n)
    buf = np.zeros(size)
    store = 0.0
    i = 0
    while i < n:
        m = min(size, n - i)
        o = buf[:m].copy()
        st, _ = lfilter([1.0 - damp], [1.0, -damp], o, zi=[damp * store])
        buf[:m] = x[i : i + m] + st * fb
        store = st[-1]
        out[i : i + m] = o
        i += m
    return out


def allpass_run(x, size, gain):
    n = len(x)
    out = np.zeros(n)
    buf = np.zeros(size)
    i = 0
    while i < n:
        m = min(size, n - i)
        b = buf[:m].copy()
        out[i : i + m] = -x[i : i + m] + b
        buf[:m] = x[i : i + m] + b * gain
        i += m
    return out


def reverb(x):
    delays = [1557, 1617, 1491, 1422, 1277, 1356]
    s = np.zeros(len(x))
    for d in delays:
        s += comb_run(x, d, 10.0 ** (-3.0 * d / (1.8 * SR)), 0.25)
    s /= len(delays)
    return allpass_run(allpass_run(s, 556, 0.5), 225, 0.5) * 1.6


def compress(y):
    attK = math.exp(-1.0 / (0.004 * SR))
    relK = math.exp(-1.0 / (0.25 * SR))
    env = 0.0
    comp = 1.0
    out = np.empty(len(y))
    ys = np.abs(y).tolist()
    yl = y.tolist()
    ol = [0.0] * len(yl)
    for i in range(len(yl)):
        a = ys[i]
        if a > env:
            env = attK * env + (1.0 - attK) * a
        else:
            env = relK * env + (1.0 - relK) * a
        if (i & 7) == 0:
            db = 20.0 * math.log10(env + 1.0e-9)
            over = db - THRESH
            if 2.0 * over < -KNEE:
                red = 0.0
            elif 2.0 * abs(over) <= KNEE:
                red = (1.0 / RATIO - 1.0) * (over + KNEE / 2.0) ** 2 / (2.0 * KNEE)
            else:
                red = (1.0 / RATIO - 1.0) * over
            comp = 10.0 ** (red / 20.0) * MAKEUP
        o = yl[i] * comp * 0.9
        ol[i] = 1.0 if o > 1.0 else (-1.0 if o < -1.0 else o)
    return np.array(ol)


def master(fx, mus, mus_gain=0.9, fx_gain=1.0):
    bus = mus * mus_gain + fx * fx_gain
    wet = reverb(bus * 0.3) * 0.85
    b, a = coefs(FLT_LOW, 18000.0, Q059)
    y = lfilter(b, a, bus + wet)
    return compress(y)
