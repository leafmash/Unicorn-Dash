import os
import subprocess
import sys
import wave
from multiprocessing import Pool

import numpy as np
from scipy.signal import resample_poly

import kotlin_synth as k
from kotlin_synth import tone, puff, bells, OSC_SINE, OSC_TRI, OSC_SAW, OSC_SQUARE, FLT_HIGH, BUS_MUS, SR

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "audio"))
MUSIC_RATE = 32000

ZONES = [
    (0, 0, 1.0), (2, 1, 1.05), (-3, 2, 1.12), (-5, 3, 1.0), (5, 1, 0.95), (-1, 2, 0.9),
    (3, 0, 1.08), (-2, 1, 1.04), (7, 2, 0.96), (4, 3, 0.88), (-4, 0, 1.12), (1, 1, 1.0),
    (6, 2, 0.94), (-6, 3, 1.15), (8, 0, 0.9), (9, 1, 1.0), (-7, 2, 1.1), (10, 3, 0.92),
]

CH = [[0, 3, 7], [-4, 0, 3], [3, 7, 10], [-2, 2, 5]]
MEL = [
    [(0, 12), (6, 15), (8, 14), (12, 10)],
    [(0, 15), (6, 12), (10, 8), (12, 12)],
    [(0, 19), (6, 15), (8, 14), (12, 15)],
    [(0, 14), (4, 17), (8, 14), (12, 10)],
]


def clampi(v, a, b):
    return max(a, min(b, v))


def sfx_specs(n, a=0.0):
    s = []
    if n == "jump":
        s += [tone(f=340.0, to=640.0, len=0.17, vol=0.1, att=0.006)]
        s += [tone(f=680.0, to=1280.0, len=0.12, vol=0.028, type=OSC_TRI)]
        s += [puff(f=1800.0, to=700.0, len=0.12, vol=0.02, q=0.8)]
    elif n == "djump":
        for i, f in enumerate([660.0, 880.0, 1320.0]):
            s += [tone(f=f, at=i * 0.045, len=0.24, vol=0.055, att=0.004)]
        s += [puff(f=3000.0, to=7000.0, len=0.22, vol=0.022, q=1.2)]
    elif n == "land":
        s += [tone(f=160.0, to=60.0, len=0.15, vol=0.05 + 0.1 * a, type=OSC_SINE)]
        s += [puff(f=500.0, len=0.08, vol=0.03 + 0.05 * a, q=0.6)]
    elif n == "coin":
        steps = [0, 2, 4, 7, 9]
        c = 1.0 if a == 0.0 else a
        idx = clampi(int(c - 1.0), 0, 4)
        f = 784.0 * 2.0 ** (steps[idx] / 12.0)
        s += [tone(f=f, len=0.34, vol=0.075, att=0.003)]
        s += [tone(f=f * 2.0, len=0.22, vol=0.026, att=0.003)]
        s += [tone(f=f * 3.01, len=0.12, vol=0.01, att=0.003)]
    elif n == "shield":
        s += bells([392.0, 587.0, 784.0, 988.0], 0.06, 0.5, 0.05)
    elif n == "skill":
        s += bells([392.0, 523.0, 784.0, 1047.0], 0.045, 0.45, 0.06)
        s += [puff(f=1200.0, to=5000.0, len=0.3, vol=0.04, q=0.8)]
    elif n == "ready":
        s += bells([988.0, 1319.0], 0.07, 0.4, 0.045)
    elif n == "life":
        s += bells([659.0, 784.0, 988.0, 1319.0], 0.07, 0.5, 0.05)
    elif n == "rain":
        s += bells([784.0, 988.0, 1175.0, 1568.0, 1976.0], 0.05, 0.5, 0.05)
    elif n == "wings":
        s += bells([330.0, 494.0, 659.0, 988.0, 1319.0], 0.06, 0.6, 0.05)
        s += [puff(f=2600.0, to=6000.0, len=0.3, vol=0.03, q=1.0)]
    elif n == "sx2":
        s += bells([523.0, 659.0, 784.0, 1047.0, 1568.0], 0.05, 0.5, 0.05)
    elif n == "flap":
        s += [tone(f=520.0, to=780.0, len=0.1, vol=0.04, type=OSC_TRI)]
        s += [puff(f=2400.0, to=1200.0, len=0.08, vol=0.02, q=0.8)]
    elif n == "revive":
        s += bells([392.0, 523.0, 659.0, 784.0, 1047.0, 1319.0], 0.07, 0.8, 0.06)
        s += [puff(f=800.0, to=4000.0, len=0.5, vol=0.05, q=0.6)]
    elif n == "magnet":
        s += bells([440.0, 554.0, 659.0, 880.0], 0.06, 0.5, 0.05)
    elif n == "star":
        s += bells([523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0], 0.05, 0.55, 0.05)
    elif n == "break":
        s += [puff(f=1400.0, to=260.0, len=0.35, vol=0.16, q=0.7)]
        s += [tone(f=260.0, to=58.0, len=0.35, vol=0.13, type=OSC_TRI)]
    elif n == "die":
        s += [tone(f=420.0, to=70.0, len=0.85, vol=0.07, type=OSC_SAW, cut=2200.0, cutTo=200.0)]
        s += [tone(f=110.0, to=38.0, len=0.7, vol=0.28)]
        s += [puff(f=3200.0, to=200.0, len=0.6, vol=0.12, q=0.7)]
    elif n == "click":
        s += [tone(f=900.0, to=700.0, len=0.06, vol=0.05, type=OSC_TRI)]
    elif n == "back":
        s += [tone(f=620.0, to=430.0, len=0.08, vol=0.05, type=OSC_TRI)]
    elif n == "buy":
        s += bells([523.0, 659.0, 784.0, 1047.0], 0.07, 0.6, 0.06)
    elif n == "deny":
        s += [tone(f=210.0, len=0.12, vol=0.05, type=OSC_SQUARE, cut=900.0)]
        s += [tone(f=160.0, at=0.1, len=0.16, vol=0.05, type=OSC_SQUARE, cut=800.0)]
    elif n == "mission":
        s += bells([659.0, 784.0, 988.0, 1319.0], 0.09, 0.7, 0.06)
    elif n == "zone":
        s += [tone(f=196.0, to=392.0, len=1.3, vol=0.05, att=0.5, det=8.0)]
        s += [puff(f=400.0, to=3200.0, len=1.0, vol=0.04, att=0.6, q=0.5)]
    elif n == "milestone":
        s += bells([784.0, 988.0, 1175.0], 0.08, 0.6, 0.05)
    elif n == "gift":
        s += bells([523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0], 0.08, 0.7, 0.05)
    elif n == "slow":
        s += [tone(f=900.0, to=180.0, len=0.55, vol=0.07, type=OSC_TRI, cut=2400.0, cutTo=300.0)]
        s += [puff(f=2400.0, to=300.0, len=0.5, vol=0.03, q=0.8)]
    elif n == "mini":
        s += [tone(f=260.0, to=1100.0, len=0.3, vol=0.06, type=OSC_TRI)]
        s += bells([1175.0, 1568.0], 0.06, 0.4, 0.04)
    elif n == "coin2":
        s += bells([880.0, 1175.0, 1760.0], 0.05, 0.5, 0.05)
    elif n == "near":
        s += [tone(f=1300.0, to=1900.0, len=0.12, vol=0.06, type=OSC_TRI)]
        s += [puff(f=5000.0, to=9000.0, len=0.1, vol=0.03, q=1.0)]
    elif n == "fall":
        s += [tone(f=700.0, to=110.0, len=0.9, vol=0.06, type=OSC_SINE)]
        s += [puff(f=1200.0, to=200.0, len=0.7, vol=0.03, q=0.6)]
    elif n == "zap":
        s += [tone(f=1900.0, to=260.0, len=0.4, vol=0.07, type=OSC_SAW, cut=3200.0, cutTo=400.0)]
        s += [puff(f=6000.0, to=500.0, len=0.45, vol=0.1, q=0.6)]
    elif n == "neigh":
        s += [tone(f=620.0, to=1050.0, len=0.22, vol=0.06, type=OSC_SAW, cut=2600.0, cutTo=1200.0)]
        s += [tone(f=1050.0, to=560.0, at=0.22, len=0.4, vol=0.06, type=OSC_SAW, cut=2600.0, cutTo=700.0)]
        s += [puff(f=3000.0, to=1500.0, len=0.5, vol=0.03, q=0.8)]
    elif n == "fan3":
        s += bells([523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0, 2093.0], 0.08, 0.9, 0.06)
        s += [tone(f=131.0, len=1.6, vol=0.1, type=OSC_TRI, cut=800.0)]
        s += [tone(f=196.0, at=0.3, len=1.3, vol=0.08, type=OSC_TRI, cut=900.0)]
        s += [tone(f=262.0, at=0.6, len=1.2, vol=0.07, type=OSC_TRI, cut=1000.0)]
        s += [puff(f=6000.0, to=12000.0, at=0.5, len=0.8, vol=0.03, q=1.0)]
    elif n == "fan2":
        s += bells([523.0, 659.0, 784.0, 1047.0, 1319.0], 0.1, 0.8, 0.055)
        s += [tone(f=131.0, len=1.2, vol=0.09, type=OSC_TRI, cut=800.0)]
        s += [tone(f=196.0, at=0.3, len=1.0, vol=0.07, type=OSC_TRI, cut=900.0)]
    elif n == "fan1":
        s += bells([523.0, 659.0, 784.0], 0.13, 0.7, 0.05)
        s += [tone(f=131.0, len=0.9, vol=0.08, type=OSC_TRI, cut=800.0)]
    elif n == "tick":
        hi = a != 0.0
        s += [tone(f=988.0 if hi else 660.0, len=0.3 if hi else 0.12, vol=0.06, att=0.004)]
    elif n == "pop":
        f = [784.0, 988.0, 1319.0][clampi(int(a), 0, 2)]
        s += bells([f], 0.05, 0.6, 0.07)
        s += [puff(f=5000.0, to=9000.0, len=0.12, vol=0.02, q=1.0)]
    elif n == "win":
        s += bells([523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0, 2093.0], 0.09, 0.85, 0.055)
        s += [tone(f=131.0, len=1.2, vol=0.12, type=OSC_TRI, cut=800.0)]
        s += [tone(f=196.0, at=0.35, len=1.0, vol=0.08, type=OSC_TRI, cut=900.0)]
    elif n == "unlock":
        s += bells([392.0, 523.0, 659.0, 784.0, 1047.0, 1319.0], 0.1, 0.9, 0.06)
        s += [tone(f=130.0, to=260.0, len=1.1, vol=0.07, att=0.3, det=8.0)]
        s += [puff(f=600.0, to=6000.0, len=0.9, vol=0.04, att=0.5, q=0.5)]
    return s


SFX_JOBS = [
    ("jump", 0.0, "jump"), ("djump", 0.0, "djump"), ("land_soft", 0.25, "land"), ("land_hard", 1.0, "land"),
    ("coin_1", 1.0, "coin"), ("coin_2", 2.0, "coin"), ("coin_3", 3.0, "coin"), ("coin_4", 4.0, "coin"), ("coin_5", 5.0, "coin"),
    ("shield", 0.0, "shield"), ("skill", 0.0, "skill"), ("ready", 0.0, "ready"), ("life", 0.0, "life"), ("rain", 0.0, "rain"),
    ("wings", 0.0, "wings"), ("sx2", 0.0, "sx2"), ("flap", 0.0, "flap"), ("revive", 0.0, "revive"), ("magnet", 0.0, "magnet"),
    ("star", 0.0, "star"), ("break", 0.0, "break"), ("die", 0.0, "die"), ("click", 0.0, "click"), ("back", 0.0, "back"),
    ("buy", 0.0, "buy"), ("deny", 0.0, "deny"), ("mission", 0.0, "mission"), ("zone", 0.0, "zone"), ("milestone", 0.0, "milestone"),
    ("gift", 0.0, "gift"), ("slow", 0.0, "slow"), ("mini", 0.0, "mini"), ("coin2", 0.0, "coin2"), ("near", 0.0, "near"),
    ("fall", 0.0, "fall"), ("zap", 0.0, "zap"), ("neigh", 0.0, "neigh"), ("fan3", 0.0, "fan3"), ("fan2", 0.0, "fan2"),
    ("fan1", 0.0, "fan1"), ("tick_lo", 0.0, "tick"), ("tick_hi", 1.0, "tick"), ("pop_0", 0.0, "pop"), ("pop_1", 1.0, "pop"),
    ("pop_2", 2.0, "pop"), ("win", 0.0, "win"), ("unlock", 0.0, "unlock"),
]


def save(path, data, rate):
    pcm = (np.clip(data, -1.0, 1.0) * 32767.0).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())


def bake_sfx(job):
    name, a, base = job
    specs = sfx_specs(base, a)
    end = max(s["at"] + s["len"] + 0.05 for s in specs)
    secs = end + 1.8
    rng = np.random.default_rng(11)
    fx, mu = k.mix_specs(specs, secs, rng, 8)
    y = k.master(fx, mu, 0.0, 1.0)
    loud = np.where(np.abs(y) > 0.004)[0]
    cut = int(min(len(y), (loud[-1] if len(loud) else len(y)) + 0.12 * SR))
    y = y[:cut]
    peak = float(np.abs(y).max())
    y = y * float(np.clip(0.5 / max(peak, 1e-6), 1.0, 3.0))
    fade = min(len(y), int(0.12 * SR))
    y[-fade:] *= np.linspace(1.0, 0.0, fade)
    wav = os.path.join(OUT, name + ".wav")
    save(wav, y, SR)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "5", os.path.join(OUT, name + ".ogg")], check=True)
    os.remove(wav)
    return name


def music_specs(key, pr, tm, inten, loops):
    dur = 0.15 * tm
    steps = 128 * loops
    specs = []
    hz = lambda n: 261.63 * 2.0 ** (n / 12.0)
    for stp in range(steps):
        i = stp % 16
        bar = ((stp >> 4) + pr) % 4
        cyc = (stp >> 6) & 1
        at = stp * dur + (dur * 0.1 if i % 2 == 1 else 0.0)
        ch = CH[bar]
        if i == 0:
            for n in ch:
                specs.append(tone(f=hz(n + key), at=at, len=dur * 17.0, hold=dur * 10.0, att=0.6, type=OSC_TRI, vol=0.026, det=6.0, cut=1200.0, bus=BUS_MUS))
            specs.append(tone(f=hz(ch[0] + key - 12), at=at, len=dur * 17.0, hold=dur * 10.0, att=0.5, vol=0.05, bus=BUS_MUS))
        if i in (0, 6, 8, 14):
            specs.append(tone(f=hz(ch[0] + key - 12), at=at, len=dur * 3.0, type=OSC_TRI, vol=0.08 + 0.05 * inten, att=0.01, cut=900.0, bus=BUS_MUS))
        if i % 2 == 0:
            order = [0, 1, 2, 1, 0, 2, 1, 2]
            idx = order[i >> 1]
            n = ch[idx] + 12 + (12 if (cyc == 1 and idx == 2) else 0)
            specs.append(tone(f=hz(n + key), at=at, len=dur * 2.6, type=OSC_TRI, vol=0.026 + 0.018 * inten, att=0.004, cut=3600.0, cutTo=800.0, det=4.0, bus=BUS_MUS))
        for m in MEL[bar]:
            if m[0] != i:
                continue
            f = hz(m[1] + key + (12 if cyc == 1 else 0))
            specs.append(tone(f=f, at=at, len=dur * 6.0, vol=0.04, att=0.012, bus=BUS_MUS))
            specs.append(tone(f=f * 2.0, at=at, len=dur * 3.0, vol=0.01, att=0.01, bus=BUS_MUS))
        if inten > 0.5:
            d = inten
            if i % 4 == 0:
                specs.append(tone(f=140.0, to=44.0, at=at, len=0.22, vol=0.26 * d, att=0.003, bus=BUS_MUS))
            if i in (4, 12):
                specs.append(puff(f=2200.0, q=0.7, at=at, len=0.13, vol=0.07 * d, bus=BUS_MUS))
                specs.append(tone(f=190.0, to=120.0, at=at, len=0.1, type=OSC_TRI, vol=0.05 * d, bus=BUS_MUS))
            if i % 2 == 1:
                specs.append(puff(f=9000.0, ft=FLT_HIGH, q=0.4, at=at, len=0.04, vol=0.03 * d, bus=BUS_MUS))
            if i % 8 == 6:
                specs.append(puff(f=8000.0, ft=FLT_HIGH, q=0.4, at=at, len=0.16, vol=0.025 * d, bus=BUS_MUS))
    return specs, dur


def bake_music(job):
    name, key, pr, tm, inten = job
    loop_n = int(round(128 * 0.15 * tm * SR))
    tm_adj = loop_n / (128 * 0.15 * SR)
    specs, dur = music_specs(key, pr, tm_adj, inten, 3)
    rng = np.random.default_rng(5)
    fx, mu = k.mix_specs(specs, 3 * loop_n / SR + 1.0, rng, 32)
    y = k.master(fx, mu, 0.9, 0.0)
    seg = y[loop_n : 2 * loop_n]
    out = resample_poly(seg, MUSIC_RATE, SR)
    out = out * (0.89 / max(0.89, np.abs(out).max()))
    wav = os.path.join(OUT, name + ".wav")
    save(wav, out, MUSIC_RATE)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "4", os.path.join(OUT, name + ".ogg")], check=True)
    os.remove(wav)
    return name


def main():
    os.makedirs(OUT, exist_ok=True)
    only = sys.argv[1] if len(sys.argv) > 1 else "all"
    with Pool() as p:
        if only in ("all", "sfx"):
            for n in p.imap_unordered(bake_sfx, SFX_JOBS):
                print("sfx", n, flush=True)
        if only in ("all", "music"):
            jobs = [("music_menu", 0, 0, 1.0, 0.35)]
            for i, (key, pr, tm) in enumerate(ZONES):
                jobs.append(("music_z%d" % i, key, pr, tm, 1.0))
            for n in p.imap_unordered(bake_music, jobs):
                print("music", n, flush=True)


if __name__ == "__main__":
    main()
