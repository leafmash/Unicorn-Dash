import math
import os

import numpy as np
from PIL import Image, ImageChops, ImageDraw

N = 128
B = 96
O = 16
SS = 8
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "art", "ui"))

WHITE = (255, 255, 255, 255)
GOLD = (255, 210, 63, 255)
GOLD_DARK = (255, 176, 0, 255)
HEART = (255, 90, 140, 255)


def px(f):
    return (O + f * B) * SS


def ln(f):
    return f * B * SS


class Icon:
    def __init__(self):
        self.size = (N * SS, N * SS)
        self.img = Image.new("RGBA", self.size, (0, 0, 0, 0))

    def mask(self):
        m = Image.new("L", self.size, 0)
        return m, ImageDraw.Draw(m)

    def paint(self, m, fill):
        if isinstance(fill, tuple):
            layer = Image.new("RGBA", self.size, fill)
        else:
            layer = fill.copy()
        a = ImageChops.multiply(layer.getchannel("A"), m)
        layer.putalpha(a)
        self.img.alpha_composite(layer)

    def vgrad(self, colors):
        h = N * SS
        y0 = O * SS
        y1 = (O + B) * SS
        ys = np.arange(h, dtype=np.float32)
        t = np.clip((ys - y0) / float(y1 - y0), 0.0, 1.0)
        pos = np.linspace(0.0, 1.0, len(colors))
        arr = np.zeros((h, N * SS, 4), dtype=np.float32)
        for ch in range(4):
            col = np.interp(t, pos, [c[ch] for c in colors])
            arr[:, :, ch] = col[:, None]
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGBA")

    def circle(self, cx, cy, r, fill):
        m, d = self.mask()
        d.ellipse([px(cx) - ln(r), px(cy) - ln(r), px(cx) + ln(r), px(cy) + ln(r)], fill=255)
        self.paint(m, fill)

    def ring(self, cx, cy, r, w, fill):
        m, d = self.mask()
        ro = ln(r) + ln(w) / 2
        ri = max(ln(r) - ln(w) / 2, 0)
        d.ellipse([px(cx) - ro, px(cy) - ro, px(cx) + ro, px(cy) + ro], fill=255)
        d.ellipse([px(cx) - ri, px(cy) - ri, px(cx) + ri, px(cy) + ri], fill=0)
        self.paint(m, fill)

    def rrect(self, x, y, w, h, r, fill):
        m, d = self.mask()
        d.rounded_rectangle([px(x), px(y), px(x + w), px(y + h)], radius=ln(r), fill=255)
        self.paint(m, fill)

    def rrect_stroke(self, x, y, w, h, r, sw, fill):
        m, d = self.mask()
        half = ln(sw) / 2
        d.rounded_rectangle([px(x) - half, px(y) - half, px(x + w) + half, px(y + h) + half], radius=ln(r) + half, fill=255)
        d.rounded_rectangle([px(x) + half, px(y) + half, px(x + w) - half, px(y + h) - half], radius=max(ln(r) - half, 0), fill=0)
        self.paint(m, fill)

    def poly(self, pts, fill):
        m, d = self.mask()
        d.polygon([(px(x), px(y)) for x, y in pts], fill=255)
        self.paint(m, fill)

    def stroke(self, pts, w, fill, closed=False, round_cap=True):
        m, d = self.mask()
        pp = [(px(x), px(y)) for x, y in pts]
        if closed:
            pp = pp + [pp[0]]
        r = ln(w) / 2
        for i in range(len(pp) - 1):
            x0, y0 = pp[i]
            x1, y1 = pp[i + 1]
            dx = x1 - x0
            dy = y1 - y0
            dist = math.hypot(dx, dy)
            if dist < 1e-6:
                continue
            nx = -dy / dist * r
            ny = dx / dist * r
            d.polygon([(x0 + nx, y0 + ny), (x1 + nx, y1 + ny), (x1 - nx, y1 - ny), (x0 - nx, y0 - ny)], fill=255)
        if round_cap or closed:
            for x, y in pp:
                d.ellipse([x - r, y - r, x + r, y + r], fill=255)
        self.paint(m, fill)

    def arc(self, x, y, w, h, start, sweep, sw, fill):
        cx = x + w / 2
        cy = y + h / 2
        rx = w / 2
        ry = h / 2
        steps = max(12, int(abs(sweep) / 2))
        pts = []
        for i in range(steps + 1):
            a = math.radians(start + sweep * i / steps)
            pts.append((cx + rx * math.cos(a), cy + ry * math.sin(a)))
        self.stroke(pts, sw, fill)

    def save(self, name):
        out = self.img.resize((N, N), Image.LANCZOS)
        out.save(os.path.join(OUT, "cp_%s.png" % name))
        return out


def star_pts(cx, cy, r):
    pts = []
    for i in range(10):
        rr = r * 0.46 if i % 2 == 1 else r
        a = -math.pi / 2 + i * math.pi / 5
        pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    return pts


def bezier(p0, p1, p2, p3, n=48):
    out = []
    for i in range(n + 1):
        t = i / n
        u = 1 - t
        x = u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0]
        y = u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]
        out.append((x, y))
    return out


def heart_pts(cx, cy, s):
    a = bezier((cx, cy + s * 0.9), (cx - s * 1.5, cy - s * 0.1), (cx - s * 0.8, cy - s * 1.2), (cx, cy - s * 0.4))
    b = bezier((cx, cy - s * 0.4), (cx + s * 0.8, cy - s * 1.2), (cx + s * 1.5, cy - s * 0.1), (cx, cy + s * 0.9))
    return a + b[1:]


def poly_grad(ic, pts, colors):
    m, d = ic.mask()
    d.polygon([(px(x), px(y)) for x, y in pts], fill=255)
    ic.paint(m, ic.vgrad(colors))


def coin():
    ic = Icon()
    m, d = ic.mask()
    d.ellipse([px(0), px(0), px(1), px(1)], fill=255)
    ic.paint(m, ic.vgrad([(255, 230, 128, 255), GOLD, GOLD_DARK]))
    ic.ring(0.5, 0.5, 0.5, 0.08, GOLD_DARK)
    ic.ring(0.5, 0.5, 0.29, 0.06, (255, 176, 0, 204))
    ic.circle(0.35, 0.34, 0.09, (255, 255, 255, 179))
    return ic


def heart():
    ic = Icon()
    pts = heart_pts(0.5, 0.5, 0.4)
    poly_grad(ic, pts, [(255, 140, 176, 255), HEART])
    ic.stroke(pts, 0.4 * 0.14, WHITE, closed=True)
    return ic


def star(on):
    ic = Icon()
    r = 0.5 * 0.92
    pts = star_pts(0.5, 0.5, r)
    if on:
        poly_grad(ic, pts, [(255, 240, 160, 255), GOLD])
        ic.stroke(pts, r * 0.14, GOLD_DARK, closed=True)
    else:
        ic.poly(pts, (255, 255, 255, 36))
        ic.stroke(pts, r * 0.14, (255, 255, 255, 87), closed=True)
    return ic


def lock():
    ic = Icon()
    ic.arc(0.28, 0.1, 0.44, 0.44, 180, 180, 0.12, WHITE)
    ic.rrect(0.2, 0.4, 0.6, 0.5, 0.1, WHITE)
    return ic


def gear():
    ic = Icon()
    r = 0.5
    for i in range(8):
        a = i * math.pi / 4
        ic.stroke(
            [(0.5 + math.cos(a) * r * 0.62, 0.5 + math.sin(a) * r * 0.62), (0.5 + math.cos(a) * r * 0.95, 0.5 + math.sin(a) * r * 0.95)],
            r * 0.34,
            WHITE,
        )
    ic.circle(0.5, 0.5, r * 0.62, WHITE)
    ic.circle(0.5, 0.5, r * 0.26, (74, 42, 152, 255))
    return ic


def sound(on):
    ic = Icon()
    ic.poly([(0.12, 0.38), (0.32, 0.38), (0.54, 0.18), (0.54, 0.82), (0.32, 0.62), (0.12, 0.62)], WHITE)
    sw = 0.09
    if on:
        ic.arc(0.4, 0.3, 0.4, 0.4, -45, 90, sw, WHITE)
        ic.arc(0.34, 0.16, 0.56, 0.68, -50, 100, sw, WHITE)
    else:
        ic.stroke([(0.66, 0.36), (0.9, 0.64)], sw, WHITE)
        ic.stroke([(0.9, 0.36), (0.66, 0.64)], sw, WHITE)
    return ic


def pause():
    ic = Icon()
    ic.rrect(0.22, 0.18, 0.18, 0.64, 0.06, WHITE)
    ic.rrect(0.6, 0.18, 0.18, 0.64, 0.06, WHITE)
    return ic


def arrow(left):
    ic = Icon()
    if left:
        pts = [(0.62, 0.2), (0.34, 0.5), (0.62, 0.8)]
    else:
        pts = [(0.38, 0.2), (0.66, 0.5), (0.38, 0.8)]
    ic.stroke(pts, 0.12, WHITE)
    return ic


def back():
    ic = Icon()
    ic.stroke([(0.58, 0.2), (0.3, 0.5), (0.58, 0.8)], 0.13, WHITE)
    return ic


def play():
    ic = Icon()
    ic.poly([(0.28, 0.16), (0.82, 0.5), (0.28, 0.84)], WHITE)
    return ic


def loop():
    ic = Icon()
    ic.arc(0.14, 0.2, 0.72, 0.6, 20, 300, 0.11, WHITE)
    ic.poly([(0.7, 0.18), (0.86, 0.36), (0.62, 0.4)], WHITE)
    return ic


def bag():
    ic = Icon()
    ic.rrect(0.18, 0.34, 0.64, 0.52, 0.1, WHITE)
    ic.arc(0.32, 0.12, 0.36, 0.44, 180, 180, 0.08, WHITE)
    return ic


def medal():
    ic = Icon()
    ic.stroke([(0.34, 0.1), (0.44, 0.4)], 0.1, WHITE)
    ic.stroke([(0.66, 0.1), (0.56, 0.4)], 0.1, WHITE)
    ic.circle(0.5, 0.62, 0.26, WHITE)
    ic.poly(star_pts(0.5, 0.62, 0.16), (106, 63, 208, 255))
    return ic


def board():
    ic = Icon()
    ic.rrect(0.12, 0.5, 0.22, 0.38, 0.05, WHITE)
    ic.rrect(0.39, 0.2, 0.22, 0.68, 0.05, WHITE)
    ic.rrect(0.66, 0.62, 0.22, 0.26, 0.05, WHITE)
    return ic


def spin():
    ic = Icon()
    r = 0.5 * 0.86
    ic.ring(0.5, 0.5, r, r * 0.16, WHITE)
    for i in range(6):
        a = i * math.pi / 3
        ic.stroke([(0.5, 0.5), (0.5 + math.cos(a) * r, 0.5 + math.sin(a) * r)], r * 0.1, WHITE)
    ic.circle(0.5, 0.5, r * 0.2, WHITE)
    return ic


def calendar():
    ic = Icon()
    ic.rrect_stroke(0.14, 0.2, 0.72, 0.66, 0.1, 0.09, WHITE)
    ic.stroke([(0.14, 0.4), (0.86, 0.4)], 0.09, WHITE, round_cap=False)
    ic.stroke([(0.34, 0.1), (0.34, 0.28)], 0.09, WHITE)
    ic.stroke([(0.66, 0.1), (0.66, 0.28)], 0.09, WHITE)
    return ic


def check():
    ic = Icon()
    ic.stroke([(0.2, 0.52), (0.42, 0.72), (0.8, 0.3)], 0.14, WHITE)
    return ic


ICONS = [
    ("coin", coin),
    ("heart", heart),
    ("star_on", lambda: star(True)),
    ("star_off", lambda: star(False)),
    ("lock", lock),
    ("gear", gear),
    ("sound_on", lambda: sound(True)),
    ("sound_off", lambda: sound(False)),
    ("pause", pause),
    ("arrow_l", lambda: arrow(True)),
    ("arrow_r", lambda: arrow(False)),
    ("back", back),
    ("play", play),
    ("loop", loop),
    ("bag", bag),
    ("medal", medal),
    ("board", board),
    ("spin", spin),
    ("calendar", calendar),
    ("check", check),
]


def sheet(images):
    cols = 5
    rows = (len(images) + cols - 1) // cols
    cell = N + 16
    out = Image.new("RGBA", (cols * cell, rows * cell), (60, 38, 136, 255))
    for i, im in enumerate(images):
        out.alpha_composite(im, ((i % cols) * cell + 8, (i // cols) * cell + 8))
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    made = []
    for name, fn in ICONS:
        made.append(fn().save(name))
    sheet(made).save(os.path.join(HERE, "cp_icons_preview.png"))
    print("icons", len(made))


if __name__ == "__main__":
    main()
