import math
import os

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

S = 4
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
OUT_DIR = os.path.join(ROOT, "art", "ui")
FONT = os.path.join(ROOT, "fonts", "Poppins-Bold.ttf")
OUTLINE = (0x3A, 0x24, 0x68)
RAINBOW = [(255, 95, 141), (255, 176, 95), (255, 224, 102), (111, 227, 165), (95, 184, 255), (165, 107, 255)]


def hexc(h, a=255):
    return ((h >> 16) & 255, (h >> 8) & 255, h & 255, a)


def vgrad(w, h, stops, y0=0, y1=None):
    if y1 is None:
        y1 = h
    ys = (np.arange(h, dtype=np.float32) - y0) / max(1.0, float(y1 - y0))
    ys = np.clip(ys, 0.0, 1.0)
    pos = [s[0] for s in stops]
    arr = np.zeros((h, w, 4), dtype=np.float32)
    for c in range(4):
        vals = [s[1][c] for s in stops]
        arr[:, :, c] = np.interp(ys, pos, vals)[:, None]
    return Image.fromarray(arr.clip(0, 255).astype(np.uint8), "RGBA")


def canvas(w, h):
    return Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0))


def rr_mask(size, box, r):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).rounded_rectangle(box, radius=r, fill=255)
    return m


def ring_mask(size, box, r, width):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).rounded_rectangle(box, radius=r, outline=255, width=width)
    return m


def fill(img, mask, stops, y0, y1):
    g = vgrad(img.width, img.height, stops, y0, y1)
    a = ImageChops.multiply(g.split()[3], mask)
    g.putalpha(a)
    img.alpha_composite(g)


def solid(img, mask, color):
    fill(img, mask, [(0, color), (1, color)], 0, img.height)


def drop_shadow(img, mask, dy, blur, alpha, color=(14, 4, 48)):
    m = ImageChops.offset(mask, 0, int(dy)).filter(ImageFilter.GaussianBlur(blur))
    m = m.point(lambda v: int(v * alpha))
    layer = Image.new("RGBA", img.size, color + (0,))
    layer.putalpha(m)
    img.alpha_composite(layer)


def soften(mask, px):
    return mask.filter(ImageFilter.GaussianBlur(px * S)).point(lambda v: 255 if v > 127 else 0)


def grow(mask, px):
    return mask.filter(ImageFilter.GaussianBlur(px * S * 0.8)).point(lambda v: 255 if v > 40 else 0)


def save(img, name, size=None):
    if size is None:
        size = (img.width // S, img.height // S)
    out = img.resize(size, Image.LANCZOS)
    os.makedirs(OUT_DIR, exist_ok=True)
    out.save(os.path.join(OUT_DIR, name + ".png"))
    return out


def make_panel():
    w = h = 224
    m = 16
    r = 44
    img = canvas(w, h)
    size = img.size
    box = (m * S, m * S, (w - m) * S - 1, (h - m) * S - 1)
    mask = rr_mask(size, box, r * S)
    drop_shadow(img, mask, 10 * S, 12 * S, 0.5)
    fill(img, mask, [(0, hexc(0x4B31A8, 246)), (1, hexc(0x1B0F4F, 250))], m * S, (h - m) * S)
    gbox = ((m + 5) * S, (m + 5) * S, (w - m - 5) * S - 1, (m + 78) * S)
    gl = rr_mask(size, gbox, (r - 5) * S)
    fill(img, gl, [(0, (255, 255, 255, 54)), (1, (255, 255, 255, 0))], (m + 5) * S, (m + 78) * S)
    rim = ring_mask(size, box, r * S, 2 * S)
    fill(img, rim, [(0, (255, 255, 255, 170)), (1, (255, 255, 255, 36))], m * S, (h - m) * S)
    inner = ring_mask(size, (box[0] + 3 * S, box[1] + 3 * S, box[2] - 3 * S, box[3] - 3 * S), (r - 3) * S, S)
    fill(img, inner, [(0, (255, 255, 255, 26)), (1, (0, 0, 0, 0))], m * S, (h - m) * S)
    save(img, "panel")


def make_pill():
    w, h, m, r = 176, 88, 8, 36
    img = canvas(w, h)
    size = img.size
    box = (m * S, m * S, (w - m) * S - 1, (h - m) * S - 1)
    mask = rr_mask(size, box, r * S)
    drop_shadow(img, mask, 6 * S, 6 * S, 0.45)
    fill(img, mask, [(0, hexc(0x3A2292, 232)), (1, hexc(0x180B45, 238))], m * S, (h - m) * S)
    gl = rr_mask(size, ((m + 4) * S, (m + 3) * S, (w - m - 4) * S - 1, (m + 32) * S), 28 * S)
    fill(img, gl, [(0, (255, 255, 255, 46)), (1, (255, 255, 255, 0))], (m + 3) * S, (m + 32) * S)
    rim = ring_mask(size, box, r * S, 2 * S)
    fill(img, rim, [(0, (255, 255, 255, 120)), (1, (255, 255, 255, 30))], m * S, (h - m) * S)
    save(img, "pill")


def make_chip():
    w, h, r = 128, 64, 28
    img = canvas(w, h)
    size = img.size
    box = (0, 0, w * S - 1, h * S - 1)
    mask = rr_mask(size, box, r * S)
    fill(img, mask, [(0, (255, 255, 255, 40)), (1, (255, 255, 255, 18))], 0, h * S)
    rim = ring_mask(size, box, r * S, 2 * S)
    fill(img, rim, [(0, (255, 255, 255, 70)), (1, (255, 255, 255, 22))], 0, h * S)
    save(img, "chip")


def make_badge():
    w, h, m, r = 192, 76, 6, 32
    img = canvas(w, h)
    size = img.size
    box = (m * S, m * S, (w - m) * S - 1, (h - m - 6) * S - 1)
    mask = rr_mask(size, box, r * S)
    drop_shadow(img, mask, 6 * S, 5 * S, 0.45)
    solid(img, mask, OUTLINE + (255,))
    ibox = (box[0] + 4 * S, box[1] + 4 * S, box[2] - 4 * S, box[3] - 4 * S)
    im = rr_mask(size, ibox, (r - 4) * S)
    fill(img, im, [(0, hexc(0xFFF1A0)), (0.5, hexc(0xFFD04A)), (1, hexc(0xFFA82A))], ibox[1], ibox[3])
    gl = rr_mask(size, (ibox[0] + 4 * S, ibox[1] + 3 * S, ibox[2] - 4 * S, ibox[1] + 24 * S), 18 * S)
    fill(img, gl, [(0, (255, 255, 255, 120)), (1, (255, 255, 255, 0))], ibox[1], ibox[1] + 24 * S)
    save(img, "badge")


BTN_SKINS = {
    "primary": ([(0, hexc(0xFF8FDC)), (0.5, hexc(0xB45CFF)), (1, hexc(0x8B45EE))], (0x4F, 0x25, 0xB0), 190),
    "gold": ([(0, hexc(0xFFEB8A)), (0.5, hexc(0xFFC23C)), (1, hexc(0xFFA61F))], (0xB8, 0x6A, 0x00), 200),
    "mint": ([(0, hexc(0x8CFFE2)), (0.5, hexc(0x36DDBE)), (1, hexc(0x16B8A2))], (0x0B, 0x6D, 0x69), 190),
    "soft": ([(0, hexc(0x5A3FB5)), (1, hexc(0x38227C))], (0x1B, 0x0D, 0x4A), 90),
}


def button_art(face_stops, lip, rim_a, w, h, fx0, fx1, fh, radius, pressed, icon=None):
    img = canvas(w, h)
    size = img.size
    lip_box = (fx0 * S, 4 * S, fx1 * S - 1, (4 + fh + 12) * S - 1)
    lip_mask = rr_mask(size, lip_box, radius * S)
    drop_shadow(img, lip_mask, 8 * S, 7 * S, 0.45)
    solid(img, lip_mask, lip + (255,))
    fy0 = 12 if pressed else 4
    fy1 = fy0 + fh
    face_box = (fx0 * S, fy0 * S, fx1 * S - 1, fy1 * S - 1)
    face_mask = rr_mask(size, face_box, radius * S)
    fill(img, face_mask, face_stops, fy0 * S, fy1 * S)
    gbox = (fx0 * S + 6 * S, fy0 * S + 4 * S, fx1 * S - 6 * S - 1, (fy0 + int(fh * 0.46)) * S)
    gl = rr_mask(size, gbox, int(radius * 0.8) * S)
    fill(img, gl, [(0, (255, 255, 255, 96)), (1, (255, 255, 255, 0))], gbox[1], gbox[3])
    rim = ring_mask(size, face_box, radius * S, 2 * S)
    solid(img, rim, (255, 255, 255, rim_a))
    if icon is not None:
        cx = (fx0 + fx1) / 2.0
        cy = fy0 + fh / 2.0
        draw_icon(img, icon, cx, cy)
    return img


def make_buttons():
    for kind, (stops, lip, rim_a) in BTN_SKINS.items():
        for pressed in (False, True):
            img = button_art(stops, lip, rim_a, 256, 124, 6, 250, 96, 34, pressed)
            save(img, "btn_%s_%s" % (kind, "p" if pressed else "n"))
    stops, lip, rim_a = BTN_SKINS["soft"]
    for icon in ("pause", "home", "retry", "play"):
        for pressed in (False, True):
            img = button_art(stops, lip, rim_a + 40, 112, 120, 8, 104, 96, 34, pressed, icon)
            save(img, "round_%s_%s" % (icon, "p" if pressed else "n"))


def icon_mask(kind, cx, cy, size):
    m = Image.new("L", size, 0)
    d = ImageDraw.Draw(m)
    X = lambda v: (cx + v) * S
    Y = lambda v: (cy + v) * S
    if kind == "pause":
        d.rounded_rectangle((X(-21), Y(-22), X(-7), Y(22)), radius=5 * S, fill=255)
        d.rounded_rectangle((X(7), Y(-22), X(21), Y(22)), radius=5 * S, fill=255)
    elif kind == "play":
        d.polygon([(X(-13), Y(-25)), (X(25), Y(0)), (X(-13), Y(25))], fill=255)
        m = soften(m, 2.2)
    elif kind == "home":
        d.polygon([(X(-31), Y(-1)), (X(0), Y(-28)), (X(31), Y(-1))], fill=255)
        d.rectangle((X(-22), Y(-4), X(22), Y(25)), fill=255)
        d.rectangle((X(-7), Y(8), X(7), Y(25)), fill=0)
        m = soften(m, 1.6)
    elif kind == "retry":
        box = (X(-23), Y(-23), X(23), Y(23))
        d.arc(box, 35, 335, fill=255, width=10 * S)
        th = math.radians(335)
        px, py = cx + 23 * math.cos(th), cy + 23 * math.sin(th)
        tx, ty = -math.sin(th), math.cos(th)
        nx, ny = math.cos(th), math.sin(th)
        tip = (px + tx * 15, py + ty * 15)
        b1 = (px - tx * 3 + nx * 15, py - ty * 3 + ny * 15)
        b2 = (px - tx * 3 - nx * 15, py - ty * 3 - ny * 15)
        d.polygon([(tip[0] * S, tip[1] * S), (b1[0] * S, b1[1] * S), (b2[0] * S, b2[1] * S)], fill=255)
        m = soften(m, 1.2)
    return m


def draw_icon(img, kind, cx, cy):
    m = icon_mask(kind, cx, cy, img.size)
    drop_shadow(img, m, 3 * S, 2 * S, 0.5, color=(20, 6, 60))
    solid(img, m, (255, 255, 255, 255))


def star_mask(size, r, inner=0.5, round_px=3.0):
    m = Image.new("L", (size * S, size * S), 0)
    cx = cy = size * S / 2.0
    pts = []
    for i in range(10):
        rr = r * S * (1.0 if i % 2 == 0 else inner)
        a = -math.pi / 2 + i * math.pi / 5
        pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr + 2 * S))
    ImageDraw.Draw(m).polygon(pts, fill=255)
    return soften(m, round_px)


def make_stars():
    size = 128
    m = star_mask(size, 52)
    out = grow(m, 7)
    on = canvas(size, size)
    drop_shadow(on, out, 4 * S, 4 * S, 0.4)
    solid(on, out, OUTLINE + (255,))
    fill(on, m, [(0, hexc(0xFFF6B0)), (0.55, hexc(0xFFCF3A)), (1, hexc(0xFFA21F))], 12 * S, 116 * S)
    hl = Image.new("L", on.size, 0)
    ImageDraw.Draw(hl).ellipse((46 * S, 40 * S, 62 * S, 50 * S), fill=190)
    hl = ImageChops.multiply(hl.filter(ImageFilter.GaussianBlur(S)), m)
    solid(on, hl, (255, 255, 255, 255))
    save(on, "star_on")
    off = canvas(size, size)
    solid(off, out, (30, 16, 76, 255))
    fill(off, m, [(0, (88, 66, 166, 255)), (1, (58, 40, 124, 255))], 12 * S, 116 * S)
    save(off, "star_off")


def make_trophy():
    size = 64
    m = Image.new("L", (size * S, size * S), 0)
    d = ImageDraw.Draw(m)
    p = lambda pts: [(x * S, y * S) for x, y in pts]
    d.polygon(p([(16, 8), (48, 8), (45, 30), (37, 40), (27, 40), (19, 30)]), fill=255)
    d.ellipse((5 * S, 12 * S, 23 * S, 32 * S), outline=255, width=4 * S)
    d.ellipse((41 * S, 12 * S, 59 * S, 32 * S), outline=255, width=4 * S)
    d.rectangle((28 * S, 38 * S, 36 * S, 48 * S), fill=255)
    d.rounded_rectangle((19 * S, 47 * S, 45 * S, 57 * S), radius=3 * S, fill=255)
    m = soften(m, 1.2)
    out = grow(m, 3)
    img = canvas(size, size)
    solid(img, out, OUTLINE + (255,))
    fill(img, m, [(0, hexc(0xFFF1A0)), (0.5, hexc(0xFFCB3A)), (1, hexc(0xFFA21F))], 6 * S, 58 * S)
    hl = Image.new("L", img.size, 0)
    ImageDraw.Draw(hl).rounded_rectangle((20 * S, 12 * S, 25 * S, 28 * S), radius=2 * S, fill=170)
    hl = ImageChops.multiply(hl.filter(ImageFilter.GaussianBlur(S * 0.6)), m)
    solid(img, hl, (255, 255, 255, 255))
    save(img, "trophy")


def text_layer(text, size, stops, stroke, tracking=0, rim=True, shadow=8):
    f = ImageFont.truetype(FONT, size * S)
    adv = [f.getlength(c) for c in text]
    total = sum(adv) + tracking * S * (len(text) - 1)
    asc, desc = f.getmetrics()
    pad = (stroke + shadow + 10) * S
    W = int(total + pad * 2)
    H = int(asc + desc + pad * 2)

    def mask(sw):
        m = Image.new("L", (W, H), 0)
        d = ImageDraw.Draw(m)
        x = pad
        for c, a in zip(text, adv):
            d.text((x, pad), c, font=f, fill=255, stroke_width=int(sw), anchor="la")
            x += a + tracking * S
        return m

    outer = mask(stroke * S)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    drop_shadow(img, outer, shadow * S, 5 * S, 0.55)
    solid(img, outer, OUTLINE + (255,))
    if rim:
        solid(img, mask(stroke * S * 0.42), (255, 255, 255, 255))
    y0 = int(pad + asc - 0.74 * size * S)
    y1 = int(pad + asc)
    fill(img, mask(0), stops, y0, y1)
    return img


def sparkle(img, cx, cy, r, color=(255, 255, 255, 255)):
    m = Image.new("L", img.size, 0)
    k = 0.2
    pts = [(0, -1), (k, -k), (1, 0), (k, k), (0, 1), (-k, k), (-1, 0), (-k, -k)]
    ImageDraw.Draw(m).polygon([(cx + x * r, cy + y * r) for x, y in pts], fill=255)
    glow = m.filter(ImageFilter.GaussianBlur(r * 0.25))
    layer = Image.new("RGBA", img.size, (255, 240, 200, 0))
    layer.putalpha(glow.point(lambda v: int(v * 0.6)))
    img.alpha_composite(layer)
    solid(img, m, color)


def make_logo():
    uni = text_layer("UNICORN", 112, [(0, (255, 255, 255, 255)), (0.5, (255, 206, 240, 255)), (1, (198, 140, 255, 255))], 11, tracking=5)
    dash = text_layer("DASH", 138, [(0, (255, 246, 170, 255)), (0.55, (255, 200, 70, 255)), (1, (255, 150, 30, 255))], 12, tracking=14)
    W, H = 900 * S, 520 * S
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ux = (W - uni.width) // 2
    img.alpha_composite(uni, (ux, 0))
    dx = (W - dash.width) // 2 + 120 * S
    dy = uni.height - 98 * S
    cyd = dy + dash.height // 2 + 6 * S
    bar_h = 13 * S
    gap = 3 * S
    total_h = 6 * bar_h + 5 * gap
    bar_end = dx + 40 * S
    for k, col in enumerate(RAINBOW):
        length = (250 - k * 12) * S
        bx0 = bar_end - length
        by0 = cyd - total_h // 2 + k * (bar_h + gap)
        m = Image.new("L", (W, H), 0)
        ImageDraw.Draw(m).rounded_rectangle((bx0, by0, bar_end, by0 + bar_h), radius=bar_h // 2, fill=255)
        fade = np.clip((np.arange(W, dtype=np.float32) - bx0) / float(length), 0.0, 1.0) ** 0.9
        fade_img = Image.fromarray((np.tile(fade, (H, 1)) * 255).astype(np.uint8), "L")
        m = ImageChops.multiply(m, fade_img)
        layer = Image.new("RGBA", (W, H), col + (0,))
        layer.putalpha(m)
        img.alpha_composite(layer)
    img.alpha_composite(dash, (dx, dy))
    sparkle(img, ux + 22 * S, 30 * S, 16 * S)
    sparkle(img, ux + uni.width - 30 * S, 14 * S, 22 * S, (255, 236, 150, 255))
    sparkle(img, dx + dash.width - 6 * S, dy + 40 * S, 18 * S)
    sparkle(img, dx + 30 * S, dy + dash.height - 26 * S, 11 * S, (255, 236, 150, 255))
    box = img.getbbox()
    img = img.crop((box[0] - 8 * S, box[1] - 8 * S, box[2] + 8 * S, box[3] + 8 * S))
    save(img, "logo")


def trim(img, margin=6):
    b = img.getbbox()
    return img.crop((b[0] - margin * S, b[1] - margin * S, b[2] + margin * S, b[3] + margin * S))


def make_titles():
    go = text_layer("GAME OVER", 66, [(0, (255, 236, 248, 255)), (1, (255, 128, 200, 255))], 9, tracking=4)
    save(trim(go), "gameover")
    ps = text_layer("PAUSED", 66, [(0, (232, 255, 250, 255)), (1, (110, 226, 255, 255))], 9, tracking=6)
    save(trim(ps), "paused")


def make_glow():
    n = 256
    y, x = np.mgrid[0:n, 0:n].astype(np.float32)
    r = np.sqrt(((x - n / 2) / (n / 2)) ** 2 + ((y - n / 2) / (n / 2)) ** 2)
    a = np.clip(1.0 - r, 0.0, 1.0) ** 2 * 0.62
    arr = np.zeros((n, n, 4), dtype=np.uint8)
    arr[..., 0] = 226
    arr[..., 1] = 200
    arr[..., 2] = 255
    arr[..., 3] = (a * 255).astype(np.uint8)
    os.makedirs(OUT_DIR, exist_ok=True)
    Image.fromarray(arr, "RGBA").save(os.path.join(OUT_DIR, "glow.png"))


def make_vignette():
    w, h = 160, 90
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    r = np.sqrt(((x - w / 2) / (w / 2)) ** 2 + ((y - h / 2) / (h / 2)) ** 2) / 1.414
    t = np.clip((r - 0.5) / 0.55, 0.0, 1.0)
    a = (t * t * (3 - 2 * t)) * 0.62
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    arr[..., 0] = 26
    arr[..., 1] = 8
    arr[..., 2] = 70
    arr[..., 3] = (a * 255).astype(np.uint8)
    Image.fromarray(arr, "RGBA").save(os.path.join(OUT_DIR, "vignette.png"))


if __name__ == "__main__":
    make_panel()
    make_pill()
    make_chip()
    make_badge()
    make_buttons()
    make_stars()
    make_trophy()
    make_logo()
    make_titles()
    make_glow()
    make_vignette()
    print(sorted(os.listdir(OUT_DIR)))
