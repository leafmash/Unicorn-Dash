import hashlib
import os
import random
import sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ALPHA = "abcdefghijklmnopqrstuvwxy012345678"


def template(name, uid, digest):
    return f"""[remap]

importer="texture"
type="CompressedTexture2D"
uid="uid://{uid}"
path="res://.godot/imported/{name}-{digest}.ctex"
metadata={{
"vram_texture": false
}}

[deps]

source_file="res://{{rel}}"
dest_files=["res://.godot/imported/{name}-{digest}.ctex"]

[params]

compress/mode=0
compress/high_quality=false
compress/lossy_quality=0.7
compress/hdr_compression=1
compress/normal_map=0
compress/channel_pack=0
mipmaps/generate=false
mipmaps/limit=-1
roughness/mode=0
roughness/src_normal=""
process/fix_alpha_border=true
process/premult_alpha=false
process/normal_map_invert_y=false
process/hdr_as_srgb=false
process/hdr_clamp_exposure=false
process/size_limit=0
detect_3d/compress_to=1
"""


def main():
    for rel in sys.argv[1:]:
        dst = os.path.join(ROOT, rel + ".import")
        if os.path.exists(dst):
            continue
        name = os.path.basename(rel)
        digest = hashlib.md5(("res://" + rel).encode()).hexdigest()
        rng = random.Random(rel)
        uid = "".join(rng.choice(ALPHA) for _ in range(13))
        text = template(name, uid, digest).replace("{rel}", rel)
        open(dst, "w").write(text)


if __name__ == "__main__":
    main()
