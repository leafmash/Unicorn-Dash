import math
import colorsys
import numpy as np
from PIL import Image, ImageDraw

PI = math.pi
TAU = math.pi * 2.0
G = 290.0
Y0 = -10.0
SS = 3.2


def hs(n):
    v = math.sin(float(n) * 127.1 + 311.7) * 43758.5453
    return v - math.floor(v)


def hsl(h, s, l, a=1.0):
    h = (h % 360.0) / 360.0
    s = max(0.0, min(1.0, s / 100.0))
    l = max(0.0, min(1.0, l / 100.0))
    r, g, b = colorsys.hls_to_rgb(h, l, s)
    return (r * 255.0, g * 255.0, b * 255.0, a)


def rgba(r, g, b, a=1.0):
    return (float(r), float(g), float(b), a)


def hexc(v):
    return ((v >> 16) & 255, (v >> 8) & 255, v & 255, 1.0)


def hue_of(c):
    r, g, b = c[0] / 255.0, c[1] / 255.0, c[2] / 255.0
    return colorsys.rgb_to_hls(r, g, b)[0] * 360.0


class Cv:
    def __init__(self, width, y0=Y0, y1=G + 140.0):
        self.w = width
        self.y0 = y0
        self.y1 = y1
        self.W = int(round(width * SS))
        self.H = int(round((y1 - y0) * SS))
        self.A = np.zeros((self.H, self.W, 4), dtype=np.float32)
        self.fill_c = (0, 0, 0, 1.0)
        self.stroke_c = (0, 0, 0, 1.0)
        self.lw = 1.0
        self.cap = "butt"
        self.dash = None
        self.alpha = 1.0
        self.clip = None
        self.sub = []
        self.cur = None

    def px(self, x, y):
        return ((x) * SS, (y - self.y0) * SS)

    def begin(self):
        self.sub = []
        self.cur = None

    def move(self, x, y):
        self.cur = [(x, y)]
        self.sub.append(self.cur)

    def line(self, x, y):
        if self.cur is None:
            self.move(x, y)
        else:
            self.cur.append((x, y))

    def quad(self, cx, cy, x, y):
        if self.cur is None:
            self.move(cx, cy)
        x0, y0 = self.cur[-1]
        for i in range(1, 11):
            t = i / 10.0
            u = 1.0 - t
            self.cur.append((u * u * x0 + 2 * u * t * cx + t * t * x, u * u * y0 + 2 * u * t * cy + t * t * y))

    def ellipse(self, cx, cy, rx, ry, rot, a0, a1):
        if rx <= 0 or ry <= 0:
            return
        n = max(12, int(max(rx, ry) * SS * 0.8))
        n = min(n, 160)
        pts = []
        for i in range(n + 1):
            t = a0 + (a1 - a0) * i / n
            ex = rx * math.cos(t)
            ey = ry * math.sin(t)
            pts.append((cx + ex * math.cos(rot) - ey * math.sin(rot), cy + ex * math.sin(rot) + ey * math.cos(rot)))
        if self.cur is None:
            self.cur = [pts[0]]
            self.sub.append(self.cur)
        self.cur.extend(pts)

    def arc(self, cx, cy, r, a0, a1):
        self.ellipse(cx, cy, r, r, 0.0, a0, a1)

    def rect(self, x, y, w, h):
        self.cur = [(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)]
        self.sub.append(self.cur)
        self.cur = None

    def disc(self, x, y, r):
        self.move(x + r, y)
        self.arc(x, y, r, 0.0, 7.0)

    def oval(self, x, y, rx, ry):
        self.move(x + rx, y)
        self.ellipse(x, y, rx, ry, 0.0, 0.0, 7.0)

    def tri(self, x, y, h, w):
        self.move(x - w, y)
        self.line(x, y - h)
        self.line(x + w, y)

    def dome(self, x, y, r, k):
        self.move(x - r, y)
        self.ellipse(x, y, r, r * k, 0.0, PI, PI * 2.0)

    def composite(self, mask, ox, oy, col, extra=1.0):
        h, w = mask.shape
        x0, y0 = max(ox, 0), max(oy, 0)
        x1, y1 = min(ox + w, self.W), min(oy + h, self.H)
        if x1 <= x0 or y1 <= y0:
            return
        m = mask[y0 - oy:y1 - oy, x0 - ox:x1 - ox]
        a = m * (col[3] * self.alpha * extra)
        if self.clip is not None:
            cy0, cy1 = self.clip
            ys = np.arange(y0, y1)
            keep = ((ys >= cy0) & (ys < cy1)).astype(np.float32)[:, None]
            a = a * keep
        reg = self.A[y0:y1, x0:x1]
        ia = 1.0 - a
        rgb = np.array(col[:3], dtype=np.float32) / 255.0
        reg[..., :3] = reg[..., :3] * ia[..., None] + rgb * a[..., None]
        reg[..., 3] = reg[..., 3] * ia + a

    def mask_polys(self, polys, bbox_pad=2):
        xs = [p[0] for poly in polys for p in poly]
        ys = [p[1] for poly in polys for p in poly]
        if not xs:
            return None
        x0 = int(math.floor(min(xs))) - bbox_pad
        y0 = int(math.floor(min(ys))) - bbox_pad
        x1 = int(math.ceil(max(xs))) + bbox_pad
        y1 = int(math.ceil(max(ys))) + bbox_pad
        if x1 <= 0 or y1 <= 0 or x0 >= self.W or y0 >= self.H:
            return None
        x0c, y0c = max(x0, 0), max(y0, 0)
        x1c, y1c = min(x1, self.W), min(y1, self.H)
        im = Image.new("L", (x1c - x0c, y1c - y0c), 0)
        d = ImageDraw.Draw(im)
        for poly in polys:
            if len(poly) >= 3:
                d.polygon([(p[0] - x0c, p[1] - y0c) for p in poly], fill=255)
        return np.asarray(im, dtype=np.float32) / 255.0, x0c, y0c

    def fill(self):
        polys = [[self.px(*p) for p in s] for s in self.sub if len(s) >= 3]
        r = self.mask_polys(polys)
        if r is not None:
            self.composite(r[0], r[1], r[2], self.fill_c)

    def fill_rect(self, x, y, w, h):
        self.begin()
        self.rect(x, y, w, h)
        self.fill()

    def stroke_rect(self, x, y, w, h):
        self.begin()
        self.rect(x, y, w, h)
        self.stroke()

    def dashed(self, pts):
        if not self.dash:
            return [pts]
        out = []
        on, off = self.dash
        i = 0
        cur = [pts[0]]
        draw = True
        remain = on
        for j in range(1, len(pts)):
            ax, ay = pts[j - 1]
            bx, by = pts[j]
            seg = math.hypot(bx - ax, by - ay)
            pos = 0.0
            while seg - pos > remain:
                pos += remain
                f = pos / seg if seg > 0 else 0
                p = (ax + (bx - ax) * f, ay + (by - ay) * f)
                if draw:
                    cur.append(p)
                    out.append(cur)
                    cur = []
                else:
                    cur = [p]
                draw = not draw
                remain = on if draw else off
            remain -= seg - pos
            if draw:
                cur.append((bx, by))
        if draw and len(cur) > 1:
            out.append(cur)
        return out

    def stroke(self):
        hw = self.lw / 2.0
        polys = []
        for s in self.sub:
            if len(s) < 2:
                continue
            for pts in self.dashed(s):
                if len(pts) < 2:
                    continue
                n = len(pts)
                for i in range(n - 1):
                    ax, ay = pts[i]
                    bx, by = pts[i + 1]
                    dx, dy = bx - ax, by - ay
                    ln = math.hypot(dx, dy)
                    if ln < 1e-6:
                        continue
                    nx, ny = -dy / ln * hw, dx / ln * hw
                    polys.append([self.px(ax + nx, ay + ny), self.px(bx + nx, by + ny), self.px(bx - nx, by - ny), self.px(ax - nx, ay - ny)])
                round_pts = pts[1:-1]
                if self.cap == "round":
                    round_pts = pts
                if hw > 1.2 or self.cap == "round":
                    for (cx, cy) in round_pts:
                        k = 10
                        polys.append([self.px(cx + hw * math.cos(i * TAU / k), cy + hw * math.sin(i * TAU / k)) for i in range(k)])
        r = self.mask_polys(polys)
        if r is not None:
            self.composite(r[0], r[1], r[2], self.stroke_c)

    def halo(self, x, y, r, h, s, l, a):
        if a <= 0 or r <= 0:
            return
        n = int(math.ceil(r * 2 * SS))
        yy, xx = np.mgrid[0:n, 0:n].astype(np.float32)
        d = np.hypot(xx - n / 2.0 + 0.5, yy - n / 2.0 + 0.5) / (n / 2.0)
        m = np.where(d < 0.35, 1.0 - 0.6 * d / 0.35, np.where(d < 1.0, 0.4 * (1.0 - (d - 0.35) / 0.65), 0.0)).astype(np.float32)
        c = hsl(h, s, l, min(1.0, a))
        px, py = self.px(x - r, y - r)
        self.composite(m, int(round(px)), int(round(py)), c)

    def result(self):
        a = self.A
        h2, w2 = self.H // 2 * 2, self.W // 2 * 2
        a = a[:h2, :w2].reshape(h2 // 2, 2, w2 // 2, 2, 4).mean(axis=(1, 3))
        alpha = a[..., 3]
        rgb = np.where(alpha[..., None] > 1e-5, a[..., :3] / np.maximum(alpha[..., None], 1e-5), 0.0)
        out = np.concatenate([np.clip(rgb, 0, 1), np.clip(alpha[..., None], 0, 1)], axis=2)
        return (out * 255.0 + 0.5).astype(np.uint8)
