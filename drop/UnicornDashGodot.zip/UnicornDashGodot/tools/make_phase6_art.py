import math
import os

from PIL import Image, ImageDraw, ImageFont

from make_phase2_art import D, OUT, star_points
from make_phase3_art import badge, FONT


def make_mini():
    d = D(128, 128)
    badge(d, (190, 120, 255, 150))
    d.ell(64, 64, 34, 34, fill=(236, 214, 255, 255), outline=(255, 255, 255, 255), width=3)
    for sx in (-1, 1):
        d.poly([(64 + sx * 40, 64), (64 + sx * 22, 54), (64 + sx * 22, 74)], fill=(120, 60, 220, 255), outline=(255, 255, 255, 255), width=2)
    d.ell(64, 64, 11, 11, fill=(150, 80, 240, 255), outline=(255, 255, 255, 255), width=2)
    d.save("pu_mini.png")


def make_star():
    d = D(128, 128)
    badge(d, (255, 214, 74, 160))
    p = star_points(64, 66, 40, 17)
    d.grad_poly(p, (255, 236, 130), (255, 176, 40))
    d.poly(p, outline=(255, 255, 255, 255), width=4)
    d.ell(56, 52, 6, 4, fill=(255, 255, 255, 170))
    d.save("pu_star.png")


def make_sx2():
    d = D(128, 128)
    badge(d, (110, 230, 150, 150))
    d.rrect(26, 38, 102, 90, 14, fill=(80, 210, 130, 255), outline=(235, 255, 240, 255), width=4)
    d.save("pu_sx2.png")
    base = Image.open(os.path.join(OUT, "pu_sx2.png")).convert("RGBA")
    dr = ImageDraw.Draw(base)
    font = ImageFont.truetype(FONT, 40)
    box = dr.textbbox((0, 0), "x2", font=font)
    dr.text((64 - (box[2] - box[0]) / 2 - box[0], 64 - (box[3] - box[1]) / 2 - box[1]), "x2", font=font, fill=(10, 70, 40, 255))
    sp = star_points(94, 38, 11, 5)
    d2 = ImageDraw.Draw(base)
    d2.polygon(sp, fill=(255, 226, 90, 255), outline=(255, 255, 255, 255))
    base.save(os.path.join(OUT, "pu_sx2.png"))


def make_rain():
    d = D(128, 128)
    badge(d, (120, 230, 200, 150))
    for cx, cy in ((42, 46), (86, 52), (62, 86)):
        d.line([(cx, cy - 22), (cx, cy - 10)], fill=(255, 240, 160, 150), width=4)
        d.ell(cx, cy, 14, 14, fill=(255, 210, 70, 255), outline=(255, 247, 205, 255), width=3)
        d.ell(cx, cy, 8, 8, outline=(230, 160, 30, 255), width=2)
    d.save("pu_rain.png")


def wing_pts(w, h):
    return [(8, h - 10), (w * 0.12, h * 0.55), (w * 0.34, h * 0.2), (w * 0.62, 6), (w - 8, h * 0.16), (w * 0.84, h * 0.42), (w * 0.9, h * 0.62), (w * 0.7, h * 0.58), (w * 0.74, h * 0.8), (w * 0.52, h * 0.7), (w * 0.5, h * 0.92), (w * 0.3, h * 0.78), (w * 0.2, h - 6)]


def make_wings_icon():
    d = D(128, 128)
    badge(d, (190, 150, 255, 150))
    p = [(34 + (x / 256.0) * 60, 36 + (y / 192.0) * 56) for x, y in wing_pts(256, 192)]
    d.grad_poly(p, (255, 255, 255), (200, 180, 255))
    d.poly(p, outline=(255, 255, 255, 255), width=3)
    d.save("pu_wings.png")


def make_wings_fx():
    d = D(256, 192)
    p = wing_pts(256, 192)
    d.glow(6, lambda t: t.poly(p, fill=(200, 170, 255, 120)))
    d.grad_poly(p, (255, 255, 255), (214, 196, 255))
    d.poly(p, outline=(255, 255, 255, 255), width=4)
    for tip in ((150, 52), (190, 78), (214, 112)):
        d.line([(30, 180), tip], fill=(190, 168, 240, 160), width=3)
    d.save("fx_wings.png")


def main():
    make_mini()
    make_star()
    make_sx2()
    make_rain()
    make_wings_icon()
    make_wings_fx()


if __name__ == "__main__":
    main()
