extends Node2D

const Cp := preload("res://cp_kit.gd")
const U := 1.6
const G := 290.0

var m
var amb: Array = []


func setup(main: Node) -> void:
	m = main
	for i in 38:
		amb.append({"x": randf() * 800.0, "y": randf() * G, "z": 0.35 + randf() * 0.65, "ph": randf() * 9.0})


func lw() -> float:
	return get_viewport_rect().size.x / U


func step(dt: float) -> void:
	if m.zk.is_empty():
		return
	var mode: int = m.zk[m.zone]["fx"]
	var clock: float = m.run_time
	var run := 130.0
	if m.state == m.State.PLAYING:
		run = m.speed / U
	elif m.state == m.State.WIN:
		run = m.speed * 0.6 / U
	var l := lw()
	for a in amb:
		var z: float = a["z"]
		var ph: float = a["ph"]
		a["x"] -= run * 0.22 * z * dt
		match mode:
			0:
				a["y"] -= 10.0 * z * dt
				a["x"] += sin(clock * 0.8 + ph) * 8.0 * dt
			1:
				a["y"] += 26.0 * z * dt
				a["x"] += sin(clock * 1.2 + ph) * 22.0 * dt
			2:
				a["y"] += sin(clock * 0.9 + ph) * 12.0 * dt
				a["x"] += cos(clock * 0.7 + ph) * 10.0 * dt
			3:
				a["y"] += 38.0 * z * dt
				a["x"] += sin(clock + ph) * 14.0 * dt - 18.0 * dt
			4:
				a["x"] -= run * 0.5 * z * dt
				a["y"] += sin(clock * 2.0 + ph) * 6.0 * dt
			6:
				a["y"] -= (14.0 + 16.0 * z) * dt
				a["x"] += sin(clock * 1.4 + ph) * 10.0 * dt
			7:
				a["y"] += 30.0 * z * dt
				a["x"] += sin(clock * 1.6 + ph) * 26.0 * dt - 16.0 * dt
			8:
				a["y"] += 230.0 * z * dt
			9:
				a["y"] += sin(clock * 0.5 + ph) * 5.0 * dt
				a["x"] += cos(clock * 0.4 + ph) * 6.0 * dt
			10:
				a["y"] += sin(clock * 0.7 + ph) * 6.0 * dt
			11, 12:
				a["y"] -= 12.0 * z * dt
				a["x"] += sin(clock + ph) * 10.0 * dt
			_:
				a["y"] -= 34.0 * z * dt
				a["x"] += sin(clock * 2.0 + ph) * 16.0 * dt
		if a["x"] < -20.0:
			a["x"] = l + 20.0
		if a["x"] > l + 40.0:
			a["x"] = -10.0
		if a["y"] > G - 4.0:
			a["y"] = -8.0
		if a["y"] < -10.0:
			a["y"] = G - 6.0


func halo(c: Vector2, r: float, col: Color) -> void:
	draw_texture_rect(Cp.halo_tex(), Rect2(c * U - Vector2(r, r) * U, Vector2(r, r) * 2.0 * U), false, col)


func dash_on() -> bool:
	return m.state == m.State.PLAYING and m.star_t > 0.0


func _process(delta: float) -> void:
	visible = not (m.state == m.State.MENU and m.screen == "home")
	if not visible or m.state == m.State.PAUSED:
		return
	step(delta)
	queue_redraw()


func _draw() -> void:
	if m == null or m.zk.is_empty():
		return
	var z: Dictionary = m.zk[m.zone]
	var mode: int = z["fx"]
	var clock: float = m.run_time
	var hue: float = z["hue"]
	for a in amb:
		var ax: float = a["x"]
		var ay: float = a["y"]
		var az: float = a["z"]
		var ph: float = a["ph"]
		var fl := 0.5 + 0.5 * sin(clock * 3.0 + ph * 5.0)
		var p := Vector2(ax, ay)
		match mode:
			0:
				halo(p, 5.0 * az + 2.0, m.hsl(48.0, 100.0, 78.0, 0.35 + 0.35 * fl))
			1:
				var rx := (4.0 * az + 1.0) * U
				var ry := (2.0 * az + 0.8) * U
				draw_set_transform(p * U, clock * 1.5 + ph, Vector2(rx, ry))
				draw_circle(Vector2.ZERO, 1.0, Color(1.0, 200.0 / 255.0, 225.0 / 255.0, 0.85))
				draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			2:
				halo(p, 9.0 * az + 3.0, m.hsl(62.0, 100.0, 70.0, 0.3 + 0.6 * fl))
			3:
				draw_circle(p * U, (1.2 + 1.6 * az) * U, Color(1, 1, 1, 0.5 + 0.4 * az))
			4:
				halo(p, 8.0 * az + 2.0, m.hsl(32.0, 70.0, 80.0, 0.18 * az))
			6:
				draw_arc(p * U, (2.0 + 4.0 * az) * U, 0.0, TAU, 14, Color(210.0 / 255.0, 245.0 / 255.0, 1.0, 0.35 + 0.4 * az), 1.1 * U, true)
				draw_rect(Rect2((p + Vector2(-1.0, -2.2 * az - 1.0)) * U, Vector2(1.4, 1.4) * U), Color(1, 1, 1, 0.6))
			7:
				var rx7 := (4.5 * az + 1.5) * U
				var ry7 := (2.4 * az + 0.8) * U
				draw_set_transform(p * U, clock * 1.8 + ph, Vector2(rx7, ry7))
				draw_circle(Vector2.ZERO, 1.0, m.hsl(hue + fposmod(ph * 7.0, 36.0), 85.0, 55.0, 0.9))
				draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			8:
				var hh := hue + 160.0 if ph > 4.5 else hue
				draw_line(p * U, (p + Vector2(-1.5, 6.0 + 8.0 * az)) * U, m.hsl(hh, 100.0, 66.0, 0.35 + 0.4 * az), 1.2 * U, true)
			9:
				halo(Vector2(ax, ay * 0.6 + 90.0), 34.0 * az + 14.0, m.hsl(hue, 30.0, 78.0, 0.06 + 0.05 * fl))
			10:
				halo(p, 5.0 * az + 2.0, m.hsl(hue, 100.0, 86.0, 0.3 + 0.6 * fl))
			11:
				halo(p, 6.0 * az + 2.0, m.hsl(hue, 100.0, 72.0, 0.35 + 0.5 * fl))
			12:
				halo(p, 6.0 * az + 2.0, m.hsl(fposmod(clock * 60.0 + ph * 40.0, 360.0), 100.0, 72.0, 0.35 + 0.5 * fl))
			_:
				halo(p, 6.0 * az + 2.0, m.hsl(22.0, 100.0, 60.0, 0.35 + 0.5 * fl))
	if dash_on():
		var l := lw()
		var col := Color(1, 1, 1, 0.35)
		for i in 12:
			var lx := l - fposmod(clock * 1100.0 + float(i) * 97.0, l + 120.0) + 60.0
			var ly := 30.0 + float((i * 53) % 250)
			draw_line(Vector2(lx, ly) * U, Vector2(lx + 46.0, ly) * U, col, 1.6 * U, true)
